//
//  Double+Extension.swift
//  NewGCB
//
//  Created by YTKJ on 2020/1/20.
//  Copyright © 2020 YTKJ. All rights reserved.
//

import Foundation
extension Double{
    
   func roundTo(places:Int) -> Double {

          let divisor = pow(10, Double(places))

          return (self * divisor).rounded() / divisor

      }
    

}
