//
//  UIView+extension.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/4.
//  Copyright © 2019 YTKJ. All rights reserved.
//
import Foundation


extension UIView{
    
    //给view添加单机事件
    func addSingleClick(target:Any,action:Selector) {
        self.isUserInteractionEnabled=true
        let tap = UITapGestureRecognizer()
        tap.numberOfTapsRequired=1
        tap.addTarget(target, action: action)
        self.addGestureRecognizer(tap)
    }
    
    func makeToastTop(message:String?) {
        guard let msg = message else { return }
        self.makeToast(msg, duration: 1.5, position: "CSToastPositionTop")
    }

    func makeToastMid(message:String?) {
        guard let msg = message else { return }
        self.makeToast(msg, duration: 1.5, position: "CSToastPositionCenter")
    }
    
   
}
