//
//  Date+extension.swift
//  GCB
//
//  Created by YTKJ on 2018/7/11.
//  Copyright © 2018年 YTKJ. All rights reserved.
//

import Foundation
extension Date {

    
    //计算两个日期相差天数
    func daysBetweenDate(toDate: Date) -> Int {
        let components = Calendar.current.dateComponents([.day], from: self, to: toDate)
        return components.day ?? 0
    }
    
    
    func getDateStr() ->String {
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy-MM-dd HH:mm:ss"
        return dateFmt.string(from: self as Date)
    }
    
    
    func strToDate(item:String) -> Date {
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy-MM-dd"
        let date = dateFmt.date(from: item)
        return date!
    }
    
    func dateToDate() -> Date {
        let date = Date()
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy-MM-dd"
        let str = dateFmt.string(from: date)
        let date1 = dateFmt.date(from: str)
        return date1!
    }
    
    
    func updateDateStr(item:String) -> String {
        
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy-MM-dd HH:mm"
        let date = dateFmt.date(from: item)
        let dateFmt1 = DateFormatter()
        dateFmt1.dateFormat = "MM/dd HH:mm"
        let ss = dateFmt1.string(from: date!)
        return ss
    }
    
    //获取本年开始
    func startOfCurrentYear() -> Date {
        let date = Date()
        let calendar = NSCalendar.current
        let components = calendar.dateComponents(Set<Calendar.Component>([.year]), from: date)
        let startOfYear = calendar.date(from: components)!
        return startOfYear
    }
    //当月第一天日期
    func startOfMonth(year: Int, month: Int) -> Date {
        let calendar = NSCalendar.current
        var startComps = DateComponents()
        startComps.day = 1
        startComps.month = month
        startComps.year = year
        let startDate = calendar.date(from: startComps)!
        return startDate
    }
    
    
    //获取当前年
    func getYear() ->String {
        let date = Date()
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy年"
        return dateFmt.string(from: date)
    }
    
    
    //获取当前月
    func getMonth() ->String {
        let date = Date()
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy/MM"
        return dateFmt.string(from:date)
    }
    
    //获取当前天
    func getDay() ->String{
        let date = Date()
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy/MM/dd"
        return dateFmt.string(from: date)
    }
    
    func getDayService() ->String{
        let date = Date()
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy-MM-dd HH:mm"
        return dateFmt.string(from: date)
    }
    
    func getLastWeekService() -> String{
        let date = Date()
        let timeS:TimeInterval = 24*60*60*6
        let nowTimeS:TimeInterval = date.timeIntervalSince1970
        let totalTime :TimeInterval = nowTimeS - timeS
        let needDate :Date  = Date.init(timeIntervalSince1970: totalTime)
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy-MM-dd HH:mm"
        return  dateFmt.string(from: needDate)
    }
        
    func getThreeDaykService() -> String{
        let date = Date()
        let timeS:TimeInterval = 24*60*60*2
        let nowTimeS:TimeInterval = date.timeIntervalSince1970
        let totalTime :TimeInterval = nowTimeS - timeS
        let needDate :Date  = Date.init(timeIntervalSince1970: totalTime)
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy-MM-dd HH:mm"
        return  dateFmt.string(from: needDate)
    }
    
    func getLastWeekDate() -> String{
        let date = Date()
        let timeS:TimeInterval = 24*60*60*6
        let nowTimeS:TimeInterval = date.timeIntervalSince1970
        let totalTime :TimeInterval = nowTimeS - timeS
        let needDate :Date  = Date.init(timeIntervalSince1970: totalTime)
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy/MM/dd"
        return  dateFmt.string(from: needDate) + "-" + dateFmt.string(from: date)
    }
    //获取每天0点的时间
    func getMorningDate(date:Date) -> String{
        let calendar = NSCalendar.init(identifier: .chinese)
        let components = calendar?.components([.year,.month,.day], from: date)
        let date = calendar?.date(from: components!)
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy-MM-dd HH:mm"
        return  dateFmt.string(from: date!)
//        return (calendar?.date(from: components!))!
    }
    
    
    
    func getStartOfWeek(date:Date) -> String{
        let calendar = NSCalendar.current
        let components = calendar.dateComponents([.year, .month, .day, .weekday], from: date)
        let weekDay = components.weekday
        let day = components.day
        var  firstFif:Int?
     
        if weekDay == 1 {
        
           firstFif = -6
        }else {
            firstFif = calendar.firstWeekday - weekDay! + 1
         
        }
        var firstDayComponent =  calendar.dateComponents([.year,.month,.day], from: date)
        firstDayComponent.day = firstFif! + day!
        let firstDayWeekDate = calendar.date(from:firstDayComponent)
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy-MM-dd"
        return  dateFmt.string(from: firstDayWeekDate!)
    }
    
    
    func getShowDateStr() ->String {
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy/MM/dd"
        return dateFmt.string(from: self as Date)
    }
    
    func getStartOfShowWeek(date:Date) -> String{
        let calendar = NSCalendar.current
        let components = calendar.dateComponents([.year, .month, .day, .weekday], from: date)
        let weekDay = components.weekday
        let day = components.day
        var  firstFif:Int?
    
        if weekDay == 1 {
          
            firstFif = -6
        }else {
            firstFif = calendar.firstWeekday - weekDay! + 1
       
        }
        var firstDayComponent =  calendar.dateComponents([.year,.month,.day], from: date)
        firstDayComponent.day = firstFif! + day!
        let firstDayWeekDate = calendar.date(from:firstDayComponent)
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy/MM/dd"
        return  dateFmt.string(from: firstDayWeekDate!)
    }
    
    
    //本年开始日期
    func startOfCurrentYear(date:Date) -> Date {
        let calendar = NSCalendar.current
        let components = calendar.dateComponents(Set<Calendar.Component>([.year]), from: date)
        let startOfYear = calendar.date(from: components)!
        return startOfYear
    }
    //本月开始日期
    func startOfCurrentMonth(date:Date) -> String{
        let calendar = NSCalendar.current
        let components = calendar.dateComponents(
            Set<Calendar.Component>([.year, .month]), from: date)
        let startOfMonth = calendar.date(from: components)!
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy-MM-dd HH:mm:ss"
        return  dateFmt.string(from: startOfMonth)
//        return startOfMonth
    }
}
