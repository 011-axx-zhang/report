//
//  String+extension.swift
//  GCB
//
//  Created by YTKJ on 2018/7/3.
//  Copyright © 2018年 YTKJ. All rights reserved.
//

import Foundation
extension String{
    
    func transformToPinYin() -> String {
        let mutableString = NSMutableString(string: self)
        //把汉字转为拼音
        CFStringTransform(mutableString, nil, kCFStringTransformToLatin, false)
        //去掉拼音的音标
        CFStringTransform(mutableString, nil, kCFStringTransformStripDiacritics, false)
        let string = String(mutableString)
        //去掉空格
        return string.replacingOccurrences(of: " ", with: "")
    }
    
    func textSize(font:UIFont,size:CGSize=CGSize.zero) -> CGSize {
        var textSize:CGSize!
        if size==CGSize.zero {
            textSize=(self as NSString).size(withAttributes: [NSAttributedString.Key.font:font])
        }else{
            textSize=(self as NSString).boundingRect(with: size, options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font:font], context: nil).size
        }
        return textSize
    }
    
    func nsRange(from range: Range<String.Index>) -> NSRange? {
        let utf16view = self.utf16
        if let from = range.lowerBound.samePosition(in: utf16view), let to = range.upperBound.samePosition(in: utf16view) {
            return NSMakeRange(utf16view.distance(from: utf16view.startIndex, to: from), utf16view.distance(from: from, to: to))
        }
        return nil
        
    }
    
}
