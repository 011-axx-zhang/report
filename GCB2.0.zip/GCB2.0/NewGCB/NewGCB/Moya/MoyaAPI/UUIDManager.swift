//
//  UUIDManager.swift
//  UUIDTest
//
//  Created by YTKJ on 2018/12/18.
//  Copyright © 2018年 YTKJ. All rights reserved.
//

import Foundation
import UIKit

private var UUID : NSString?

public func getUUID()->String{
    
    
    let UUIDDate = SSKeychain.passwordData(forService: "com.magic.bang", account: "com.magic.bang")
    
    
    if UUIDDate != nil{
        
        UUID = NSString(data: UUIDDate!, encoding: String.Encoding.utf8.rawValue)
    }
    
    
    if(UUID == nil){

        UUID = UIDevice.current.identifierForVendor!.uuidString as NSString

        SSKeychain.setPassword(UUID! as String, forService: "com.magic.bang", account: "com.magic.bang")

    }
    
    return UUID! as String
    
}


