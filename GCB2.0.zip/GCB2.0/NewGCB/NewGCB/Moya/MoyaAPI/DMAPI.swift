//  moya的一个具体的接口实现

import Foundation
import Moya

enum  DMAPI {
    //
    case homeVehicle(param:Dictionary<String,Any>)
    case login(param:Dictionary<String,Any>)
    case getVersion(param:Dictionary<String,Any>)
    ///其他接口...
    case other2
}


// 补全【MoyaConfig 3：配置TargetType协议可以一次性处理的参数】中没有处理的参数
extension DMAPI: TargetType {
    //1. 每个接口的相对路径
    //请求时的绝对路径是   baseURL + path
    var path: String {
        switch self {
        case .homeVehicle( _):
            return "getVehicles"
        case .login( _):
            return "/user/login"
        case .getVersion( _):
            return "/getVersion"
        case .other2:
            return ""
        }
    }
    

    var baseURL: URL {
        //  域名
        //  newgcb.56matrix.com
        
         return URL(string: "http://appversion.56matrix.com")!
       // return URL(string: "http://192.168.11.42:3023")!
    }

    //2. 每个接口要使用的请求方式
    var method: Moya.Method {
        switch self {
        case .homeVehicle( _):
            return .get
        case .login(param: _):
            return .post
        case .getVersion(param: _):
            return .get
        case .other2:
            return .get
       
        }
    }

    //3. Task是一个枚举值，根据后台需要的数据，选择不同的http task。
    var task: Task {
        var params: [String: Any] = [:]
        switch self {
        case .homeVehicle(let dic),.login(param: let dic),.getVersion(param: let dic):
           params = dic
        default:
            //不需要传参数的接口走这里
            return .requestPlain
        }
        
        return  .requestParameters(parameters: params, encoding: URLEncoding.default)
      
    }
    
}
