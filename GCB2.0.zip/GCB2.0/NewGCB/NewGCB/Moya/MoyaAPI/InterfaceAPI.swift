//
//  InterfaceAPI.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/17.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import Moya
import Foundation

enum  InterfaceAPI {
    
    //获取验证码
    case getVerCode(param:Dictionary<String,Any>)
    //登录
    case login(param:Dictionary<String,Any>)
    // 获取用户信息
    case getUserInfo
    //通知设置
    case notiSet(param:Dictionary<String,Any>)
    // 筛选,获取名下组织和车队
    case getOrgsAndVehGroups
    
    case homeVehicle(param:Dictionary<String,Any>)
    
    //首页司机
    case focusDriver(param:Dictionary<String,Any>)
    
    //关注车辆
    case focusVeh(param:Dictionary<String,Any>)
    
    //企业运营报告基本信息
    case getEnterpriseInfo(param:Dictionary<String,Any>)
    
    //获取企业运营报告
    case getEnterpriseReport(param:Dictionary<String,Any>)
    
    //车辆管理 获取车辆管理报表
    case getVehReport(param:Dictionary<String,Any>)
    //车辆档案(车辆安全运营报告) 基本信息
    case getVehInfo(param:Dictionary<String,Any>)
    
    //车辆档案(车辆安全运营报告) 报告 GET
    case getVehRunningReport(param:Dictionary<String,Any>)
    
    //车辆档案(车辆安全运营报告) 历史路径 GET
    case playback(param:Dictionary<String,Any>)
    
    //车辆档案(车辆安全运营报告) 车辆定位,最新车况 GET
    case getVehCondition(param:Dictionary<String,Any>)
    
    case getVehRunningRate(param:Dictionary<String,Any>)
    
    //获取司机列表
    case getDriverListData(param:Dictionary<String,Any>)
    //获取司机基本信息
    case getDriverInfo(param:Dictionary<String,Any>)
    //获取司机安全运营档案
    case getDriverReport(param:Dictionary<String,Any>)
    //获取通知-风险事件列表
    case getNotificationEvents(param:Dictionary<String,Any>)
    //获取通知-风险事件-筛选条件
    case getNotificationEventFilter
    //获取通知-风险事件详情
    case getNotificationEventDetail(param:Dictionary<String,Any>)
    //获取通知-交通违章列表
    case getNotificationViolateRules(param:Dictionary<String,Any>)
    //获取通知-交通违章详情表
    case getNotificationViolateRuleDetail(param:Dictionary<String,Any>)
    //获取通知-事故列表
    case getNotificationAccidents(param:Dictionary<String,Any>)
    //获取通知-事故详情
    case getNotificationAccidentDetail(param:Dictionary<String,Any>)
    //获取通知-维保列表
    case getNotificationMaintenances(param:Dictionary<String,Any>)
    //获取通知-维保详情
    case getNotificationMaintenance(param:Dictionary<String,Any>)
    //获取通知-保险到期列表
    case getNotificationInsuranceWarns(param:Dictionary<String,Any>)
    //获取通知-保险到期详情
    case getNotificationInsuranceWarn(param:Dictionary<String,Any>)
    
    case pushTokenBind(param:Dictionary<String,Any>)
    
    case pushTokenUnbind(param:Dictionary<String,Any>)
    
    
    case other1(param: String)

}

// 补全【MoyaConfig 3：配置TargetType协议可以一次性处理的参数】中没有处理的参数
extension InterfaceAPI: TargetType {
    

    var baseURL: URL {
       // return URL(string: "http://192.168.11.42:3043")!
        return URL(string: "http://newgcb.56matrix.com")!
   
    }
    
    //1. 每个接口的相对路径
    //请求时的绝对路径是   baseURL + path
    var path: String {
        switch self {
        //获取验证码
        case .getVerCode( _):
            return "/user/getVerCode"
        //登录
        case .login( _):
            return "/user/login"
        // 获取用户信息
        case .getUserInfo:
            return "/user/getUserInfo"
        case .getOrgsAndVehGroups:
            return "/screen/getOrgsAndVehGroups"
        case .notiSet( _):
            return "/notification/notificationSet"
        case .homeVehicle( _):
            return   "/vehicle/getVehs"
        case .focusDriver( _):
            return "/follow/focusDriver"
        case .focusVeh( _):
            return "/follow/focusVeh"
            
        //企业运营报告基本信息
        case .getEnterpriseInfo( _):
            return "/company/getEnterpriseInfo"
        //获取企业运营报告
        case .getEnterpriseReport( _):
            return "/company/getEnterpriseReport"
        //车辆管理 获取车辆管理报表
        case .getVehReport( _):
            return "/vehicle/getVehReport"
        case .getVehInfo( _):
            return "/vehicle/getVehInfo"
        case .getVehRunningReport( _):
            return "/vehicle/getVehRunningReport"
        case .playback( _):
            return "/vehicle/getVehHisTrack"
        case .getVehCondition( _):
            return "/vehicle/getVehCondition"
        case .getVehRunningRate( _):
            return "/vehicle/getVehRunningRate"
        case .getDriverListData( _):
            return "driver/getDrivers"
        case .getDriverInfo( _):
            return "driver/getDriverInfo"
        case .getDriverReport( _):
            return "driver/getDriverReport"
        case .getNotificationEvents( _):
            return "base/event/getNotificationEvents"
        case .getNotificationEventFilter:
            return "base/PolicyRule/getNotificationEventFilter"
        case .getNotificationEventDetail( _):
            return "base/event/getNotificationEventDetail"
        case .getNotificationViolateRules( _):
            return "custom/customVolationRecord/getNotificationViolateRules"
        case .getNotificationViolateRuleDetail( _):
            return "custom/customVolationRecord/getNotificationViolateRuleDetail"
        case .getNotificationAccidents( _):
            return "custom/accident/getNotificationAccidents"
        case .getNotificationAccidentDetail( _):
            return "custom/accident/getNotificationAccidentDetail"
        case .getNotificationMaintenances( _):
            return "custom/customMaintenanceRecord/getNotificationMaintenances"
        case .getNotificationMaintenance( _):
            return "custom/customMaintenanceRecord/getNotificationMaintenance"
        case .getNotificationInsuranceWarns( _):
            return "custom/customInsurance/getNotificationInsuranceWarns"
        case .getNotificationInsuranceWarn( _):
            return "custom/customInsurance/getNotificationInsuranceWarn"
        case .pushTokenBind( _):
            return "/deviceMsg/pushTokenBind"
        case .pushTokenUnbind( _):
            return "/deviceMsg/pushTokenUnbind"
            
        case .other1:
            return ""
        }
    }

    //2. 每个接口要使用的请求方式
    var method: Moya.Method {
        switch self {
        case .getVerCode( _),.getUserInfo,.getOrgsAndVehGroups,.homeVehicle( _),.focusDriver( _),.focusVeh( _),.playback(param: _),.getEnterpriseInfo( _),.getEnterpriseReport( _),.getVehReport( _),.getVehInfo( _),.getVehRunningReport( _),.getVehCondition( _),.getVehRunningRate( _),.getDriverListData( _),.getDriverInfo( _),.getDriverReport( _),.getNotificationEvents( _),.getNotificationEventFilter,.getNotificationEventDetail( _),.getNotificationViolateRules( _),.getNotificationViolateRuleDetail( _),.getNotificationAccidents( _),.getNotificationAccidentDetail( _),.getNotificationMaintenances( _),.getNotificationMaintenance( _),.getNotificationInsuranceWarns( _),.getNotificationInsuranceWarn( _):
            return .get
        case .login(param: _),.notiSet(param: _),.pushTokenUnbind(param: _),.pushTokenBind(param: _):
            return .post
        case .other1( _):
            return .get
        }
    }

    
    
    
    //3. Task是一个枚举值，根据后台需要的数据，选择不同的http task。
    var task: Task {
        var params: [String: Any] = [:]
        switch self {
        case .getVerCode(let dic),.homeVehicle(let dic),.focusDriver(let dic),.focusVeh(let dic),.playback(let dic),.getEnterpriseInfo( let dic),.getEnterpriseReport(let dic),.getVehReport(let dic),.getVehInfo(let dic),.getVehRunningReport(let dic),.getVehCondition(let dic),.getVehRunningRate( let dic),.getDriverListData( let dic),.getDriverInfo( let dic),.getDriverReport( let dic),.getNotificationEvents( let dic),.getNotificationEventDetail( let dic),.getNotificationViolateRules( let dic),.getNotificationViolateRuleDetail( let dic),.getNotificationAccidents( let dic),.getNotificationAccidentDetail( let dic),.getNotificationMaintenances( let dic),.getNotificationMaintenance( let dic),.getNotificationInsuranceWarns( let dic),.getNotificationInsuranceWarn( let dic):
           params = dic
        case .login(param: let dic),.notiSet(param: let dic),.pushTokenUnbind(param: let dic),.pushTokenBind(param: let dic):
             params = dic
            return .requestParameters(parameters: params, encoding: JSONEncoding.default)
        default:
            //不需要传参数的接口走这里
            return .requestPlain
        }
        return .requestParameters(parameters: params, encoding: URLEncoding.default)
    
    }
    
}
