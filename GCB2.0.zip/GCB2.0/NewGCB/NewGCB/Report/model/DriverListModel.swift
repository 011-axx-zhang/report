//
//  DriverListModel.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/31.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class DriverListModel: NSObject,HandyJSON {
    var age : Int!
    var company : String!
    var id : Int64!
    var isFocused : Bool!
    var latestAttendDate : String!
    var licenseUrl : String!
    var milsToday : Float!
    var name : String!
    var driverurl : String!
    var orgName : String!
    var phone : String!
    var riskHighCount : Int!
    var riskMiddleCount : Int!
    var safeCreditIndex : Int!
    
    override required init() {
        super.init()
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.age<--"age"
        mapper<<<self.company<--"company"
        mapper<<<self.id<--"id"
        mapper<<<self.isFocused<--"isFocused"
        mapper<<<self.latestAttendDate<--"latestAttendDate"
        mapper<<<self.licenseUrl<--"licenseUrl"
        mapper<<<self.milsToday<--"milsToday"
        mapper<<<self.name<--"name"
        mapper<<<self.driverurl<--"driverurl"
        mapper<<<self.orgName<--"orgName"
        mapper<<<self.phone<--"phone"
        mapper<<<self.riskHighCount<--"riskHighCount"
        mapper<<<self.riskMiddleCount<--"riskMiddleCount"
        mapper<<<self.safeCreditIndex<--"safeCreditIndex"
    }
}
