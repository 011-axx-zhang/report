//
//  ViolateRuleModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/27.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class ViolateRuleModel: NSObject,HandyJSON {
    var deadline:String? //截止日期
    var sum:Int64?  //总次数
    var processed:Int64? //已处理
    var unprocessed:Int64? //未处理
    var processedCost:Float? //已处理金额
    var unprocessedCost:Float? //金额
    
    override required init() {
        super.init()
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.deadline<--"deadline"
        mapper<<<self.sum<--"sum"
        mapper<<<self.processed<--"processed"
        mapper<<<self.unprocessed<--"unprocessed"
        mapper<<<self.processedCost<--"processedCost"
        mapper<<<self.unprocessedCost<--"unprocessedCost"
        
    }
}
