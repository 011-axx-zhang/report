//
//  VehicleManagerModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/27.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class VehicleManagerModel: NSObject,HandyJSON{
       var modelPie:[PieModel]? //车型
       var runningPie:[PieModel]?
       var stopPie:[PieModel]? //中风险次数
       var accident:[PieModel]? //事故
       var maintenance:[WeiBaoModel]? //维保
       var insuranceExpires:[PieModel]? //保险到期
       var violateRule:ViolateRuleModel?
       

       
       override required init() {
           super.init()
       }
       
       
       func mapping(mapper: HelpingMapper) {
           mapper<<<self.modelPie<--"modelPie"
           mapper<<<self.runningPie<--"runningPie"
           mapper<<<self.stopPie<--"stopPie"
           mapper<<<self.accident<--"accident"
           mapper<<<self.maintenance<--"maintenance"
           mapper<<<self.maintenance<--"maintenance"
           mapper<<<self.insuranceExpires<--"insuranceExpires"
           mapper<<<self.violateRule<--"violateRule"
       }
}
