//
//  DriverInfoModel.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/31.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class DriverInfoModel: NSObject,HandyJSON {
    var age : Int?
    var attendDays : Int?
    var behaviorScore : Int?
    var company : String?
    var creditExplain : String?
    var drivingLicenseType : String?
    var hasCer : Bool?
    var hasHealthCer : Bool?
    var id : Int?
    var isFocused : Bool?
    var licenseUrl : String?
    var medalScore : Int?
    var mils : Float?
    var name : String?
    var driverurl : String?
    var orgName : String?
    var ownScore : Int?
    var phone : String?
    var riskCount : Int?
    var safeCreditIndex : Int?
    var safeCreditIndexDes : String?
    var shareScore : Int?
    var studyScore : Int?
    
    override required init() {
        super.init()
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.id<--"id"
        mapper<<<self.age<--"age"
        mapper<<<self.attendDays<--"attendDays"
        mapper<<<self.behaviorScore<--"behaviorScore"
        mapper<<<self.company<--"company"
        mapper<<<self.drivingLicenseType<--"drivingLicenseType"
        mapper<<<self.name<--"name"
        mapper<<<self.driverurl<--"driverurl"
        mapper<<<self.orgName<--"orgName"
        mapper<<<self.hasCer<--"hasCer"
        mapper<<<self.hasHealthCer<--"hasHealthCer"
        mapper<<<self.safeCreditIndex<--"safeCreditIndex"
        mapper<<<self.isFocused<--"isFocused"
        mapper<<<self.licenseUrl<--"licenseUrl"
        mapper<<<self.medalScore<--"medalScore"
        mapper<<<self.mils<--"mils"
        mapper<<<self.name<--"name"
        mapper<<<self.orgName<--"orgName"
        mapper<<<self.ownScore<--"ownScore"
        mapper<<<self.phone<--"phone"
        mapper<<<self.riskCount<--"riskCount"
        mapper<<<self.safeCreditIndex<--"safeCreditIndex"
        mapper<<<self.safeCreditIndexDes<--"safeCreditIndexDes"
        mapper<<<self.shareScore<--"shareScore"
        mapper<<<self.studyScore<--"studyScore"
    }
}
