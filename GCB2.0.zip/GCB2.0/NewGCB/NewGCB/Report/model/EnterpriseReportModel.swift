//
//  EnterpriseReportModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/27.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class EnterpriseReportModel: NSObject,HandyJSON {
    
    var mils:EnterpriseMilsModel? //里程
    var vehsInfo:EnterpriseVehsInfoModel? //车辆信息
    var driverInfo:EnterpriseDriverInfoModel? //司机信息
    var risk:EnterpriseRiskModel? //风险信息
  
    override required init() {
        super.init()
    }
    
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.mils<--"mils"
        mapper<<<self.vehsInfo<--"vehsInfo"
        mapper<<<self.driverInfo<--"driverInfo"
        mapper<<<self.risk<--"risk"
    }
    
}
