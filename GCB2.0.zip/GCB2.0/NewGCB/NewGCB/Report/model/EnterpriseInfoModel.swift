//
//  EnterpriseInfoModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/27.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON


class EnterpriseInfoModel: NSObject,HandyJSON {
    var logo:String? //组织/车队logo地址
    var orgName:String? //组织/车队名称
     var name:String? //组织/车队名称
    var safeCreditIndex:Int? //企业安全信用指数(0-100)
    var safeCreditIndexDes:String? //"极好",
    var vehSum:Int? //车辆总数
    var driverSum:Int? //驾驶员总数
    var adasSum:Int? //企业（组织/车队）购买的ADAS设备数量
    var dmsSum:Int? //企业（组织/车队）购买的DMS设备数量
    var temperatureDevices:Int? //企业（组织/车队）购买的温控设备数量
    
    override required init() {
        super.init()
    }
    
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.logo<--"logo"
        mapper<<<self.orgName<--"orgName"
        mapper<<<self.safeCreditIndex<--"safeCreditIndex"
        mapper<<<self.safeCreditIndexDes<--"safeCreditIndexDes"
        mapper<<<self.vehSum<--"vehSum"
        mapper<<<self.driverSum<--"driverSum"
        mapper<<<self.adasSum<--"adasSum"
        mapper<<<self.dmsSum<--"dmsSum"
        mapper<<<self.temperatureDevices<--"temperatureDevices"
        mapper<<<self.name<--"name"
    }
}
