//
//  EnterpriseVehsInfoModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/27.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class EnterpriseVehsInfoModel: NSObject,HandyJSON {
    var runVehs:Int64? //运营车辆
    var runVehsYOY:Float? //运营车辆同比增长率
    var runRate:Float? //运营率
    var runRateYOY:Float?
    var stopVehs:Int64? //停驶车辆
    var stopVehsYOY:Float?
    var stopVehsRate:Float? //停驶车辆占比
    var stopVehsRateYOY:Float? //
    var sumVehs:Int64? //车辆总数
    var milsPerVeh:Float? //车均里程
    var milsPerVehYOY:Float?
    var durationPerDayVeh:Float? //日车均行驶时间
    var durationPerDayVehYOY:Float?
    var maintenance:Int64? //维保次数
    var accident:Int64? //事故次数
    var violateRule:Int64? //违章次数
    var insuranceExpires:Int64? //行驶总里程 km
    
    override required init() {
        super.init()
    }
    
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.runVehs<--"runVehs"
        mapper<<<self.runVehsYOY<--"runVehsYOY"
        mapper<<<self.runRate<--"runRate"
        mapper<<<self.runRateYOY<--"runRateYOY"
        mapper<<<self.stopVehs<--"stopVehs"
        mapper<<<self.stopVehsYOY<--"stopVehsYOY"
        mapper<<<self.stopVehsRate<--"stopVehsRate"
        mapper<<<self.stopVehsRateYOY<--"stopVehsRateYOY"
        mapper<<<self.sumVehs<--"sumVehs"
        mapper<<<self.milsPerVeh<--"milsPerVeh"
        mapper<<<self.milsPerVehYOY<--"milsPerVehYOY"
        mapper<<<self.durationPerDayVeh<--"durationPerDayVeh"
        mapper<<<self.durationPerDayVehYOY<--"durationPerDayVehYOY"
        mapper<<<self.maintenance<--"maintenance"
        mapper<<<self.accident<--"accident"
        mapper<<<self.violateRule<--"violateRule"
        mapper<<<self.insuranceExpires<--"insuranceExpires"
    }
}
