//
//  DriverReportModel.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/31.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

//  二级model
class DriverReportMils: NSObject,HandyJSON {
    var milsSum:Double!
    var riskPerHundred:Float!
    var milsDay:Float!
    var milsNight:Float!
    
    override required init() {
        super.init()
    }
    
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.milsSum<--"milsSum"
        mapper<<<self.riskPerHundred<--"riskPerHundred"
        mapper<<<self.milsDay<--"milsDay"
        mapper<<<self.milsNight<--"milsNight"
    }
}

//  二级model
class DriverReportRunningInfo: NSObject,HandyJSON {
    var attendDays:Int16!
    var rate:Float!
    var milsPerDay:Int16!
    var durationPerDay:Int16!
    
    override required init() {
        super.init()
    }
    
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.attendDays<--"attendDays"
        mapper<<<self.rate<--"rate"
        mapper<<<self.milsPerDay<--"milsPerDay"
        mapper<<<self.durationPerDay<--"durationPerDay"
    }
}

//  二级model
class DriverReportRisk: NSObject,HandyJSON {
    var high : Int?
    var highPerHundredDay : Float?
    var highPerHundredDayYOY : Float?
    var highPerHundredNight : Float?
    var highPerHundredNightYOY : Float?
    var highYOY : Float?
    var low : Int?
    var lowYOY : Float?
    var middle : Int?
    var middleYOY : Float?
    var bar : [RiskBar]?
    var barPre : [RiskBar]?
    var pie : [RiskPie]?
    
    override required init() {
        super.init()
    }
    
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.high<--"high"
        mapper<<<self.highPerHundredDay<--"highPerHundredDay"
        mapper<<<self.highPerHundredDayYOY<--"highPerHundredDayYOY"
        mapper<<<self.highPerHundredNight<--"highPerHundredNight"
        mapper<<<self.highPerHundredNightYOY<--"highPerHundredNightYOY"
        mapper<<<self.highYOY<--"highYOY"
        mapper<<<self.low<--"low"
        mapper<<<self.lowYOY<--"lowYOY"
        mapper<<<self.middle<--"middle"
        mapper<<<self.middleYOY<--"middleYOY"
        mapper<<<self.bar<--"bar"
        mapper<<<self.barPre<--"barPre"
        mapper<<<self.pie<--"pie"
    }
}

//  三级model
class RiskBar: NSObject,HandyJSON {
    var x : String!
    var y : Int!
    
    override required init() {
        super.init()
    }
    
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.x<--"x"
        mapper<<<self.y<--"y"
    }
}

//  三级model
class RiskPie: NSObject,HandyJSON {
    var event : String?
    var value : Int64?
    var color : String?
    var rate : Double?
    
    override required init() {
        super.init()
    }
    
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.event<--"event"
        mapper<<<self.value<--"value"
        mapper<<<self.color<--"color"
        mapper<<<self.rate<--"rate"
    }
}







//  司机报表model   一级model
class DriverReportModel: NSObject,HandyJSON {
    var mils : DriverReportMils?
    var runningInfo : DriverReportRunningInfo?
    var risk : DriverReportRisk?
    
    
    override required init() {
        super.init()
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.mils<--"mils"
        mapper<<<self.runningInfo<--"runningInfo"
        mapper<<<self.risk<--"risk"
    }
}
