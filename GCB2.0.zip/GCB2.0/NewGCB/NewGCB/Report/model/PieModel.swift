//
//  PieModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/27.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class PieModel: NSObject,HandyJSON{
    var model:String? //高风险数
    var count:Int64?
    var rate:Double? //中风险次数
    override required init() {
        super.init()
    }

    func mapping(mapper: HelpingMapper) {
        mapper<<<self.model<--"model"
        mapper<<<self.count<--"count"
        mapper<<<self.rate<--"rate"
        
    }
}
