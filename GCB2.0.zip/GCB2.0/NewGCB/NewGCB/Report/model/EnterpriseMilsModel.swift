//
//  EnterpriseMilsModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/27.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class EnterpriseMilsModel: NSObject,HandyJSON {
    var milsSum:Double? //行驶总里程 km
    var milsSumYOY:Double? //同比
    var milsPerDay:Double? //日均里程 km
    var milsPerDayYOY:Double?
    var milsDay:Double? //日间里程
    var milsDayYOY:Double? //日间同比增长率
    var milsNight:Double? //夜间里程
    var milsNightYOY:Double? //同比增长率
    var milsData:[ChartModel]?
    var milsDataPre:[ChartModel]?
    
    
    override required init() {
        super.init()
    }
    
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.milsSum<--"milsSum"
        mapper<<<self.milsSumYOY<--"milsSumYOY"
        mapper<<<self.milsPerDay<--"milsPerDay"
        mapper<<<self.milsPerDayYOY<--"milsPerDayYOY"
        mapper<<<self.milsDay<--"milsDay"
        mapper<<<self.milsDayYOY<--"milsDayYOY"
        mapper<<<self.milsNight<--"milsNight"
        mapper<<<self.milsNightYOY<--"milsNightYOY"
        mapper<<<self.milsData<--"milsData"
        mapper<<<self.milsDataPre<--"milsDataPre"
    }
    
}
