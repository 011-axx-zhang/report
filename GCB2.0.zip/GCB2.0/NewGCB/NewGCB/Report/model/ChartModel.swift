//
//  ChartModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/30.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class ChartModel: NSObject,HandyJSON {
    var x:String? //截止日期
    var y:Double?  //总次数
   
    
    override required init() {
        super.init()
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.x<--"x"
        mapper<<<self.y<--"y"
    }
}
