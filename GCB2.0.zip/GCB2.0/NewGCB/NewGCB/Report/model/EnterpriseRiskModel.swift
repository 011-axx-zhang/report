//
//  EnterpriseRiskModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/27.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class EnterpriseRiskModel: NSObject,HandyJSON {
    var high:Int64? //高风险数
    var highYOY:Float?
    var middle:Int64? //中风险次数
    var middleYOY:Float?
    var low:Int64? //低风险次数
    var lowYOY:Float?
    var highPerHundredDay:Float? //日间百公里高风险次数
    var highPerHundredDayYOY:Float?
    var highPerHundredNight:Float? //夜间百公里高风险次数
    var highPerHundredNightYOY:Float?
    
    var bar:[RiskBarModel]?
    var barPre:[RiskBarModel]?
    var pie:[RiskPieModel]?

    
    override required init() {
        super.init()
    }
    
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.high<--"high"
        mapper<<<self.highYOY<--"highYOY"
        mapper<<<self.middle<--"middle"
        mapper<<<self.middleYOY<--"middleYOY"
        mapper<<<self.low<--"low"
        mapper<<<self.lowYOY<--"lowYOY"
        mapper<<<self.highPerHundredDay<--"highPerHundredDay"
        mapper<<<self.highPerHundredDayYOY<--"highPerHundredDayYOY"
        mapper<<<self.highPerHundredNight<--"highPerHundredNight"
        mapper<<<self.highPerHundredNightYOY<--"highPerHundredNightYOY"
        mapper<<<self.bar<--"bar"
        mapper<<<self.barPre<--"barPre"
        mapper<<<self.pie<--"pie"
    }
}
