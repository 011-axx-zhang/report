//
//  EnterpriseDriverInfoModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/27.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class EnterpriseDriverInfoModel: NSObject,HandyJSON {
    var attend:Int64? //出勤驾驶员
    var attendYOY:Double?
    var attendRate:Double? //出勤率
    var attendRateYOY:Double?
    var notAttend:Int64? //未出勤驾驶员
    var notAttendYOY:Double?
    var notAttendRate:Double? //未出勤率
    var notAttendRateYOY:Double? //
    var milsPerDay:Double? //日均驾驶公里数 km
    var milsPerDayYOY:Double?
    var durationPerDay:Double? //日均驾驶时长 h
    var durationPerDayYOY:Double? //日车均行驶时间

    
    override required init() {
        super.init()
    }
    
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.attend<--"attend"
        mapper<<<self.attendYOY<--"attendYOY"
        mapper<<<self.attendRate<--"attendRate"
        mapper<<<self.attendRateYOY<--"attendRateYOY"
        mapper<<<self.notAttend<--"notAttend"
        mapper<<<self.notAttendYOY<--"notAttendYOY"
        mapper<<<self.notAttendRate<--"notAttendRate"
        mapper<<<self.notAttendRateYOY<--"notAttendRateYOY"
        mapper<<<self.milsPerDay<--"milsPerDay"
        mapper<<<self.milsPerDayYOY<--"milsPerDayYOY"
        mapper<<<self.durationPerDay<--"durationPerDay"
        mapper<<<self.durationPerDayYOY<--"durationPerDayYOY"
    }
}
