//
//  VehicleModelRightView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/23.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class VehicleModelRightView: UIView {
       var circleView:UIView!
       var modelNameLabel:UILabel!
       var numLabel:UILabel!
       var percentLabel:UILabel!
    
      
       
       override init(frame: CGRect) {
           super.init(frame: frame)
           self.backgroundColor = UIColor.white
           self.createUI()
           updateConstraints()
       }
       
       private func createUI() {
        
        circleView = UIView()
        circleView.backgroundColor = UIColor(hex: "#66B8FE", alpha: 1.0)
        circleView.layer.cornerRadius = 4
        self.addSubview(circleView)
        numLabel = UILabel()
        numLabel.text = "12次"
        numLabel.font = UIFont.boldSystemFont(ofSize: 11)
        numLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.addSubview(numLabel)
        percentLabel = UILabel()
        percentLabel.text = "38.4%"
        percentLabel.font = UIFont.boldSystemFont(ofSize: 11)
        percentLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        percentLabel.textAlignment = .left
        self.addSubview(percentLabel)
        
        modelNameLabel = UILabel()
        modelNameLabel.text = "江铃顺达"
        modelNameLabel.font = UIFont.systemFont(ofSize: 11)
        modelNameLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.addSubview(modelNameLabel)
        
       }
       
       
       override func updateConstraints() {
           super.updateConstraints()
           
        circleView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(5)
            make.centerY.equalTo(self)
            make.size.equalTo(CGSize(width: 8, height: 8))
        }
        modelNameLabel .snp.makeConstraints { (make) in
            make.left.equalTo(circleView.snp.right).offset(5)
            make.centerY.equalTo(self)
        }
        numLabel.snp.makeConstraints { (make) in
            make.left.equalTo(modelNameLabel.snp.right).offset(5)
            make.centerY.equalTo(self)
        }
        
        
        percentLabel.snp.makeConstraints { (make) in
            make.left.equalTo(numLabel.snp.right).offset(10)
            make.centerY.equalTo(self)
        }
        
       
           
           
       }
       
       required init?(coder aDecoder: NSCoder) {
           fatalError("init(coder:) has not been implemented")
       }

}
