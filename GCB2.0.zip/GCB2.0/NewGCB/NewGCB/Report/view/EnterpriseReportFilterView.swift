//
//  EnterpriseReportFilterView.swift
//  NewGCB
//
//  Created by YTKJ on 2020/2/1.
//  Copyright © 2020 YTKJ. All rights reserved.
//

import UIKit

class EnterpriseReportFilterView:UIView,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
   
   var collectView :UICollectionView!
   var bottomView:UIView!
   var gestureView:UIView!
   var resetBtn:UIButton!
   var confirmBtn:UIButton!
   var shadowView:UIView!
   var firstArr:Array<String> = []
   var secArr:Array<String> = []
   var thirdArr:Array<String> = []
   @objc var resetClick:(()->Void)?
   @objc var confirmClick:((String)->Void)?
   @objc var closeClick:(()->Void)?
   var selectStr = ""
   var thirdStr = ""   //  关注下的内容
   var orgArr:Array<OrgAndGroupContent> = []
   var vehicleGroupArr:Array<OrgAndGroupContent> = []
   var flagOrg:Bool = false
   var flagGroup:Bool = false
    @objc var passValue:((Int,Int64)->Void)?
   var index = 0
   var id:Int64! = 0


   
    init(frame: CGRect,orgArr:Array<OrgAndGroupContent>,vehicleGroupArr:Array<OrgAndGroupContent>) {
       super.init(frame: frame)
       self.backgroundColor =  UIColor(red: 51.0/255.0, green: 51.0/255.0, blue: 51.0/255.0, alpha: 0.5)
      
       let defaults = UserDefaults.standard
       if defaults.value(forKey: "filterValue") != nil{
           selectStr = defaults.value(forKey: "filterValue") as! String
       }
//        for i in 0...3 {
//            let model = OrgAndGroupContent()
//            model.id = 1
//            model.name = "组织" + "一"
//            self.orgArr.append(model)
//        }
//
//        for i in 0...1{
//            let model = OrgAndGroupContent()
//            model.id = 1
//            model.name = "车队" + "一"
//            self.vehicleGroupArr.append(model)
//        }
////      self.orgArr = []
////      self.vehicleGroupArr = []
    
        self.orgArr = orgArr
        self.vehicleGroupArr = vehicleGroupArr
        self.createCollectionView()
        self.createUI()
        updateConstraints()
   }
   
   func createCollectionView()  {
    
    
    var num:Double = 0
    if self.orgArr.count == 0  && self.vehicleGroupArr.count != 0 && self.vehicleGroupArr.count < 4{
        num = 1
    }else if self.orgArr.count != 0  && self.vehicleGroupArr.count == 0 && self.orgArr.count < 4{
        num = 1
    }else if self.orgArr.count < 4 && self.vehicleGroupArr.count < 4  && self.orgArr.count != 0  && self.vehicleGroupArr.count != 0 {
        num = 2
    }else if self.orgArr.count > 3 && self.vehicleGroupArr.count > 3  && self.orgArr.count != 0  && self.vehicleGroupArr.count != 0   {
        num = 3
    }else {
        num = 2.5
    }
    
         let h = 90 * num + 30
       // (KH*4/7) - CGFloat(55) - CGFloat(num * 90)
       let layout = UICollectionViewFlowLayout()
       layout.sectionInset = UIEdgeInsets(top: 0, left: 15,bottom:0, right: 15)
       layout.minimumInteritemSpacing = 10
       layout.minimumLineSpacing  = 10
       collectView = UICollectionView(frame:CGRect(x: 0, y: 0, width: KW, height: CGFloat(h)), collectionViewLayout: layout)
       collectView.backgroundColor = UIColor.white
       collectView.register(VehicleChooseCollectionViewCell.self, forCellWithReuseIdentifier:"vehicleChooseCollectionViewCell")
       collectView!.register(VehicleFilterCollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionHeader, withReuseIdentifier: "vehicleFilterCollectionReusableView")
       collectView!.register(UICollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionFooter, withReuseIdentifier: "nofooterID")
       collectView.delegate = self
       collectView.dataSource = self
       self.addSubview(collectView)
   }
   
   
   func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
       
       let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "vehicleChooseCollectionViewCell", for: indexPath) as! VehicleChooseCollectionViewCell

       if indexPath.section == 0 {
           let model = self.orgArr[indexPath.row]
           let str = model.name
           if str == selectStr {
               cell.backgroundColor = UIColor(hex: "#D6DEFC", alpha: 1.0)
               cell.contentLabel.textColor = UIColor(hex: "#1D69F5", alpha: 1.0)
               
           }else {
               cell.backgroundColor = UIColor(hex: "#EFF1F6", alpha: 1.0)
               cell.contentLabel.textColor = UIColor(hex: "#2A2B37", alpha: 1.0)
           }
           cell.contentLabel.text = str
       }else {
           let model = self.vehicleGroupArr[indexPath.row]
           let str = model.name
           cell.contentLabel.text = str
           if str == selectStr {
               cell.backgroundColor = UIColor(hex: "#D6DEFC", alpha: 1.0)
               cell.contentLabel.textColor = UIColor(hex: "#1D69F5", alpha: 1.0)
               
           }else {
               cell.backgroundColor = UIColor(hex: "#EFF1F6", alpha: 1.0)
               cell.contentLabel.textColor = UIColor(hex: "#2A2B37", alpha: 1.0)
           }
       }
      
       return cell
   }
   
   
   
   func numberOfSections(in collectionView: UICollectionView) -> Int {
       return 2
   }
   
   func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       
       if section == 0 {
           if flagOrg == true {
               if self.orgArr.count <= 6 {
                return self.orgArr.count
               }else {
                   return 6
               }
                
           }else {
             return self.orgArr.count
           }
          
       }else {
          if flagGroup == true {
           if self.vehicleGroupArr.count <= 6 {
               return self.vehicleGroupArr.count
           }else {
               return 6
           }
               
           }else {
               return self.vehicleGroupArr.count
           }
       }
   }
   
   
   func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
       return CGSize(width: (KW - 30 - 2*10)/3 , height: 40)
   }
   
   
   func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
    if section == 0 {
        if self.orgArr.count != 0 {
            return CGSize(width: KW, height: 48)
        }else {
            return CGSize(width: KW, height: 0.01)
        }
        
    }else {
        if self.vehicleGroupArr.count != 0 {
            return CGSize(width: KW, height: 48)
        }else {
            return CGSize(width: KW, height: 0.01)
        }
    }

       
   }
   
   func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
       return CGSize(width: KW, height: 0.01)
   }
   
   func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String,
                       at indexPath: IndexPath) -> UICollectionReusableView {
       var  filterReusableview:VehicleFilterCollectionReusableView!
       var noneReusableview:UICollectionReusableView!
       if kind == UICollectionView.elementKindSectionHeader{
           filterReusableview = (collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "vehicleFilterCollectionReusableView", for: indexPath) as! VehicleFilterCollectionReusableView)
           if indexPath.section == 0 {
               
               filterReusableview.rightBtn.isHidden = false
               filterReusableview.expendClick = {
                   self.flagOrg = !self.flagOrg
                   self.collectView.reloadData()
               }
            if self.orgArr.count > 6 {
                if self.flagOrg == true {
                    filterReusableview.rightLabel.text = "收起"
                    filterReusableview.rightIcon.image = UIImage(named: "vehicle_filterUpIcon")
                }else {
                    filterReusableview.rightLabel.text = "展开"
                    filterReusableview.rightIcon.image = UIImage(named: "vehicle_filterDownIcon")
                }
                filterReusableview.rightLabel.isHidden = false
                filterReusableview.rightIcon.isHidden = false
            }else {
                
                filterReusableview.rightLabel.isHidden = true
                filterReusableview.rightIcon.isHidden = true
            }
            
            if self.orgArr.count != 0 {
               filterReusableview.leftLabel.text = "公司组织"
            }else {
                 filterReusableview.leftLabel.text = ""
            }
              
              
           }else  {
            
            if self.vehicleGroupArr.count != 0 {
                 filterReusableview.leftLabel.text = "车队"
            }else {
                  filterReusableview.leftLabel.text = ""
            }
             
               filterReusableview.rightBtn.isHidden = false
               filterReusableview.expendClick = {
                   self.flagGroup = !self.flagGroup
                    self.collectView.reloadData()
               }
            if self.vehicleGroupArr.count > 6 {
                if self.flagGroup == true {
                    filterReusableview.rightLabel.text = "收起"
                    filterReusableview.rightIcon.image = UIImage(named: "vehicle_filterUpIcon")
                }else {
                    filterReusableview.rightLabel.text = "展开"
                    filterReusableview.rightIcon.image = UIImage(named: "vehicle_filterDownIcon")
                }
                
                filterReusableview.rightLabel.isHidden = false
                filterReusableview.rightIcon.isHidden = false
            }else {
                filterReusableview.rightLabel.isHidden = true
                filterReusableview.rightIcon.isHidden = true
                
            }
               
           }
           
           return  filterReusableview
           
       }else {
           noneReusableview = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "nofooterID", for: indexPath)
           noneReusableview.backgroundColor = UIColor.white
           return noneReusableview
       }
       
   }
   
   
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        var str = ""
        if indexPath.section == 0 {
            let model = self.orgArr[indexPath.row]
            str = model.name ?? ""
            index = 1
            id = model.id
            selectStr = str
        }else  {
            let model = self.vehicleGroupArr[indexPath.row]
            str = model.name ?? ""
            id = model.id
            index = 2
            selectStr = str
        }
        self.collectView.reloadData()
        let defaults = UserDefaults.standard
        defaults.set(selectStr, forKey: "filterValue")
        defaults.set(index, forKey: "filterIndex")
        defaults.set(id, forKey: "filterId")
        
        if self.passValue != nil {
            self.passValue?(index,id)
        }
    }
   
   
   func createUI()  {
//       bottomView = UIView()
//       bottomView.backgroundColor = UIColor.white
//       bottomView.layer.shadowOpacity = 0.1
//       bottomView.layer.shadowColor =  UIColor(hex: "#363847",alpha: 1.0)?.cgColor
//       self.addSubview(bottomView)
//
//       resetBtn = UIButton()
//       resetBtn.setTitle("重置", for: .normal)
//       resetBtn.backgroundColor = UIColor(hex: "#EFF1F6", alpha: 1.0)
//       resetBtn.titleLabel?.font = UIFont.systemFont(ofSize: 13)
//       resetBtn.setTitleColor(UIColor(hex: "#2A2B37", alpha: 1.0), for: .normal)
//       resetBtn.layer.cornerRadius = 5
//       resetBtn.addTarget(self, action: #selector(self.resetEvent), for: .touchUpInside)
//       bottomView.addSubview(resetBtn)
//       confirmBtn = UIButton()
//       confirmBtn.setTitle("确定", for: .normal)
//       confirmBtn.setTitleColor(UIColor(hex: "#FFFFFF", alpha: 1.0), for: .normal)
//       confirmBtn.backgroundColor = UIColor(hex: "#2B72F5", alpha: 1.0)
//       confirmBtn.titleLabel?.font = UIFont.systemFont(ofSize: 13)
//       confirmBtn.layer.cornerRadius = 5
//       confirmBtn.addTarget(self, action: #selector(self.confirmEvent), for: .touchUpInside)
//       bottomView.addSubview(confirmBtn)
   
       gestureView = UIView()
       let tapGest = UITapGestureRecognizer.init(target: self, action: #selector(self.tapBackgroundView))
       gestureView.addGestureRecognizer(tapGest)
       self.addSubview(gestureView)
   }
   
   
//
   @objc func tapBackgroundView(){
       self.closeClick?()
   }
   
   override func updateConstraints() {
       super.updateConstraints()
//       bottomView.snp.makeConstraints { (make) in
//           make.left.equalTo(self.snp.left).offset(0)
//           make.top.equalTo(self.snp.top).offset(KH*4/7 - 48)
//           make.size.equalTo(CGSize(width: KW, height: 48))
//       }
//
//       resetBtn.snp.makeConstraints { (make) in
//           make.left.equalTo(bottomView.snp.left).offset(15)
//           make.centerY.equalTo(bottomView)
//           make.size.equalTo(CGSize(width: (KW - 38)/2, height: 35))
//       }
//
//       confirmBtn.snp.makeConstraints { (make) in
//           make.right.equalTo(bottomView.snp.right).offset(-15)
//           make.centerY.equalTo(bottomView)
//           make.size.equalTo(CGSize(width: (KW - 38)/2, height: 35))
//       }
       
       gestureView.snp.makeConstraints { (make) in
           make.left.equalTo(self.snp.left)
           make.top.equalTo(self.collectView.snp.bottom)
           make.width.equalTo(KW)
           make.bottom.equalTo(self.snp.bottom)
       }
   }
    
    
    // @objc  func resetEvent()  {
    //       let defaults = UserDefaults.standard
    //       defaults.setValue(nil, forKey: "enterpriseFilterValue")
    //       selectStr = ""
    //       index = 0
    //       self.collectView.reloadData()
    //       self.resetClick?()
    //   }
    //
    //   @objc  func confirmEvent()  {
    //
    //   let defaults = UserDefaults.standard
    //
    //    if index == 0  && selectStr != ""{
    //        index = defaults.value(forKey: "enterpriseFilterIndex") as! Int
    //        id = defaults.value(forKey: "enterpriseFilterId") as! Int64
    //    }
    //    defaults.set(selectStr, forKey: "enterpriseFilterValue")
    //    defaults.set(index, forKey: "enterpriseFilterIndex")
    //    defaults.set(id, forKey: "enterpriseFilterId")
    //
    //       if self.passValue != nil {
    //           self.passValue?(index,id)
    //       }
    //   }
    //
   
   required init?(coder: NSCoder) {
       fatalError("init(coder:) has not been implemented")
   }

}
