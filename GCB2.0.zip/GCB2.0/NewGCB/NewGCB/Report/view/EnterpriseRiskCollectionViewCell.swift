//
//  EnterpriseRiskCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/19.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class EnterpriseRiskCollectionViewCell: UICollectionViewCell {
      
    var firstView:UIView!
    var seconView:UIView!
    var thirdView:UIView!
    var fourView:UIView!

    var rijianIcon:UIImageView!
    var rijianTimeLabel:UILabel!

    var yejianIcon:UIImageView!
    var yejiianTimeLabel:UILabel!
  
    var riskHightView:EnterpriseView!
    var riskMiddleView:EnterpriseView!
    var risklowView:EnterpriseView!
 
    var riskSecView:EnterpriseView!
    var riskThirdView:EnterpriseView!
    
       
       
       override init(frame: CGRect) {
           super.init(frame: frame)
           self.backgroundColor = UIColor.white
           initView()
           updateConstraints()
       }
       
       
       func initView(){
        
        firstView = UIView()
        firstView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        firstView.layer.cornerRadius = 4
        self.contentView.addSubview(firstView)
        
        thirdView = UIView()
        thirdView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        thirdView.layer.cornerRadius = 4
        self.contentView.addSubview(thirdView)
        
        fourView = UIView()
        fourView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        fourView.layer.cornerRadius = 4
        self.contentView.addSubview(fourView)
        
        rijianIcon = UIImageView()
        rijianIcon.image = UIImage(named: "baobiao_rijian")
        thirdView.addSubview(rijianIcon)
        rijianTimeLabel = UILabel()
        rijianTimeLabel.text = "(7:00～21:00)"
        rijianTimeLabel.font = UIFont.systemFont(ofSize: 10)
        rijianTimeLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        thirdView.addSubview(rijianTimeLabel)
      
        yejianIcon = UIImageView()
        yejianIcon.image = UIImage(named: "baobiao_yejian")
        fourView.addSubview(yejianIcon)
        yejiianTimeLabel = UILabel()
        yejiianTimeLabel.text = "(7:00～21:00)"
        yejiianTimeLabel.font = UIFont.systemFont(ofSize: 10)
        yejiianTimeLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        fourView.addSubview(yejiianTimeLabel)
        
        riskHightView = EnterpriseView()
        riskHightView.topValueLabel.text = ""
        riskHightView.desLabel.text = "高风险"
        firstView.addSubview(riskHightView)
        
        riskMiddleView = EnterpriseView()
        riskMiddleView.topValueLabel.text = ""
        riskMiddleView.desLabel.text = "中风险"
        firstView.addSubview(riskMiddleView)
        
        risklowView = EnterpriseView()
        risklowView.topValueLabel.text = ""
        risklowView.desLabel.text = "低风险"
        risklowView.setContentCompressionResistancePriority(.defaultHigh, for: .horizontal)
        firstView.addSubview(risklowView)
   
        riskSecView = EnterpriseView()
        riskSecView.topValueLabel.text = ""
        riskSecView.desLabel.text = "日间行驶公里"
        self.contentView.addSubview(riskSecView)
        riskThirdView = EnterpriseView()
        riskThirdView.topValueLabel.text = ""
        riskThirdView.desLabel.text = "夜间行驶公里"
        self.contentView.addSubview(riskThirdView)
               
       }
       
       override func updateConstraints() {
           super.updateConstraints()
          
        firstView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self.snp.top).offset(10)
            make.size.equalTo(CGSize(width: (KW - 30), height: 68))
        }
        
        
        
        thirdView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(firstView.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 38)/2, height: 84))
        }
        
        fourView.snp.makeConstraints { (make) in
            make.left.equalTo( thirdView.snp.right).offset(8)
            make.top.equalTo(firstView.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 38)/2, height: 84))
        }
        
        
        rijianIcon.snp.makeConstraints { (make) in
            make.left.equalTo(thirdView.snp.left).offset(5)
            make.top.equalTo(thirdView.snp.top).offset(13)
            make.size.equalTo(CGSize(width: 20, height: 20))
        }
        rijianTimeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(rijianIcon.snp.right).offset(2)
            make.top.equalTo(thirdView.snp.top).offset(13)
        }
      
        
        yejianIcon.snp.makeConstraints { (make) in
            make.left.equalTo(fourView.snp.left).offset(5)
            make.top.equalTo(fourView.snp.top).offset(13)
            make.size.equalTo(CGSize(width: 20, height: 20))
        }
        yejiianTimeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(yejianIcon.snp.right).offset(2)
            make.top.equalTo(fourView.snp.top).offset(13)
        }
       
    
        riskHightView.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.left).offset(20)
            make.top.equalTo(firstView.snp.top).offset(12)
        }
        
        riskMiddleView.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.left).offset(KW*1/3 + 10)
            make.top.equalTo(firstView.snp.top).offset(12)
        }
        
        
        risklowView.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.left).offset(KW*2/3)
            make.top.equalTo(firstView.snp.top).offset(12)
        }
        
        
        
        riskSecView.snp.makeConstraints { (make) in
            make.left.equalTo(thirdView.snp.left).offset(26)
            make.top.equalTo(rijianTimeLabel.snp.bottom).offset(5)
        }
        riskThirdView.snp.makeConstraints { (make) in
             make.left.equalTo(fourView.snp.left).offset(26)
            make.top.equalTo(rijianTimeLabel.snp.bottom).offset(5)
        }
        
       
        
    }
       
     
    
    func configData(model:EnterpriseReportModel) {
          let model = model.risk
        
        
        riskHightView.topValueLabel.text = String(format: "%d", model?.high ?? 0)
       
        if model!.highYOY! > 0.0 {
            riskHightView.mileTotalIcon.isHidden = false
            riskHightView.mileTotalIcon.image = UIImage(named: "report_tigao")
            riskHightView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            riskHightView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
            riskHightView.mileTotalLabel.text = String(format: "%.1f%@", (model?.highYOY ?? 0) * 100,"%")
        }else if  model!.highYOY! < 0.0{
            riskHightView.mileTotalIcon.isHidden = false
            riskHightView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            riskHightView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            riskHightView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
            riskHightView.mileTotalLabel.text = String(format: "%.1f%@", -(model?.highYOY ?? 0) * 100,"%")
        }else if model!.highYOY! == 0.0{
            riskHightView.mileTotalIcon.isHidden = true
            riskHightView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            riskHightView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
            riskHightView.mileTotalLabel.text = String(format: "%.1f%@", (model?.highYOY ?? 0) * 100,"%")
        }
        
        riskMiddleView.topValueLabel.text = String(format: "%d", model?.middle ?? 0)
        
        if model!.middleYOY! > 0.0 {
            riskMiddleView.mileTotalIcon.isHidden = false
            riskMiddleView.mileTotalIcon.image = UIImage(named: "report_tigao")
            riskMiddleView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            riskMiddleView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
            riskMiddleView.mileTotalLabel.text = String(format: "%.1f%@", (model?.middleYOY ?? 0) * 100,"%")
        }else if model!.middleYOY! < 0.0{
            riskMiddleView.mileTotalIcon.isHidden = false
            riskMiddleView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            riskMiddleView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            riskMiddleView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
            riskMiddleView.mileTotalLabel.text = String(format: "%.1f%@", -(model?.middleYOY ?? 0) * 100,"%")
        }else if model!.middleYOY! == 0.0{
            riskMiddleView.mileTotalIcon.isHidden = true
            riskMiddleView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            riskMiddleView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            riskMiddleView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
            riskMiddleView.mileTotalLabel.text = String(format: "%.1f%@", (model?.middleYOY ?? 0) * 100,"%")
        }
        
        
        risklowView.topValueLabel.text = String(format: "%d", model?.low ?? 0)
        
        if model!.lowYOY! > 0.0 {
            risklowView.mileTotalIcon.isHidden = false
            risklowView.mileTotalIcon.image = UIImage(named: "report_tigao")
            risklowView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            risklowView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
            risklowView.mileTotalLabel.text = String(format: "%.1f%@", (model?.lowYOY ?? 0) * 100,"%")
        }else if model!.lowYOY! < 0.0{
            risklowView.mileTotalIcon.isHidden = false
            risklowView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            risklowView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            risklowView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
            risklowView.mileTotalLabel.text = String(format: "%.1f%@", -(model?.lowYOY ?? 0) * 100,"%")
        }else if model!.lowYOY! == 0.0{
             risklowView.mileTotalIcon.isHidden = true
            risklowView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            risklowView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
            risklowView.mileTotalLabel.text = String(format: "%.1f%@", (model?.lowYOY ?? 0) * 100,"%")
        }
        
        riskSecView.topValueLabel.text = String(format: "%.2f", model?.highPerHundredDay ?? 0)
        
        if model!.highPerHundredDayYOY! > 0.0 {
            riskSecView.mileTotalIcon.isHidden = false
            riskSecView.mileTotalIcon.image = UIImage(named: "report_tigao")
            riskSecView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            riskSecView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
            riskSecView.mileTotalLabel.text = String(format: "%.1f%@", (model?.highPerHundredDayYOY ?? 0) * 100,"%")
        }else  if model!.highPerHundredDayYOY! < 0.0 {
            riskSecView.mileTotalIcon.isHidden = false
            riskSecView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            riskSecView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            riskSecView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
            riskSecView.mileTotalLabel.text = String(format: "%.1f%@", -(model?.highPerHundredDayYOY ?? 0) * 100,"%")
        }else  if model!.highPerHundredDayYOY! == 0.0 {
            riskSecView.mileTotalIcon.isHidden = true
            riskSecView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            riskSecView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
            riskSecView.mileTotalLabel.text = String(format: "%.1f%@", (model?.highPerHundredDayYOY ?? 0) * 100,"%")
        }
        
        
        riskThirdView.topValueLabel.text = String(format: "%.2f", model?.highPerHundredNight ?? 0)
        
        if model!.highPerHundredNightYOY! > 0.0 {
            riskThirdView.mileTotalIcon.isHidden = false
            riskThirdView.mileTotalIcon.image = UIImage(named: "report_tigao")
            riskThirdView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            riskThirdView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
            riskThirdView.mileTotalLabel.text = String(format: "%.1f%@", (model?.highPerHundredNightYOY ?? 0) * 100,"%")
        }else if model!.highPerHundredNightYOY! < 0.0{
            riskThirdView.mileTotalIcon.isHidden = false
            riskThirdView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            riskThirdView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            riskThirdView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
            riskThirdView.mileTotalLabel.text = String(format: "%.1f%@", -(model?.highPerHundredNightYOY ?? 0) * 100,"%")
        }else if model!.highPerHundredNightYOY! == 0.0{
            riskThirdView.mileTotalIcon.isHidden = true
            riskThirdView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            riskThirdView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
            riskThirdView.mileTotalLabel.text = String(format: "%.1f%@", (model?.highPerHundredNightYOY ?? 0) * 100,"%")
        }
        
        
    }
    
       
       required init?(coder aDecoder: NSCoder) {
           fatalError("init(coder:) has not been implemented")
       }
}
