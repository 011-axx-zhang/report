//
//  VehicleOtherCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/24.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import Charts

class VehicleOtherCollectionViewCell: UICollectionViewCell {
    var titleLabel:UILabel!
    var bgView:UIView!
    var searchMoreBtn:UIButton!
    var searchLabel:UILabel!
    var searchIcon:UIImageView!
    @objc var checkMoreClick:(()->Void)?
    var yDataArr:Array<Float> = []
    var colors:Array<UIColor> = []
    var rightView:UIView!
    
    var imageView:UIImageView!
    var nodataLabel:UILabel!
    
  // var weibaoyDataArr:Array<Float> = []
    
    var h: CGFloat = 0
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor(hex: "#F5F5F9", alpha: 1.0)
        initView()
        self.addSubview(self.pieChartView)
        self.createColors()
        updateConstraints()
    }
    
    func createColors()  {
        let arr = ["#66B8FE","#7BE279","#FFE03F","#FAB286","#FD723A","#7D8DFD","#8AE1BF","#F59BCC","#FFC53F","#F95642","#1889F7","#38C465","#A7B4FF","#FFCCE3","#FD723A","#4163DD","#85DE50","#FFA0ED","#C7D0FF","#FE9A28"]
        for i in 0...19 {
            let color = UIColor(hex: arr[i], alpha: 1.0)
            colors.append(color!)
        }
    }
    
    func createRightView(dataArr:Array<PieModel>)  {
        for i in 0..<dataArr.count {
            let model = dataArr[i]
            let view = VehicleModelRightView()
            view.frame = CGRect(x: 0, y: CGFloat(i * 20), width: (KW - 30)/2, height: 20)
            view.modelNameLabel.text = model.model ?? ""
            view.numLabel.text = String(format: "%d辆", model.count ?? 0)
            view.percentLabel.text = String(format: "%.1f%@", (model.rate ?? 0)*100,"%")
            view.circleView.backgroundColor = colors[i]
            self.rightView.addSubview(view)
        }
        
        h = CGFloat(dataArr.count * 20)
        updateConstraints()
        
    }
    
    func initView(){
        
        bgView = UIView()
        bgView.backgroundColor = UIColor.white
        self.addSubview(bgView)
        
        rightView = UIView()
        rightView.backgroundColor = UIColor.white
        self.addSubview(rightView)
        
//        titleLabel = UILabel()
//        titleLabel.font = UIFont.boldSystemFont(ofSize: 13)
//        titleLabel.text = "车辆事故"
//        titleLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
//        bgView.addSubview(titleLabel)
        
        searchMoreBtn = UIButton()
        bgView.addSubview(searchMoreBtn)
        searchLabel = UILabel()
        searchLabel.text = "查看更多"
        searchLabel.font = UIFont.systemFont(ofSize: 12)
        searchLabel.textColor = UIColor(hex: "#1D69F5", alpha: 1.0)
        searchMoreBtn.addSubview(searchLabel)
        searchIcon = UIImageView()
        searchIcon.image = UIImage(named: "baobiao_chakan")
        searchIcon.contentMode = .center
        searchMoreBtn.addSubview(searchIcon)
        searchMoreBtn.addTarget(self, action: #selector(self.searchaMoreEvent), for: .touchUpInside)
        
        imageView = UIImageView()
        imageView.image = UIImage(named: "icon_zanwushuju")
        imageView.isHidden = true
        self.addSubview(imageView)
      
        nodataLabel = UILabel()
        nodataLabel.text = "暂无数据"
        nodataLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        nodataLabel.font = UIFont.systemFont(ofSize: 15)
        self.addSubview(nodataLabel)
     
        
    }
    
    @objc  func searchaMoreEvent()  {
        self.checkMoreClick?()
        
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        
        bgView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self)
            make.size.equalTo(CGSize(width: KW - 30, height: 200))
        }
        
        rightView.snp.updateConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(KW/2)
            make.centerY.equalTo(self.pieChartView)
            make.size.equalTo(CGSize(width: (KW - 30)/2, height:self.h))
        }


        searchMoreBtn.snp.makeConstraints { (make) in
            make.right.equalTo(bgView.snp.right).offset(-8)
            make.top.equalTo(bgView.snp.top).offset(10)
            make.size.equalTo(CGSize(width: 65, height: 20))
        }
        
        searchLabel.snp.makeConstraints { (make) in
            make.left.equalTo(searchMoreBtn.snp.left).offset(0)
            make.centerY.equalTo(searchMoreBtn)
        }
        
        searchIcon.snp.makeConstraints { (make) in
            make.left.equalTo(searchLabel.snp.right).offset(2)
            make.centerY.equalTo(searchMoreBtn)
            make.size.equalTo(CGSize(width: 10, height: 20))
        }
        
        imageView.snp.makeConstraints { (make) in
            make.center.equalTo(self)
            make.size.equalTo(CGSize(width: 81, height: 61))
        }
        
        nodataLabel.snp.makeConstraints { (make) in
            make.top.equalTo(imageView.snp.bottom).offset(18)
            make.centerX.equalTo(self)
        }
        
        
    }
    
    
    lazy var pieChartView: PieChartView = {
        let _pieChartView = PieChartView.init(frame: CGRect.init(x: 0, y: 40, width: (KW - 30)/2, height: 160));
        // _pieChartView.backgroundColor = UIColor.red;
        _pieChartView.setExtraOffsets(left: 10, top: 0, right: 10, bottom: 0);//设置这块饼的位置
        _pieChartView.chartDescription?.text = "";//描述文字
        _pieChartView.chartDescription?.font = UIFont.systemFont(ofSize: 12.0);//字体
        _pieChartView.chartDescription?.textColor = UIColor.black;//颜色
        
        _pieChartView.usePercentValuesEnabled = true;//转化为百分比
        _pieChartView.dragDecelerationEnabled = false;//我把拖拽效果关了
        _pieChartView.drawEntryLabelsEnabled = false;//不显示区块文本
        _pieChartView.entryLabelFont = UIFont.systemFont(ofSize: 10);//区块文本的字体
        _pieChartView.entryLabelColor = UIColor.white;
        _pieChartView.drawSlicesUnderHoleEnabled = true;
        
        
        _pieChartView.drawHoleEnabled = true;//这个饼是空心的
        _pieChartView.holeRadiusPercent = 0.65//空心半径黄金比例
        _pieChartView.holeColor = UIColor.white;//空心颜色设置为白色
        _pieChartView.transparentCircleRadiusPercent = 0.65;//半透明空心半径
        
        _pieChartView.drawCenterTextEnabled = true;//显示中心文本
        _pieChartView.centerText = "";//设置中心文本,你也可以设置富文本`centerAttributedText`
        
        
        //图例样式设置
        _pieChartView.legend.maxSizePercent = 0;//图例的占比
        _pieChartView.legend.form = .circle//图示：原、方、线
        _pieChartView.legend.formSize = 0;//图示大小
        
        _pieChartView.noDataText = "";
        _pieChartView.noDataTextColor = UIColor.gray;
        _pieChartView.noDataFont = UIFont.boldSystemFont(ofSize: 14);
        
        return _pieChartView;
    }()
    
     func drawPieChartView() {
        
           var colorArr:Array<UIColor> = []
           var yVals = [PieChartDataEntry]();
           for i in 0..<yDataArr.count{
               let entry = PieChartDataEntry.init(value: Double(yDataArr[i]), label: "");
               yVals.append(entry);
               colorArr.append(colors[i])
           }
        
           
           let dataSet = PieChartDataSet.init(entries: yVals, label: "");
           dataSet.colors = colorArr;
           //设置名称和数据的位置 都在内就没有折线了哦
           dataSet.xValuePosition = .insideSlice;
           dataSet.yValuePosition = .outsideSlice;
           dataSet.sliceSpace = 1;//相邻块的距离
           dataSet.selectionShift = 0;//选中放大半径
           let data = PieChartData.init(dataSets: [dataSet]);
           pieChartView.data = data;
           dataSet.valueLineWidth = 0 //折线的粗细
           
           
           
           
       }
    
    func configData(dataModel:VehicleManagerModel,index:Int){
        if index == 2 {
            yDataArr = []
            let  modelArr = dataModel.accident
            if modelArr != nil && modelArr?.count != 0{
                for model in modelArr! {
                    yDataArr.append(Float(model.count ?? 0))
                }
                
                let sum  = yDataArr.reduce(0,{$0 + $1})
                
                for item in self.rightView.subviews {
                    item.removeFromSuperview()
                }
                self.drawPieChartView()
                self.createRightView(dataArr: modelArr!)
                if sum != 0 {
                     pieChartView.centerText = String(format: "事故\n %.f", sum)
                }else {
                      pieChartView.centerText = ""
                }
                
                imageView.isHidden = true
                nodataLabel.isHidden = true
                searchMoreBtn.isHidden = false
                self.pieChartView.isHidden = false
            }else {
                self.pieChartView.isHidden = true
                imageView.isHidden = false
                nodataLabel.isHidden = false
                searchMoreBtn.isHidden = true
                for item in self.rightView.subviews {
                    item.removeFromSuperview()
                }
            }
           
          
        }else if index == 3 {
            yDataArr = []
            let  modelArr = dataModel.maintenance
            if modelArr != nil  && modelArr?.count != 0{
                for model in modelArr! {
                    yDataArr.append(model.cost ?? 0)
                }
                
                let sum  = yDataArr.reduce(0,{$0 + $1})
                
                for item in self.rightView.subviews {
                    item.removeFromSuperview()
                }
                              
                self.drawPieChartView()
                self.weiBaoRightView(dataArr: modelArr!)
                
                if sum != 0 {
                   pieChartView.centerText = String(format: "维保\n %.2f", sum)
                }else {
                    pieChartView.centerText = ""
                }
                imageView.isHidden = true
                nodataLabel.isHidden = true
                  searchMoreBtn.isHidden = false
                self.pieChartView.isHidden = false
            }else {
                imageView.isHidden = false
                 nodataLabel.isHidden = false
                 searchMoreBtn.isHidden = true
                self.pieChartView.isHidden = true
                for item in self.rightView.subviews {
                    item.removeFromSuperview()
                }
            }
            
            
        }else if index == 4 {
            yDataArr = []
            let  modelArr = dataModel.insuranceExpires
            if modelArr != nil && modelArr?.count != 0 {
                for model in modelArr! {
                    yDataArr.append(Float(model.count ?? 0))
                }
                for item in self.rightView.subviews {
                    item.removeFromSuperview()
                }
                let sum  = yDataArr.reduce(0,{$0 + $1})
                self.drawPieChartView()
                self.createRightView(dataArr: modelArr!)
                if sum != 0 {
                    pieChartView.centerText = String(format: "保险\n %.f", sum)
                }else {
                    pieChartView.centerText = ""
                }
                imageView.isHidden = true
                nodataLabel.isHidden = true
                  searchMoreBtn.isHidden = false
                 self.pieChartView.isHidden = false
            }else{
                
                imageView.isHidden = false
                nodataLabel.isHidden = false
                searchMoreBtn.isHidden = true
                self.pieChartView.isHidden = true
                for item in self.rightView.subviews {
                    item.removeFromSuperview()
                }
            }
            
            
        }
    
    }
    
    
    func weiBaoRightView(dataArr:Array<WeiBaoModel>)  {
        for i in 0..<dataArr.count {
            let model = dataArr[i]
            let view = VehicleModelRightView()
            view.frame = CGRect(x: 0, y: CGFloat(i * 20), width: (KW - 30)/2, height: 20)
            view.modelNameLabel.text = model.model ?? ""
            view.numLabel.text = String(format: "%.2f元", model.cost ?? 0)
            view.percentLabel.text = String(format: "%.1f%@", (model.rate ?? 0) * 100 ,"%")
            view.circleView.backgroundColor = colors[i]
            self.rightView.addSubview(view)
        }
        h = CGFloat(dataArr.count * 20)
        updateConstraints()
        
    }
    
    
    
    
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
