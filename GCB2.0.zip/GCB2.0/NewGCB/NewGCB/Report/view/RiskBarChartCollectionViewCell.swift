//
//  RiskBarChartCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/20.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import Charts

class RiskBarChartCollectionViewCell: UICollectionViewCell,ChartViewDelegate {
     //每个分组之间的间隔
     let groupSpace = 0.32
     //同一分组内柱子间隔
     let barSpace = 0.02
     //柱子宽度（ (0.2 + 0.03) * 3 + 0.31 = 1.00 -> interval per "group"）
     let barWidth = 0.32
     
     //每组数据条数
    var groupCount = 7
    
    
    var titleLabel:UILabel!
    var currentView:UIView!
    var currentLabel:UILabel!
    var beforeView:UIView!
    var beforeLabel:UILabel!
    
    var bgView:UIView!
    var dateLabel:UILabel!
    var driverDesLabel:UILabel!
    var bottomCurrentView:UIView!
    var bottomCurrentLabel:UILabel!
    var bottomBeforeView:UIView!
    var bottomBeforeLabel:UILabel!
    var xValueArr:Array<String> = []
    var yValueArr:Array<Int64> = []
    var yPreValueArr:Array<Int64> = []
    
    var xArr:Array<String> = []
    var index:Int = 0
    
     var imageView:UIImageView!
     var nodataLabel:UILabel!
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.clear
        self.initView()
        updateConstraints()
        self.addSubview(self.chartView)
       
        
    }
    
    
    lazy var chartView:BarChartView = {
        let barChartView = BarChartView.init(frame: CGRect.init(x: 10, y: 50, width: KW - 20, height: 160));
        //设置X轴范围
        barChartView.xAxis.axisMinimum = Double(0)
        barChartView.xAxis.centerAxisLabelsEnabled = false  //文字标签居中
       barChartView.xAxis.granularity = 1
        barChartView.xAxis.labelPosition = .bottom
       // barChartView.xAxis.labelCount =
        barChartView.dragDecelerationEnabled = false // 关闭拖拽
        barChartView.doubleTapToZoomEnabled = false //取消双击缩放
        
        
        let scaleX = barChartView.viewPortHandler
        scaleX?.setMinimumScaleX(1.2)
        //设置动画效果，可以设置X轴和Y轴的动画效
        barChartView.animate(yAxisDuration: 0.25)
        
        //设置最右边的不显示
        barChartView.rightAxis.enabled = false
        
        barChartView.leftAxis.axisMinimum = 0;
        //设置y轴颜色
         barChartView.leftAxis.axisLineColor = UIColor.white
        //横网格线颜色
         barChartView.leftAxis.gridColor = UIColor.init(red: 230/255.0, green: 233/255.0, blue: 238/255.0, alpha: 1.0);
        //竖网格线变成白色
        barChartView.xAxis.gridColor = UIColor.init(red: 255/255.0, green: 255/255.0, blue: 255/255.0, alpha: 1.0);
        
        //x轴颜色
        barChartView.xAxis.axisLineColor = UIColor.init(red: 230/255.0, green: 233/255.0, blue: 238/255.0, alpha: 1.0);

        barChartView.xAxis.labelRotationAngle = -30
        
        barChartView.noDataText = "";
        barChartView.noDataTextColor = UIColor.gray;
        barChartView.noDataFont = UIFont.boldSystemFont(ofSize: 14);
        barChartView.xAxis.labelFont = UIFont.systemFont(ofSize: 9.0);
        
        barChartView.delegate = self
        
                
        return barChartView;
        
    }()
    
    func configChartData() {
 
        //第一组数据
        var dataEntries1 = [BarChartDataEntry]()
        for i in 0..<yValueArr.count {
          //  let y = arc4random()%20 + 1
            let entry = BarChartDataEntry(x: Double(i), y: Double(yValueArr[i]))
            dataEntries1.append(entry)
        }
        let chartDataSet1 = BarChartDataSet(entries: dataEntries1, label: "")
        let color1 = UIColor(hex: "#FB6610", alpha: 1.0)
        chartDataSet1.colors = [color1!]
        //图列大小
        chartDataSet1.formSize = 0
        // 是否显示值
        chartDataSet1.drawValuesEnabled = true
        chartDataSet1.highlightEnabled = false //点击选中柱形图是否有高亮效果，（单击空白处取消选中）

        
        //第二组数据
        var dataEntries2 = [BarChartDataEntry]()
        for i in 0..<yPreValueArr.count {
            let entry = BarChartDataEntry(x: Double(i), y: Double(yPreValueArr[i]))
            dataEntries2.append(entry)
        }
        let chartDataSet2 = BarChartDataSet(entries: dataEntries2, label: "")
        let color2 = UIColor(hex: "#CAD2DB", alpha: 1.0)
        chartDataSet2.colors = [color2!]
        chartDataSet2.highlightEnabled = false
        //图列大小
        chartDataSet2.formSize = 0
        // 是否显示值
        chartDataSet2.drawValuesEnabled = true
        
        let chartData = BarChartData(dataSets: [chartDataSet1, chartDataSet2])
        //设置柱子宽度
        chartData.barWidth = Double(barWidth)
        
        if yPreValueArr.count > 15 {
            chartData.setValueFont(UIFont.systemFont(ofSize: 6))
        }else {
            chartData.setValueFont(UIFont.systemFont(ofSize: 10))
        }
        
        
        groupCount = yValueArr.count
//        
//        //对数据进行分组（不重叠显示）
        chartData.groupBars(fromX: Double(0), groupSpace: groupSpace, barSpace: barSpace)
//        
         chartView.xAxis.axisMaximum = Double(0) +
             chartData.groupWidth(groupSpace: groupSpace, barSpace: barSpace) * Double(groupCount)
     
        //设置柱状图数据
        chartView.xAxis.valueFormatter = IndexAxisValueFormatter(values:xValueArr)
  
        let noZeroFormatter = NumberFormatter()
        noZeroFormatter.zeroSymbol = ""
        chartDataSet2.valueFormatter = DefaultValueFormatter(formatter: noZeroFormatter)
        chartDataSet1.valueFormatter = DefaultValueFormatter(formatter: noZeroFormatter)
        
       
        chartView.data = chartData
        chartView.setScaleEnabled(true)
        self.chartView.setVisibleXRangeMaximum(60)
        
        
    }
    
    func configData(model:EnterpriseReportModel,dateStr:String)  {
        let barModel = model.risk
        let barDataArr = barModel?.bar
        let barPreDataArr = barModel?.barPre
        
        
        xArr = barDataArr?.map({ (item) -> String in
            return item.x!
        }) ?? []
        
        xValueArr = barDataArr?.map({ (item) -> String in
            return self.setDateStr(str: item.x!)
        }) ?? []
        yValueArr = barDataArr?.map({ (item) -> Int64 in
            return item.y!
        }) ?? []
        yPreValueArr = barPreDataArr?.map({ (item) -> Int64 in
            return item.y!
        }) ?? []
        
        let max1 = yValueArr.max()
        let max2 = yPreValueArr.max()
        if max1 != 0 || max2 != 0 {
           self.configChartData()
            self.chartView.isHidden = false
        }else {
            yValueArr = []
            yPreValueArr = []
            xValueArr = []
            self.chartView.isHidden = true
        }
        
        if max1 == 0 && max2 == 0 {
            self.nodataLabel.isHidden = false
            self.imageView.isHidden = false
        }else {
            self.nodataLabel.isHidden = true
             self.imageView.isHidden = true
        }
           
      
    }
    
    func setDateStr(str:String) -> String {
//        let milsSum  = yValueArr.reduce(0,{$0 + $1})
//        let milesPreSum = yPreValueArr.reduce(0,{$0 + $1})
//
        if str.count > 5 {
            let dateFmt = DateFormatter()
            dateFmt.dateFormat = "yyyy-MM-dd"
            let date = dateFmt.date(from: str)
            let dateFmt1 = DateFormatter()
            dateFmt1.dateFormat = "MM-dd"
            let dateStr = dateFmt1.string(from: date!)
            return dateStr
        }else {
            return str
        }
        
    }
       
  
    func initView(){
        titleLabel = UILabel()
        titleLabel.text = "风险事件"
        titleLabel.font = UIFont.boldSystemFont(ofSize: 14)
        titleLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(titleLabel)
        
        currentView = UIView()
        currentView.backgroundColor = UIColor(hex: "#FB6610", alpha: 1.0)
        currentView.layer.cornerRadius = 3
        self.contentView.addSubview(currentView)
        
        beforeView = UIView()
        beforeView.backgroundColor = UIColor(hex: "#CAD2DB", alpha: 1.0)
        beforeView.layer.cornerRadius = 3
        self.contentView.addSubview(beforeView)
        
        
        currentLabel = UILabel()
        currentLabel.text = "现在"
        currentLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        currentLabel.font = UIFont.systemFont(ofSize: 10)
        self.contentView.addSubview(currentLabel)
        
        beforeLabel = UILabel()
        beforeLabel.text = "环比"
        beforeLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        beforeLabel.font = UIFont.systemFont(ofSize: 10)
        self.contentView.addSubview(beforeLabel)
        
        imageView = UIImageView()
        imageView.image = UIImage(named: "icon_zanwushuju")
        imageView.isHidden = true
        self.addSubview(imageView)
        
        
       
        nodataLabel = UILabel()
        nodataLabel.text = "暂无数据"
        nodataLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        nodataLabel.font = UIFont.systemFont(ofSize: 15)
        self.addSubview(nodataLabel)
               

   
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.top.equalTo(self.contentView.snp.top).offset(1)
        }
        
        currentView.snp.makeConstraints { (make) in
            make.right.equalTo(self.contentView.snp.right).offset(-100)
            make.centerY.equalTo(titleLabel)
            make.size.equalTo(CGSize(width: 6, height: 6))
        }
        currentLabel.snp.makeConstraints { (make) in
            make.left.equalTo(currentView.snp.right).offset(5)
            make.centerY.equalTo(titleLabel)
        }
        beforeView.snp.makeConstraints { (make) in
            make.left.equalTo(currentLabel.snp.right).offset(10)
            make.centerY.equalTo(titleLabel)
            make.size.equalTo(CGSize(width: 6, height: 6))
        }
        beforeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(beforeView.snp.right).offset(5)
            make.centerY.equalTo(titleLabel)
        }
        
        
        imageView.snp.makeConstraints { (make) in
            make.center.equalTo(self)
            make.size.equalTo(CGSize(width: 81, height: 61))
        }
        
        nodataLabel.snp.makeConstraints { (make) in
            make.top.equalTo(imageView.snp.bottom).offset(18)
            make.centerX.equalTo(self)
        }

        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func showMarkerView(_ value: String) {
         let marker = MarkerView.init(frame: CGRect.init(x: 20, y: 20, width: 60, height: 20));
         marker.chartView = self.chartView;
         let label = UILabel.init(frame: CGRect.init(x: 0, y: 0, width: 60, height: 20));
         label.text = value;
         label.textColor = UIColor(hex: "#1D69F5", alpha: 1.0);
         label.font = UIFont.systemFont(ofSize: 12);
        // label.backgroundColor = UIColor.gray;
         label.textAlignment = .center;
         marker.addSubview(label);
         self.chartView.marker = marker;
     }
        
     func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry, highlight: Highlight) {
         
         // index =  Int(entry.x)
//        if yValueArr.count != 0 {
//           bottomCurrentLabel.text = String(format: "%d", yValueArr[index])
//        }
//
//        if yPreValueArr.count != 0 {
//          bottomBeforeLabel.text = String(format: "%d", yPreValueArr[index])
//        }
         
        // dateLabel.text = xArr[index]
       // self.showMarkerView("\(entry.y)");
     }
    
    
}
