//
//  VehicleWeizhangCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/23.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class VehicleWeizhangCollectionViewCell: UICollectionViewCell {
    var titleLabel:UILabel!
  
    var bgView:UIView!
    var searchMoreBtn:UIButton!
    var searchLabel:UILabel!
    var searchIcon:UIImageView!
    var firstLeftLabel:UILabel!
    var firstNumLabel:UILabel!
    var firsttMoneyLabel:UILabel!
    var lineView:UIView!
    
    var secLeftLabel:UILabel!
    var secNumLabel:UILabel!
    var secMoneyLabel:UILabel!
    var bottomLabel:UILabel!
    @objc var checkMoreClick:(()->Void)?
   
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
         self.backgroundColor = UIColor(hex: "#F5F5F9", alpha: 1.0)
        initView()
        updateConstraints()
    }
    
    func initView(){
        
        bgView = UIView()
        bgView.backgroundColor = UIColor.white
        self.addSubview(bgView)
        
        titleLabel = UILabel()
        titleLabel.font = UIFont.boldSystemFont(ofSize: 13)
        titleLabel.text = "截止：2019-11-25"
        titleLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        bgView.addSubview(titleLabel)
        
        searchMoreBtn = UIButton()
        bgView.addSubview(searchMoreBtn)
        searchLabel = UILabel()
        searchLabel.text = "查看更多"
        searchLabel.font = UIFont.systemFont(ofSize: 12)
        searchLabel.textColor = UIColor(hex: "#1D69F5", alpha: 1.0)
        searchMoreBtn.addSubview(searchLabel)
        searchIcon = UIImageView()
        searchIcon.image = UIImage(named: "baobiao_chakan")
        searchIcon.contentMode = .center
        searchMoreBtn.addSubview(searchIcon)
        searchMoreBtn.addTarget(self, action: #selector(self.searchaMoreEvent), for: .touchUpInside)
        
    
        firstLeftLabel = UILabel()
        firstLeftLabel.text = "已处理"
        firstLeftLabel.font = UIFont.boldSystemFont(ofSize: 15)
        firstLeftLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        bgView.addSubview(firstLeftLabel)
        
        firstNumLabel = UILabel()
        firstNumLabel.text = "12次"
        firstNumLabel.font = UIFont.boldSystemFont(ofSize: 15)
        firstNumLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        bgView.addSubview(firstNumLabel)
        
        firsttMoneyLabel = UILabel()
        firsttMoneyLabel.text = "¥2232"
        firsttMoneyLabel.font = UIFont.boldSystemFont(ofSize: 15)
        firsttMoneyLabel.textColor = UIColor(hex: "#FB6610", alpha: 1.0)
        bgView.addSubview(firsttMoneyLabel)

        lineView = UIView()
        bgView.addSubview(lineView)
        lineView.backgroundColor = UIColor(hex: "#E6E9EE", alpha: 1.0)
//

        secLeftLabel = UILabel()
        secLeftLabel.text = "未处理"
        secLeftLabel.font = UIFont.boldSystemFont(ofSize: 15)
        secLeftLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        bgView.addSubview(secLeftLabel)
        
        secNumLabel = UILabel()
        secNumLabel.text = "12次"
        secNumLabel.font = UIFont.boldSystemFont(ofSize: 15)
        secNumLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        bgView.addSubview(secNumLabel)
        
        secMoneyLabel = UILabel()
        secMoneyLabel.text = "¥2232"
        secMoneyLabel.font = UIFont.boldSystemFont(ofSize: 15)
        secMoneyLabel.textColor = UIColor(hex: "#FB6610", alpha: 1.0)
        bgView.addSubview(secMoneyLabel)
        
        
        bottomLabel = UILabel()
        bottomLabel.text = "共计发生事故: 5次"
        bottomLabel.font = UIFont.systemFont(ofSize: 13)
        bottomLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        bgView.addSubview(bottomLabel)
        
      
    }
    
    @objc  func searchaMoreEvent()  {
        self.checkMoreClick?()
        
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        
        bgView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self.snp.top).offset(0)
            make.size.equalTo(CGSize(width: KW - 30, height: 170))
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(bgView.snp.left).offset(8)
            make.top.equalTo(bgView.snp.top).offset(10)
        }
        
        searchMoreBtn.snp.makeConstraints { (make) in
            make.right.equalTo(bgView.snp.right).offset(-8)
            make.top.equalTo(bgView.snp.top).offset(10)
            make.size.equalTo(CGSize(width: 65, height: 20))
        }
        
        searchLabel.snp.makeConstraints { (make) in
            make.left.equalTo(searchMoreBtn.snp.left).offset(0)
            make.centerY.equalTo(searchMoreBtn)
        }
        
        searchIcon.snp.makeConstraints { (make) in
            make.left.equalTo(searchLabel.snp.right).offset(2)
            make.centerY.equalTo(searchMoreBtn)
            make.size.equalTo(CGSize(width: 10, height: 20))
        }
        
     
        firstLeftLabel.snp.makeConstraints { (make) in
            make.left.equalTo(bgView.snp.left).offset(32)
           make.top.equalTo(titleLabel.snp.bottom).offset(30)
        }
        
        firstNumLabel.snp.makeConstraints { (make) in
            make.left.equalTo(titleLabel.snp.right).offset(57)
            make.top.equalTo(titleLabel.snp.bottom).offset(30)
        }

        firsttMoneyLabel.snp.makeConstraints { (make) in
         make.right.equalTo(bgView.snp.right).offset(-28)
         make.top.equalTo(titleLabel.snp.bottom).offset(30)
        }

        lineView.snp.makeConstraints { (make) in
            make.left.equalTo(bgView.snp.left).offset(8)
            make.right.equalTo(bgView.snp.right).offset(-8)
            make.top.equalTo(firstLeftLabel.snp.bottom).offset(10)
            make.height.equalTo(1)
        }

        secLeftLabel .snp.makeConstraints { (make) in
            make.left.equalTo(bgView.snp.left).offset(32)
            make.top.equalTo(lineView.snp.bottom).offset(10)
        }
        secNumLabel.snp.makeConstraints { (make) in
            make.left.equalTo(titleLabel.snp.right).offset(57)
            make.top.equalTo(lineView.snp.bottom).offset(10)
        }

        secMoneyLabel.snp.makeConstraints { (make) in
            make.right.equalTo(bgView.snp.right).offset(-28)
            make.top.equalTo(lineView.snp.bottom).offset(10)
        }
        bottomLabel.snp.makeConstraints { (make) in
            make.right.equalTo(bgView.snp.right).offset(-24)
            make.bottom.equalTo(bgView.snp.bottom).offset(-10)
        }
    }
    
    func configData(dataModel:VehicleManagerModel){
        let  model = dataModel.violateRule
        firstNumLabel.text = String(format: "%d次", model?.processed ?? 0)
        firsttMoneyLabel.text = String(format: "¥%.2f", model?.processedCost ?? 0.0)
        secNumLabel.text = String(format: "%d次", model?.unprocessed ?? 0)
        secMoneyLabel.text = String(format: "¥%.2f", model?.unprocessedCost ?? 0.0)
        bottomLabel.text = String(format: "共计发生事故:%d次", model?.processed ?? 0 + (model?.unprocessed ?? 0))
       }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
