//
//  VDChartAxisVehicleValueFormatter.swift
//  NewGCB
//
//  Created by YTKJ on 2020/1/15.
//  Copyright © 2020 YTKJ. All rights reserved.
//

import UIKit
import Charts

class VDChartAxisVehicleValueFormatter: NSObject,IAxisValueFormatter {
    var values:NSArray?;
    override init() {
        super.init();
    }
    init(_ values: NSArray) {
        super.init();
        self.values = values;
    }
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        if values == nil {
            return "\(value)";
        }
        let str = values?.object(at: Int(value)) as! String;
        return str;
    }
}
