//
//  DriverOperatedStatusCell.swift
//  NewGCB
//
//  Created by 亭子 on 2020/1/14.
//  Copyright © 2020 YTKJ. All rights reserved.
//

import UIKit

class DriverOperatedStatusCell: UICollectionViewCell {
    var firstView:UIView!
    var seconView:UIView!
    
    var driverFirstLeftView:EnterpriseView!
    var driverFirstRightView:EnterpriseView!
    
    var driverSecLeftView:EnterpriseView!
    var driverSecRightView:EnterpriseView!
    
    
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        initView()
        updateConstraints()
    }
    
    
    func initView(){
        
        
        firstView = UIView()
        firstView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        firstView.layer.cornerRadius = 4
        self.contentView.addSubview(firstView)
        
        seconView = UIView()
        seconView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        seconView.layer.cornerRadius = 4
        self.contentView.addSubview( seconView)
        
        driverFirstLeftView = EnterpriseView()
        driverFirstLeftView.topValueLabel.text = "870"
        driverFirstLeftView.desLabel.text = "出勤天数(天)"
        driverFirstLeftView.mileBgView.isHidden = true
        self.contentView.addSubview(driverFirstLeftView)
        driverFirstRightView = EnterpriseView()
        driverFirstRightView.topValueLabel.text = "98.2%"
        driverFirstRightView.desLabel.text = "出勤率"
        driverFirstRightView.mileBgView.isHidden = true
        self.contentView.addSubview(driverFirstRightView)
        
        
        driverSecLeftView = EnterpriseView()
        driverSecLeftView.topValueLabel.text = "6"
        driverSecLeftView.desLabel.text = "日均行驶公里"
        driverSecLeftView.mileBgView.isHidden = true
        self.contentView.addSubview(driverSecLeftView)
        driverSecRightView = EnterpriseView()
        driverSecRightView.topValueLabel.text = "0.8%"
        driverSecRightView.desLabel.text = "日均行驶时长(小时)"
        driverSecRightView.mileBgView.isHidden = true
        self.contentView.addSubview(driverSecRightView)
        
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        
        
        firstView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self.snp.top).offset(10)
            make.size.equalTo(CGSize(width: (KW - 30), height: 68))
        }
        seconView.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.left).offset(0)
            make.top.equalTo(firstView.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 30), height: 68))
        }
        
        driverFirstLeftView.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.left).offset(30)
            make.top.equalTo(firstView.snp.top).offset(12)
        }
        driverFirstRightView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(KW/2 + 20)
            make.top.equalTo(firstView.snp.top).offset(12)
        }
        
        
        driverSecLeftView.snp.makeConstraints { (make) in
            make.left.equalTo(seconView.snp.left).offset(30)
            make.top.equalTo(seconView.snp.top).offset(12)
        }
        driverSecRightView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(KW/2 + 20)
            make.top.equalTo(seconView.snp.top).offset(12)
        }
    }
    
    func setOperatedModel(model:DriverReportRunningInfo) {
        
        driverFirstLeftView.topValueLabel.text = String(format: "%d", model.attendDays ?? 0)
        
        driverFirstRightView.topValueLabel.text = String(format: "%.2f", model.rate ?? 0.0)
        
        driverSecLeftView.topValueLabel.text = String(format: "%d", model.milsPerDay ?? 0.0)
        
        driverSecRightView.topValueLabel.text = String(format: "%.2f", model.durationPerDay ?? 0.0)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
