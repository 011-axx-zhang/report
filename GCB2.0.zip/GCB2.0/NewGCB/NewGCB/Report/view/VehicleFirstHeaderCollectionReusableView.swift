//
//  VehicleFirstHeaderCollectionReusableView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/23.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class VehicleFirstHeaderCollectionReusableView: UICollectionReusableView {
         var bgView:UIView!
         var searchMoreBtn:UIButton!
         var searchLabel:UILabel!
         var searchIcon:UIImageView!
         var titleLabel:UILabel!
         @objc var checkMoreClick:(()->Void)?
         
         
         override init(frame: CGRect) {
             super.init(frame: frame)
             self.backgroundColor = UIColor(hex: "#F5F5F9", alpha: 1.0)
             self.createUI()
             self.updateConstraints()
         }
         
         private func createUI() {
             bgView = UIView()
             bgView.backgroundColor = UIColor.white
             self.addSubview(bgView)
             
             titleLabel = UILabel()
             titleLabel.font = UIFont.boldSystemFont(ofSize: 15)
             titleLabel.text = "车型数量"
             titleLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
             bgView.addSubview(titleLabel)
             
             searchMoreBtn = UIButton()
             bgView.addSubview(searchMoreBtn)
             searchLabel = UILabel()
             searchLabel.text = "查看更多"
             searchLabel.font = UIFont.systemFont(ofSize: 12)
             searchLabel.textColor = UIColor(hex: "#1D69F5", alpha: 1.0)
             searchMoreBtn.addSubview(searchLabel)
             searchIcon = UIImageView()
             searchIcon.image = UIImage(named: "baobiao_chakan")
             searchIcon.contentMode = .center
             searchMoreBtn.addSubview(searchIcon)
             searchMoreBtn.addTarget(self, action: #selector(self.searchaMoreEvent), for: .touchUpInside)
         }
         
        @objc  func searchaMoreEvent()  {
         self.checkMoreClick?()
             
         }
         
         override func updateConstraints() {
             super.updateConstraints()
            
             bgView.snp.makeConstraints { (make) in
                 make.left.equalTo(self.snp.left).offset(15)
                 make.top.equalTo(self.snp.top).offset(10)
                 make.size.equalTo(CGSize(width: KW - 30, height: 40))
             }
             
             titleLabel.snp.makeConstraints { (make) in
                  make.left.equalTo(bgView.snp.left).offset(8)
                  make.top.equalTo(bgView.snp.top).offset(10)
             }
             
            searchMoreBtn.snp.makeConstraints { (make) in
                make.right.equalTo(bgView.snp.right).offset(-8)
                make.centerY.equalTo(bgView)
                make.size.equalTo(CGSize(width: 65, height: 20))
            }
             
             searchLabel.snp.makeConstraints { (make) in
                 make.left.equalTo(searchMoreBtn.snp.left).offset(0)
                 make.centerY.equalTo(searchMoreBtn)
             }
             
             searchIcon.snp.makeConstraints { (make) in
                 make.left.equalTo(searchLabel.snp.right).offset(2)
                 make.centerY.equalTo(searchMoreBtn)
                 make.size.equalTo(CGSize(width: 10, height: 20))
             }
             
         }
         required init?(coder aDecoder: NSCoder) {
             fatalError("init(coder:) has not been implemented")
         }
}
