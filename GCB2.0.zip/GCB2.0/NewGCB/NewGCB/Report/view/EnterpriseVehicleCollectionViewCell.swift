//
//  EnterpriseVehicleCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/19.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class EnterpriseVehicleCollectionViewCell: UICollectionViewCell {
    
    var firstView:UIView!
    var seconView:UIView!
    var thirdView:UIView!
    
    var vehicleFirstLeftView:EnterpriseView!
    var vehicleFirstRightView:EnterpriseView!
    
    var vehicleSecLeftView:EnterpriseView!
    var vehicleSecRightView:EnterpriseView!
    
    var vehicleThirdLeftView:EnterpriseView!
    var vehicleThirdRightView:EnterpriseView!
    
    var weibaoView:EnterpriseVehicleBottomView!
    var shiguView:EnterpriseVehicleBottomView!
    var weizhangView:EnterpriseVehicleBottomView!
    var baoxianView:EnterpriseVehicleBottomView!
    
    
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        initView()
        updateConstraints()
    }
    
    
    func initView(){
        
        
        firstView = UIView()
        firstView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        firstView.layer.cornerRadius = 4
        self.contentView.addSubview(firstView)
        
        seconView = UIView()
        seconView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        seconView.layer.cornerRadius = 4
        self.contentView.addSubview( seconView)
        
        thirdView = UIView()
        thirdView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        thirdView.layer.cornerRadius = 4
        self.contentView.addSubview(thirdView)
        
        
        vehicleFirstLeftView = EnterpriseView()
        vehicleFirstLeftView.topValueLabel.text = "870"
        vehicleFirstLeftView.desLabel.text = "运营车辆"
        self.contentView.addSubview(vehicleFirstLeftView)
        vehicleFirstRightView = EnterpriseView()
        vehicleFirstRightView.topValueLabel.text = "98.2%"
        vehicleFirstRightView.desLabel.text = "运营率"
        self.contentView.addSubview(vehicleFirstRightView)
        
        
        vehicleSecLeftView = EnterpriseView()
        vehicleSecLeftView.topValueLabel.text = "6"
        vehicleSecLeftView.desLabel.text = "停驶车辆(辆)"
        self.contentView.addSubview(vehicleSecLeftView)
        vehicleSecRightView = EnterpriseView()
        vehicleSecRightView.topValueLabel.text = "0.8%"
        vehicleSecRightView.desLabel.text = "停驶车辆占比"
        self.contentView.addSubview(vehicleSecRightView)
        
      
        vehicleThirdLeftView = EnterpriseView()
        vehicleThirdLeftView.topValueLabel.text = "303.2"
        vehicleThirdLeftView.desLabel.text = "车均行驶公里"
        self.contentView.addSubview(vehicleThirdLeftView)
        vehicleThirdRightView = EnterpriseView()
        vehicleThirdRightView.topValueLabel.text = "4.5"
        vehicleThirdRightView.desLabel.text = "车均行驶时长(小时)"
        self.contentView.addSubview(vehicleThirdRightView)
        
        
        weibaoView = EnterpriseVehicleBottomView()
        weibaoView.topValueLabel.text = "686"
        weibaoView.desLabel.text = "维保次数"
        self.contentView.addSubview(weibaoView)
        
        shiguView = EnterpriseVehicleBottomView()
        shiguView.topValueLabel.text = "6"
        shiguView.desLabel.text = "事故次数"
        self.contentView.addSubview(shiguView)

        weizhangView = EnterpriseVehicleBottomView()
        weizhangView.topValueLabel.text = "257"
        weizhangView.desLabel.text = "违章次数"
        self.contentView.addSubview(weizhangView)

        baoxianView = EnterpriseVehicleBottomView()
        baoxianView.topValueLabel.text = "409"
        baoxianView.desLabel.text = "保险即将到期"
        self.contentView.addSubview(baoxianView)
        
  
       
        
        
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        
        
        firstView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self.snp.top).offset(10)
            make.size.equalTo(CGSize(width: (KW - 30), height: 68))
        }
        seconView.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.left).offset(0)
            make.top.equalTo(firstView.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 30), height: 68))
        }
        
        thirdView.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.left).offset(0)
            make.top.equalTo(seconView.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 30), height: 68))
        }
        
        vehicleFirstLeftView.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.left).offset(30)
            make.top.equalTo(firstView.snp.top).offset(12)
        }
        vehicleFirstRightView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(KW/2 + 20)
            make.top.equalTo(firstView.snp.top).offset(12)
        }
  
        
        vehicleSecLeftView.snp.makeConstraints { (make) in
            make.left.equalTo(seconView.snp.left).offset(30)
            make.top.equalTo(seconView.snp.top).offset(12)
        }
        vehicleSecRightView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(KW/2 + 20)
            make.top.equalTo(seconView.snp.top).offset(12)
        }
        
        vehicleThirdLeftView.snp.makeConstraints { (make) in
            make.left.equalTo(thirdView.snp.left).offset(30)
            make.top.equalTo(thirdView.snp.top).offset(12)
        }
        vehicleThirdRightView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(KW/2 + 20)
            make.top.equalTo(thirdView.snp.top).offset(12)
        }
        
        weibaoView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(38)
            make.top.equalTo(thirdView.snp.bottom).offset(24)
        }
        
        shiguView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset( KW*1/4 + 30)
            make.top.equalTo(thirdView.snp.bottom).offset(24)
        }

      weizhangView.snp.makeConstraints { (make) in
              make.left.equalTo(self.snp.left).offset( KW*2/4 + 20)
            make.top.equalTo(thirdView.snp.bottom).offset(24)
        }

        baoxianView.snp.makeConstraints { (make) in
              make.left.equalTo(self.snp.left).offset( KW*3/4 + 20)
            make.top.equalTo(thirdView.snp.bottom).offset(24)
        }
    
        
    }
    
    func configData(model:EnterpriseReportModel) {
          let model = model.vehsInfo
        
        vehicleFirstLeftView.topValueLabel.text = String(format: "%d", model?.runVehs ?? 0.0)
       
        if model!.runVehsYOY! > 0.0 {
            vehicleFirstLeftView.mileTotalIcon.isHidden = false
            vehicleFirstLeftView.mileTotalIcon.image = UIImage(named: "report_tigao")
            vehicleFirstLeftView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            vehicleFirstLeftView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
             vehicleFirstLeftView.mileTotalLabel.text = String(format: "%.1f%@", (model?.runVehsYOY ?? 0) * 100,"%")
        }else if model!.runVehsYOY! < 0.0{
            vehicleFirstLeftView.mileTotalIcon.isHidden = false
            vehicleFirstLeftView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            vehicleFirstLeftView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            vehicleFirstLeftView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
             vehicleFirstLeftView.mileTotalLabel.text = String(format: "%.1f%@", -(model?.runVehsYOY ?? 0) * 100,"%")
        }else if model!.runVehsYOY! == 0.0{
            vehicleFirstLeftView.mileTotalIcon.isHidden = true
            vehicleFirstLeftView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            vehicleFirstLeftView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
             vehicleFirstLeftView.mileTotalLabel.text = String(format: "%.1f%@", (model?.runVehsYOY ?? 0) * 100,"%")
        }
        
        vehicleFirstRightView.topValueLabel.text = String(format: "%.1f%@", (model?.runRate ?? 0)*100,"%")
        
        if model!.runRateYOY! > 0.0 {
            vehicleFirstRightView.mileTotalIcon.isHidden = false
            vehicleFirstRightView.mileTotalIcon.image = UIImage(named: "report_tigao")
            vehicleFirstRightView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            vehicleFirstRightView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
            vehicleFirstRightView.mileTotalLabel.text = String(format: "%.1f%@", (model?.runRateYOY ?? 0) * 100,"%")
        }else if model!.runRateYOY! < 0.0 {
            vehicleFirstRightView.mileTotalIcon.isHidden = false
            vehicleFirstRightView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            vehicleFirstRightView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            vehicleFirstRightView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
            vehicleFirstRightView.mileTotalLabel.text = String(format: "%.1f%@", -(model?.runRateYOY ?? 0) * 100,"%")
        }else if model!.runRateYOY! == 0.0 {
           vehicleFirstRightView.mileTotalIcon.isHidden = true
            vehicleFirstRightView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            vehicleFirstRightView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            vehicleFirstRightView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
            vehicleFirstRightView.mileTotalLabel.text = String(format: "%.1f%@", (model?.runRateYOY ?? 0) * 100,"%")
        }
        
        vehicleSecLeftView.topValueLabel.text = String(format: "%d", model?.stopVehs ?? 0 )
        
        if model!.stopVehsYOY! > 0.0 {
             vehicleSecLeftView.mileTotalIcon.isHidden = false
            vehicleSecLeftView.mileTotalIcon.image = UIImage(named: "report_tigao")
            vehicleSecLeftView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            vehicleSecLeftView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
            vehicleSecLeftView.mileTotalLabel.text = String(format: "%.1f%@", (model?.stopVehsYOY ?? 0) * 100,"%")
        }else if model!.stopVehsYOY! < 0.0{
             vehicleSecLeftView.mileTotalIcon.isHidden = false
            vehicleSecLeftView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            vehicleSecLeftView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            vehicleSecLeftView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
            vehicleSecLeftView.mileTotalLabel.text = String(format: "%.1f%@", -(model?.stopVehsYOY ?? 0) * 100,"%")
        }else if model!.stopVehsYOY! == 0.0{
            vehicleSecLeftView.mileTotalIcon.isHidden = true
            vehicleSecLeftView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            vehicleSecLeftView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
            vehicleSecLeftView.mileTotalLabel.text = String(format: "%.1f%@", (model?.stopVehsYOY ?? 0) * 100,"%")
        }
        
        
        vehicleSecRightView.topValueLabel.text = String(format: "%.1f%@", (model?.stopVehsRate ?? 0) * 100  ,"%")
        
        if model!.stopVehsRateYOY! > 0.0 {
            vehicleSecRightView.mileTotalIcon.isHidden = false
            vehicleSecRightView.mileTotalIcon.image = UIImage(named: "report_tigao")
            vehicleSecRightView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            vehicleSecRightView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
            vehicleSecRightView.mileTotalLabel.text = String(format: "%.1f%@", (model?.stopVehsRateYOY ?? 0) * 100,"%")
        }else if model!.stopVehsRateYOY! < 0.0  {
            vehicleSecRightView.mileTotalIcon.isHidden = false
            vehicleSecRightView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            vehicleSecRightView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            vehicleSecRightView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
            vehicleSecRightView.mileTotalLabel.text = String(format: "%.1f%@", -(model?.stopVehsRateYOY ?? 0) * 100,"%")
        }else if model!.stopVehsRateYOY! == 0.0  {
            vehicleSecRightView.mileTotalIcon.isHidden = true
            vehicleSecRightView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            vehicleSecRightView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
            vehicleSecRightView.mileTotalLabel.text = String(format: "%.1f%@", (model?.stopVehsRateYOY ?? 0) * 100,"%")
        }
        
        
        vehicleThirdLeftView.topValueLabel.text = String(format: "%.2f", model?.milsPerVeh ?? 0.0)
       
        if model!.milsPerVehYOY! > 0.0 {
            vehicleThirdLeftView.mileTotalIcon.isHidden = false
            vehicleThirdLeftView.mileTotalIcon.image = UIImage(named: "report_tigao")
            vehicleThirdLeftView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            vehicleThirdLeftView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
             vehicleThirdLeftView.mileTotalLabel.text = String(format: "%.1f%@", (model?.milsPerVehYOY ?? 0) * 100,"%")
        }else if model!.milsPerVehYOY! < 0.0 {
            vehicleThirdLeftView.mileTotalIcon.isHidden = false
            vehicleThirdLeftView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            vehicleThirdLeftView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            vehicleThirdLeftView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
             vehicleThirdLeftView.mileTotalLabel.text = String(format: "%.1f%@", -(model?.milsPerVehYOY ?? 0) * 100,"%")
        }else if model!.milsPerVehYOY! == 0.0 {
            vehicleThirdLeftView.mileTotalIcon.isHidden = true
            vehicleThirdLeftView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            vehicleThirdLeftView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
             vehicleThirdLeftView.mileTotalLabel.text = String(format: "%.1f%@", (model?.milsPerVehYOY ?? 0) * 100,"%")
        }
        
        
        vehicleThirdRightView.topValueLabel.text = String(format: "%.2f", model?.durationPerDayVeh ?? 0.0)
        
        if model!.durationPerDayVehYOY! > 0.0 {
             vehicleThirdRightView.mileTotalIcon.isHidden = false
            vehicleThirdRightView.mileTotalIcon.image = UIImage(named: "report_tigao")
            vehicleThirdRightView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            vehicleThirdRightView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
            vehicleThirdRightView.mileTotalLabel.text = String(format: "%.1f%@", (model?.durationPerDayVehYOY ?? 0) * 100,"%")
        }else if model!.durationPerDayVehYOY! < 0.0{
             vehicleThirdRightView.mileTotalIcon.isHidden = false
            vehicleThirdRightView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            vehicleThirdRightView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            vehicleThirdRightView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
            vehicleThirdRightView.mileTotalLabel.text = String(format: "%.1f%@", -(model?.durationPerDayVehYOY ?? 0) * 100,"%")
        }else if model!.durationPerDayVehYOY! == 0.0{
             vehicleThirdRightView.mileTotalIcon.isHidden = true
            vehicleThirdRightView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            vehicleThirdRightView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
            vehicleThirdRightView.mileTotalLabel.text = String(format: "%.1f%@", (model?.durationPerDayVehYOY ?? 0) * 100,"%")
        }
        
        weibaoView.topValueLabel.text = String(format: "%d", model?.maintenance ?? 0)
        shiguView.topValueLabel.text = String(format: "%d", model?.accident ?? 0)
        weizhangView.topValueLabel.text = String(format: "%d", model?.violateRule ?? 0)
        baoxianView.topValueLabel.text = String(format: "%d", model?.insuranceExpires ?? 0)
        
        
        
        
        
        
          
      }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
