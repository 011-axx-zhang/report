//
//  VehicleLastHeaderCollectionReusableView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/23.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class VehicleLastHeaderCollectionReusableView: UICollectionReusableView {
    var weizhangBtn:UIButton!
    var shiguBtn:UIButton!
    var weibaoBtn:UIButton!
    var baoxianBtn:UIButton!
    var selectedBtn:UIButton!
    @objc var dangAnClick:((Int)->Void)?
    
   
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor(hex: "#F5F5F9", alpha: 1.0)
        self.createUI()
        self.updateConstraints()
    }
    
    private func createUI() {
        weizhangBtn = UIButton()
        weizhangBtn.layer.cornerRadius = 16
        weizhangBtn.setTitle("车辆违章", for: .normal)
        weizhangBtn.layer.borderWidth = 1
        weizhangBtn.layer.borderColor = UIColor(hex: "#1D69F5", alpha: 1.0)?.cgColor
        weizhangBtn.setTitleColor(UIColor(hex: "#1D69F5", alpha: 1.0), for: .normal)
        weizhangBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        weizhangBtn.tag = 190001
        weizhangBtn.addTarget(self, action: #selector(self.btnEvent(sender:)), for: .touchUpInside)
        selectedBtn = weizhangBtn
        self.addSubview(weizhangBtn)
        
        shiguBtn = UIButton()
        shiguBtn.layer.cornerRadius = 16
        shiguBtn.setTitle("车辆事故", for: .normal)
        shiguBtn.layer.borderWidth = 1
        shiguBtn.layer.borderColor = UIColor(hex: "#9395AC", alpha: 1.0)?.cgColor
        shiguBtn.setTitleColor(UIColor(hex: "#5C5E74", alpha: 1.0), for: .normal)
        shiguBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        shiguBtn.tag = 190002
        shiguBtn.addTarget(self, action: #selector(self.btnEvent(sender:)), for: .touchUpInside)
        self.addSubview(shiguBtn)
        
        weibaoBtn = UIButton()
        weibaoBtn.layer.cornerRadius = 16
        weibaoBtn.setTitle("车辆维保", for: .normal)
        weibaoBtn.layer.borderWidth = 1
        weibaoBtn.layer.borderColor = UIColor(hex: "#9395AC", alpha: 1.0)?.cgColor
        weibaoBtn.setTitleColor(UIColor(hex: "#5C5E74", alpha: 1.0), for: .normal)
        weibaoBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        weibaoBtn.tag = 190003
        weibaoBtn.addTarget(self, action: #selector(self.btnEvent(sender:)), for: .touchUpInside)
        self.addSubview(weibaoBtn)
        
        baoxianBtn = UIButton()
        baoxianBtn.layer.cornerRadius = 16
        baoxianBtn.setTitle("保险即将到期", for: .normal)
        baoxianBtn.layer.borderWidth = 1
        baoxianBtn.layer.borderColor = UIColor(hex: "#9395AC", alpha: 1.0)?.cgColor
        baoxianBtn.setTitleColor(UIColor(hex: "#5C5E74", alpha: 1.0), for: .normal)
        baoxianBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        baoxianBtn.tag = 190004
        baoxianBtn.addTarget(self, action: #selector(self.btnEvent(sender:)), for: .touchUpInside)
        self.addSubview(baoxianBtn)
        
    }
    
    
    @objc  func btnEvent(sender:UIButton)  {
        selectedBtn.layer.borderColor = UIColor(hex: "#9395AC", alpha: 1.0)?.cgColor
        selectedBtn.setTitleColor(UIColor(hex: "#5C5E74", alpha: 1.0), for: .normal)
        sender.layer.borderColor = UIColor(hex: "#1D69F5", alpha: 1.0)?.cgColor
        sender.setTitleColor(UIColor(hex: "#1D69F5", alpha: 1.0), for: .normal)
        selectedBtn = sender
        self.dangAnClick?(sender.tag - 190000)
        
    }
   
    
    override func updateConstraints() {
        super.updateConstraints()
        weizhangBtn.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self.snp.top).offset(10)
            make.size.equalTo(CGSize(width: (KW - 108 - 30 - 15)/3, height: 30))
        }
        shiguBtn.snp.makeConstraints { (make) in
            make.left.equalTo(weizhangBtn.snp.right).offset(5)
            make.top.equalTo(self.snp.top).offset(10)
            make.size.equalTo(CGSize(width: (KW - 108 - 30 - 15)/3, height: 30))
        }
        
        weibaoBtn.snp.makeConstraints { (make) in
            make.left.equalTo(shiguBtn.snp.right).offset(5)
            make.top.equalTo(self.snp.top).offset(10)
            make.size.equalTo(CGSize(width: (KW - 108 - 30 - 15)/3, height: 30))
        }
        baoxianBtn.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp.right).offset(-15)
            make.top.equalTo(self.snp.top).offset(10)
            make.size.equalTo(CGSize(width: 108, height: 30))
        }
        
        
        
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
