//
//  MileChartCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/19.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import Charts

class MileChartCollectionViewCell: UICollectionViewCell, ChartViewDelegate {
    var chartView: LineChartView!
    var titleLabel:UILabel!
    var currentView:UIView!
    var currentLabel:UILabel!
    var beforeView:UIView!
    var beforeLabel:UILabel!
    
    var bgView:UIView!
    var dateLabel:UILabel!
    var driverDesLabel:UILabel!
    var bottomCurrentView:UIView!
    var bottomCurrentLabel:UILabel!
    var bottomBeforeView:UIView!
    var bottomBeforeLabel:UILabel!
    var xValueArr:Array<String> = []
    var yValueArr:Array<Double> = []
    var yPreValueArr:Array<Double> = []
    var xArr:Array<String> = []
    var index:Int = 0
    
    var yValueStrArr:Array<String> = []
    var yPreValueStrArr:Array<String> = []
    
    
    // 当日 4个小时一组
    // 30天 5天一组
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        self.addSubview(lineChartView)
        self.initView()
        updateConstraints()
    }
    
    func initView(){
        titleLabel = UILabel()
        titleLabel.text = "行驶里程表(km)"
        titleLabel.font = UIFont.boldSystemFont(ofSize: 14)
        titleLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(titleLabel)
        
        currentView = UIView()
        currentView.backgroundColor = UIColor(hex: "#1D69F5", alpha: 1.0)
        currentView.layer.cornerRadius = 3
        self.contentView.addSubview(currentView)
        
        beforeView = UIView()
        beforeView.backgroundColor = UIColor(hex: "#CAD2DB", alpha: 1.0)
        beforeView.layer.cornerRadius = 3
        self.contentView.addSubview(beforeView)
        
        
        currentLabel = UILabel()
        currentLabel.text = "现在"
        currentLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        currentLabel.font = UIFont.systemFont(ofSize: 10)
        self.contentView.addSubview(currentLabel)
        
        beforeLabel = UILabel()
        beforeLabel.text = "环比"
        beforeLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        beforeLabel.font = UIFont.systemFont(ofSize: 10)
        self.contentView.addSubview(beforeLabel)
        
//        bgView = UIView()
//        bgView.backgroundColor = UIColor(hex: "#EAF1FC", alpha: 1.0)
//        self.contentView.addSubview(bgView)
//
//        dateLabel = UILabel()
//        dateLabel.text = ""
//        dateLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
//        dateLabel.font = UIFont.systemFont(ofSize: 12)
//        self.contentView.addSubview(dateLabel)
        

        
        
        
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.top.equalTo(self.contentView.snp.top).offset(1)
        }
        
        currentView.snp.makeConstraints { (make) in
            make.right.equalTo(self.contentView.snp.right).offset(-100)
            make.centerY.equalTo(titleLabel)
            make.size.equalTo(CGSize(width: 6, height: 6))
        }
        currentLabel.snp.makeConstraints { (make) in
            make.left.equalTo(currentView.snp.right).offset(5)
            make.centerY.equalTo(titleLabel)
        }
        beforeView.snp.makeConstraints { (make) in
            make.left.equalTo(currentLabel.snp.right).offset(10)
            make.centerY.equalTo(titleLabel)
            make.size.equalTo(CGSize(width: 6, height: 6))
        }
        beforeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(beforeView.snp.right).offset(5)
            make.centerY.equalTo(titleLabel)
        }
        
  
//        bgView.snp.makeConstraints { (make) in
//            make.left.equalTo(self.contentView.snp.left).offset(0)
//            make.top.equalTo(titleLabel.snp.bottom).offset(5)
//            make.size.equalTo(CGSize(width: KW, height: 24))
//        }
//        dateLabel.snp.makeConstraints { (make) in
//            make.left.equalTo(bgView.snp.left).offset(20)
//            make.centerY.equalTo(bgView)
//        }
        

        
        
    }
    

    lazy var lineChartView:LineChartView = {
        let _lineChartView = LineChartView.init(frame: CGRect.init(x: 10, y: 25, width: KW - 20, height: 200));
        _lineChartView.delegate = self //
        //_lineChartView.backgroundColor = UIColor.init(red: 230/255.0, green: 253/255.0, blue: 253/255.0, alpha: 1.0);
        _lineChartView.doubleTapToZoomEnabled = false;
        _lineChartView.scaleXEnabled = false;
        _lineChartView.scaleYEnabled = false;
        _lineChartView.chartDescription?.text = "";//设置为""隐藏描述文字
        
        _lineChartView.noDataText = "暂无数据";
        _lineChartView.noDataTextColor = UIColor.gray;
        _lineChartView.noDataFont = UIFont.boldSystemFont(ofSize: 14);
       // _lineChartView.drawGridBackgroundEnabled = false
        _lineChartView.xAxis.labelRotationAngle = -50
    
        //y轴
        _lineChartView.rightAxis.enabled = false;
        let leftAxis = _lineChartView.leftAxis;
        leftAxis.labelCount = 5;
        leftAxis.forceLabelsEnabled = false;
        leftAxis.axisLineColor = UIColor.white;
        leftAxis.labelTextColor = UIColor.black;
        leftAxis.labelFont = UIFont.systemFont(ofSize: 10);
        leftAxis.labelPosition = .outsideChart;
        leftAxis.gridAntialiasEnabled = false;//抗锯齿
      //  leftAxis.axisMaximum = 1000;//最大值
        leftAxis.axisMinimum = 0;
        leftAxis.labelCount = 5;//多少等分
    
        _lineChartView.leftAxis.drawGridLinesEnabled = true; // 网格绘制
         //网格线颜色
        _lineChartView.leftAxis.gridColor = UIColor.init(red: 230/255.0, green: 233/255.0, blue: 238/255.0, alpha: 1.0);
        _lineChartView.leftAxis.drawAxisLineEnabled = false; // 是否显示轴线
        //y轴颜色
        _lineChartView.leftAxis.axisLineColor =  UIColor(hex: "#E6E9EE", alpha: 1.0)!
        
        //x轴
        let xAxis = _lineChartView.xAxis;
        xAxis.granularityEnabled = false;
        xAxis.labelTextColor = UIColor.black;
        xAxis.labelFont = UIFont.systemFont(ofSize: 9.0);
        xAxis.labelPosition = .bottom;
        _lineChartView.xAxis.drawGridLinesEnabled = false //网格绘制
        //网格线颜色
        _lineChartView.xAxis.gridColor = UIColor.red
        _lineChartView.xAxis.drawAxisLineEnabled = true; // 是否显示轴线
        //x轴颜色
        _lineChartView.xAxis.axisLineColor = UIColor(hex: "#E6E9EE", alpha: 1.0)!

        xAxis.labelCount = 6;
        xAxis.axisLineWidth = 1.5
        return _lineChartView;
    }()
    
    
    func drawLineChart(){
//        let xValues = ["11-01","11-02","11-03","11-04","11-05","11-06","11-07"];
        lineChartView.xAxis.valueFormatter = VDChartAxisValueFormatter.init(xValueArr as NSArray);
        lineChartView.leftAxis.valueFormatter = VDChartAxisValueFormatter.init();
        var yDataArray1 = [ChartDataEntry]();
        for i in 0..<yValueArr.count {
            let entry = ChartDataEntry.init(x: Double(i), y: Double(yValueArr[i]));
            yDataArray1.append(entry);
        }
        let set1 = LineChartDataSet.init(entries: yDataArray1, label: "")
        let lineColor = UIColor(red: 29/255.0, green: 105/255.0, blue: 245/255.0, alpha: 1.0)
        set1.colors = [ lineColor]
        set1.drawCirclesEnabled = false;//绘制转折点
        set1.lineWidth = 1.5;
        set1.mode = .horizontalBezier //贝塞尔曲线
        //图列大小
        set1.formSize = 0
        //开启填充颜色
        set1.drawFilledEnabled = true
        let color1 = UIColor(red: 26/255.0, green:  102/255.0, blue: 230/255.0, alpha: 0.3)
        let gradientColors = [color1.cgColor, UIColor.white.cgColor] as CFArray
        //每组颜色所在位置（范围0~1)
        let colorLocations:[CGFloat] = [1.0, 0.0]
        //生成渐变色
        let gradient = CGGradient.init(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                       colors: gradientColors, locations: colorLocations)
        //将渐变色作为填充对象
        set1.fill = Fill.fillWithLinearGradient(gradient!, angle: 90.0)
        //拐点不显示值
        set1.drawValuesEnabled = false
        set1.highlightColor = UIColor(red: 29/255.0, green: 105/255.0, blue: 245/255.0, alpha: 1.0)
        var yDataArray2 = [ChartDataEntry]();
        for i in 0..<yPreValueArr.count {

            let entry = ChartDataEntry.init(x: Double(i), y: Double(yPreValueArr[i]));
            yDataArray2.append(entry);
        }
        let set2 = LineChartDataSet.init(entries: yDataArray2, label: "");
        
        set2.drawFilledEnabled = true
        let lineColor2 = UIColor(red: 202/255.0, green: 210/255.0, blue: 219/255.0, alpha: 1.0)
        set2.colors = [lineColor2]
        set2.drawCirclesEnabled = false;//绘制转折点
        set2.lineWidth = 1.5;
        set2.mode = .horizontalBezier //贝塞尔曲线
        //图列大小
        set2.formSize = 0
        //拐点不显示值
        set2.drawValuesEnabled = false
        set2.highlightColor = UIColor(red: 29/255.0, green: 105/255.0, blue: 245/255.0, alpha: 1.0)
        
        
        let color2 = UIColor(red: 202/255.0, green:  210/255.0, blue: 219/255.0, alpha: 0.6)
        //let color3 = UIColor(red: 202/255.0, green:  210/255.0, blue: 219/255.0, alpha: 0.0)
        let gradientColors2 = [color2.cgColor,  UIColor.white.cgColor] as CFArray
        //每组颜色所在位置（范围0~1)
        let colorLocations2:[CGFloat] = [1.0, 0.0]
        //生成渐变色
        let gradient2 = CGGradient.init(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                       colors: gradientColors2, locations: colorLocations2)
        //将渐变色作为填充对象
        set2.fill = Fill.fillWithLinearGradient(gradient2!, angle: 90.0)
        
        
        
        let data = LineChartData.init(dataSets: [set1,set2]);
        lineChartView.data = data;
        //动画形式出现
        // lineChartView.animate(xAxisDuration: 1.0, yAxisDuration: 1.0, easingOption: .easeInBack);
    }
    
    
    func roundToNearestQuarter(num : Double) -> Double {
        return round(num * 4.0)/4.0
    }
    
    func configData(model:EnterpriseReportModel,dateStr:String)  {
        let milsModel = model.mils
        let milsDataArr = milsModel?.milsData
        let milsPreDataArr = milsModel?.milsDataPre
        
        xArr = milsDataArr?.map({ (item) -> String in
            return item.x!
        }) ?? []
        
        
        xValueArr = milsDataArr?.map({ (item) -> String in
            return self.setDateStr(str: item.x!)
        }) ?? []
        
        
//        yValueArr = milsDataArr?.map({ (item) -> Double in
//            return  item.y!
//        }) ?? []
//
//        yPreValueArr = milsPreDataArr?.map({ (item) -> Double in
//            return item.y!
//        }) ?? []
        
        yValueArr = milsDataArr?.map({ (item) -> Double in
            return  self.roundToNearestQuarter(num: item.y!)
        }) ?? []

        yPreValueArr = milsPreDataArr?.map({ (item) -> Double in
            return self.roundToNearestQuarter(num: item.y!)
        }) ?? []


        let milsMax = yValueArr.max()
        let milsPreMax = yPreValueArr.max()
        if milsPreMax != nil && milsMax != nil {
            if milsMax! > milsPreMax! {
                lineChartView.leftAxis.axisMaximum = milsMax! + 5
            }else {
                lineChartView.leftAxis.axisMaximum = milsPreMax! + 5
            }
            if milsMax != 0  || milsPreMax != 0{
                self.drawLineChart()
            }else {
                self.drawLineChart()
            }
        }else if milsPreMax == nil && milsMax != nil {
            lineChartView.leftAxis.axisMaximum = milsMax! + 5
            if milsMax != 0  || milsPreMax != 0{
                self.drawLineChart()
            }
        }else if milsPreMax != nil && milsMax == nil{
            lineChartView.leftAxis.axisMaximum = milsPreMax! + 5
            if milsMax != 0  || milsPreMax != 0{
                self.drawLineChart()
            }
        }
        


       
     
    }
    
    
    
    
   
    
    
    func setDateStr(str:String) -> String {
       
        if str.count > 5 {
            let dateFmt = DateFormatter()
            dateFmt.dateFormat = "yyyy-MM-dd"
            let date = dateFmt.date(from: str)
            let dateFmt1 = DateFormatter()
            dateFmt1.dateFormat = "MM-dd"
            let dateStr = dateFmt1.string(from: date!)
            return dateStr
        }else {
            return str
        }
       
    }
    
  
    
    
    func showMarkerView(currentValue: String,beforeValue:String,dateStr:String) {
        let marker = MarkerView.init(frame: CGRect.init(x: 0, y: 0, width: 115, height: 75));
        marker.chartView = lineChartView;
        marker.backgroundColor = UIColor.clear
        
        
        let bgView = UIView.init(frame: CGRect(x: 15, y: 10, width: 100, height: 65))
        bgView.backgroundColor = UIColor.white
        bgView.layer.cornerRadius = 5
        bgView.layer.shadowColor = UIColor.black.cgColor
        bgView.layer.shadowRadius = 5
        bgView.layer.masksToBounds = false
        bgView.layer.shadowOffset = CGSize(width: 2, height: 2)
        bgView.layer.shadowOpacity = 0.4
        marker.addSubview(bgView)
        
        let dateLabel = UILabel.init(frame: CGRect(x: 10, y: 5, width: 100, height: 15))
        dateLabel.font = UIFont.systemFont(ofSize: 13)
        dateLabel.text = dateStr
        bgView.addSubview(dateLabel)
        
        let currentView = UIView.init(frame: CGRect(x: 10, y: 28, width: 6, height: 6))
        currentView.layer.cornerRadius = 3
        currentView.backgroundColor = UIColor(hex: "#1D69F5", alpha: 1.0)
        bgView.addSubview(currentView);
//
        let currentLabel = UILabel.init(frame: CGRect.init(x: 20, y: 20, width:100, height: 20));
        currentLabel.text = currentValue;
        currentLabel.textColor =  UIColor(hex: "#1D69F5", alpha: 1.0)
        currentLabel.font = UIFont.systemFont(ofSize: 12);
        currentLabel.textAlignment = .left;
        bgView.addSubview(currentLabel);
        
        let beforeView = UIView.init(frame: CGRect(x: 10, y: 48, width: 6, height: 6))
        beforeView.layer.cornerRadius = 3
        beforeView.backgroundColor =  UIColor(hex: "#CAD2DB", alpha: 1.0)
        bgView.addSubview(beforeView);
        
        let beforeLabel = UILabel.init(frame: CGRect.init(x: 20, y: 40, width: 100, height: 20));
        beforeLabel.text = beforeValue;
        beforeLabel.textColor = UIColor.black
        beforeLabel.font = UIFont.systemFont(ofSize: 12);
        beforeLabel.textAlignment = .left;
        bgView.addSubview(beforeLabel);

        lineChartView.marker = marker;
    }
       
    func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry, highlight: Highlight) {
        
        index =  Int(entry.x)
        //dateLabel.text = xArr[index]
        
        var currentStr:String = ""
        var beforeStr:String = ""
        
        if yValueArr.count != 0 {
              currentStr = String(format: "现在 %.1f", yValueArr[index])
        }else {
             currentStr = String(format: "现在")
        }
       
        if yPreValueArr.count != 0 {
              beforeStr = String(format: "环比 %.1f", yPreValueArr[index])
        }else {
             beforeStr = String(format: "环比")
        }
        
       
        self.showMarkerView(currentValue: currentStr, beforeValue: beforeStr,dateStr: xArr[index])
        //self.showMarkerView("\(entry.y)");
    }
       
    
   
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
