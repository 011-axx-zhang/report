//
//  EnterpriseDriverCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/19.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class EnterpriseDriverCollectionViewCell: UICollectionViewCell {
       var firstView:UIView!
      var seconView:UIView!
      var thirdView:UIView!
      
      var driverFirstLeftView:EnterpriseView!
      var driverFirstRightView:EnterpriseView!
      
      var driverSecLeftView:EnterpriseView!
      var driverSecRightView:EnterpriseView!
      
      var driverThirdLeftView:EnterpriseView!
      var driverThirdRightView:EnterpriseView!
      
      
      
      
      override init(frame: CGRect) {
          super.init(frame: frame)
          self.backgroundColor = UIColor.white
          initView()
          updateConstraints()
      }
      
      
      func initView(){
          
          
          firstView = UIView()
          firstView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
          firstView.layer.cornerRadius = 4
          self.contentView.addSubview(firstView)
          
          seconView = UIView()
          seconView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
          seconView.layer.cornerRadius = 4
          self.contentView.addSubview( seconView)
          
          thirdView = UIView()
          thirdView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
          thirdView.layer.cornerRadius = 4
          self.contentView.addSubview(thirdView)
          
          
          driverFirstLeftView = EnterpriseView()
          driverFirstLeftView.topValueLabel.text = "870"
          driverFirstLeftView.desLabel.text = "出勤驾驶员"
          self.contentView.addSubview(driverFirstLeftView)
          driverFirstRightView = EnterpriseView()
          driverFirstRightView.topValueLabel.text = "98.2%"
          driverFirstRightView.desLabel.text = "出勤率"
          self.contentView.addSubview(driverFirstRightView)
          
          
          driverSecLeftView = EnterpriseView()
          driverSecLeftView.topValueLabel.text = "6"
          driverSecLeftView.desLabel.text = "未出勤驾驶员"
          self.contentView.addSubview(driverSecLeftView)
          driverSecRightView = EnterpriseView()
          driverSecRightView.topValueLabel.text = "0.8%"
          driverSecRightView.desLabel.text = "未出勤率"
          self.contentView.addSubview(driverSecRightView)
          
        
          driverThirdLeftView = EnterpriseView()
          driverThirdLeftView.topValueLabel.text = "303.2"
          driverThirdLeftView.desLabel.text = "日均行驶公里"
          self.contentView.addSubview(driverThirdLeftView)
          driverThirdRightView = EnterpriseView()
          driverThirdRightView.topValueLabel.text = "4.5"
          driverThirdRightView.desLabel.text = "日均行驶时长(小时)"
          self.contentView.addSubview(driverThirdRightView)
          
    
         
          
          
      }
      
      override func updateConstraints() {
          super.updateConstraints()
          
          
          firstView.snp.makeConstraints { (make) in
              make.left.equalTo(self.snp.left).offset(15)
              make.top.equalTo(self.snp.top).offset(10)
              make.size.equalTo(CGSize(width: (KW - 30), height: 68))
          }
          seconView.snp.makeConstraints { (make) in
              make.left.equalTo(firstView.snp.left).offset(0)
              make.top.equalTo(firstView.snp.bottom).offset(10)
              make.size.equalTo(CGSize(width: (KW - 30), height: 68))
          }
          
          thirdView.snp.makeConstraints { (make) in
              make.left.equalTo(firstView.snp.left).offset(0)
              make.top.equalTo(seconView.snp.bottom).offset(10)
              make.size.equalTo(CGSize(width: (KW - 30), height: 68))
          }
          
          driverFirstLeftView.snp.makeConstraints { (make) in
              make.left.equalTo(firstView.snp.left).offset(30)
              make.top.equalTo(firstView.snp.top).offset(12)
          }
          driverFirstRightView.snp.makeConstraints { (make) in
              make.left.equalTo(self.snp.left).offset(KW/2 + 20)
              make.top.equalTo(firstView.snp.top).offset(12)
          }
    
          
          driverSecLeftView.snp.makeConstraints { (make) in
              make.left.equalTo(seconView.snp.left).offset(30)
              make.top.equalTo(seconView.snp.top).offset(12)
          }
          driverSecRightView.snp.makeConstraints { (make) in
              make.left.equalTo(self.snp.left).offset(KW/2 + 20)
              make.top.equalTo(seconView.snp.top).offset(12)
          }
          
          driverThirdLeftView.snp.makeConstraints { (make) in
              make.left.equalTo(thirdView.snp.left).offset(30)
              make.top.equalTo(thirdView.snp.top).offset(12)
          }
        
          driverThirdRightView.snp.makeConstraints { (make) in
              make.left.equalTo(self.snp.left).offset(KW/2 + 20)
              make.top.equalTo(thirdView.snp.top).offset(12)
          }
      
          
      }
      
    func configData(model:EnterpriseReportModel) {
        let model = model.driverInfo
        
        driverFirstLeftView.topValueLabel.text = String(format: "%d", model?.attend ?? 0)
        
        if model!.attendYOY! > 0 {
            driverFirstLeftView.mileTotalIcon.isHidden = false
            driverFirstLeftView.mileTotalIcon.image = UIImage(named: "report_tigao")
            driverFirstLeftView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            driverFirstLeftView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
            driverFirstLeftView.mileTotalLabel.text = String(format: "%.1f%@", (model?.attendYOY ?? 0) * 100,"%")
        }else if model!.attendYOY! < 0{
            driverFirstLeftView.mileTotalIcon.isHidden = false
            driverFirstLeftView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            driverFirstLeftView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            driverFirstLeftView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
            driverFirstLeftView.mileTotalLabel.text = String(format: "%.1f%@", -(model?.attendYOY ?? 0) * 100,"%")
        }else if model!.attendYOY! == 0 {
            driverFirstLeftView.mileTotalIcon.isHidden = true
            driverFirstLeftView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            driverFirstLeftView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
            driverFirstLeftView.mileTotalLabel.text = String(format: "%.1f%@", (model?.attendYOY ?? 0) * 100,"%")
        }
        
        driverFirstRightView.topValueLabel.text = String(format: "%.1f%@", (model?.attendRate ?? 0)  * 100,"%")
        
        if model!.attendRateYOY! > 0 {
             driverFirstRightView.mileTotalIcon.isHidden = false
            driverFirstRightView.mileTotalIcon.image = UIImage(named: "report_tigao")
            driverFirstRightView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            driverFirstRightView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
            driverFirstRightView.mileTotalLabel.text = String(format: "%.1f%@", (model?.attendRateYOY ?? 0) * 100,"%")
        }else  if model!.attendRateYOY! < 0{
             driverFirstRightView.mileTotalIcon.isHidden = false
            driverFirstRightView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            driverFirstRightView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            driverFirstRightView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
            driverFirstRightView.mileTotalLabel.text = String(format: "%.1f%@", -(model?.attendRateYOY ?? 0) * 100,"%")
        }else  if model!.attendRateYOY! == 0{
            driverFirstRightView.mileTotalIcon.isHidden = true
            driverFirstRightView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            driverFirstRightView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
            driverFirstRightView.mileTotalLabel.text = String(format: "%.1f%@", (model?.attendRateYOY ?? 0) * 100,"%")
        }
        
        driverSecLeftView.topValueLabel.text = String(format: "%d", model?.notAttend ?? 0.0)
       
        if model!.notAttendYOY! > 0 {
            driverSecLeftView.mileTotalIcon.isHidden = false
            driverSecLeftView.mileTotalIcon.image = UIImage(named: "report_tigao")
            driverSecLeftView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            driverSecLeftView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
             driverSecLeftView.mileTotalLabel.text = String(format: "%.1f%@", (model?.notAttendYOY ?? 0) * 100,"%")
        }else if model!.notAttendYOY! < 0{
            driverSecLeftView.mileTotalIcon.isHidden = false
            driverSecLeftView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            driverSecLeftView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            driverSecLeftView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
             driverSecLeftView.mileTotalLabel.text = String(format: "%.1f%@", -(model?.notAttendYOY ?? 0) * 100,"%")
        }else if model!.notAttendYOY! == 0{
            driverSecLeftView.mileTotalIcon.isHidden = true
            driverSecLeftView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            driverSecLeftView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
             driverSecLeftView.mileTotalLabel.text = String(format: "%.1f%@", (model?.notAttendYOY ?? 0) * 100,"%")
        }
        
        
        driverSecRightView.topValueLabel.text = String(format: "%.1f%@", (model?.notAttendRate ?? 0)  * 100 ,"%")
       
        if model!.notAttendRateYOY! > 0 {
            driverSecRightView.mileTotalIcon.isHidden = false
            driverSecRightView.mileTotalIcon.image = UIImage(named: "report_tigao")
            driverSecRightView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            driverSecRightView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
             driverSecRightView.mileTotalLabel.text = String(format: "%.1f%@", (model?.notAttendRateYOY ?? 0) * 100,"%")
        }else if model!.notAttendRateYOY! < 0{
             driverSecRightView.mileTotalIcon.isHidden = false
            driverSecRightView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            driverSecRightView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            driverSecRightView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
             driverSecRightView.mileTotalLabel.text = String(format: "%.1f%@", -(model?.notAttendRateYOY ?? 0) * 100,"%")
        }else if model!.notAttendRateYOY! == 0 {
             driverSecRightView.mileTotalIcon.isHidden = true
            driverSecRightView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            driverSecRightView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
             driverSecRightView.mileTotalLabel.text = String(format: "%.1f%@", (model?.notAttendRateYOY ?? 0) * 100,"%")
        }
        
        
        driverThirdLeftView.topValueLabel.text = String(format: "%.2f", model?.milsPerDay ?? 0.0)
        
        
        if model!.milsPerDayYOY! > 0.0 {
              driverThirdLeftView.mileTotalIcon.isHidden = false
            driverThirdLeftView.mileTotalIcon.image = UIImage(named: "report_tigao")
            driverThirdLeftView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            driverThirdLeftView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
            driverThirdLeftView.mileTotalLabel.text = String(format: "%.1f%@", (model?.milsPerDayYOY ?? 0) * 100,"%")
        }else if  model!.milsPerDayYOY! < 0.0{
            driverThirdLeftView.mileTotalIcon.isHidden = false
            driverThirdLeftView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            driverThirdLeftView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            driverThirdLeftView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
            driverThirdLeftView.mileTotalLabel.text = String(format: "%.1f%@", -(model?.milsPerDayYOY ?? 0) * 100,"%")
        }else if  model!.milsPerDayYOY! == 0.0{
             driverThirdLeftView.mileTotalIcon.isHidden = true
            driverThirdLeftView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            driverThirdLeftView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
            driverThirdLeftView.mileTotalLabel.text = String(format: "%.1f%@", (model?.milsPerDayYOY ?? 0) * 100,"%")
        }
        
        
        
        driverThirdRightView.topValueLabel.text = String(format: "%.2f", model?.durationPerDay ?? 0.0)
       
        if model!.durationPerDayYOY! > 0.0 {
            driverThirdRightView.mileTotalIcon.isHidden = true
            driverThirdRightView.mileTotalIcon.image = UIImage(named: "report_tigao")
            driverThirdRightView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            driverThirdRightView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
            driverThirdRightView.mileTotalLabel.text = String(format: "%.1f%@", (model?.durationPerDayYOY ?? 0) * 100,"%")
        }else if  model!.durationPerDayYOY! < 0.0 {
            driverThirdRightView.mileTotalIcon.isHidden = true
            driverThirdRightView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            driverThirdRightView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            driverThirdRightView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
            driverThirdRightView.mileTotalLabel.text = String(format: "%.1f%@", -(model?.durationPerDayYOY ?? 0) * 100,"%")
        }else if  model!.durationPerDayYOY! == 0.0 {
            driverThirdRightView.mileTotalIcon.isHidden = true
            driverThirdRightView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            driverThirdRightView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
            driverThirdRightView.mileTotalLabel.text = String(format: "%.1f%@", (model?.durationPerDayYOY ?? 0) * 100,"%")
        }
        
    }
    
      required init?(coder aDecoder: NSCoder) {
          fatalError("init(coder:) has not been implemented")
      }
}
