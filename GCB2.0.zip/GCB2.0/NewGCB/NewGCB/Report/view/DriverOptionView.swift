//
//  DriverOptionView.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/20.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class DriverOptionView: UIView,UITableViewDelegate,UITableViewDataSource {
    var optionList : UITableView!
    var gestureView:UIView!
    var cellArr:[String] = []
    var selectId:Int=0
    @objc var selectedCellBlock:((Int,String)->Void)?
    @objc var closeOptionView:(()->Void)?
    var h :CGFloat = 0
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    init(frame: CGRect, index: Int, titleArr:[String]) {
        super.init(frame: frame)
        self.backgroundColor = UIColor(red: 51.0/255.0, green: 51.0/255.0, blue: 51.0/255.0, alpha: 0.5)
        selectId = index
        cellArr = titleArr
        h = CGFloat(cellArr.count * 40)
        setupView()
        updateConstraints()
    }
    func setupView() -> Void {
        
        optionList = UITableView.init(frame: .zero, style: .plain)
        optionList.delegate = self
        optionList.dataSource = self
        optionList.rowHeight = 40.0
        optionList.backgroundColor = UIColor.white
        optionList.isScrollEnabled = false
        optionList.tableFooterView = UIView.init()
        self.addSubview(optionList)
        optionList!.register(UITableViewCell.self, forCellReuseIdentifier: "notiCellID")
        
        let gesture = UITapGestureRecognizer.init(target: self, action: #selector(closeView))
        gestureView = UIView.init()
        gestureView.isUserInteractionEnabled = true
        gestureView.addGestureRecognizer(gesture)
        self.addSubview(gestureView)
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cellArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "notiCellID", for: indexPath)
        cell.textLabel?.font = UIFont.systemFont(ofSize: 13)
        cell.textLabel?.text = cellArr[indexPath.row]
        cell.accessoryType = .none
        if indexPath.row == selectId {
            cell.accessoryType = .checkmark
            cell.textLabel?.textColor = UIColor(hex: "#325AEF", alpha: 1.0)
        }
        
        if indexPath.row == 2 {
            cell.separatorInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: KW )
        }
      
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let cell:UITableViewCell! = tableView.cellForRow(at: indexPath)

        //返回所有单元格
        //遍历取消所有单元格样式
        let arry = tableView.visibleCells
        for i in 0 ..< arry.count {
            let cells: UITableViewCell = arry[i]
            cells.accessoryType = .none
        }
        //设置选中的单元格样式
        cell.accessoryType = .checkmark
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            let str = self.cellArr[indexPath.row]
            self.selectedCellBlock?(indexPath.row+1,str)
        }
    }
    
    @objc func closeView() {
        self.closeOptionView?()
    }
    
    
    override func updateConstraints() {
        super.updateConstraints()
        
        optionList.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left)
            make.top.equalTo(self.snp.top)
            make.width.equalTo(self.snp.width)
            make.height.equalTo(h)
        }
        
        gestureView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left)
            make.top.equalTo(optionList.snp.bottom)
            make.width.equalTo(self.snp.width)
            make.bottom.equalTo(self.snp.bottom)
        }
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
