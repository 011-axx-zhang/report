//
//  StopVehicleCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/23.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import Charts

class StopVehicleCollectionViewCell: UICollectionViewCell {
    var bgView:UIView!
    var yDataArr:Array<Int64> = []
    var colors:Array<UIColor> = []
     var rightView:UIView!
     var h: CGFloat = 0
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor(hex: "#F5F5F9", alpha: 1.0)
        self.initView()
        self.addSubview(self.pieChartView)
        self.createColors()
    }
    
    func createColors()  {
         let arr = ["#66B8FE","#7BE279","#FFE03F","#FAB286","#FD723A","#7D8DFD","#8AE1BF","#F59BCC","#FFC53F","#F95642","#1889F7","#38C465","#A7B4FF","#FFCCE3","#FD723A","#4163DD","#85DE50","#FFA0ED","#C7D0FF","#FE9A28"]
         for i in 0...19 {
             let color = UIColor(hex: arr[i], alpha: 1.0)
             colors.append(color!)
         }
     }
    
    lazy var pieChartView: PieChartView = {
        let _pieChartView = PieChartView.init(frame: CGRect.init(x: 0, y: 0, width: (KW - 30)/2, height: 160));
        // _pieChartView.backgroundColor = UIColor.red;
        _pieChartView.setExtraOffsets(left: 10, top: 0, right: 10, bottom: 0);//设置这块饼的位置
        _pieChartView.chartDescription?.text = "";//描述文字
        _pieChartView.chartDescription?.font = UIFont.systemFont(ofSize: 12.0);//字体
        _pieChartView.chartDescription?.textColor = UIColor.black;//颜色
        
        _pieChartView.usePercentValuesEnabled = true;//转化为百分比
        _pieChartView.dragDecelerationEnabled = false;//我把拖拽效果关了
        _pieChartView.drawEntryLabelsEnabled = false;//不显示区块文本
        _pieChartView.entryLabelFont = UIFont.systemFont(ofSize: 10);//区块文本的字体
        _pieChartView.entryLabelColor = UIColor.white;
        _pieChartView.drawSlicesUnderHoleEnabled = true;
        
        
        _pieChartView.drawHoleEnabled = true;//这个饼是空心的
        _pieChartView.holeRadiusPercent = 0.65//空心半径黄金比例
        _pieChartView.holeColor = UIColor.white;//空心颜色设置为白色
        _pieChartView.transparentCircleRadiusPercent = 0.65;//半透明空心半径
        
        _pieChartView.drawCenterTextEnabled = true;//显示中心文本
        _pieChartView.centerText = "";//设置中心文本,你也可以设置富文本`centerAttributedText`
        
        
        //图例样式设置
        _pieChartView.legend.maxSizePercent = 0;//图例的占比
        _pieChartView.legend.form = .circle//图示：原、方、线
        _pieChartView.legend.formSize = 0;//图示大小
        
        _pieChartView.noDataText = "停运车辆饼状图暂无数据";
        _pieChartView.noDataTextColor = UIColor.gray;
        _pieChartView.noDataFont = UIFont.boldSystemFont(ofSize: 14);
        
        return _pieChartView;
    }()
    
    func drawPieChartView() {
       
        var colorArr:Array<UIColor> = []
        
        var yVals = [PieChartDataEntry]();
        for i in 0..<yDataArr.count{
            let entry = PieChartDataEntry.init(value: Double(yDataArr[i]), label: "");
            yVals.append(entry);
            colorArr.append(colors[i])
        }
     
        
        let dataSet = PieChartDataSet.init(entries: yVals, label: "");
        dataSet.colors = colorArr;
        //设置名称和数据的位置 都在内就没有折线了哦
        dataSet.xValuePosition = .insideSlice;
        dataSet.yValuePosition = .outsideSlice;
        dataSet.sliceSpace = 1;//相邻块的距离
        dataSet.selectionShift = 0;//选中放大半径
        let data = PieChartData.init(dataSets: [dataSet]);
        pieChartView.data = data;
        dataSet.valueLineWidth = 0 //折线的粗细
        
        
        
        
    }
    
    
    func initView(){
        bgView = UIView()
        bgView.backgroundColor = UIColor.white
        self.addSubview(bgView)
        
        rightView = UIView()
        rightView.backgroundColor = UIColor.white
        self.addSubview(rightView)
        
    }
    
    func createRightView(dataArr:Array<PieModel>)  {
        for i in 0..<dataArr.count {
            let model = dataArr[i]
            let view = VehicleModelRightView()
            view.frame = CGRect(x: 0, y: CGFloat(i * 20) , width: (KW - 30)/2, height: 20)
            view.modelNameLabel.text = model.model ?? ""
            view.numLabel.text = String(format: "%d辆", model.count ?? 0)
            view.percentLabel.text = String(format: "%.1f%@", model.rate!*100,"%")
            view.circleView.backgroundColor = colors[i]
            self.rightView.addSubview(view)
        }
        h = CGFloat(dataArr.count * 20)
        updateConstraints()
        
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        bgView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self)
            make.size.equalTo(CGSize(width: KW - 30, height: 170))
        }
        
        rightView.snp.updateConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(KW/2)
            make.centerY.equalTo(self.pieChartView)
            make.size.equalTo(CGSize(width: (KW - 30)/2, height:self.h))
        }
        
    }
    
    
    func configData(dataModel:VehicleManagerModel){
         yDataArr = []
        let  modelArr = dataModel.stopPie ?? []
        for model in modelArr {
            yDataArr.append(model.count ?? 0)
        }
       
        let sum  = yDataArr.reduce(0,{$0 + $1})
        if sum != 0 {
            pieChartView.centerText = String(format: "停运车辆\n %d", sum)
            self.drawPieChartView()
            self.createRightView(dataArr: modelArr)
        }
      
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
