//
//  VehicleCollectionReusableView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/18.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class VehicleCollectionReusableView: UICollectionReusableView {
    
    var topBgView:UIView!
    var searchMoreBtn:UIButton!
    var searchLabel:UILabel!
    var searchIcon:UIImageView!
    var titleLabel:UILabel!
    @objc var checkMoreClick:(()->Void)?
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.createUI()
        self.updateConstraints()
    }
    
    private func createUI() {
        topBgView = UIView()
        topBgView.backgroundColor = UIColor(hex: "#F0F0F7", alpha: 1.0)
        self.addSubview(topBgView)
        
        titleLabel = UILabel()
        titleLabel.font = UIFont.boldSystemFont(ofSize: 17)
        titleLabel.text = "车辆管理"
        titleLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.addSubview(titleLabel)
        
        searchMoreBtn = UIButton()
        self.addSubview(searchMoreBtn)
        searchLabel = UILabel()
        searchLabel.text = "查看更多"
        searchLabel.font = UIFont.systemFont(ofSize: 12)
        searchLabel.textColor = UIColor(hex: "#1D69F5", alpha: 1.0)
        searchMoreBtn.addSubview(searchLabel)
        searchIcon = UIImageView()
        searchIcon.image = UIImage(named: "baobiao_chakan")
        searchIcon.contentMode = .center
        searchMoreBtn.addSubview(searchIcon)
        searchMoreBtn.addTarget(self, action: #selector(self.searchaMoreEvent), for: .touchUpInside)
    }
    
   @objc  func searchaMoreEvent()  {
    self.checkMoreClick?()
        
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        topBgView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(0)
            make.top.equalTo(self.snp.top).offset(0)
            make.size.equalTo(CGSize(width: KW, height: 20))
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(topBgView.snp.bottom).offset(12)
        }
        
        searchMoreBtn.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp.right).offset(-15)
            make.top.equalTo(topBgView.snp.bottom).offset(12)
            make.size.equalTo(CGSize(width: 65, height: 20))
        }
        
        searchLabel.snp.makeConstraints { (make) in
            make.left.equalTo(searchMoreBtn.snp.left).offset(0)
            make.centerY.equalTo(searchMoreBtn)
        }
        
        searchIcon.snp.makeConstraints { (make) in
            make.left.equalTo(searchLabel.snp.right).offset(2)
            make.centerY.equalTo(searchMoreBtn)
            make.size.equalTo(CGSize(width: 10, height: 20))
        }
        
    }
    
    
    func setTitleText(title:String) -> Void {
        titleLabel.text = title
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
