//
//  PieChartValueFormatter.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/20.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import Charts

class PieChartValueFormatter:NSObject,IValueFormatter {
   

  func stringForValue(_ value: Double, entry: ChartDataEntry, dataSetIndex: Int, viewPortHandler: ViewPortHandler?) -> String {
        return String.init(format: "%.2f%%", value);
    }
}
