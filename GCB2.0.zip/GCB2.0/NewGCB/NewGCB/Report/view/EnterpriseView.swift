//
//  EnterpriseView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/19.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class EnterpriseView: UIView {
    var topValueLabel:UILabel!
    var desLabel:UILabel!
    var mileTotalLabel:UILabel!
    var mileTotalIcon:UIImageView!
    var mileBgView:UIView!
    
   
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        self.createUI()
        updateConstraints()
    }
    
    private func createUI() {
        topValueLabel = UILabel()
        topValueLabel.text = ""
        topValueLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        topValueLabel.font = UIFont.systemFont(ofSize: 20)
        self.addSubview(topValueLabel)
        
        desLabel = UILabel()
        desLabel.text = ""
        desLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        desLabel.font = UIFont.systemFont(ofSize: 13)
        self.addSubview(desLabel)
        
        mileBgView = UIView()
        mileBgView.layer.borderWidth = 1.5
        mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
        mileBgView.layer.cornerRadius = 2
        self.addSubview(mileBgView)
        mileTotalLabel = UILabel()
        mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
        mileTotalLabel.text = ""
        mileTotalLabel.font = UIFont.systemFont(ofSize: 11)
        mileBgView.addSubview(mileTotalLabel)
        mileTotalIcon = UIImageView()
        mileTotalIcon.image = UIImage(named: "report_tigao")
        mileTotalIcon.contentMode = .center
        mileBgView.addSubview(mileTotalIcon)
        
        
    }
    
    
    
    
    
    
    override func updateConstraints() {
        super.updateConstraints()
        
        topValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(2)
            make.top.equalTo(self.snp.top).offset(2)
        }
        
        
        desLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(2)
            make.top.equalTo(topValueLabel.snp.bottom).offset(4)
        }
        
        
        mileTotalIcon.snp.makeConstraints { (make) in
            make.left.equalTo(mileBgView.snp.left).offset(2)
            make.centerY.equalTo(mileBgView)
            make.size.equalTo(CGSize(width: 10, height: 10))
        }
        mileTotalLabel.snp.makeConstraints { (make) in
            make.left.equalTo(mileTotalIcon.snp.right).offset(2)
            make.centerY.equalTo(mileBgView)
        }
        
        mileBgView.snp.makeConstraints { (make) in
            make.left.equalTo(topValueLabel.snp.right).offset(5)
            make.top.equalTo(self.snp.top).offset(6)
            make.height.equalTo(16)
            make.right.equalTo(mileTotalLabel.snp.right).offset(5)
        }

        
    }
    
    func hiddenViewIcon() -> Void {
        mileBgView.isHidden = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

}
