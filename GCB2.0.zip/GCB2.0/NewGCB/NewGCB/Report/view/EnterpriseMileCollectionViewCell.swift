//
//  EnterpriseMileCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/18.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class EnterpriseMileCollectionViewCell: UICollectionViewCell {
    var titleLabel:UILabel!
    var firstView:UIView!
    var seconView:UIView!
    var thirdView:UIView!
    var fourView:UIView!
    
    
    var rijianIcon:UIImageView!
    var rijianTimeLabel:UILabel!
    
    var yejianIcon:UIImageView!
    var yejiianTimeLabel:UILabel!
 
    
   
    var mileFirstView:EnterpriseView!
    var mileSecView:EnterpriseView!
    
    var mileThirdView:EnterpriseView!
    var mileFourView:EnterpriseView!
    
 
   
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        initView()
        updateConstraints()
    }
    
    
    func initView(){
        titleLabel = UILabel()
        titleLabel.font = UIFont.boldSystemFont(ofSize: 17)
        titleLabel.text = "行驶里程"
        titleLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(titleLabel)
        
        firstView = UIView()
        firstView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        firstView.layer.cornerRadius = 4
        self.contentView.addSubview(firstView)
        
        seconView = UIView()
        seconView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        seconView.layer.cornerRadius = 4
        self.contentView.addSubview( seconView)
        
        
        thirdView = UIView()
        thirdView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        thirdView.layer.cornerRadius = 4
        self.contentView.addSubview(thirdView)
        
        fourView = UIView()
        fourView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        fourView.layer.cornerRadius = 4
        self.contentView.addSubview(fourView)
        
        
        rijianIcon = UIImageView()
        rijianIcon.image = UIImage(named: "baobiao_rijian")
        thirdView.addSubview(rijianIcon)
        rijianTimeLabel = UILabel()
        rijianTimeLabel.text = "(7:00～21:00)"
        rijianTimeLabel.font = UIFont.systemFont(ofSize: 10)
        rijianTimeLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        thirdView.addSubview(rijianTimeLabel)
        
        
        yejianIcon = UIImageView()
        yejianIcon.image = UIImage(named: "baobiao_yejian")
        fourView.addSubview(yejianIcon)
        yejiianTimeLabel = UILabel()
        yejiianTimeLabel.text = "(7:00～21:00)"
        yejiianTimeLabel.font = UIFont.systemFont(ofSize: 10)
        yejiianTimeLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        fourView.addSubview(yejiianTimeLabel)
        
        
        mileFirstView = EnterpriseView()
        mileFirstView.topValueLabel.text = ""
        mileFirstView.desLabel.text = "累计行驶公里"
        self.contentView.addSubview(mileFirstView)
        mileSecView = EnterpriseView()
        mileSecView.topValueLabel.text = ""
        mileSecView.desLabel.text = "日均行驶时公里"
        self.contentView.addSubview(mileSecView)
        
        
        mileThirdView = EnterpriseView()
        mileThirdView.topValueLabel.text = ""
        mileThirdView.desLabel.text = "日间行驶公里"
        self.contentView.addSubview(mileThirdView)
        mileFourView = EnterpriseView()
        mileFourView.topValueLabel.text = ""
        mileFourView.desLabel.text = "夜间行驶公里"
        self.contentView.addSubview(mileFourView)
        

        
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self.snp.top).offset(12)
        }
        
        firstView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(titleLabel.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 38)/2, height: 68))
        }
        seconView.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.right).offset(8)
            make.top.equalTo(titleLabel.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 38)/2, height: 68))
        }
        
        
        thirdView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(firstView.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 38)/2, height: 84))
        }
        
        fourView.snp.makeConstraints { (make) in
            make.left.equalTo( thirdView.snp.right).offset(8)
            make.top.equalTo(firstView.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 38)/2, height: 84))
        }
        
        
        
        
        rijianIcon.snp.makeConstraints { (make) in
            make.left.equalTo(thirdView.snp.left).offset(5)
            make.top.equalTo(thirdView.snp.top).offset(13)
            make.size.equalTo(CGSize(width: 20, height: 20))
        }
        rijianTimeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(rijianIcon.snp.right).offset(2)
            make.top.equalTo(thirdView.snp.top).offset(13)
        }
       
        
        yejianIcon.snp.makeConstraints { (make) in
            make.left.equalTo(fourView.snp.left).offset(5)
            make.top.equalTo(fourView.snp.top).offset(13)
            make.size.equalTo(CGSize(width: 20, height: 20))
        }
        yejiianTimeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(yejianIcon.snp.right).offset(2)
            make.top.equalTo(fourView.snp.top).offset(13)
        }
        
        
        mileFirstView.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.left).offset(20)
            make.top.equalTo(firstView.snp.top).offset(12)
        }
        mileSecView.snp.makeConstraints { (make) in
            make.left.equalTo(seconView.snp.left).offset(26)
            make.top.equalTo(seconView.snp.top).offset(12)
        }
        
        mileThirdView.snp.makeConstraints { (make) in
            make.left.equalTo(thirdView.snp.left).offset(26)
            make.top.equalTo(rijianTimeLabel.snp.bottom).offset(5)
        }
        mileFourView.snp.makeConstraints { (make) in
             make.left.equalTo(fourView.snp.left).offset(26)
            make.top.equalTo(rijianTimeLabel.snp.bottom).offset(5)
        }
               
        
    }
    
    
    func configData(model:EnterpriseReportModel) {
        let mileModel = model.mils
        
        if mileModel?.milsSum != nil{
            if mileModel!.milsSum! > 10000.0 {
                mileFirstView.topValueLabel.text = String(format: "%.2f万", (mileModel!.milsSum!)/10000.0)
            }else {
               mileFirstView.topValueLabel.text = String(format: "%.2f", mileModel?.milsSum ?? 0.0)
            }
        }else {
            mileFirstView.topValueLabel.text = String(format: "%.2f", mileModel?.milsSum ?? 0.0)
        }
        
        
        if mileModel!.milsSumYOY! > 0.0 {
            mileFirstView.mileTotalIcon.isHidden = false
            mileFirstView.mileTotalIcon.image = UIImage(named: "report_tigao")
            mileFirstView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            mileFirstView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
            mileFirstView.mileTotalLabel.text = String(format: "%.1f%@", (mileModel?.milsSumYOY ?? 0.0)*100,"%")
        }else if mileModel!.milsSumYOY! < 0.0{
            mileFirstView.mileTotalIcon.isHidden = false
            mileFirstView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            mileFirstView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            mileFirstView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
            mileFirstView.mileTotalLabel.text = String(format: "%.1f%@", -(mileModel?.milsSumYOY ?? 0.0)*100,"%")
        }else if  mileModel!.milsSumYOY! == 0.0{
            mileFirstView.mileTotalIcon.isHidden = true
            mileFirstView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            mileFirstView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
            mileFirstView.mileTotalLabel.text = String(format: "%.f%@", (mileModel?.milsSumYOY ?? 0.0)*100,"%")
        }
        
        
        if mileModel?.milsPerDay != nil{
            if mileModel!.milsPerDay! > 10000.0 {
                mileSecView.topValueLabel.text = String(format: "%.2f万", mileModel!.milsPerDay!/10000.0)
            }else {
                mileSecView.topValueLabel.text = String(format: "%.2f", mileModel?.milsPerDay ?? 0.0)
            }
        }else {
            mileSecView.topValueLabel.text = String(format: "%.2f", mileModel?.milsPerDay ?? 0.0)
        }
        
        
       
        
        if mileModel!.milsPerDayYOY! >= 0.0 {
              mileSecView.mileTotalIcon.isHidden = false
            mileSecView.mileTotalIcon.image = UIImage(named: "report_tigao")
            mileSecView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            mileSecView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
             mileSecView.mileTotalLabel.text = String(format: "%.1f%@", (mileModel?.milsPerDayYOY ?? 0)*100 ,"%")
        }else if mileModel!.milsPerDayYOY! < 0.0 {
               mileSecView.mileTotalIcon.isHidden = false
            mileSecView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            mileSecView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            mileSecView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
             mileSecView.mileTotalLabel.text = String(format: "%.1f%@", -(mileModel?.milsPerDayYOY ?? 0)*100 ,"%")
        }else if mileModel!.milsPerDayYOY! == 0.0 {
            mileSecView.mileTotalIcon.isHidden = true
            mileSecView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            mileSecView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
            mileSecView.mileTotalLabel.text = String(format: "%.1f%@", (mileModel?.milsPerDayYOY ?? 0)*100 ,"%")
        }
        
        
        if mileModel?.milsDay != nil{
            if mileModel!.milsDay! > 10000.0 {
                mileThirdView.topValueLabel.text = String(format: "%.2f万", mileModel!.milsDay!/10000.0)
            }else {
                mileThirdView.topValueLabel.text = String(format: "%.2f", mileModel?.milsDay ?? 0.0)
            }
        }else {
            mileThirdView.topValueLabel.text = String(format: "%.2f", mileModel?.milsDay ?? 0.0)
        }
       
      
        
        if mileModel!.milsDayYOY! > 0.0 {
            mileThirdView.mileTotalIcon.isHidden = false
            mileThirdView.mileTotalIcon.image = UIImage(named: "report_tigao")
            mileThirdView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            mileThirdView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
            mileThirdView.mileTotalLabel.text = String(format: "%.1f%@", (mileModel?.milsDayYOY ?? 0) * 100,"%")
        }else if mileModel!.milsDayYOY! < 0.0{
            mileThirdView.mileTotalIcon.isHidden = false
            mileThirdView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            mileThirdView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            mileThirdView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
            mileThirdView.mileTotalLabel.text = String(format: "%.1f%@", -(mileModel?.milsDayYOY ?? 0) * 100,"%")
        }else  if mileModel!.milsDayYOY! == 0.0 {
            mileThirdView.mileTotalIcon.isHidden = true
            mileThirdView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            mileThirdView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
            mileThirdView.mileTotalLabel.text = String(format: "%.1f%@", (mileModel?.milsDayYOY ?? 0) * 100,"%")
        }
        
        if mileModel?.milsNight != nil{
            if mileModel!.milsNight! > 10000.0 {
                mileFourView.topValueLabel.text = String(format: "%.2f", mileModel!.milsNight!/10000.0)
            }else {
                mileFourView.topValueLabel.text = String(format: "%.2f", mileModel?.milsNight ?? 0.0)
            }
        }else {
             mileFourView.topValueLabel.text = String(format: "%.2f", mileModel?.milsNight ?? 0.0)
        }
        
       
        
        
        if mileModel!.milsNightYOY! > 0.0 {
            mileFourView.mileTotalIcon.isHidden = false
            mileFourView.mileTotalIcon.image = UIImage(named: "report_tigao")
            mileFourView.mileBgView.layer.borderColor = UIColor(hex: "#F23E3E", alpha: 1.0)?.cgColor
            mileFourView.mileTotalLabel.textColor = UIColor(hex: "#F23E3E", alpha: 1.0)
            mileFourView.mileTotalLabel.text = String(format: "%.1f%@", (mileModel?.milsNightYOY ?? 0) * 100 ,"%")
        }else if mileModel!.milsNightYOY! < 0.0{
             mileFourView.mileTotalIcon.isHidden = false
            mileFourView.mileTotalIcon.image = UIImage(named: "report_jiangdi")
            mileFourView.mileBgView.layer.borderColor = UIColor(hex: "#1C942D", alpha: 1.0)?.cgColor
            mileFourView.mileTotalLabel.textColor = UIColor(hex: "#1C942D", alpha: 1.0)
            mileFourView.mileTotalLabel.text = String(format: "%.1f%@", -(mileModel?.milsNightYOY ?? 0) * 100 ,"%")
        }else if mileModel!.milsNightYOY! == 0.0{
             mileFourView.mileTotalIcon.isHidden = true
            mileFourView.mileBgView.layer.borderColor = UIColor(hex: "#363847", alpha: 1.0)?.cgColor
            mileFourView.mileTotalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
            mileFourView.mileTotalLabel.text = String(format: "%.1f%@", (mileModel?.milsNightYOY ?? 0) * 100 ,"%")
        }
        
        
       
        
    }
    
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
