//
//  EnterpriseVehicleBottomView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/19.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class EnterpriseVehicleBottomView: UIView {
    
    var topValueLabel:UILabel!
    var desLabel:UILabel!
    
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        self.createUI()
        updateConstraints()
    }
    
    
    private func createUI() {
        topValueLabel = UILabel()
        topValueLabel.text = ""
        topValueLabel.textColor = UIColor(hex: "#1D69F5", alpha: 1.0)
        topValueLabel.font = UIFont.systemFont(ofSize: 17)
        topValueLabel.textAlignment = .left
        self.addSubview(topValueLabel)
        
        desLabel = UILabel()
        desLabel.text = ""
        desLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        desLabel.font = UIFont.systemFont(ofSize: 12)
        desLabel.textAlignment = .left
        self.addSubview(desLabel)
  
    }
    
    
    
    
    
    
    override func updateConstraints() {
        super.updateConstraints()
        
        topValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(2)
            make.top.equalTo(self.snp.top).offset(2)
        }
        
        
        desLabel.snp.makeConstraints { (make) in
            make.centerX.equalTo(topValueLabel)
            make.top.equalTo(topValueLabel.snp.bottom).offset(4)
        }
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

}
