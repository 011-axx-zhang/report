
//
//  RIskPieChartDesCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/20.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class RiskPieChartDesCollectionViewCell: UICollectionViewCell {
    var circleView:UIView!
    var desLabel:UILabel!
    var numLabel:UILabel!
    var percentLabel:UILabel!
    
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        initView()
        updateConstraints()
    }
    
    func initView(){

        circleView = UIView()
        circleView.layer.cornerRadius = 5
        circleView.backgroundColor = UIColor(hex: "#F88574", alpha: 1.0)
        self.contentView.addSubview(circleView)
        desLabel = UILabel()
        desLabel.text = "中: 跟车距离过近（日间）"
        desLabel.font = UIFont.boldSystemFont(ofSize: 12)
        desLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(desLabel)
        numLabel = UILabel()
        numLabel.text = "12次"
        numLabel.font = UIFont.boldSystemFont(ofSize: 12)
        numLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(numLabel)
        percentLabel = UILabel()
        percentLabel.text = "38.4%"
        percentLabel.font = UIFont.boldSystemFont(ofSize: 12)
        percentLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(percentLabel)
 
    }
    
    
    func configData(model:RiskPieModel,color:UIColor)  {
        desLabel.text = model.x ?? ""
        numLabel.text = String(format: "%d次", model.y!)
        percentLabel.text = String(format: "%.1f%@", model.rate!,"%")
        circleView.backgroundColor = color
    }
    
    override func updateConstraints() {
        super.updateConstraints()
    
        
        circleView.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.left).offset(32)
            make.centerY.equalTo(self)
            make.size.equalTo(CGSize(width: 10, height: 10))
        }
        desLabel .snp.makeConstraints { (make) in
            make.left.equalTo(circleView.snp.right).offset(5)
            make.centerY.equalTo(self)
        }
        percentLabel.snp.makeConstraints { (make) in
            make.right.equalTo(self.contentView.snp.right).offset(-52)
            make.centerY.equalTo(self)
        }
        
        numLabel.snp.makeConstraints { (make) in
           make.right.equalTo(percentLabel.snp.left).offset(-42)
            make.centerY.equalTo(self)
        }
    
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
