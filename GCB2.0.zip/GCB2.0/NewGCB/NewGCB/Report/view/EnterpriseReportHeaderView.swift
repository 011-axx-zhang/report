//
//  EnterpriseReportHeaderView.swift
//  NewGCB
//
//  Created by YTKJ on 2020/2/12.
//  Copyright © 2020 YTKJ. All rights reserved.
//

import UIKit

class EnterpriseReportHeaderView: UIView {

     var vehicleImageView:UIImageView!
      var companyLabel:UILabel!
      var numLabel:UILabel!
      var creditLabel :UILabel!
      var creditValueLabel:UILabel!
    
      var vehicleNumLabel:UILabel!
      var fuzhuSetNumLabel:UILabel!
      var wenkongSetNumLabel:UILabel!
      var jiankongSetNumLabel:UILabel!
      var driverNumLabel:UILabel!
      
      
      
      override init(frame: CGRect) {
          super.init(frame: frame)
          self.backgroundColor = UIColor.white
          initView()
          updateConstraints()
      }
      
      
      
      
      func initView(){
        vehicleImageView = UIImageView()
        vehicleImageView.image = UIImage(named: "company")
        self.addSubview(vehicleImageView)
        
        companyLabel = UILabel()
        companyLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        companyLabel.text = ""
        companyLabel.font = UIFont.systemFont(ofSize: 15)
        self.addSubview(companyLabel)
        
//        numLabel = UILabel()
//        numLabel.text = ""
//        numLabel.font = UIFont.systemFont(ofSize: 18)
//        numLabel.textColor = UIColor(hex: "#1D69F5", alpha: 1.0)
//        numLabel.isHidden = true
//        self.addSubview(numLabel)
//
//        creditLabel = UILabel()
//        creditLabel.text = "安全信用积分:"
//        creditLabel.font = UIFont.systemFont(ofSize: 12)
//        creditLabel.textColor = UIColor(hex: "#1D69F5", alpha: 1.0)
//        creditLabel.isHidden = true
//        self.addSubview(creditLabel)
//
//        creditValueLabel = UILabel()
//        creditValueLabel.text = ""
//        creditValueLabel.font = UIFont.boldSystemFont(ofSize: 12)
//        creditValueLabel.textColor = UIColor(hex: "#1D69F5", alpha: 1.0)
//        creditValueLabel.isHidden = true
//        self.addSubview(creditValueLabel)
        
        vehicleNumLabel = UILabel()
        vehicleNumLabel.text = "已安装车辆："
        vehicleNumLabel.font = UIFont.systemFont(ofSize: 11)
        vehicleNumLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.addSubview(vehicleNumLabel)
        
        fuzhuSetNumLabel = UILabel()
        fuzhuSetNumLabel.text = "辅助驾驶设备："
        fuzhuSetNumLabel.font = UIFont.systemFont(ofSize: 11)
        fuzhuSetNumLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.addSubview(fuzhuSetNumLabel)
        
        wenkongSetNumLabel = UILabel()
        wenkongSetNumLabel.text = "温控设备："
        wenkongSetNumLabel.font = UIFont.systemFont(ofSize: 11)
        wenkongSetNumLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.addSubview(wenkongSetNumLabel)
        
        jiankongSetNumLabel = UILabel()
        jiankongSetNumLabel.text = "司机监控设备："
        jiankongSetNumLabel.font = UIFont.systemFont(ofSize: 11)
        jiankongSetNumLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.addSubview(jiankongSetNumLabel)
        
        driverNumLabel = UILabel()
        driverNumLabel.text = "已认证驾驶员："
        driverNumLabel.font = UIFont.systemFont(ofSize: 11)
        driverNumLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.addSubview(driverNumLabel)
          
          
          
      }
      
      override func updateConstraints() {
          super.updateConstraints()
          vehicleImageView.snp.makeConstraints { (make) in
              make.left.equalTo(self.snp.left).offset(15)
              make.top.equalTo(self.snp.top).offset(18)
              make.size.equalTo(CGSize(width: 100, height: 124))
          }
      
          companyLabel.snp.makeConstraints { (make) in
              make.left.equalTo(vehicleImageView.snp.right).offset(16)
              make.top.equalTo(self.snp.top).offset(26)
          }

        
//        creditLabel.snp.makeConstraints { (make) in
//            make.left.equalTo(vehicleImageView.snp.right).offset(16)
//            make.top.equalTo(companyLabel.snp.bottom).offset(7)
//
//        }
//        numLabel.snp.makeConstraints { (make) in
//            make.left.equalTo(creditLabel.snp.right).offset(8)
//            make.centerY.equalTo(creditLabel)
//        }
//
//        creditValueLabel.snp.makeConstraints { (make) in
//            make.left.equalTo(numLabel.snp.right).offset(8)
//            make.centerY.equalTo(creditLabel)
//        }
        
      
          vehicleNumLabel.snp.makeConstraints { (make) in
              make.left.equalTo(vehicleImageView.snp.right).offset(16)
              make.top.equalTo(companyLabel.snp.bottom).offset(24)
          }
          
         fuzhuSetNumLabel.snp.makeConstraints { (make) in
              make.left.equalTo(vehicleNumLabel.snp.right).offset(20)
              make.top.equalTo(companyLabel.snp.bottom).offset(24)
          }
          
          wenkongSetNumLabel.snp.makeConstraints { (make) in
               make.left.equalTo(vehicleImageView.snp.right).offset(16)
               make.top.equalTo(vehicleNumLabel.snp.bottom).offset(4)
           }
           
          jiankongSetNumLabel.snp.makeConstraints { (make) in
               make.left.equalTo(fuzhuSetNumLabel.snp.left).offset(0)
               make.top.equalTo(vehicleNumLabel.snp.bottom).offset(4)
           }
              
          driverNumLabel.snp.makeConstraints { (make) in
               make.left.equalTo(vehicleImageView.snp.right).offset(16)
               make.top.equalTo(wenkongSetNumLabel.snp.bottom).offset(4)
           }
    
      }
      
      func configData(model:EnterpriseInfoModel) {
          companyLabel.text = model.name ?? ""
          if model.logo != nil && model.logo != "" {
              let url = URL.init(string: model.logo!)
              vehicleImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "company"), options: .highPriority) { (image, error, sdImageCacheType, url) in
              }
          }else {
              vehicleImageView.image = UIImage(named: "company")
          }
//          numLabel.text = String(format: "%d", model.safeCreditIndex ?? 0)
//          creditValueLabel.text = model.safeCreditIndexDes ?? ""
        
          vehicleNumLabel.text =  String(format: "已安装车辆: %d", model.vehSum ?? 0)
          fuzhuSetNumLabel.text =  String(format: "辅助驾驶设备:%d", model.adasSum ?? 0)
          wenkongSetNumLabel.text =  String(format: "温控设备:%d", model.temperatureDevices ?? 0)
          jiankongSetNumLabel.text =  String(format: "司机监控设备:%d", model.dmsSum ?? 0)
          driverNumLabel.text =  String(format: "已认证驾驶员:%d", model.driverSum ?? 0)
      }
      
      required init?(coder: NSCoder) {
          fatalError("init(coder:) has not been implemented")
      }

}
