//
//  RiskPieChartCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/20.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import Charts

class RiskPieChartCollectionViewCell: UICollectionViewCell {
    var titleLabel:UILabel!
    var desLabel:UILabel!
    var desRightLabel:UILabel!
    var xValueArr:Array<String> = []
    var yValueArr:Array<Int64> = []
    var colors:Array<UIColor> = []
    var imageView:UIImageView!
    var nodataLabel:UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.clear
        self.addSubview(self.pieChartView)
        self.createColors()
       // self.drawPieChartView()
        self.initView()
        updateConstraints()
    }
    
    lazy var pieChartView: PieChartView = {
        let _pieChartView = PieChartView.init(frame: CGRect.init(x: 10, y: 10, width: KW - 20, height: 160));
       // _pieChartView.backgroundColor = UIColor.init(red: 230/255.0, green: 253/255.0, blue: 253/255.0, alpha: 1.0);
        _pieChartView.setExtraOffsets(left: 10, top: 0, right: 10, bottom: 0);//设置这块饼的位置
        _pieChartView.chartDescription?.text = "";//描述文字
        _pieChartView.chartDescription?.font = UIFont.systemFont(ofSize: 12.0);//字体
        _pieChartView.chartDescription?.textColor = UIColor.black;//颜色
        
        _pieChartView.usePercentValuesEnabled = true;//转化为百分比
        _pieChartView.dragDecelerationEnabled = false;//我把拖拽效果关了
        _pieChartView.drawEntryLabelsEnabled = false;//不显示区块文本
        _pieChartView.entryLabelFont = UIFont.systemFont(ofSize: 10);//区块文本的字体
        _pieChartView.entryLabelColor = UIColor.white;
        _pieChartView.drawSlicesUnderHoleEnabled = true;
        
        
        _pieChartView.drawHoleEnabled = true;//这个饼是空心的
        _pieChartView.holeRadiusPercent = 0.65//空心半径黄金比例
        _pieChartView.holeColor = UIColor.white;//空心颜色设置为白色
        _pieChartView.transparentCircleRadiusPercent = 0.65;//半透明空心半径
        
        _pieChartView.drawCenterTextEnabled = true;//显示中心文本
        _pieChartView.centerText = "";//设置中心文本,你也可以设置富文本`centerAttributedText`
    
        
        //图例样式设置
        _pieChartView.legend.maxSizePercent = 0;//图例的占比
        _pieChartView.legend.form = .circle//图示：原、方、线
        _pieChartView.legend.formSize = 0;//图示大小
        _pieChartView.noDataText = "";
        _pieChartView.noDataTextColor = UIColor.gray;
        _pieChartView.noDataFont = UIFont.boldSystemFont(ofSize: 14);
        
        return _pieChartView;
    }()
    
    func drawPieChartView() {
       // let titles = ["红","黄","蓝色","橙","绿"];
        let yData = yValueArr
        var yVals = [PieChartDataEntry]();
        for i in 0..<yValueArr.count {
            let entry = PieChartDataEntry.init(value: Double(yValueArr[i]), label: "");
            yVals.append(entry);
        }
    
        let dataSet = PieChartDataSet.init(entries: yVals, label: "");
        dataSet.colors = colors;
        //设置名称和数据的位置 都在内就没有折线了哦
        dataSet.xValuePosition = .insideSlice;
        dataSet.yValuePosition = .outsideSlice;
        dataSet.sliceSpace = 1;//相邻块的距离
        dataSet.selectionShift = 0;//选中放大半径
        let data = PieChartData.init(dataSets: [dataSet]);
        pieChartView.data = data;
        dataSet.valueLineWidth = 0 //折线的粗细
    
    }
    
    func createColors()  {
        let arr = ["#66B8FE","#7BE279","#FFE03F","#FAB286","#FD723A","#7D8DFD","#8AE1BF","#F59BCC","#FFC53F","#F95642","#1889F7","#38C465","#A7B4FF","#FFCCE3","#FD723A","#4163DD","#85DE50","#FFA0ED","#C7D0FF","#FE9A28"]
        for i in 0...19 {
            let color = UIColor(hex: arr[i], alpha: 1.0)
            colors.append(color!)
        }
    }
    
  
    func initView(){
        
        titleLabel = UILabel()
        titleLabel.text = "中高风险类型"
        titleLabel.font = UIFont.boldSystemFont(ofSize: 14)
        titleLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(titleLabel)
        
        
        desLabel = UILabel()
        desLabel.text = "Top风险事件"
        desLabel.font = UIFont.boldSystemFont(ofSize: 14)
        desLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.contentView.addSubview(desLabel)
        
        desRightLabel = UILabel()
        desRightLabel.text = ""
        desRightLabel.font = UIFont.boldSystemFont(ofSize: 12)
        desRightLabel.textColor = UIColor(hex: "#FF0000", alpha: 1.0)
        self.contentView.addSubview(desRightLabel)
        
        
        imageView = UIImageView()
        imageView.image = UIImage(named: "icon_zanwushuju")
        imageView.isHidden = true
        self.addSubview(imageView)
        
        
        
        nodataLabel = UILabel()
        nodataLabel.text = "暂无数据"
        nodataLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        nodataLabel.font = UIFont.systemFont(ofSize: 15)
        self.addSubview(nodataLabel)
        
        
    }
    
    func configData(model:EnterpriseReportModel)  {
         let barModel = model.risk
         let barDataArr = barModel?.pie
       
         xValueArr = barDataArr?.map({ (item) -> String in
             return item.x!
         }) ?? []
        
         yValueArr = barDataArr?.map({ (item) -> Int64 in
             return item.y!
         }) ?? []
        
        let max = yValueArr.max()
        if max != 0  && max != nil{
            self.drawPieChartView()
            desLabel.text = "Top风险事件"
            desRightLabel.text = ""
            self.pieChartView.centerText = "风险事件\n 中/高"
            titleLabel.text = "中高风险类型"
            self.nodataLabel.isHidden = true
            self.imageView.isHidden = true
        }else {
            titleLabel.text = "中高风险类型"
            desLabel.text = ""
            desRightLabel.text = ""
            self.pieChartView.centerText = ""
            self.drawPieChartView()
            self.nodataLabel.isHidden = false
            self.imageView.isHidden = false
        }
        
       
    
     }
    
    
    //  配置司机报表model
    func configDriverData(model:DriverReportModel)  {
         let barModel = model.risk
         let barDataArr = barModel?.pie
       
         xValueArr = barDataArr?.map({ (item) -> String in
             return item.event!
         }) ?? []
        
         yValueArr = barDataArr?.map({ (item) -> Int64 in
            return item.value!
         }) ?? []
        
        let max = yValueArr.max()
        if max != 0  && max != nil{
            self.drawPieChartView()
            desLabel.text = "Top风险事件"
            desRightLabel.text = ""
            self.pieChartView.centerText = "风险事件\n 中/高"
            titleLabel.text = "中高风险类型"
            self.drawPieChartView()
        }else {
            titleLabel.text = ""
            desLabel.text = ""
            desRightLabel.text = ""
            self.pieChartView.centerText = ""
            nodataLabel.isHidden = true
        }
    
     }
    
    
    
    override func updateConstraints() {
        super.updateConstraints()
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self.contentView.snp.top).offset(5)
        }
        
        desLabel.snp.makeConstraints { (make) in
            make.bottom.equalTo(self.contentView.snp.bottom).offset(-10)
            make.left.equalTo(self.snp.left).offset(33)
        }
        
        desRightLabel.snp.makeConstraints { (make) in
            make.left.equalTo(desLabel.snp.right).offset(10)
            make.centerY.equalTo(desLabel)
        }
        
        
        imageView.snp.makeConstraints { (make) in
            make.center.equalTo(self)
            make.size.equalTo(CGSize(width: 81, height: 61))
        }
        
        nodataLabel.snp.makeConstraints { (make) in
            make.top.equalTo(imageView.snp.bottom).offset(18)
            make.centerX.equalTo(self)
        }
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
