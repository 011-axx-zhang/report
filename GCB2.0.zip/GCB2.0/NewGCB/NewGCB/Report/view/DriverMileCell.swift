//
//  DriverMileCell.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/24.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class DriverMileCell: UICollectionViewCell {
    var titleLabel:UILabel!
    var firstView:UIView!
    var seconView:UIView!
    var thirdView:UIView!
    var fourView:UIView!
    
    
    var rijianIcon:UIImageView!
    var rijianTimeLabel:UILabel!
    
    var yejianIcon:UIImageView!
    var yejiianTimeLabel:UILabel!
    
    
    var mileFirstView:EnterpriseView!
    var mileSecView:EnterpriseView!
    
    var mileThirdView:EnterpriseView!
    var mileFourView:EnterpriseView!
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        initView()
        updateConstraints()
    }
    
    
    func initView(){
        titleLabel = UILabel()
        titleLabel.font = UIFont.boldSystemFont(ofSize: 17)
        titleLabel.text = "行驶里程"
        titleLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(titleLabel)
        
        firstView = UIView()
        firstView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        firstView.layer.cornerRadius = 4
        self.contentView.addSubview(firstView)
        
        seconView = UIView()
        seconView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        seconView.layer.cornerRadius = 4
        self.contentView.addSubview( seconView)
        
        
        thirdView = UIView()
        thirdView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        thirdView.layer.cornerRadius = 4
        self.contentView.addSubview(thirdView)
        
        fourView = UIView()
        fourView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        fourView.layer.cornerRadius = 4
        self.contentView.addSubview(fourView)
        
        
        rijianIcon = UIImageView()
        rijianIcon.image = UIImage(named: "baobiao_rijian")
        thirdView.addSubview(rijianIcon)
        rijianTimeLabel = UILabel()
        rijianTimeLabel.text = "(7:00～21:00)"
        rijianTimeLabel.font = UIFont.systemFont(ofSize: 10)
        rijianTimeLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        thirdView.addSubview(rijianTimeLabel)
        
        
        yejianIcon = UIImageView()
        yejianIcon.image = UIImage(named: "baobiao_yejian")
        fourView.addSubview(yejianIcon)
        yejiianTimeLabel = UILabel()
        yejiianTimeLabel.text = "(7:00～21:00)"
        yejiianTimeLabel.font = UIFont.systemFont(ofSize: 10)
        yejiianTimeLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        fourView.addSubview(yejiianTimeLabel)
        
        
        mileFirstView = EnterpriseView()
        mileFirstView.desLabel.text = "累计行驶公里"
        mileFirstView.hiddenViewIcon()
        mileFirstView.mileBgView.isHidden = true
        self.contentView.addSubview(mileFirstView)
        mileSecView = EnterpriseView()
        mileSecView.desLabel.text = "百公里高/中风险数"
        mileSecView.mileBgView.isHidden = true
        self.contentView.addSubview(mileSecView)
        
        
        mileThirdView = EnterpriseView()
        mileThirdView.desLabel.text = "日间行驶公里"
        mileThirdView.mileBgView.isHidden = true
        self.contentView.addSubview(mileThirdView)
        mileFourView = EnterpriseView()
        mileFourView.desLabel.text = "夜间行驶公里"
        mileFourView.mileBgView.isHidden = true
        self.contentView.addSubview(mileFourView)
        
        
        
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self.snp.top).offset(12)
        }
        
        firstView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(titleLabel.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 38)/2, height: 68))
        }
        seconView.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.right).offset(8)
            make.top.equalTo(titleLabel.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 38)/2, height: 68))
        }
        
        
        thirdView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(firstView.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 38)/2, height: 84))
        }
        
        fourView.snp.makeConstraints { (make) in
            make.left.equalTo( thirdView.snp.right).offset(8)
            make.top.equalTo(firstView.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 38)/2, height: 84))
        }
        
        
        
        
        rijianIcon.snp.makeConstraints { (make) in
            make.left.equalTo(thirdView.snp.left).offset(5)
            make.top.equalTo(thirdView.snp.top).offset(13)
            make.size.equalTo(CGSize(width: 20, height: 20))
        }
        rijianTimeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(rijianIcon.snp.right).offset(2)
            make.top.equalTo(thirdView.snp.top).offset(13)
        }
        
        
        yejianIcon.snp.makeConstraints { (make) in
            make.left.equalTo(fourView.snp.left).offset(5)
            make.top.equalTo(fourView.snp.top).offset(13)
            make.size.equalTo(CGSize(width: 20, height: 20))
        }
        yejiianTimeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(yejianIcon.snp.right).offset(2)
            make.top.equalTo(fourView.snp.top).offset(13)
        }
        
        
        mileFirstView.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.left).offset(20)
            make.top.equalTo(firstView.snp.top).offset(12)
        }
        mileSecView.snp.makeConstraints { (make) in
            make.left.equalTo(seconView.snp.left).offset(26)
            make.top.equalTo(seconView.snp.top).offset(12)
        }
        
        mileThirdView.snp.makeConstraints { (make) in
            make.left.equalTo(thirdView.snp.left).offset(26)
            make.top.equalTo(rijianTimeLabel.snp.bottom).offset(5)
        }
        mileFourView.snp.makeConstraints { (make) in
            make.left.equalTo(fourView.snp.left).offset(26)
            make.top.equalTo(rijianTimeLabel.snp.bottom).offset(5)
        }
        
        
    }
    
    
    func setDriverMileCellData(cellModel: DriverReportMils) -> Void {
        
        mileFirstView.topValueLabel.text = String(cellModel.milsSum)  //  累计行驶公里
        mileSecView.topValueLabel.text = String(cellModel.riskPerHundred)      //  百公里高/中风险数
        mileThirdView.topValueLabel.text = String(cellModel.milsDay)  //  日间行驶公里
        mileFourView.topValueLabel.text = String(cellModel.milsNight)     //  夜间行驶公里
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
