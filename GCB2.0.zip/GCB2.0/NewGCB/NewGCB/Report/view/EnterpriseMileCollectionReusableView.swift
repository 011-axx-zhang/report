//
//  EnterpriseMileCollectionReusableView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/18.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class EnterpriseMileCollectionReusableView: UICollectionReusableView {
    var topBgView:UIView!
    var dateBtn:UIButton!
    var dateLabel:UILabel!
    var dateIcon:UIImageView!
    var dateValueLabel:UILabel!
    var todayBtn:UIButton!
    var sevBtn:UIButton!
    var thirtyBtn:UIButton!
    var lineView:UIView!
    var animateView:UIView!
    var selectBtn:UIButton!
    var toTimeStr:String = ""
    
    @objc var passDay:((Int)->Void)?
     @objc var dateClick:(()->Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setNowTime()
        self.createUI()
        self.updateConstraints()
    }
    
    private func createUI() {
        
        topBgView = UIView()
        topBgView.backgroundColor = UIColor(hex: "#F0F0F7", alpha: 1.0)
        self.addSubview(topBgView)
        
        
        dateBtn = UIButton()
        dateBtn.backgroundColor = UIColor.white
        dateBtn.layer.cornerRadius = 12
        topBgView.addSubview(dateBtn)
        
        dateLabel = UILabel()
        dateLabel.text = toTimeStr
        dateLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        dateLabel.font = UIFont.systemFont(ofSize: 13)
        dateBtn.addSubview(dateLabel)
        
        
        dateIcon = UIImageView()
        dateIcon.image = UIImage(named: "report_xiala")
        dateIcon.contentMode = .center
        dateBtn.addSubview(dateIcon)
        
        dateValueLabel = UILabel()
        dateValueLabel.text = toTimeStr
        dateValueLabel.font = UIFont.systemFont(ofSize: 13)
        dateValueLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        topBgView.addSubview(dateValueLabel)
        
        todayBtn = UIButton()
        todayBtn.setTitle("当日", for: .normal)
        todayBtn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
        todayBtn.setTitleColor(UIColor(hex: "#363847", alpha: 1.0), for: .normal)
        todayBtn.setTitleColor(UIColor(hex: "#325AEF", alpha: 1.0), for: .selected)
        todayBtn.tag = 170001
        todayBtn.addTarget(self, action: #selector(self.btnEvent(btn:)), for: .touchUpInside)
        self.addSubview(todayBtn)
        selectBtn = todayBtn
        todayBtn.isSelected = true
        
        sevBtn = UIButton()
        sevBtn.setTitle("7天", for: .normal)
        sevBtn.titleLabel?.font = UIFont.systemFont(ofSize: 15.0)
        sevBtn.setTitleColor(UIColor(hex: "#363847", alpha: 1.0), for: .normal)
        sevBtn.setTitleColor(UIColor(hex: "#325AEF", alpha: 1.0), for: .selected)
        sevBtn.tag = 170002
        sevBtn.addTarget(self, action: #selector(self.btnEvent(btn:)), for: .touchUpInside)
        self.addSubview(sevBtn)
        
        thirtyBtn = UIButton()
        thirtyBtn.setTitle("30天", for: .normal)
        thirtyBtn.titleLabel?.font = UIFont.systemFont(ofSize: 15.0)
        thirtyBtn.setTitleColor(UIColor(hex: "#363847", alpha: 1.0), for: .normal)
        thirtyBtn.setTitleColor(UIColor(hex: "#325AEF", alpha: 1.0), for: .selected)
        thirtyBtn.tag = 170003
        thirtyBtn.addTarget(self, action: #selector(self.btnEvent(btn:)), for: .touchUpInside)
        self.addSubview(thirtyBtn)
        
        lineView = UIView()
        lineView.backgroundColor = UIColor(hex: "#E6E9EE", alpha: 1.0)
        self.addSubview(lineView)
        
        animateView = UIView()
        animateView.backgroundColor = UIColor(hex: "#325AEF", alpha: 1.0)
        animateView.layer.cornerRadius = 1.5
        self.addSubview(animateView)
        
        dateBtn.addTarget(self, action: #selector(self.dateEvent), for: .touchUpInside)
        self.animateView.frame = CGRect(x: KW/6 - 15, y: 85, width: 30, height: 3)
        
    }
    
    func setNowTime() {
        let date = Date()
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy-MM-dd"
        let timeS:TimeInterval = TimeInterval(24*60*60)
        let nowTimeS:TimeInterval = date.timeIntervalSince1970
        let totalTime :TimeInterval = nowTimeS - timeS
        let needDate :Date  = Date.init(timeIntervalSince1970: totalTime)
        toTimeStr = dateFmt.string(from: needDate)
    }
    
    
    
    
    @objc  func dateEvent()  {
        self.dateClick?()
    }
    
    
    
    @objc  func btnEvent(btn:UIButton)  {
        selectBtn.titleLabel?.font = UIFont.systemFont(ofSize: 15.0)
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15.0)
        selectBtn.isSelected = false
        btn.isSelected = true
        selectBtn = btn

        UIView.animate(withDuration: 0.1, animations: {
            if btn.tag == 170001 {
                self.animateView.frame = CGRect(x: KW/6 - 15, y: 85, width: 30, height: 3)
            }else if btn.tag == 170002 {
                self.animateView.frame = CGRect(x: KW/2.0 - 15, y: 85, width: 30, height: 3)
            }else {
                self.animateView.frame = CGRect(x: KW/6*5 - 15 , y: 85, width: 30, height: 3)
            }
            
            
        }) { (finished) in
         
            if btn.tag == 170001 {
                self.passDay?(1)
            }else if btn.tag == 170002 {
                self.passDay?(7)
            }else {
                self.passDay?(30)
            }
            
           
        }
        
        
    }
    
    
    
    
    override func updateConstraints() {
        super.updateConstraints()
        topBgView.snp.makeConstraints { (make) in
            make.top.equalTo(self.snp.top).offset(0)
            make.left.equalTo(self)
            make.size.equalTo(CGSize(width: KW, height: 44))
        }
        
        
        
        dateBtn.snp.makeConstraints { (make) in
            make.left.equalTo(topBgView.snp.left).offset(15)
            make.top.equalTo(topBgView.snp.top).offset(10)
            make.size.equalTo(CGSize(width: 108, height: 24))
        }
        
        dateLabel.snp.makeConstraints { (make) in
            make.left.equalTo(dateBtn.snp.left).offset(8)
            make.centerY.equalTo(dateBtn)
        }
        
        dateIcon.snp.makeConstraints { (make) in
            make.left.equalTo(dateLabel.snp.right).offset(5)
            make.centerY.equalTo(dateBtn)
            make.size.equalTo(CGSize(width: 10, height: 10))
        }
        
        dateValueLabel.snp.makeConstraints { (make) in
            make.right.equalTo(topBgView.snp.right).offset(-15)
            make.centerY.equalTo(dateBtn)
        }
        
        todayBtn.snp.makeConstraints { (make) in
            make.top.equalTo(topBgView.snp.bottom).offset(0)
            make.left.equalTo(self)
            make.size.equalTo(CGSize(width: KW/3.0, height: 40))
        }
        
        
        sevBtn.snp.makeConstraints { (make) in
            make.top.equalTo(topBgView.snp.bottom).offset(0)
            make.left.equalTo(todayBtn.snp.right).offset(0)
            make.size.equalTo(CGSize(width: KW/3.0, height: 40))
        }
        
        thirtyBtn.snp.makeConstraints { (make) in
            make.top.equalTo(topBgView.snp.bottom).offset(0)
            make.left.equalTo(sevBtn.snp.right).offset(0)
            make.size.equalTo(CGSize(width: KW/3.0, height: 40))
        }
        
        lineView.snp.makeConstraints { (make) in
            make.top.equalTo(todayBtn.snp.bottom).offset(4)
            make.left.equalTo(self.snp.left).offset(0)
            make.size.equalTo(CGSize(width: KW, height: 1))
        }
        
        
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
