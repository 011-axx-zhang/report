//
//  DriverInfoHeaderCell.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/24.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import Charts

class DriverInfoHeaderCell: UICollectionViewCell {
    let btnTitle:Array<String> = ["驾驶证","年龄","资格证","健康证"]
    let headPicker = UIImageView()
    let driverName = UILabel()
    let orgName = UILabel()
    let orgLocality = UILabel()
    let creditValue = UILabel()
    let creditTitle = UILabel()
    let creditLevel = UILabel()
    var call : UIButton!
    var collect:UIButton!
    var titleArr = [UIButton]()
    let line = UIView()
//    let chart = ChartView.init()
    @objc var callTheNumberClick:(()->Void)?
    @objc var focusDriverClick:(()->Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        initView()
        updateConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func initView() -> Void {
        self.contentView.addSubview(headPicker)
        
        driverName.font = UIFont.boldSystemFont(ofSize: 16)
        self.contentView.addSubview(driverName)
        
        orgName.font = UIFont.systemFont(ofSize: 14)
        self.contentView.addSubview(orgName)
        
        orgLocality.font = UIFont.systemFont(ofSize: 11)
        orgLocality.textColor = UIColor.init(hex: "#5C5E74", alpha: 1.0)
        self.contentView.addSubview(orgLocality)
        
        creditValue.font = UIFont.boldSystemFont(ofSize: 17)
        creditValue.textColor = UIColor.init(hex: "#1D69F5", alpha: 1.0)
//        self.contentView.addSubview(creditValue)
        
        creditTitle.font = UIFont.systemFont(ofSize: 12)
        creditTitle.text = "安全信用 "
        creditTitle.textColor = UIColor.init(hex: "#1D69F5", alpha: 1.0)
//        self.contentView.addSubview(creditTitle)
        
        creditLevel.font = UIFont.boldSystemFont(ofSize: 12)
        creditLevel.textColor = UIColor.init(hex: "#1D69F5", alpha: 1.0)
//        self.contentView.addSubview(creditLevel)
        
        for index in 0..<4 {
            let item = UIButton.init(type: .custom)
            item.titleLabel?.font = UIFont.systemFont(ofSize: 10)
            item.setTitle(btnTitle[index], for: .normal)
            item.backgroundColor = UIColor.init(hex: "#1A66E6", alpha: 0.16)
            item.setTitleColor(UIColor.init(hex: "#1D69F5", alpha: 1.0), for: .normal)
            item.setTitleColor(UIColor.init(hex: "#9395AC", alpha: 1.0), for: .disabled)
            item.layer.cornerRadius = 8
            self.contentView.addSubview(item)
            titleArr.append(item)
        }
        
        collect = UIButton.init(type: .custom)
        collect.setImage(UIImage.init(named: "follow_heart_normal"), for: .normal)
        collect.setImage(UIImage.init(named: "follow_heart_selected"), for: .selected)
        collect.addTarget(self, action: #selector(clickFocusDriverBtn), for: .touchUpInside)
        self.contentView.addSubview(collect)
        
        call = UIButton.init(type: .custom)
        call.setImage(UIImage.init(named: "driver_report_call"), for: .normal)
        call.addTarget(self, action: #selector(clickCallBtn), for: .touchUpInside)
        self.contentView.addSubview(call)
        
        line.backgroundColor = UIColor.init(hex: "#E2E2F2", alpha: 1.0)
        self.contentView.addSubview(line)
        
        
        //  雷达图
//        contentView.addSubview(chart)
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        
        headPicker.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.top.equalTo(self.contentView.snp.top).offset(18)
            make.width.equalTo(100)
            make.height.equalTo(124)
        }
        
        driverName.snp.makeConstraints { (make) in
            make.left.equalTo(headPicker.snp.right).offset(16)
            make.top.equalTo(self.contentView.snp.top).offset(28)
            make.height.equalTo(22)
        }
        
        orgName.snp.makeConstraints { (make) in
            make.left.equalTo(headPicker.snp.right).offset(16)
            make.top.equalTo(driverName.snp.bottom).offset(2)
            make.height.equalTo(20)
        }
        
        orgLocality.snp.makeConstraints { (make) in
            make.left.equalTo(headPicker.snp.right).offset(16)
            make.top.equalTo(orgName.snp.bottom)
            make.height.equalTo(16)
        }
        
//        creditValue.snp.makeConstraints { (make) in
//            make.left.equalTo(headPicker.snp.right).offset(16)
//            make.top.equalTo(orgLocality.snp.bottom).offset(10)
//            make.height.equalTo(24)
//        }
//
//        creditTitle.snp.makeConstraints { (make) in
//            make.left.equalTo(creditValue.snp.right).offset(15)
//            make.top.equalTo(orgLocality.snp.bottom).offset(14)
//            make.height.equalTo(17)
//        }
//
//        creditLevel.snp.makeConstraints { (make) in
//            make.left.equalTo(creditTitle.snp.right).offset(5)
//            make.top.equalTo(orgLocality.snp.bottom).offset(14)
//            make.height.equalTo(17)
//        }
        
        var space = 16.0
        var leftConstraintView:UIView = headPicker
        var topConstranintView:UIView = orgLocality
        
        for index in 0..<titleArr.count {
            let btn = titleArr[index]
            btn.snp.makeConstraints { (make) in
                make.left.equalTo(leftConstraintView.snp.right).offset(space)
                make.top.equalTo(topConstranintView.snp.bottom).offset(4)
                make.height.equalTo(16)
                make.width.equalTo(50)
            }
            
            if index == 1 {
                leftConstraintView = headPicker
                topConstranintView = titleArr.first!
                space = 16.0
            }else{
                leftConstraintView = btn
                space = 8.0
            }
        }
        
        collect.snp.makeConstraints { (make) in
            make.right.equalTo(self.contentView.snp.right).offset(-15)
            make.top.equalTo(self.contentView.snp.top).offset(26)
            make.width.equalTo(25)
            make.height.equalTo(25)
        }
        
        call.snp.makeConstraints { (make) in
            make.right.equalTo(self.contentView.snp.right).offset(-15)
            make.top.equalTo(collect.snp.bottom).offset(15)
            make.width.equalTo(25)
            make.height.equalTo(25)
        }
        
        line.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.left)
            make.right.equalTo(self.contentView.snp.right)
            make.top.equalTo(headPicker.snp.bottom).offset(18)
            make.height.equalTo(1)
        }
        
//        chart.snp.makeConstraints { (make) in
//            make.left.equalTo(self.contentView.snp.left)
//            make.top.equalTo(line.snp.bottom).offset(10)
//            make.height.equalTo(420)
//            make.width.equalTo(KW)
//        }
    }
    
    func changeChartViewData(value:DriverInfoModel) -> Void {
        if value.driverurl == nil || value.driverurl == "" || value.driverurl == " " {
            headPicker.image = UIImage.init(named: "home_driver")
        }else{
            headPicker.sd_setImage(with: URL.init(string: value.driverurl!), placeholderImage: UIImage.init(named: "home_driver"), options: .delayPlaceholder, completed: nil)
        }
        
        driverName.text = value.name
        orgName.text = value.orgName
        orgLocality.text = value.company
        creditValue.text = "\(value.safeCreditIndex ?? 0)"
        creditLevel.text = value.safeCreditIndexDes
        collect.isSelected = value.isFocused!
//        chart.dataArr = [(value.behaviorScore ?? 0),(value.ownScore ?? 0),(value.studyScore ?? 0),(value.studyScore ?? 0),(value.studyScore ?? 0)]
//        chart.creditExplainString = value.creditExplain ?? ""
//        chart.configData()
        
        let licenseBtn = titleArr[0]
        licenseBtn.setTitle("驾驶证\(value.drivingLicenseType ?? "")", for: .normal)
        
        let ageBtn = titleArr[1]
        ageBtn.setTitle("年龄\(value.age ?? 0)", for: .normal)
        
        let hasCerBtn = titleArr[2]
        if value.hasCer! == false {
            hasCerBtn.isEnabled = false
            hasCerBtn.backgroundColor = UIColor.init(hex: "#E6E9EE", alpha: 1.0)
        }
        
        let healthBtn = titleArr[3]
        if value.hasHealthCer! == false {
            healthBtn.isEnabled = false
            healthBtn.backgroundColor = UIColor.init(hex: "#E6E9EE", alpha: 1.0)
        }
        
    }
    
    
    @objc func clickCallBtn(){
        self.callTheNumberClick?()
    }
    
    @objc func clickFocusDriverBtn(){
        self.focusDriverClick?()
    }
}
