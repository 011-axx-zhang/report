//
//  DriverListTableViewCell.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/20.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

protocol DriverListCellDelegate:NSObjectProtocol {
    func didSelectCollect(_ driverID: Int, isSelected:Bool, selectCell: DriverListTableViewCell)
}

class DriverListTableViewCell: UITableViewCell {
    let headPicker = UIImageView.init() //  头像
    let driver = UILabel.init()     //  驾驶员
    let orgName = UILabel.init()    //  组织名
    let credit = UILabel.init()     //  信用
    let creditValue = UILabel.init()    //  信用分数
    let workTime = UILabel.init()   //  出勤
    let timeValue = UILabel.init()  //  出勤时间
    let mileage = UILabel.init()    //  里程
    let mileageValue = UILabel.init()   //  里程
    let highRisk = UILabel.init()   //  高风险
    let highRiskLabel = UILabel.init()
    let mediumRisk = UILabel.init() //  中风险
    let mediumRiskLabel = UILabel.init()
    var collect : UIButton!    //  收藏
    let line = UIView.init()
    weak var delegate:DriverListCellDelegate?
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        createUI()
        self .updateConstraints()
        self.backgroundColor = UIColor.white
        self.contentView.backgroundColor = UIColor.white
    }
    
    
    private func createUI() {
        
        self.contentView.addSubview(headPicker)
        
        driver.font = UIFont.boldSystemFont(ofSize: 15)
        self.contentView.addSubview(driver)
        
        orgName.font = UIFont.systemFont(ofSize: 10)
        orgName.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.contentView.addSubview(orgName)
        
        credit.textColor = UIColor(hex: "#325AEF", alpha: 1.0)
        credit.font = UIFont.systemFont(ofSize: 12)
        credit.text = "安全信用"
//        self.contentView.addSubview(credit)
        
        creditValue.font = UIFont.boldSystemFont(ofSize: 17)
        creditValue.textColor = UIColor.init(hex: "#325AEF", alpha: 1.0)
//        self.contentView.addSubview(creditValue)
        
        workTime.font = UIFont.systemFont(ofSize: 12)
        workTime.textColor = UIColor.init(hex: "#5C5E74", alpha: 1.0)
        workTime.text = "最近出勤日期："
        self.contentView.addSubview(workTime)
        
        timeValue.font = UIFont.systemFont(ofSize: 12)
        timeValue.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.contentView.addSubview(timeValue)
        
        mileage.font = UIFont.systemFont(ofSize: 12)
        mileage.textColor = UIColor.init(hex: "#5C5E74", alpha: 1.0)
        mileage.text = "今日驾驶里程："
        self.contentView.addSubview(mileage)
        
        mileageValue.font = UIFont.systemFont(ofSize: 12)
        mileageValue.textColor = UIColor.init(hex: "#5C5E74", alpha: 1.0)
        self.contentView.addSubview(mileageValue)
        
        highRisk.font = UIFont.systemFont(ofSize: 9)
        highRisk.textColor = UIColor.init(hex: "#F23E3E", alpha: 1.0)
        highRisk.text = "高风险"
        highRisk.textAlignment = NSTextAlignment.center
        highRisk.layer.borderColor = UIColor.init(hex: "#F23E3E", alpha: 1.0)?.cgColor
        highRisk.layer.borderWidth = 1.0
        self.contentView.addSubview(highRisk)
        
        highRiskLabel.font = UIFont.systemFont(ofSize: 11)
        highRiskLabel.textColor = UIColor.init(hex: "#F23E3E", alpha: 1.0)
        highRiskLabel.textAlignment = NSTextAlignment.left
        self.contentView.addSubview(highRiskLabel)
        
        mediumRisk.font = UIFont.systemFont(ofSize: 9)
        mediumRisk.textColor = UIColor.init(hex: "#F23E3E", alpha: 1.0)
        mediumRisk.text = "中风险"
        mediumRisk.textAlignment = NSTextAlignment.center
        mediumRisk.layer.borderColor = UIColor.init(hex: "#F23E3E", alpha: 1.0)?.cgColor
        mediumRisk.layer.borderWidth = 1.0
        self.contentView.addSubview(mediumRisk)
        
        mediumRiskLabel.font = UIFont.systemFont(ofSize: 11)
        mediumRiskLabel.textColor = UIColor.init(hex: "#F23E3E", alpha: 1.0)
        mediumRiskLabel.textAlignment = NSTextAlignment.left
        self.contentView.addSubview(mediumRiskLabel)
        
        collect = UIButton.init(type: .custom)
        collect.isSelected = false
        collect.setImage(UIImage.init(named: "follow_heart_normal"), for: .normal)
        collect.setImage(UIImage.init(named: "follow_heart_selected"), for: .selected)
        collect.addTarget(self, action: #selector(buttonAction(collect:)), for: .touchUpInside)
        self.contentView.addSubview(collect)
        
        line.backgroundColor = UIColor.init(hex: "#E6E9EE", alpha: 1.0)
        self.contentView.addSubview(line)
        
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        
        headPicker.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.top.equalTo(self.contentView.snp.top).offset(10)
            make.width.equalTo(80)
            make.height.equalTo(100)
        }
        
        driver.snp.makeConstraints { (make) in
            make.left.equalTo(headPicker.snp.right).offset(8)
            make.top.equalTo(self.contentView.snp.top).offset(12)
            make.height.equalTo(21)
        }
        
        orgName.snp.makeConstraints { (make) in
            make.left.equalTo(driver.snp.right).offset(4)
            make.top.equalTo(self.contentView.snp.top).offset(16)
            make.height.equalTo(14)
        }
        
        //  信用
//        credit.snp.makeConstraints { (make) in
//            make.left.equalTo(headPicker.snp.right).offset(8)
//            make.top.equalTo(driver.snp.bottom).offset(4)
//            make.height.equalTo(17)
//        }
        
        //  信用分数
//        creditValue.snp.makeConstraints { (make) in
//            make.left.equalTo(credit.snp.right).offset(5)
//            make.top.equalTo(driver.snp.bottom)
//            make.height.equalTo(24)
//        }
        
        //  出勤
        workTime.snp.makeConstraints { (make) in
            make.left.equalTo(headPicker.snp.right).offset(8)
            make.top.equalTo(driver.snp.bottom).offset(8)
            make.height.equalTo(17)
        }
        
        //  出勤日期
        timeValue.snp.makeConstraints { (make) in
            make.left.equalTo(workTime.snp.right)
            make.top.equalTo(driver.snp.bottom).offset(2)
            make.height.equalTo(17)
        }
        
        //  今日行驶公里
        mileage.snp.makeConstraints { (make) in
            make.left.equalTo(headPicker.snp.right).offset(8)
            make.top.equalTo(workTime.snp.bottom).offset(2)
            make.height.equalTo(17)
        }
        
        //  公里数
        mileageValue.snp.makeConstraints { (make) in
            make.left.equalTo(mileage.snp.right)
            make.top.equalTo(workTime.snp.bottom).offset(2)
            make.height.equalTo(17)
        }
        
        highRisk.snp.makeConstraints { (make) in
            make.left.equalTo(headPicker.snp.right).offset(8)
            make.top.equalTo(mileage.snp.bottom).offset(9)
            make.height.equalTo(13)
            make.width.equalTo(35)
        }
        
        highRiskLabel.snp.makeConstraints { (make) in
            make.left.equalTo(highRisk.snp.right).offset(4)
            make.top.equalTo(mileage.snp.bottom).offset(9)
            make.height.equalTo(13)
        }
        
        mediumRisk.snp.makeConstraints { (make) in
            make.left.equalTo(highRisk.snp.right).offset(35)
            make.top.equalTo(mileage.snp.bottom).offset(9)
            make.height.equalTo(13)
            make.width.equalTo(35)
        }
        
        mediumRiskLabel.snp.makeConstraints { (make) in
            make.left.equalTo(mediumRisk.snp.right).offset(4)
            make.top.equalTo(mileage.snp.bottom).offset(9)
            make.height.equalTo(13)
        }
        
        collect.snp.makeConstraints { (make) in
            make.right.equalTo(self.contentView.snp.right).offset(-15)
            make.top.equalTo(self.contentView.snp.top).offset(10)
            make.height.equalTo(25)
            make.width.equalTo(25)
        }
        
        line.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.bottom.equalTo(self.contentView.snp.bottom).offset(0)
            make.width.equalTo(KW-30)
            make.height.equalTo(1)
        }
    }
    
    func configDataSource (riskData:DriverListModel) {
        if riskData.driverurl != nil && riskData.driverurl != "" {
            let url = URL.init(string: riskData.driverurl!)
            headPicker.sd_setImage(with: url, placeholderImage: UIImage.init(named: "vehicle_driverIcon"), options: .highPriority, completed: nil)
        }else{
            headPicker.image = UIImage.init(named: "vehicle_driverIcon")
        }
        driver.text = riskData.name
        orgName.text = "【\(riskData.orgName ?? "")】"
//        creditValue.text = String(riskData.safeCreditIndex)
        timeValue.text = riskData.latestAttendDate
        mileageValue.text = "\(String(riskData.milsToday))公里"
        collect.isSelected = riskData.isFocused
        collect.tag = Int(riskData.id)
        
        highRiskLabel.text = String(riskData.riskHighCount)
        mediumRiskLabel.text = String(riskData.riskMiddleCount)
        
    }
    
    
    @objc func buttonAction (collect:UIButton) {
//        collect.isSelected = !collect.isSelected
        
        delegate?.didSelectCollect(collect.tag, isSelected: !collect.isSelected, selectCell: self)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
