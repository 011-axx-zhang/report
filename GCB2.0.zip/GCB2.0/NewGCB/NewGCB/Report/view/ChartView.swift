//
//  ChartView.swift
//  SafetyDrive
//
//  Created by YTKJ on 2019/11/5.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import Charts

class ChartView: UIView {
    let activities:Array<String> = ["安全驾驶","个人信用","知识掌握","同行认可","历史成就"]
    var chartView: RadarChartView!
    var topLabel:UILabel!
    var titleLabel:UILabel!
    var textView:UILabel!
    var dataArr:Array<Int> = []
    var creditExplainString:String = ""
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        self.createUI()
        self.updateConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func createUI() {
        topLabel = UILabel()
        topLabel.text = "安全信用解读"
        topLabel.frame = CGRect(x: 15, y: 8, width: 100, height: 21)
        topLabel.font = UIFont.boldSystemFont(ofSize: 15)
        self.addSubview(topLabel)
        
        //创建折线图组件对象
        chartView = RadarChartView()
        //是否允许滚动
        chartView.rotationEnabled = true
        chartView.frame = CGRect(x: 50, y: 30, width: 300,height: 300)
        self.addSubview(chartView)
        //维度标签文字
        chartView.xAxis.valueFormatter = self
        chartView.legend.formSize = 0
        chartView.legend.maxSizePercent = 1
        chartView.webLineWidth = 1 //网格主干线粗细
        chartView.webColor = UIColor(hex: "#585B67", alpha: 1.0)!//网格主干线颜色
        chartView.webAlpha = 1  //网格线透明度
        chartView.innerWebLineWidth = 1  //网格边线粗细
        chartView.innerWebColor = UIColor(hex: "#1C7EF2", alpha: 0.5)!
        //最小、最大刻度值
        let yAxis = chartView.yAxis
        yAxis.axisMinimum = 0
        yAxis.axisMaximum = 100
        yAxis.labelCount = 0
        yAxis.drawLabelsEnabled = false//不显示刻度值
        
        let xAxis = chartView.xAxis
        xAxis.labelFont = UIFont.systemFont(ofSize: 10)
        xAxis.labelPosition = .bottomInside
        xAxis.labelHeight = 10
 
        titleLabel = UILabel()
        titleLabel.text = "分析解读:"
        titleLabel.textColor = UIColor(hex: "#37AC4A", alpha: 1.0)
        titleLabel.frame = CGRect(x: 20, y: 270, width: 100, height: 21)
        titleLabel.font = UIFont.boldSystemFont(ofSize: 15)
        self.addSubview(titleLabel)
        
        textView = UILabel()
        textView.text = "您的安全信用指数比较平稳，保持或加强安全驾驶行为等维度的表现，如减少疲劳驾驶等行为，同时在安全知识方面可以加强积累。"
        textView.font = UIFont.systemFont(ofSize: 14)
        textView.numberOfLines = 0
        textView.frame = CGRect(x: 20, y: 293, width: KW - 40, height: 66)
        self.addSubview(textView)
        

    }
    
    func configData()  {
      //生成6条随机数据
        let dataEntries = (0..<dataArr.count).map { (i) -> RadarChartDataEntry in
            return RadarChartDataEntry(value: Double(dataArr[i]))
        }
        
        let chartDataSet = RadarChartDataSet(entries: dataEntries, label: "")
        //是否显示数据
        chartDataSet .drawValuesEnabled = false
        //目前雷达图只包括1组数据
        let chartData = RadarChartData(dataSets: [chartDataSet])
        chartDataSet.setColor(UIColor(hex: "#E7EEFD", alpha: 1.0)!) //线条颜色
        chartDataSet.lineWidth = 0.1 //线条粗细
        //填充颜色
        chartDataSet.fillColor = UIColor(hex: "#1C7EF2", alpha: 1.0)!
        chartDataSet.fillAlpha = 0.2 //填充透明度
        chartDataSet.drawFilledEnabled = true  //启用填充色绘制
        chartDataSet.setDrawHighlightIndicators(false)  //  点击后显示十字图
        //设置雷达图数据
        chartView.data = chartData
        
        textView.text = self.creditExplainString
        textView.sizeToFit()
    }
    
    
    
    
    
    
    override func updateConstraints() {
        super.updateConstraints()
        
    }
    
    
    
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
       
          return super.hitTest(point, with: event)
          
      }

}

extension ChartView: IAxisValueFormatter {
    //维度标签文字（x轴文字）
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        return activities[Int(value) % activities.count]
    }
}
