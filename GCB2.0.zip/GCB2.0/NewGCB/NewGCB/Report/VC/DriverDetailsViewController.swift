//
//  DriverDetailsViewController.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/20.
//  Copyright © 2019 YTKJ. All rights reserved.
//  驾驶员安全运营报告

import UIKit
import HandyJSON
import SwiftyJSON

class DriverDetailsViewController: RootController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    let activities:Array<String> = ["安全驾驶","个人信用","知识掌握","同行认可","历史成就"]
    var collectHeader:DriverInfoHeaderCell! //  头部，司机信息与安全信用
    var collectView :UICollectionView!
    var cellHeader : EnterpriseMileCollectionReusableView!
    var infoModel:DriverInfoModel!
    var reportModel:DriverReportModel!
    var driverID:Int64!
    var pieArr:Array<RiskPie> = []
    
    //  时间选择
    var todayStr:String = ""
    var fromTimeStr:String = ""
    var toTimeStr:String = ""
    var days:Int = 1
    var colors:Array<UIColor> = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.createColors()
        self.view.backgroundColor = UIColor.init(hex: "#F5F5F9", alpha: 1.0)
        self.setNavViewData(title: "驾驶员安全运营报告", leftImage: nil, rightImage: "navigation_backToHome")
        setNowTime()
    }
    
    func createColors()  {
            let arr = ["#66B8FE","#7BE279","#FFE03F","#FAB286","#FD723A","#7D8DFD","#8AE1BF","#F59BCC","#FFC53F","#F95642","#1889F7","#38C465","#A7B4FF","#FFCCE3","#FD723A","#4163DD","#85DE50","#FFA0ED","#C7D0FF","#FE9A28"]
            for i in 0...19 {
                let color = UIColor(hex: arr[i], alpha: 1.0)
                colors.append(color!)
            }
        }
    
    override func addChildView() {
        let layout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 5, left: 5,bottom: 5, right: 5)
        layout.minimumInteritemSpacing = 10
        layout.minimumLineSpacing  = 10
        collectView = UICollectionView(frame:CGRect(x: 0, y: navigationBarHeight, width: KW, height: KH-navigationBarHeight), collectionViewLayout: layout)
        collectView.backgroundColor = UIColor.white
//        collectView!.register(DriverInfoHeaderCell.self, forCellWithReuseIdentifier:"driverInfoHeaderCell")
        collectView!.register(DriverMileCell.self, forCellWithReuseIdentifier:"driverMileCell")
        collectView!.register(DriverOperatedStatusCell.self, forCellWithReuseIdentifier:"driverOperatedStatusCell")
        collectView!.register(EnterpriseRiskCollectionViewCell.self, forCellWithReuseIdentifier:"enterpriseRiskCollectionViewCell")
        collectView!.register( RiskBarChartCollectionViewCell.self, forCellWithReuseIdentifier:"riskBarChartCollectionViewCell")
        
        collectView!.register(RiskPieChartCollectionViewCell.self, forCellWithReuseIdentifier:"riskPieChartCollectionViewCell")
        
        collectView!.register( RiskPieChartDesCollectionViewCell.self, forCellWithReuseIdentifier:" riskPieChartDesCollectionViewCell")
        collectView!.register(EnterpriseMileCollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionHeader, withReuseIdentifier: "enterpriseMileCollectionReusableView")
        collectView!.register(VehicleCollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionHeader, withReuseIdentifier: "vehicleCollectionReusableView")
        collectView!.register(UICollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionHeader, withReuseIdentifier: "noHeaderID")
        collectView!.register(UICollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionFooter, withReuseIdentifier: "nofooterID")
        collectView!.delegate = self
        collectView!.dataSource = self
        collectView.showsHorizontalScrollIndicator = false
        collectView.contentInset = UIEdgeInsets(top: 245, left: 0, bottom: 0, right: 0)
        collectView.addSubview(self.headerView)
        self.collectView.addSubview(self.topView)
        self.view.addSubview(collectView!)
    }
    
    
    //  MARK: - collection View Delegate
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 6
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if section == 5{
            return pieArr.count
        }else{
            return 1
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        if indexPath.section == 0 {
//            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "driverInfoHeaderCell", for: indexPath) as! DriverInfoHeaderCell
//            collectHeader = cell
//            cell.callTheNumberClick = {
//                print("拨打电话")
//                if self.infoModel.phone?.count == 0 {
//                    return
//                }
//                let phoneStr = "telprompt://"+self.infoModel.phone!
//                UIApplication.shared.openURL(URL(string: phoneStr)!)
//            }
//            return cell
//        } else
        if indexPath.section == 0{
            //  行驶里程
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "driverMileCell", for: indexPath) as! DriverMileCell
            if self.reportModel != nil {
                cell.setDriverMileCellData(cellModel: self.reportModel.mils!)
            }
            return cell
        } else  if indexPath.section == 1{
            //  运营状况
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "driverOperatedStatusCell", for: indexPath) as! DriverOperatedStatusCell
//            print("这个地方总崩溃\(self.reportModel.runningInfo)")
            if self.reportModel != nil {
                cell.setOperatedModel(model: self.reportModel.runningInfo!)
            }
            return cell
        }else  if indexPath.section == 2{
            //  驾驶风险
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "enterpriseRiskCollectionViewCell", for: indexPath) as! EnterpriseRiskCollectionViewCell
            if self.reportModel != nil && self.reportModel.risk != nil {
                let model = EnterpriseReportModel()
                
                let data = JSONDeserializer<EnterpriseRiskModel>.deserializeFrom(json: self.reportModel.risk!.toJSONString()?.description)
                
                model.risk = data
                
                cell.configData(model: model)
            }
            return cell
        }else  if indexPath.section == 3{
            //  柱状图
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "riskBarChartCollectionViewCell", for: indexPath) as! RiskBarChartCollectionViewCell
            if self.reportModel != nil && self.reportModel.risk != nil {
                let model = EnterpriseReportModel()
                let data = JSONDeserializer<EnterpriseRiskModel>.deserializeFrom(json: self.reportModel.risk!.toJSONString()?.description)
                model.risk = data
                cell.configData(model: model, dateStr: self.toTimeStr)
            }
            return cell
            
        }else  if indexPath.section == 4{
            //  饼图
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "riskPieChartCollectionViewCell", for: indexPath) as! RiskPieChartCollectionViewCell
            if self.reportModel != nil {
                cell.configDriverData(model: self.reportModel)
            }
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: " riskPieChartDesCollectionViewCell", for: indexPath) as!  RiskPieChartDesCollectionViewCell
            if self.reportModel != nil {
                let arr =  self.configData(model: self.reportModel)
                if arr.count != 0 {
                    cell.configData(model: arr[indexPath.row], color: colors[indexPath.row])
                }
            }
            return cell
        }
    }
    func configData(model:DriverReportModel) -> [RiskPieModel] {
        let barModel = model.risk
        let barDataArr = barModel?.pie
        let yValue = barDataArr?.map({ (item) -> Int64 in
            return item.value!
        }) ?? []
        let sumY = yValue.reduce(0,{$0 + $1})
        
        //  返回值
        var resultArr:[RiskPieModel] = []
        for model in barDataArr! {
            model.rate = Double(model.value! * 100/sumY )
            
            let md = RiskPieModel()
            md.x = model.event
            md.y = model.value
            md.rate = model.rate
            
//            let json = JSONDeserializer<RiskPieModel>.deserializeFrom(json: model.toJSONString()?.description)!
            resultArr.append(md)
        }
        pieArr = barDataArr!
        return resultArr
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        if section == 0 || section == 4 || section == 5 || section == 3{
            return CGSize(width: KW, height: 0.01)
        }
        if section == 1 || section == 2{
            return CGSize(width: KW, height: 50)
        }
        return CGSize(width: KW, height: 84)
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        
        return CGSize(width: KW, height: 0.01)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
//        if indexPath.section == 0 {
//            return CGSize(width: KW , height: 160)
//        }else
            if indexPath.section == 0 {
            return CGSize(width: KW , height: 220)
        }else if indexPath.section == 1{
            return CGSize(width: KW , height: 170)
        }else if indexPath.section == 2{
            return CGSize(width: KW , height: 190)
        }else if indexPath.section == 3{
            return CGSize(width: KW , height: 200)
        }else if indexPath.section == 4{
            return CGSize(width: KW , height: 220)
        }
        
        return CGSize(width: KW , height: 20)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String,
                        at indexPath: IndexPath) -> UICollectionReusableView {
        
        var noneReusableview:UICollectionReusableView!
//        let  mileageHeaderreusableview:EnterpriseMileCollectionReusableView!
//        cellHeader = mileageHeaderreusableview
        var  vehicleCollectionReusableView:VehicleCollectionReusableView!
        
        
        if kind == UICollectionView.elementKindSectionHeader{
            if indexPath.section == 0 {
                noneReusableview = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "noHeaderID", for: indexPath)
                noneReusableview.backgroundColor = UIColor(hex: "#F0F0F7", alpha: 1.0)
                return noneReusableview
//            }else if  indexPath.section == 1{
//                mileageHeaderreusableview = (collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "enterpriseMileCollectionReusableView", for: indexPath) as! EnterpriseMileCollectionReusableView)
//                //  选择日期
//                mileageHeaderreusableview.passDay = { day in
//                    //  当日  7天  30天
//                    self.days = day
//                    self.setFromTime(index: day )
//
//                    if self.days == 1 {
//                        mileageHeaderreusableview.dateValueLabel.text = String(format: "%@", self.toTimeStr)
//                    }else {
//                        mileageHeaderreusableview.dateValueLabel.text = String(format: "%@至%@", self.fromTimeStr,self.toTimeStr)
//                    }
//
//                    self.getSafeReportForms()   //  获取企业运营报告
////                    self.getEnterpriseInfoRequest()     //  企业运营报告基本信息
//                }
//                mileageHeaderreusableview.dateClick = {
//                    let picker = QCalendarPicker { (date: String) in
//                        print("选择的日期 \(date)")
//                        if date == self.todayStr {
//                            self.view.makeToastMid(message: "只能选择当天之前的日期")
//                        }else {
//                            mileageHeaderreusableview.dateLabel.text = date
//                            self.toTimeStr = date
//                            if self.days == 1 {
//                                mileageHeaderreusableview.dateValueLabel.text = String(format: "%@", self.toTimeStr)
//                            }else {
//                                self.setFromTime(index: self.days)
//                                mileageHeaderreusableview.dateValueLabel.text = String(format: "%@至%@", self.fromTimeStr,self.toTimeStr)
//
//                            }
//                            self.getSafeReportForms()   //获取企业运营报告
////                            self.getEnterpriseInfoRequest()     //企业运营报告基本信息
//                        }
//                    }
//                    picker.isAllowSelectTime = false
//                    picker.show()
//                }
//                return mileageHeaderreusableview
            }else if  indexPath.section == 1{
                vehicleCollectionReusableView = (collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "vehicleCollectionReusableView", for: indexPath) as! VehicleCollectionReusableView)
                vehicleCollectionReusableView.setTitleText(title: "运营情况")
                vehicleCollectionReusableView.searchMoreBtn.isHidden = true
                return vehicleCollectionReusableView
            }else if  indexPath.section == 2{
                vehicleCollectionReusableView = (collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "vehicleCollectionReusableView", for: indexPath) as! VehicleCollectionReusableView)
                vehicleCollectionReusableView.setTitleText(title: "驾驶风险")
                vehicleCollectionReusableView.checkMoreClick = {
                    let vc = NotificationViewController()
                    vc.selectIndex = 0
                    vc.isOtherPage = true
                     // 此处需要传一个车辆ID  self.vehId
                    vc.driverID = self.driverID
                    vc.vehicleID = Int64(self.infoModel.id!)
                    self.navigationController?.pushViewController(vc, animated: true)
                }
                return vehicleCollectionReusableView
            } else {
                noneReusableview = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "noHeaderID", for: indexPath)
                noneReusableview.backgroundColor = UIColor(hex: "#F0F0F7", alpha: 1.0)
                return noneReusableview
            }
        }else {
            noneReusableview = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "nofooterID", for: indexPath)
            noneReusableview.backgroundColor = UIColor(hex: "#F0F0F7", alpha: 1.0)
            noneReusableview.backgroundColor = UIColor.red
            return noneReusableview
        }
        
    }
    
    //  MARK:- 获取数据
    //  驾驶员基本信息
    func getDriverDetailsData() -> Void {
        let param = ["driverId":driverID!] as [String : Any]
        HttpRequest.loadData(target: InterfaceAPI.getDriverInfo(param: param), needCache: false, cache: nil, success: { (datas) in
            let json = JSON(datas)
            let data = JSONDeserializer<DriverInfoModel>.deserializeFrom(json: json["data"].description)
            self.infoModel = data
            self.collectHeader.changeChartViewData(value: self.infoModel)
        }) { (stateCode ,message)  in
            self.view.makeToast(message)
        }
    }
    
    //  运营报告
    func getSafeReportForms() -> Void {
        let param = ["driverId":driverID!,  //driverID!      305
                     "days":days,
                     "endDate":toTimeStr] as [String : Any]
        print("请求参数 \(param)")
        HttpRequest.loadData(target: InterfaceAPI.getDriverReport(param: param), success: { (datas) in
            let json = JSON(datas)
            let data = JSONDeserializer<DriverReportModel>.deserializeFrom(json: json["data"].description)
            self.reportModel = data
            
            
            let _ = self.configData(model: data!)
            self.collectView.reloadData()
        }) { (stateCode, message) in
            self.view.makeToast(message)
        }
    }
    
    //  关注司机
    func fucusDriver() -> Void {
        //  关注或取消关注司机
        if driverID == nil || driverID == 0 {
            return
        }
        let status = !self.infoModel.isFocused!
        
//        print("关注司机\(status)")
        let param = ["driverId":driverID!,
                     "isFocused":status] as [String : Any]
        HttpRequest.loadData(target: InterfaceAPI.focusDriver(param: param), success: { (datas) in
            let json = JSON(datas)
            if json["code"] == 0 {
//                print("改变model\(status)")
                self.infoModel.isFocused = status
                if status {
                    self.view.makeToast("已关注该司机")
                }else{
                    self.view.makeToast("已取消关注该司机")
                }
                self.collectHeader.collect.isSelected = status
            }
        }) { (stateCode, message) in
            print("关注司机失败---\(message)")
        }
    }
    
    
    //  MARK: - 时间选择
    func setFromTime(index:Int)  {
        if index == 1 {
            fromTimeStr = ""
        }else {
           let  index1 = index - 1
            
            let dateFmt = DateFormatter()
            dateFmt.dateFormat = "yyyy-MM-dd"
            let date = dateFmt.date(from: self.toTimeStr)
            
            let timeS:TimeInterval = TimeInterval(24*60*60*index1)
            let nowTimeS:TimeInterval = date!.timeIntervalSince1970
            let totalTime :TimeInterval = nowTimeS - timeS
            let needDate :Date  = Date.init(timeIntervalSince1970: totalTime)
            fromTimeStr = dateFmt.string(from: needDate)
        }
        
    }
    lazy var headerView:DriverInfoHeaderCell = {
        let headerView =  DriverInfoHeaderCell.init(frame: CGRect(x: 0, y: -245, width: KW, height: 160))
        headerView.focusDriverClick = {
            //  关注司机
            self.fucusDriver()
        }
        headerView.callTheNumberClick = {
            print("拨打电话")
            if self.infoModel.phone?.count == 0 {
                return
            }
            let phoneStr = "telprompt://"+self.infoModel.phone!
            UIApplication.shared.openURL(URL(string: phoneStr)!)
        }
        self.collectHeader = headerView
        return headerView
    }()
    lazy var topView:VehicleTopView = {
        let topView = VehicleTopView.init(frame: CGRect(x: 0, y: -85, width: KW, height: 85))
        topView.passDay = { day in
            self.days = day
            self.setFromTime(index: day )
            
            if self.days == 1 {
                self.topView.dateValueLabel.text = String(format: "%@", self.toTimeStr)
            }else {
                self.topView.dateValueLabel.text = String(format: "%@至%@", self.fromTimeStr,self.toTimeStr)
            }
            self.infoModel = nil
            self.reportModel = nil
            self.getDriverDetailsData()
            self.getSafeReportForms()
        }
        topView.dateClick = {
            let picker = QCalendarPicker { (date: String) in
                if self.judgeTime(dateStr: date) {
                    self.view.makeToastMid(message: "只能选择当天之前的日期")
                }else {
                    self.topView.dateLabel.text = date
                    self.toTimeStr = date
                    if self.days == 1 {
                        self.topView.dateValueLabel.text = String(format: "%@", self.toTimeStr)
                    }else {
                        self.setFromTime(index: self.days)
                        self.topView.dateValueLabel.text = String(format: "%@至%@", self.fromTimeStr,self.toTimeStr)
                        
                    }
                    self.infoModel = nil
                    self.reportModel = nil
                    self.getDriverDetailsData()
                    self.getSafeReportForms()
                }
            }
            picker.isAllowSelectTime = false
            picker.show()
        }
        return topView
    }()
    
    func judgeTime(dateStr:String) -> Bool {
        let date = Date()
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy-MM-dd"
        let str = dateFmt.string(from: date)
        let date0 = date.strToDate(item: str)
        let date1 = date.strToDate(item: dateStr)
        if date1.compare(date0 as Date) == ComparisonResult.orderedSame {
            return true
        } else if date1.compare(date0 as Date) == ComparisonResult.orderedDescending {
            return true
        } else if date1.compare(date0 as Date) == ComparisonResult.orderedAscending {
            return false
        }
         return true
       
    }
    
    func setNowTime() {
        let date = Date()
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy-MM-dd"
        todayStr = dateFmt.string(from: date)
        let timeS:TimeInterval = TimeInterval(24*60*60)
        let nowTimeS:TimeInterval = date.timeIntervalSince1970
        let totalTime :TimeInterval = nowTimeS - timeS
        let needDate :Date  = Date.init(timeIntervalSince1970: totalTime)
        toTimeStr = dateFmt.string(from: needDate)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let  offsetY = scrollView.contentOffset.y
        if (offsetY > -navigationBarHeight ) {
             //防止多次更改页面层级
            let bool = self.topView.superview?.isEqual(self.view)
            if (bool == true) {

                return;
            }
             //加载到view上
             self.topView.frame = CGRect(x: 0, y: navigationBarHeight, width: KW, height: 85)
             self.view.addSubview(self.topView)
         } else{
            let bool = self.topView.superview?.isEqual(self.collectView)
             //防止多次更改页面层级
            if (bool == true) {
                 return;
             }
             self.topView.frame = CGRect(x: 0, y: -85, width: KW, height: 85)
             self.collectView.addSubview(self.topView)
         }
        
    }
    
    override func rightNavigationBarItemAction() {
        self.navigationController?.popToRootViewController(animated: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        if infoModel == nil {
            getDriverDetailsData()
        }
        if reportModel == nil {
            getSafeReportForms()
        }
    }
    
    @objc func timeAction () {
        print("调起时间选择器")
    }
    
}
