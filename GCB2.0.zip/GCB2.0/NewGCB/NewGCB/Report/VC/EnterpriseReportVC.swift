//
//  EnterpriseReportVC.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/18.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

import SwiftyJSON

import HandyJSON

class EnterpriseReportVC: BaseVC,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {

    var collectView :UICollectionView!
    var infModel:EnterpriseInfoModel!
    var reportModel:EnterpriseReportModel!
    var filterView:EnterpriseReportFilterView!
    var fromTimeStr:String = ""
    var toTimeStr:String = ""
    var days:Int = 1
    
    var orgId:Int64?
    var vehGroupId:Int64?
    var pieArr:Array<RiskPieModel> = []
    var focusDriver:Bool?
    var focusVeh:Bool?
    var todayStr:String = ""
    var colors:Array<UIColor> = []
    
    var orgArr:Array<OrgAndGroupContent> = []
    var vehicleGroupArr:Array<OrgAndGroupContent> = []
    var collectArr:Array<String> = ["关注驾驶员","收藏车辆"]
    
    var filterFlag:Bool = false
  
    
   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setNowTime()
        self.setDefaultValue()
        self.view.backgroundColor = UIColor.white
        self.createColors()
        self.createCollectionView()
        self.getEnterpriseInfoRequest()
        self.getEnterpriseReportRequest()
        
        if #available(iOS 11.0, *) {
            collectView.contentInsetAdjustmentBehavior = .never
        }
        view.insertSubview(navBar, aboveSubview: collectView)
        navBar.title = "企业安全运营报告"
        if self.navigationController?.children.count != 0 {
            navBar.wr_setRightButton(title: "筛选", titleColor: .black)
        }
        navBar.onClickRightButton = {
            self.createFilterView()
        }
        self.getOrgsAndVehGroups()
    }
    
 
  func getOrgsAndVehGroups() {
      HttpRequest.loadData(target: InterfaceAPI.getOrgsAndVehGroups, needCache: false, cache: nil, success: { (datas) in
          let json = JSON(datas)
          let data = JSONDeserializer<OrgAndVehGroupsModel>.deserializeFrom(json: json["data"].description)
          self.orgArr = data?.orgs ?? []
          self.vehicleGroupArr = data?.vehGroups ?? []
          
          
      }) { (stateCode, message) in
          
      }
  }
  
    
    func createColors()  {
           let arr = ["#66B8FE","#7BE279","#FFE03F","#FAB286","#FD723A","#7D8DFD","#8AE1BF","#F59BCC","#FFC53F","#F95642","#1889F7","#38C465","#A7B4FF","#FFCCE3","#FD723A","#4163DD","#85DE50","#FFA0ED","#C7D0FF","#FE9A28"]
           for i in 0...19 {
               let color = UIColor(hex: arr[i], alpha: 1.0)
               colors.append(color!)
           }
       }
    
    func setNowTime() {
        let date = Date()
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy-MM-dd"
        todayStr = dateFmt.string(from: date)
        let timeS:TimeInterval = TimeInterval(24*60*60)
        let nowTimeS:TimeInterval = date.timeIntervalSince1970
        let totalTime :TimeInterval = nowTimeS - timeS
        let needDate :Date  = Date.init(timeIntervalSince1970: totalTime)
        toTimeStr = dateFmt.string(from: needDate)
    }
    func setDefaultValue() {
        let defaults = UserDefaults.standard
        if defaults.value(forKey: "orgId") != nil {
            self.orgId = defaults.value(forKey: "orgId") as? Int64
        }
        if defaults.value(forKey: "groupId") != nil {
            self.vehGroupId = defaults.value(forKey: "groupId") as? Int64
        }
        
    }
 
    lazy var transparentView:UIView = {
           let transparentView = UIView()
           transparentView.backgroundColor = UIColor.clear
           transparentView.frame = CGRect(x: 0, y: kNavBarBottom, width: KW, height: KH)
           transparentView.isUserInteractionEnabled = true
           return transparentView
       }()
    
    func createFilterView()  {
        self.filterFlag = !self.filterFlag
        if self.filterFlag == true {
            self.view.addSubview(transparentView)
            filterView = EnterpriseReportFilterView.init(frame: CGRect(x: 0, y: 0, width: KW, height: KH - kNavBarBottom),orgArr:self.orgArr,vehicleGroupArr:self.vehicleGroupArr)
            transparentView.addSubview(filterView)
            filterView.passValue = { (index,id) in
                self.handleFilterValue(index: index, id: id)
            }
        }else {
            self.filterFlag = false
            self.filterView.removeFromSuperview()
            self.transparentView.removeFromSuperview()
        }
        
        
        filterView.closeClick = {
            self.filterFlag = false
            self.filterView.removeFromSuperview()
            self.transparentView.removeFromSuperview()
        }
       }
       
       func handleFilterValue(index:Int,id:Int64)  {
        
        if index == 1 {
            orgId = id
            vehGroupId = nil
        }else if index == 2 {
            orgId = nil
            vehGroupId = id
        }else if index == 0 {
            orgId = nil
            vehGroupId = nil
        }
        
        let defaults = UserDefaults.standard
        defaults.set(orgId, forKey: "orgId")
        defaults.set(vehGroupId, forKey: "groupId")
       
        self.getEnterpriseReportRequest()
        self.getEnterpriseInfoRequest()
        self.filterFlag = false
        self.filterView.removeFromSuperview()
        self.transparentView.removeFromSuperview()
       }
    
    func getEnterpriseInfoRequest()  {
        var paramDic:Dictionary<String,Any> = [:]
        if orgId != nil {
            paramDic["orgId"] = self.orgId
        }else if self.vehGroupId != nil {
            paramDic["vehGroupId"] = self.vehGroupId
        }
        
        HttpRequest.loadData(target: InterfaceAPI.getEnterpriseInfo(param: paramDic), needCache: false, cache: nil, success: { (datas) in
            let json = JSON(datas)
            let data = JSONDeserializer<EnterpriseInfoModel>.deserializeFrom(json: json["data"].description)
            self.infModel = data
            if self.infModel != nil {
                self.headerView.configData(model: self.infModel)
            }
            self.collectView.reloadData()
        }) { (stateCode ,message) in
            
        }
    }

      
    func getEnterpriseReportRequest() {
        var paramDic:Dictionary<String,Any> = [:]
        if orgId != nil {
            paramDic["orgId"] = self.orgId
        }else if self.vehGroupId != nil {
            paramDic["vehGroupId"] = self.vehGroupId
        }
        paramDic["days"] = self.days
        paramDic["endDate"] = self.toTimeStr
        
        HttpRequest.loadData(target: InterfaceAPI.getEnterpriseReport(param: paramDic), needCache: false, cache: nil, success: { (datas) in
            let json = JSON(datas)
            let data = JSONDeserializer<EnterpriseReportModel>.deserializeFrom(json: json["data"].description)
            self.reportModel = data
            let barModel = self.reportModel.risk
            let barDataArr = barModel?.pie
            self.pieArr = barDataArr!
            self.collectView.reloadData()
        }) { (stateCode ,message)  in
            
        }
    }
    
    lazy var headerView:EnterpriseReportHeaderView = {
        let headerView =  EnterpriseReportHeaderView.init(frame: CGRect(x: 0, y: -245, width: KW, height: 160))
        return headerView
    }()
    lazy var topView:VehicleTopView = {
        let topView = VehicleTopView.init(frame: CGRect(x: 0, y: -85, width: KW, height: 85))
        topView.passDay = { day in
            self.days = day
            self.setFromTime(index: day )
            
            if self.days == 1 {
                self.topView.dateValueLabel.text = String(format: "%@", self.toTimeStr)
            }else {
                self.topView.dateValueLabel.text = String(format: "%@至%@", self.fromTimeStr,self.toTimeStr)
            }
            
            self.getEnterpriseReportRequest()
            self.getEnterpriseInfoRequest()
        }
        topView.dateClick = {
            let picker = QCalendarPicker { (date: String) in
                if self.judgeTime(dateStr: date) {
                    self.view.makeToastMid(message: "只能选择当天之前的日期")
                }else {
                    self.topView.dateLabel.text = date
                    self.toTimeStr = date
                    if self.days == 1 {
                        self.topView.dateValueLabel.text = String(format: "%@", self.toTimeStr)
                    }else {
                        self.setFromTime(index: self.days)
                        self.topView.dateValueLabel.text = String(format: "%@至%@", self.fromTimeStr,self.toTimeStr)
                        
                    }
                    self.getEnterpriseReportRequest()
                    self.getEnterpriseInfoRequest()
                }
            }
            picker.isAllowSelectTime = false
            picker.show()
        }
        return topView
    }()
    

    
    func createCollectionView()  {
        let layout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0,bottom: 0, right: 0)
        layout.minimumInteritemSpacing = 10
        layout.minimumLineSpacing  = 10
        collectView = UICollectionView(frame:CGRect(x: 0, y: kNavBarBottom, width: KW, height: KH - kNavBarBottom ), collectionViewLayout: layout)
        collectView.backgroundColor = UIColor.white
        collectView!.register(EnterpriseInfoCollectionViewCell.self, forCellWithReuseIdentifier:"enterpriseInfoCollectionViewCell")
        collectView!.register(EnterpriseMileCollectionViewCell.self, forCellWithReuseIdentifier:"enterpriseMileCollectionViewCell")
        collectView!.register(EnterpriseVehicleCollectionViewCell.self, forCellWithReuseIdentifier:"enterpriseVehicleCollectionViewCell")
        collectView!.register(EnterpriseDriverCollectionViewCell.self, forCellWithReuseIdentifier:"enterpriseDriverCollectionViewCell")
        collectView!.register(MileChartCollectionViewCell.self, forCellWithReuseIdentifier:"mileChartCollectionViewCell")
        collectView!.register(EnterpriseRiskCollectionViewCell.self, forCellWithReuseIdentifier:"enterpriseRiskCollectionViewCell")
        collectView!.register( RiskBarChartCollectionViewCell.self, forCellWithReuseIdentifier:"riskBarChartCollectionViewCell")
        
        collectView!.register(RiskPieChartCollectionViewCell.self, forCellWithReuseIdentifier:"riskPieChartCollectionViewCell")
        collectView!.register( RiskPieChartDesCollectionViewCell.self, forCellWithReuseIdentifier:" riskPieChartDesCollectionViewCell")
        collectView!.register(EnterpriseMileCollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionHeader, withReuseIdentifier: "enterpriseMileCollectionReusableView")
        collectView!.register(VehicleCollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionHeader, withReuseIdentifier: "vehicleCollectionReusableView")
        collectView!.register(UICollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionHeader, withReuseIdentifier: "noHeaderID")
        collectView!.register(UICollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionFooter, withReuseIdentifier: "nofooterID")
        collectView!.delegate = self
        collectView!.dataSource = self
        collectView.showsHorizontalScrollIndicator = false
        collectView.contentInset = UIEdgeInsets(top: 245, left: 0, bottom: 0, right: 0)
        collectView.addSubview(self.headerView)
        self.collectView.addSubview(self.topView)
        self.view.addSubview(collectView!)
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 8
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        }else  if section == 1{
            return 1
        }else  if section == 7{
            if pieArr.count > 10 {
                return 10
            }else {
                return pieArr.count
            }
        } else {
            return 1
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
      if indexPath.section == 0{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "enterpriseMileCollectionViewCell", for: indexPath) as! EnterpriseMileCollectionViewCell
            if self.reportModel != nil {
                cell.configData(model: self.reportModel)
            }
            return cell
        }else  if indexPath.section == 1{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "mileChartCollectionViewCell", for: indexPath) as! MileChartCollectionViewCell
            if self.reportModel != nil {
                cell.configData(model: self.reportModel,dateStr:self.toTimeStr)
            }
            return cell
            
        }else  if indexPath.section == 2{
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "enterpriseVehicleCollectionViewCell", for: indexPath) as! EnterpriseVehicleCollectionViewCell
            if self.reportModel != nil {
                cell.configData(model: self.reportModel)
            }
            return cell
            
        } else  if indexPath.section == 3{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "enterpriseDriverCollectionViewCell", for: indexPath) as! EnterpriseDriverCollectionViewCell
            if self.reportModel != nil {
                cell.configData(model: self.reportModel)
            }
            return cell
        }else  if indexPath.section == 4{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "enterpriseRiskCollectionViewCell", for: indexPath) as! EnterpriseRiskCollectionViewCell
           
            if self.reportModel != nil {
                cell.configData(model: self.reportModel)
            }
             return cell
        }else  if indexPath.section == 5{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "riskBarChartCollectionViewCell", for: indexPath) as! RiskBarChartCollectionViewCell
                    
            if self.reportModel != nil {
                
                 cell.configData(model: self.reportModel,dateStr:self.toTimeStr)
            }
             return cell
         
        }else  if indexPath.section == 6{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "riskPieChartCollectionViewCell", for: indexPath) as! RiskPieChartCollectionViewCell
            if self.reportModel != nil {
                cell.configData(model: self.reportModel)
            }
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: " riskPieChartDesCollectionViewCell", for: indexPath) as!  RiskPieChartDesCollectionViewCell
            if self.reportModel != nil {
                let arr =  self.configData(model: self.reportModel)
                cell.configData(model: arr[indexPath.row],color:colors[indexPath.row])
                
            }
        
           
            return cell
        }
        
        
    }
    
    func configData(model:EnterpriseReportModel) -> [RiskPieModel] {
        let barModel = model.risk
        let barDataArr = barModel?.pie
        let yValue = barDataArr?.map({ (item) -> Int64 in
            return item.y!
        }) ?? []
        let sumY = yValue.reduce(0,{$0 + $1})
        for model in barDataArr! {
            model.rate = Double(model.y! * 100/sumY )
        }
        pieArr = barDataArr!
        return barDataArr!
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        if  section == 0 || section == 1 ||  section == 5 || section == 6  || section == 7 || section == 8 {
            return CGSize(width: KW, height: 0.01)
        }else {
            return CGSize(width: KW, height: 60)
        }
        
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
       
        if section ==  7 {
             return CGSize(width: KW, height: 40)
            
        }else {
             return CGSize(width: KW, height: 0.01)
        }
           
        
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {

        if indexPath.section == 0{
            return CGSize(width: KW , height: 220)
        }else if indexPath.section == 1 {
            return CGSize(width: KW , height: 230)
        } else if indexPath.section == 2{
            return CGSize(width: KW , height: 320)
        }else if indexPath.section == 3{
            return CGSize(width: KW , height: 260)
        }else if indexPath.section == 4{
            return CGSize(width: KW , height: 190)
        }else if indexPath.section == 5{
            return CGSize(width: KW , height: 200)
        }else if indexPath.section == 6{
            return CGSize(width: KW , height: 220)
        }else if indexPath.section == 7{
            return CGSize(width: KW , height: 20)
        } else{
            return CGSize(width: KW , height: 260)
        }
        
        
    }
    
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String,
                        at indexPath: IndexPath) -> UICollectionReusableView {
       
        var noneReusableview:UICollectionReusableView!
      //  var  mileageHeaderreusableview:EnterpriseMileCollectionReusableView!
        var  vehicleCollectionReusableView:VehicleCollectionReusableView!
        

        if kind == UICollectionView.elementKindSectionHeader{
             if  indexPath.section == 2{
                vehicleCollectionReusableView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "vehicleCollectionReusableView", for: indexPath) as! VehicleCollectionReusableView
                vehicleCollectionReusableView.titleLabel.text = "车辆管理"
                vehicleCollectionReusableView.checkMoreClick = {
                    let vc = VehicleManagerVC()
                    vc.orgId = self.orgId
                    vc.vehGroupId = self.vehGroupId
                    self.navigationController?.pushViewController(vc, animated: true)
                }
                return vehicleCollectionReusableView
            }else if  indexPath.section == 3{
                vehicleCollectionReusableView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "vehicleCollectionReusableView", for: indexPath) as! VehicleCollectionReusableView
                vehicleCollectionReusableView.titleLabel.text = "驾驶员管理"
                vehicleCollectionReusableView.checkMoreClick = {
                   //驾驶员管理页面
                    let vc = DriverListViewController()
                    vc.orgId = self.orgId
                    vc.vehGroupId = self.vehGroupId
                    self.navigationController?.pushViewController(vc, animated: true)
                }
                return vehicleCollectionReusableView
            }else if  indexPath.section == 4{
                vehicleCollectionReusableView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "vehicleCollectionReusableView", for: indexPath) as! VehicleCollectionReusableView
                vehicleCollectionReusableView.titleLabel.text = "驾驶风险管理"
                vehicleCollectionReusableView.checkMoreClick = {
                   //驾驶风险管理页面
                    let vc = NotificationViewController()
                    vc.isOtherPage = true
                    vc.orgId = self.orgId
                    vc.vehGroupId = self.vehGroupId ?? 0
                    self.navigationController?.pushViewController(vc, animated: true)
                }
                return vehicleCollectionReusableView
            } else {
              noneReusableview = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "noHeaderID", for: indexPath)
                noneReusableview.backgroundColor = UIColor.white
                return noneReusableview
            }
        }else {
            noneReusableview = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "nofooterID", for: indexPath)
            noneReusableview.backgroundColor = UIColor.white
            return noneReusableview
        }
        
    }
    
    
    func judgeTime(dateStr:String) -> Bool {
           let date = Date()
           let dateFmt = DateFormatter()
           dateFmt.dateFormat = "yyyy-MM-dd"
           let str = dateFmt.string(from: date)
           let date0 = date.strToDate(item: str)
           let date1 = date.strToDate(item: dateStr)
           if date1.compare(date0 as Date) == ComparisonResult.orderedSame {
               return true
           } else if date1.compare(date0 as Date) == ComparisonResult.orderedDescending {
               return true
           } else if date1.compare(date0 as Date) == ComparisonResult.orderedAscending {
               return false
           }
            return true
          
       }
 
    
      
      func setFromTime(index:Int)  {
        if index == 1 {
            fromTimeStr = ""
        }else {
           let  index1 = index - 1
            
            let dateFmt = DateFormatter()
            dateFmt.dateFormat = "yyyy-MM-dd"
            let date = dateFmt.date(from: self.toTimeStr)
            
            let timeS:TimeInterval = TimeInterval(24*60*60*index1)
            let nowTimeS:TimeInterval = date!.timeIntervalSince1970
            let totalTime :TimeInterval = nowTimeS - timeS
            let needDate :Date  = Date.init(timeIntervalSince1970: totalTime)
            fromTimeStr = dateFmt.string(from: needDate)
        }
        
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
         let  offsetY = scrollView.contentOffset.y
         if (offsetY > -160 ) {
              //防止多次更改页面层级
             let bool = self.topView.superview?.isEqual(self.view)
             if (bool == true) {

                 return;
             }
              //加载到view上
              self.topView.frame = CGRect(x: 0, y: navigationBarHeight, width: KW, height: 85)
              self.view.addSubview(self.topView)
          } else{
             let bool = self.topView.superview?.isEqual(self.collectView)
              //防止多次更改页面层级
             if (bool == true) {
                  return;
              }
              self.topView.frame = CGRect(x: 0, y: -85, width: KW, height: 85)
              self.collectView.addSubview(self.topView)
          }
         
     }
    
    

  
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
       // self.navigationController?.navigationBar.isHidden = false
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
