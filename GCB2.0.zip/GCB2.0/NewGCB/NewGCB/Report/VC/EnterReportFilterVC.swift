//
//  EnterReportFilterVC.swift
//  NewGCB
//
//  Created by YTKJ on 2020/1/14.
//  Copyright © 2020 YTKJ. All rights reserved.
//


import UIKit
import SwiftyJSON
import HandyJSON

class EnterReportFilterVC: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout  {
    
    var collectView :UICollectionView!
    var orgArrs:Array<String> = []
    var vehicleGroupArrs:Array<String> = []
    var collectArr:Array<String> = []
    var selectValue = ""
    var orgArr:Array<OrgAndGroupContent> = []
    var vehicleGroupArr:Array<OrgAndGroupContent> = []
    
    @objc var passValue:((Int,Int64)->Void)?

    override func viewDidLoad() {
        super.viewDidLoad()
        let defaults = UserDefaults.standard
        if defaults.value(forKey: "reportFilterValue") != nil{
            selectValue = defaults.value(forKey: "reportFilterValue") as! String
        }
        self.view.backgroundColor = UIColor.white
        self.createCollectionView()
        self.getOrgsAndVehGroups()
         collectArr = ["关注驾驶员","收藏车辆"]
       
    }
    
    
    func getOrgsAndVehGroups() {
        HttpRequest.loadData(target: InterfaceAPI.getOrgsAndVehGroups, needCache: false, cache: nil, success: { (datas) in
            let json = JSON(datas)
            let data = JSONDeserializer<OrgAndVehGroupsModel>.deserializeFrom(json: json["data"].description)
            self.orgArr = data?.orgs ?? []
            self.vehicleGroupArr = data?.vehGroups ?? []
            self.collectView.reloadData()
            
        }) { (stateCode, message) in
            self.view.makeToast(message)
        }
    }
    
    
    func configData()  {
    
        for i in 0..<8 {
            let model = OrgAndGroupContent()
            model.id = Int64(i)
            model.name = String(format: "公司%d", model.id)
            orgArr.append(model)
        }
        for i in 0..<8 {
            let model = OrgAndGroupContent()
            model.id = Int64(i)
            model.name = String(format: "车队%d", model.id)
            vehicleGroupArr.append(model)
        }
        
        
       
        self.collectView.reloadData()
        
    }
    
    func createCollectionView()  {
        let layout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 5, left: 5,bottom: 5, right: 5)
        layout.minimumInteritemSpacing = 10
        layout.minimumLineSpacing  = 10
        collectView = UICollectionView(frame:CGRect(x: 0, y: 0, width: 5/7*KW, height: KH), collectionViewLayout: layout)
        collectView.backgroundColor = UIColor.white
        //注册一个cell
        collectView!.register(FilterCollectionViewCell.self, forCellWithReuseIdentifier:"filterCollectionViewCell")
        collectView!.delegate = self
        collectView!.dataSource = self
        layout.itemSize = CGSize(width: (KW - 46)/3, height: 32)
        self.view.addSubview(collectView!)
        collectView!.register(FilterHeaderCollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionHeader, withReuseIdentifier: "headerID")
        collectView!.register(UICollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionHeader, withReuseIdentifier: "noHeaderID")
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 3
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0 {
            return self.orgArr.count
        }else if section == 1 {
            return  self.vehicleGroupArr.count
        }else {
            return self.collectArr.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "filterCollectionViewCell", for: indexPath) as! FilterCollectionViewCell
        if indexPath.section == 0 {
            let model = self.orgArr[indexPath.row]
            cell.config(model: model)
            if selectValue != model.name {
                cell.titLabel.backgroundColor = UIColor(hex: "#E9E9E9",alpha: 1.0)
                cell.titLabel.textColor = UIColor(hex: "#2A2B37", alpha: 1.0)
            }else {
                cell.titLabel.backgroundColor = UIColor(hex: "#D6DEFC",alpha: 1.0)
                cell.titLabel.textColor = UIColor(hex: "#1D69F5", alpha: 1.0)
            }
            
        } else if  indexPath.section == 1{
            let model = self.vehicleGroupArr[indexPath.row]
            cell.config(model: model)
            if selectValue != model.name {
                cell.titLabel.backgroundColor = UIColor(hex: "#E9E9E9",alpha: 1.0)
                cell.titLabel.textColor = UIColor(hex: "#2A2B37", alpha: 1.0)
            }else {
                cell.titLabel.backgroundColor = UIColor(hex: "#D6DEFC",alpha: 1.0)
                cell.titLabel.textColor = UIColor(hex: "#1D69F5", alpha: 1.0)
            }
        }else {
            cell.configData(item: self.collectArr[indexPath.row])
            if selectValue != self.collectArr[indexPath.row] {
                cell.titLabel.backgroundColor = UIColor(hex: "#E9E9E9",alpha: 1.0)
                cell.titLabel.textColor = UIColor(hex: "#2A2B37", alpha: 1.0)
            }else {
                cell.titLabel.backgroundColor = UIColor(hex: "#D6DEFC",alpha: 1.0)
                cell.titLabel.textColor = UIColor(hex: "#1D69F5", alpha: 1.0)
            }
        }
        return cell
    }
 
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        if section == 0 {
            return CGSize(width: KW, height: 60)
        }else  if section == 1 {
            return CGSize(width: KW, height: 40)
        }else {
            return CGSize(width: KW, height: 40)
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        var str = ""
        var id:Int64! = 0
        var index = 0  // 1 代表公司 2车队 3 驾驶员 4 车辆
        if indexPath.section == 0{
            let model = self.orgArr[indexPath.row]
            str = model.name ?? ""
            index = 1
            id = model.id
        }else if indexPath.section == 1{
            let model = self.vehicleGroupArr[indexPath.row]
            str = model.name ?? ""
            id = model.id
            index = 2
        }else {
            if indexPath.row == 0 {
                index = 3
            }else {
                index = 4
            }
            str = self.collectArr[indexPath.row]
        }
        
        selectValue = str
        let defaults = UserDefaults.standard
        defaults.set(str, forKey: "reportFilterValue")
    
        self.collectView.reloadData()
        if self.passValue != nil {
            self.passValue?(index,id)
        }
        NotificationCenter.default.post(name: NSNotification.Name(rawValue:GYSideTapNotification), object: nil)
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        var reusableview:FilterHeaderCollectionReusableView!
        var noneReusableview:UICollectionReusableView!
        if kind == UICollectionView.elementKindSectionHeader{
            reusableview = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "headerID", for: indexPath) as! FilterHeaderCollectionReusableView
            reusableview.backgroundColor = UIColor.white
        
            if indexPath.section == 0 {
                if self.orgArr.count != 0 {
                    reusableview.label.text = "公司组织"
                }
                
            }else if indexPath.section == 1{
                if self.vehicleGroupArr.count != 0 {
                    reusableview.label.text = "车队"
                }
                
            }else {
                if self.collectArr.count != 0 {
                    reusableview.label.text = "关注"
                }
                
            }
            return reusableview
            
        }else {
            noneReusableview = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "noHeaderID", for: indexPath)
            return noneReusableview
        }
        
    }
     
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
