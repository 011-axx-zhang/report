//
//  VehicleManagerVC.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/23.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON
import SwiftyJSON


class VehicleManagerVC: BaseVC ,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    var collectView :UICollectionView!
    var topView:VehicleTopView!
    var flag:Bool = false
    var index:Int = 1
    var model:VehicleManagerModel!
    
    var chartArr:Array<ChartModel> = []
    var fromTimeStr:String = ""
    var toTimeStr:String = ""
    var days:Int = 1
    var vehId:Int64?
    var orgId:Int64?
    var vehGroupId:Int64?
    
     var todayStr:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setNowTime()
        self.view.backgroundColor = UIColor.white
        self.createtopView()
        self.createCollectionView()
        self.getVehReportRequest()
        self.getVehRunningRateRequest()
        // Do any additional setup after loading the view.
        if #available(iOS 11.0, *) {
            collectView.contentInsetAdjustmentBehavior = .never
        }
        view.insertSubview(navBar, aboveSubview: collectView)
        navBar.title = "车辆管理"
    }

    
   func setNowTime() {
        let date = Date()
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy-MM-dd"
        todayStr = dateFmt.string(from: date)
        let timeS:TimeInterval = TimeInterval(24*60*60)
        let nowTimeS:TimeInterval = date.timeIntervalSince1970
        let totalTime :TimeInterval = nowTimeS - timeS
        let needDate :Date  = Date.init(timeIntervalSince1970: totalTime)
        toTimeStr = dateFmt.string(from: needDate)
    }
    
    func createtopView() {
        topView = VehicleTopView.init(frame: CGRect(x: 0, y: kNavBarBottom, width: KW, height: 85))
        self.view.addSubview(topView)
        topView.passDay = { day in
            self.days = day
            self.setFromTime(index: day)
            if self.days == 1 {
                self.topView.dateValueLabel.text = String(format: "%@", self.toTimeStr)
            }else {
                self.topView.dateValueLabel.text = String(format: "%@至%@", self.fromTimeStr,self.toTimeStr)
            }
            self.getVehReportRequest()
            self.getVehRunningRateRequest()
        }
        topView.dateClick = {
            let picker = QCalendarPicker { (date: String) in
                if self.judgeTime(dateStr: date){
                    self.view.makeToastMid(message: "只能选择当天之前的日期")
                }else {
                    self.topView.dateLabel.text = date
                    self.toTimeStr = date
                    if self.days == 1 {
                        self.topView.dateValueLabel.text = String(format: "%@", self.toTimeStr)
                    }else {
                        
                        self.setFromTime(index: self.days)
                        self.topView.dateValueLabel.text = String(format: "%@至%@", self.fromTimeStr,self.toTimeStr)
                    }
                    self.getVehReportRequest()
                    self.getVehRunningRateRequest()
                }
            }
            picker.isAllowSelectTime = false
            picker.show()
        }
    }
    
    func judgeTime(dateStr:String) -> Bool {
        let date = Date()
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy-MM-dd"
        let str = dateFmt.string(from: date)
        let date0 = date.strToDate(item: str)
        let date1 = date.strToDate(item: dateStr)
        if date1.compare(date0 as Date) == ComparisonResult.orderedSame {
            return true
        } else if date1.compare(date0 as Date) == ComparisonResult.orderedDescending {
            return true
        } else if date1.compare(date0 as Date) == ComparisonResult.orderedAscending {
            return false
        }
         return true
       
    }
    
    
    func setFromTime(index:Int)  {
        if index == 1 {
            fromTimeStr = ""
        }else {
            let index1 = index - 1
            let dateFmt = DateFormatter.init()
            dateFmt.dateFormat = "yyyy-MM-dd"
            let date = dateFmt.date(from: self.toTimeStr)
            
            let timeS:TimeInterval = TimeInterval(24*60*60*index1)
            let nowTimeS:TimeInterval = date!.timeIntervalSince1970
            let totalTime :TimeInterval = nowTimeS - timeS
            let needDate :Date  = Date.init(timeIntervalSince1970: totalTime)
            fromTimeStr = dateFmt.string(from: needDate)
        }
        
    }
    
    func createCollectionView()  {
        let layout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0,bottom: 0, right: 0)
        layout.minimumInteritemSpacing = 10
        layout.minimumLineSpacing  = 10
        collectView = UICollectionView(frame:CGRect(x: 0, y: kNavBarBottom+86, width: KW, height: KH - 86 - kNavBarBottom), collectionViewLayout: layout)
        collectView!.register(VehicleModelCollectionViewCell.self, forCellWithReuseIdentifier:"vehicleModelCollectionViewCell")
        collectView!.register(VehicleYunYingCollectionViewCell.self, forCellWithReuseIdentifier:"vehicleYunYingCollectionViewCell")
        collectView!.register(YunYingPieChartCollectionViewCell.self,forCellWithReuseIdentifier:"yunYingPieChartCollectionViewCell")
        collectView!.register(StopVehicleCollectionViewCell.self, forCellWithReuseIdentifier:"stopVehicleCollectionViewCell")
        collectView!.register(VehicleOtherCollectionViewCell.self, forCellWithReuseIdentifier:"vehicleOtherCollectionViewCell")
        collectView!.register(VehicleWeizhangCollectionViewCell.self, forCellWithReuseIdentifier:"vehicleWeizhangCollectionViewCell")
        collectView!.register(VehicleLastHeaderCollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionHeader, withReuseIdentifier: "vehicleLastHeaderCollectionReusableView")
        collectView!.register(VehicleFirstHeaderCollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionHeader, withReuseIdentifier: "vehicleFirstHeaderCollectionReusableView")
        collectView!.register(UICollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionHeader, withReuseIdentifier: "noHeaderID")
        collectView!.register(UICollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionFooter, withReuseIdentifier: "nofooterID")
        collectView!.delegate = self
        collectView!.dataSource = self
        collectView.showsHorizontalScrollIndicator = false
        collectView.backgroundColor = UIColor(hex: "#F5F5F9", alpha: 1.0)
        self.view.addSubview(collectView!)
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 5
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 1
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if indexPath.section == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "vehicleModelCollectionViewCell", for: indexPath) as! VehicleModelCollectionViewCell
            if self.model != nil {
                cell.configData(dataModel: self.model)
            }
            return cell
        } else  if indexPath.section == 1{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "vehicleYunYingCollectionViewCell", for: indexPath) as! VehicleYunYingCollectionViewCell
            if self.chartArr.count != 0 {
                 cell.configData(dataArr: self.chartArr,dateStr:self.toTimeStr)
            }
           
            return cell
        }else if indexPath.section == 2 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "yunYingPieChartCollectionViewCell", for: indexPath) as! YunYingPieChartCollectionViewCell
            if self.model != nil {
                cell.configData(dataModel: self.model)
            }
            return cell
            
        }else if  indexPath.section == 3{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "stopVehicleCollectionViewCell", for: indexPath) as! StopVehicleCollectionViewCell
            if self.model != nil {
                cell.configData(dataModel: self.model)
            }
            return cell
        }else {
            if !flag == true {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "vehicleWeizhangCollectionViewCell", for: indexPath) as! VehicleWeizhangCollectionViewCell
                cell.titleLabel.text = String(format: "截止:%@", self.toTimeStr)
                cell.configData(dataModel: self.model)
                //  页面跳转时需要带入当前车辆ID
                cell.checkMoreClick = {
                    //到违章页面
                    let vc = NotificationViewController()
                    vc.selectIndex = 1
                    vc.isOtherPage = true
                    vc.vehicleID = self.vehId ?? 0  //  车辆ID
                    vc.vehGroupId = self.vehGroupId
                    vc.orgId = self.orgId
                    self.navigationController?.pushViewController(vc, animated: true)
                }

                return cell
            }else {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "vehicleOtherCollectionViewCell", for: indexPath) as! VehicleOtherCollectionViewCell
                
                cell.checkMoreClick = {
                    // 2事故页面   3车辆维保页面   4保险页面
                    let vc = NotificationViewController()
                    vc.selectIndex = self.index
                    vc.isOtherPage = true
                    vc.vehicleID = self.vehId ?? 0  //  车辆ID
                    vc.vehGroupId = self.vehGroupId
                    vc.orgId = self.orgId
                    self.navigationController?.pushViewController(vc, animated: true)
                }
                if self.model != nil {
                    cell.configData(dataModel: self.model, index: index)
                }
                
                return cell
            }
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        if section == 0 {
            return CGSize(width: KW, height: 50)
        } else if section == 4{
            return CGSize(width: KW, height: 50)
        }else {
            return CGSize(width: KW, height: 0.01)
        }
        
        
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        
        return CGSize(width: KW, height: 0.01)
        
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if indexPath.section == 0 {
            return CGSize(width: KW , height: 170)
        } else if indexPath.section == 1{
            return CGSize(width: KW, height: 210)
        }else if indexPath.section == 2 || indexPath.section == 3 {
            return CGSize(width: KW , height: 170)
        }else {
            if !flag == true {
                return CGSize(width: KW , height: 170)
            }else {
                return CGSize(width: KW , height: 200)
            }
            
        }
        
        
    }
    
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String,
                        at indexPath: IndexPath) -> UICollectionReusableView {
        
        var noneReusableview:UICollectionReusableView!
        var  vehicleLastHeaderCollectionReusableView:VehicleLastHeaderCollectionReusableView!
        var  vehicleFirstHeaderCollectionReusableView:VehicleFirstHeaderCollectionReusableView!
        
        if kind == UICollectionView.elementKindSectionHeader{
            if indexPath.section == 0 {
                vehicleFirstHeaderCollectionReusableView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "vehicleFirstHeaderCollectionReusableView", for: indexPath) as! VehicleFirstHeaderCollectionReusableView
                vehicleFirstHeaderCollectionReusableView.checkMoreClick = {
                    let vc  = VehicleVC()
                    vc.orgId = self.orgId
                    vc.vehGroupId = self.vehGroupId
                    self.navigationController?.pushViewController(vc, animated: true)
                }
                return vehicleFirstHeaderCollectionReusableView
                
            }else  if indexPath.section == 4{
                vehicleLastHeaderCollectionReusableView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "vehicleLastHeaderCollectionReusableView", for: indexPath) as! VehicleLastHeaderCollectionReusableView
                vehicleLastHeaderCollectionReusableView.dangAnClick  = { index in
                    self.index = index
                    if index == 1 {
                        self.flag = false
                        self.collectView.reloadData()
                    }else {
                        self.flag = true
                        self.collectView.reloadData()
                    }
                    
                }
                
                return vehicleLastHeaderCollectionReusableView
            }else {
                noneReusableview = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "noHeaderID", for: indexPath)
                noneReusableview.backgroundColor = UIColor(hex: "#F5F5F9", alpha: 1.0)
                return noneReusableview
            }
            
        }else {
            noneReusableview = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "nofooterID", for: indexPath)
            noneReusableview.backgroundColor = UIColor(hex: "#F5F5F9", alpha: 1.0)
            return noneReusableview
        }
        
    }
    
    func getVehReportRequest() {
         var paramDic:Dictionary<String,Any> = [:]
        if orgId != nil {
            paramDic["orgId"] = self.orgId
        }else if self.vehGroupId != nil {
            paramDic["vehGroupId"] = self.vehGroupId
        }
        paramDic["days"] =  self.days
        paramDic["endDate"] =  self.toTimeStr
        
       // let param = ["days":self.days,"endDate":self.toTimeStr] as [String : Any]
        
        HttpRequest.loadData(target: InterfaceAPI.getVehReport(param: paramDic), needCache: false, cache: nil, success: { (datas) in
            let json = JSON(datas)
            let data = JSONDeserializer<VehicleManagerModel>.deserializeFrom(json: json["data"].description)
            self.model = data
            self.collectView.reloadData()
        }) { (stateCode ,message)  in
            
        }
    }
    
    
    func getVehRunningRateRequest()  {
        var paramDic:Dictionary<String,Any> = [:]
        if orgId != nil {
            paramDic["orgId"] = self.orgId
        }else if self.vehGroupId != nil {
            paramDic["vehGroupId"] = self.vehGroupId
        }
        paramDic["endDate"] =  self.toTimeStr
        HttpRequest.loadData(target: InterfaceAPI.getVehRunningRate(param: paramDic), needCache: false, cache: nil, success: { (datas) in
            let json = JSON(datas)
            let data = JSONDeserializer<ChartModel>.deserializeModelArrayFrom(json: json["data"].description)
            if data != nil {
                self.chartArr = data as! Array<ChartModel>
                self.collectView.reloadData()
            }
           
        }) { (stateCode ,message)  in
            self.view.makeToastMid(message: message)
        }
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
     //   self.navigationController?.navigationBar.isHidden = false
    }
    
   
    
}
