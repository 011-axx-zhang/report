//
//  DriverListViewController.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/19.
//  Copyright © 2019 YTKJ. All rights reserved.
//  驾驶员列表

import UIKit
import HandyJSON
import SwiftyJSON

class DriverListViewController: RootController,UITableViewDelegate,UITableViewDataSource,DriverListCellDelegate {
    let topView = UIView()
    var mileage = UIButton()        //  里程数
    var siftedOption = UIButton()   //  筛选
    var driverList : UITableView!
    var searchLabel : SearchInputView!
    var filterView:VehicleChooseView!   //  筛选
    var eventType:DriverOptionView!     //  事件类型
    var typeIndex:Int = 1   //  类型标记
    var sourceData:[DriverListModel] = []
    
    var orgArr:Array<OrgAndGroupContent> = []
    var vehicleGroupArr:Array<OrgAndGroupContent> = []
    
    var orgId:Int64? = 0
    var vehGroupId:Int64? = 0
    var focusDriver:Bool = false
//    var focusVeh:Bool = false
    var keyword = ""    //  搜索的关键字
    var pageOffset = 0  //  请求数据的条数，从0开始以10为值自增
//    var requestValue : [String : Any] = [:]
    var isSelectFocus = false   //  是否选择关注司机
    
    
    override func viewDidLoad() {
        //
        super.viewDidLoad()
    }
    override func addNavView() {
        topView.frame = CGRect.init(x: 0, y: 0, width: KW, height: navigationBarHeight == 64 ? 103 : 128)
        topView.backgroundColor = UIColor.white
        self.view.addSubview(topView)
        
        //  返回
        let back = UIButton.init(type: .custom)
        back.frame = CGRect.init(x: 5, y: statusHeight, width: 44, height: 44)
        back.setImage(UIImage(named: "navigation_back"), for: .normal)
        back.addTarget(self, action: #selector(leftNavigationBarItemAction), for: .touchUpInside)
        topView.addSubview(back)
        
        //  输入
        searchLabel = SearchInputView.init(frame: CGRect.init(x: 50, y: statusHeight+2, width: KW-50-55, height: 40))
        searchLabel.backgroundColor = UIColor.init(hex: "#DFDFF1", alpha: 1.0)
        searchLabel.placeholder = "搜索车牌号/驾驶员姓名"
        searchLabel.font = UIFont.systemFont(ofSize: 13)
        searchLabel.layer.cornerRadius = 4;
        searchLabel.backgroundColor = UIColor.init(hex: "#EFF1F6", alpha: 1.0)
        topView.addSubview(searchLabel)
        
        //  搜索
        let search = UIButton.init(type: .custom)
        search.frame = CGRect.init(x: KW-44-10, y: statusHeight, width: 44, height: 44)
        search.setTitle("搜索", for: .normal)
        search.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        search.setTitleColor(UIColor.init(hex: "#325AEF", alpha: 1.0), for: .normal)
        search.addTarget(self, action: #selector(searchClicked), for: .touchUpInside)
        topView.addSubview(search)
        
        //  筛选条件
        let bottomLine = UIView.init(frame: .init(x: 0, y: topView.frame.height-1, width: topView.frame.width, height: 1))
        bottomLine.backgroundColor = UIColor.init(hex: "#DFDFF1", alpha: 1.0)
        topView.addSubview(bottomLine)
        
        
        //  事件类型
        mileage.frame = CGRect.init(x: 15, y: searchLabel.frame.maxY, width: KW/2, height: 40)
        mileage.setTitle("综合排序", for: .normal)
        mileage.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        mileage.setTitleColor(.black, for: .normal)
        mileage.setTitleColor(UIColor.init(hex: "#325AEF", alpha: 1.0), for: .selected)
        mileage.isSelected = false
        mileage.setImage(UIImage.init(named: "notification_pull_down"), for: .normal)
        mileage.setImage(UIImage.init(named: "notification_pull_up"), for: .selected)
        mileage.imageEdgeInsets = UIEdgeInsets.init(top: 0, left: 50, bottom: 0, right: -10)
        mileage.titleEdgeInsets = UIEdgeInsets.init(top: 0, left: -70, bottom: 0, right: 10)
        mileage.addTarget(self, action: #selector(mileageClicked), for: .touchUpInside)
        topView.addSubview(mileage)
        
        
        //  筛选
        siftedOption.frame = CGRect.init(x: topView.frame.width/2+50, y: searchLabel.frame.maxY, width: 70, height: 40)
        siftedOption.setTitle("筛选", for: .normal)
        siftedOption.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        siftedOption.setTitleColor(.black, for: .normal)
        siftedOption.setTitleColor(UIColor.init(hex: "#325AEF", alpha: 1.0), for: .selected)
        siftedOption.isSelected = false
        siftedOption.setImage(UIImage.init(named: "home_shaixuan"), for: .normal)
        siftedOption.imageEdgeInsets = UIEdgeInsets.init(top: 0, left: 40, bottom: 0, right: 10)
        siftedOption.titleEdgeInsets = UIEdgeInsets.init(top: 0, left: -30, bottom: 0, right: 10)
        siftedOption.imageView?.contentMode = UIView.ContentMode.scaleAspectFit
        siftedOption.addTarget(self, action: #selector(siftedOptionClicked), for: .touchUpInside)
        topView.addSubview(siftedOption)
    }
    
    override func addChildView() {
        driverList = UITableView.init(frame: .init(x: 0, y: topView.frame.maxY+8, width: KW, height: KH-topView.frame.maxY-8), style: .plain)
        driverList.delegate = self
        driverList.dataSource = self
        driverList.rowHeight = 117.0
        driverList.separatorStyle = .none
        driverList.backgroundColor = UIColor.white
        self.view.addSubview(driverList)
        driverList!.register(DriverListTableViewCell.self, forCellReuseIdentifier: "notiCellID")
        driverList.mj_header = MJRefreshNormalHeader.init(refreshingBlock: {
            self.sourceData.removeAll()
            self.getNewData()
        })
        driverList.mj_footer = MJRefreshBackNormalFooter.init(refreshingBlock: {
            self.getMoreData()
        })
    }
    
    
    //  MARK: - tableView 代理
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sourceData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "notiCellID", for: indexPath) as! DriverListTableViewCell
        cell.selectionStyle = .none

        if sourceData.count > 0 {
            
            cell.configDataSource(riskData: sourceData[indexPath.row])
        }
        cell.delegate = self
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailVC = DriverDetailsViewController()
        detailVC.driverID = sourceData[indexPath.row].id
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
    
    @objc func searchClicked () {
        keyword = searchLabel.text ?? ""
        driverList.mj_header.beginRefreshing()
    }
    
    //  排序
    @objc func mileageClicked () {
        print("今日行驶公里数点击事件")
        self.view.addSubview(transparentView)
        eventType = DriverOptionView.init(frame: CGRect(x: 0, y: topView.frame.maxY, width: KW, height: KH - topView.frame.maxY), index: typeIndex-1, titleArr:["今日行驶公里","风险次数"])  //  ["今日行驶公里","风险次数","安全信用指数"]
        transparentView.addSubview(eventType)
        eventType.selectedCellBlock = { selectIndex, cellText in
//            print("选中的是第 \(selectIndex) 行")
            self.typeIndex = selectIndex
            self.mileage.setTitle(cellText, for: .normal)
            if selectIndex != 2 {
                self.mileage.imageEdgeInsets = UIEdgeInsets.init(top: 0, left: 100, bottom: 0, right: -10)
            }else{
                self.mileage.imageEdgeInsets = UIEdgeInsets.init(top: 0, left: 50, bottom: 0, right: -10)
            }
            self.eventType.removeFromSuperview()
            self.transparentView.removeFromSuperview()
            //  选完之后刷新数据
            self.driverList.mj_header.beginRefreshing()
        }
        
        //  关闭筛选框
        eventType.closeOptionView = {
            self.eventType.removeFromSuperview()
            self.transparentView.removeFromSuperview()
        }
    }
    
    //  筛选
    @objc func siftedOptionClicked () {
        self.view.addSubview(transparentView)
        filterView =  VehicleChooseView.init(frame: CGRect(x: 0, y: topView.frame.maxY, width: KW, height: KH - topView.frame.maxY),orgArr:self.orgArr,vehicleGroupArr:self.vehicleGroupArr)
        filterView.orgArr = self.orgArr
        filterView.vehicleGroupArr = self.vehicleGroupArr
        filterView.thirdArr = ["关注司机"]
        filterView.frame = CGRect(x: 0, y: topView.frame.maxY, width: KW, height: KH - topView.frame.maxY)
        transparentView.addSubview(filterView)
        filterView.passValue = { (index,id,isFocus) in
            print("关注司机选线 \(index)  isFocus \(isFocus)")
            self.handleFilterValue(index: index, id: id, focus: isFocus)
        }
        filterView.closeClick = {
            self.filterView.removeFromSuperview()
            self.transparentView.removeFromSuperview()
        }
        filterView.resetClick = {
            self.isSelectFocus = false
            self.handleFilterValue(index: 0, id: 0, focus: false)
        }
    }
    
    func handleFilterValue(index:Int,id:Int64,focus:Bool)  {
        print("筛选条件 \(index)--\(id)--\(focus)")
        if index == 1 {
            orgId = id
            vehGroupId = 0
            focusDriver = focus
//            focusVeh = false
        }else if index == 2 {
            vehGroupId = id
            orgId = 0
            focusDriver = false
//            focusVeh = false
        }else if index == 3 {
            //  关注司机
            orgId = 0
            vehGroupId = 0
            focusDriver = true
            isSelectFocus = true
//            focusVeh = false
        }else if index == 4{
            orgId = 0
            vehGroupId = 0
            focusDriver = false
//            focusVeh = false
        }else {
            //  重置筛选条件
            orgId = 0
            vehGroupId = 0
            focusDriver = focus
            isSelectFocus = false
//            focusVeh = false
        }
        
        self.filterView.removeFromSuperview()
        self.transparentView.removeFromSuperview()
        driverList.mj_header.beginRefreshing()
    }
    
    
    //  MARK: - 刷新
    func getNewData() -> Void {
        pageOffset = 0
        getData()
    }
    func getMoreData() -> Void {
        pageOffset += 10
        getData()
    }
    
    //  MARK: - 请求数据
    func getData() -> Void {
        //  sortby 排序方式
        var param = ["orgId":self.orgId ?? 0,"vehGroupId":self.vehGroupId ?? 0,"focusDriver":focusDriver,"sortby":typeIndex,"key":keyword,"offset":pageOffset,"limit":10] as [String : Any]
        
//        requestValue = param
        
        //  值为 0 或者没有的话就不传
        for (objcKey, objcValue) in param {
            if objcValue is Int64 && objcValue as! Int64 == 0{
                param.removeValue(forKey: objcKey)
            }else if objcValue is String && objcValue as! String == "" {
                param.removeValue(forKey: objcKey)
            }else{
                print("key = \(objcKey)  value = \(objcValue)")
            }
        }
        
        //  如果是首次进入，无需传以下参数
        if isSelectFocus == false {
            param.removeValue(forKey: "focusDriver")
        }
        
        print("司机列表最后请求接口 \(param)")
        HttpRequest.loadData(target: InterfaceAPI.getDriverListData(param: param), success: { (datas) in
            if self.driverList.mj_footer.isRefreshing {
                self.driverList.mj_footer.endRefreshing()
            }else if self.driverList.mj_header.isRefreshing {
                self.driverList.mj_header.endRefreshing()
            }
            
            let json = JSON(datas)
            let data = JSONDeserializer<DriverListModel>.deserializeModelArrayFrom(json: json["data"].description)
            for model in data ?? [] {
                self.sourceData.append(model!)
            }
            if data?.count == 0 {
                self.view.makeToast("没有更多内容")
            }
            self.driverList.reloadData()
        }) { (stateCode ,message)  in
            print("请求失败  \(message)")
        }
    }
    
    //  获取筛选数据
    func getOrgData() -> Void {
        HttpRequest.loadData(target: InterfaceAPI.getOrgsAndVehGroups, needCache: false, cache: nil, success: { (datas) in
            let json = JSON(datas)
            let data = JSONDeserializer<OrgAndVehGroupsModel>.deserializeFrom(json: json["data"].description)
            self.orgArr = data?.orgs ?? []
            self.vehicleGroupArr = data?.vehGroups ?? []
        }) { (stateCode, message) in
            
        }
    }
    
    //  收藏驾驶员
    func didSelectCollect(_ driverID: Int, isSelected:Bool, selectCell: DriverListTableViewCell) {
        let param = ["driverId" : driverID,"isFocused":isSelected] as [String : Any]
        let cellIndex = driverList.indexPath(for: selectCell)
        HttpRequest.loadData(target: InterfaceAPI.focusDriver(param: param), success: { (datas) in
            let json = JSON(datas)
            if json["code"] == 0 {
                self.sourceData[cellIndex!.row].isFocused = isSelected
                self.driverList.reloadRows(at: [cellIndex!], with: .none)
            }
        }) { (stateCode, message) in
            print("请求失败 \(message)")
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        if self.sourceData.count < 1 {
            getData()
        }
        
        if orgArr.count == 0 {
            getOrgData()
        }
    }
    
    lazy var transparentView:UIView = {
        let transparentView = UIView()
        transparentView.backgroundColor = UIColor.clear
        transparentView.frame = CGRect(x: 0, y: 0, width: KW, height: KH)
        transparentView.isUserInteractionEnabled = true
        return transparentView
    }()
}
