//
//  FilterCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/6.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class FilterCollectionViewCell: UICollectionViewCell {
    var titLabel:UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        self.contentView.backgroundColor = UIColor.white
        initView()
        updateConstraints()
    }
    
    
    func initView(){
        titLabel = UILabel()
        titLabel.font = UIFont.systemFont(ofSize: 14)
        titLabel.textColor = UIColor.black
        titLabel.textAlignment = .center
        titLabel.numberOfLines = 0
        titLabel.layer.cornerRadius = 3
        titLabel.layer.masksToBounds = true
        self.contentView.addSubview(titLabel)
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        
        titLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(self)
            make.right.equalTo(self)
            make.size.equalToSuperview()
        }
        
    }
    
    
    func configData(item:String)  {
        titLabel.text = item
    }
    
    func config(model:OrgAndGroupContent)  {
        titLabel.text = model.name ?? ""
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
