//
//  HomeBottomView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/4.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import SnapKit
class HomeBottomView: UIView {

    var bgImageView:UIImageView!
    var notificationBtn:UIButton!
    var notiImageView:UIImageView!
    var notiLabel:UILabel!
    var guanCheBtn:UIButton!
    var guanCheImageView:UIImageView!
    var guanCheLabel:UILabel!
    var reportFormBtn:UIButton!
    var reportFormImageView:UIImageView!
    var reportFormLabel:UILabel!
    @objc var notiClick:(()->Void)?
    @objc var guanCheClick:(()->Void)?
    @objc var baoBiaoClick:(()->Void)?
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.clear
        self.createUI()
        updateConstraints()
    }
    
    private func createUI() {
       
      //  背景
        bgImageView = UIImageView()
        bgImageView.image = UIImage(named: "home_bottomBg")
        bgImageView.isUserInteractionEnabled = true
        self.addSubview(bgImageView)
        
        //通知
        notificationBtn = UIButton()
        bgImageView.addSubview(notificationBtn)
        notiImageView = UIImageView()
        notiImageView.contentMode = .center
        notiImageView.image = UIImage(named: "home_noti")
        notificationBtn.addSubview(notiImageView)
        notiLabel = UILabel()
        notiLabel.font = UIFont.systemFont(ofSize: 11)
        notiLabel.text = "通知"
        notiLabel.textAlignment = .center
        notiLabel.textColor = UIColor(hex: "#333333",alpha: 1.0)
        notificationBtn.addSubview(notiLabel)
        notificationBtn.addTarget(self, action: #selector(notiEvent), for: .touchUpInside)
        //管车
        guanCheBtn = UIButton()
        self.addSubview(guanCheBtn)
        guanCheImageView = UIImageView()
        guanCheImageView.image = UIImage(named: "home_guanChe")
        guanCheImageView.contentMode = .center
        guanCheBtn.addSubview(guanCheImageView)
        guanCheLabel = UILabel()
        guanCheLabel.text = "管车"
        guanCheLabel.textColor = UIColor.white
        guanCheLabel.font = UIFont.systemFont(ofSize: 11)
        guanCheLabel.textAlignment = .center
        guanCheBtn.addSubview(guanCheLabel)
        guanCheBtn.addTarget(self, action: #selector(guanCheEvent), for: .touchUpInside)
        //报表
        reportFormBtn = UIButton()
        bgImageView.addSubview(reportFormBtn)
        
        reportFormImageView = UIImageView()
       // reportFormImageView.backgroundColor = UIColor.red
        reportFormImageView.image = UIImage(named: "home_baobiao")
        reportFormImageView.contentMode = .center
        reportFormBtn.addSubview(reportFormImageView)
        
        reportFormLabel = UILabel()
        reportFormLabel.text = "报表"
        reportFormLabel.textAlignment = .center
        reportFormLabel.textColor = UIColor(hex: "#333333",alpha: 1.0)
        reportFormLabel.font = UIFont.systemFont(ofSize: 11)
        reportFormBtn.addSubview(reportFormLabel)
        reportFormBtn.addTarget(self, action: #selector(baoBiaoEvent), for: .touchUpInside)
    }
    
    @objc func notiEvent() {
        if  self.notiClick != nil {
            self.notiClick?()
        }
    }
    
    
    @objc  func guanCheEvent()  {
        if  self.guanCheClick != nil {
            self.guanCheClick?()
        }
    
    }
    
    
    @objc   func baoBiaoEvent()  {
        if self.baoBiaoClick != nil {
            self.baoBiaoClick?()
        }
    }
    
    
    
    override func updateConstraints() {
        super.updateConstraints()
        bgImageView.snp.makeConstraints { (make) in
            make.center.equalTo(self)
            make.size.equalTo(CGSize(width: 246, height: 84))
        }

        notificationBtn.snp.makeConstraints { (make) in
            make.left.equalTo(bgImageView.snp.left).offset(40)
            make.top.equalTo(bgImageView.snp.top).offset(20)
        }
        
        notiImageView.snp.makeConstraints { (make) in
            make.top.equalTo(notificationBtn.snp.top).offset(2)
            make.centerX.equalTo(notificationBtn)
            make.size.equalTo(CGSize(width: 25, height: 25))
        }
        notiLabel.snp.makeConstraints { (make) in
            make.top.equalTo(notiImageView.snp.bottom).offset(2)
            make.centerX.equalTo(notiImageView)
        }
        guanCheBtn.snp.makeConstraints { (make) in
            make.centerX.equalTo(bgImageView)
            make.top.equalTo(bgImageView.snp.top).offset(19)
            make.size.equalTo(CGSize(width: 68, height: 68))
        }
        guanCheImageView.snp.makeConstraints { (make) in
            make.centerX.equalTo(guanCheBtn)
            make.top.equalTo(guanCheBtn.snp.top).offset(2)
            make.size.equalTo(CGSize(width: 25, height: 25))
        }
        guanCheLabel.snp.makeConstraints { (make) in
            make.top.equalTo(guanCheImageView.snp.bottom).offset(2)
            make.centerX.equalTo(guanCheImageView)
        }
        
        
        reportFormBtn.snp.makeConstraints { (make) in
            make.right.equalTo(bgImageView.snp.right).offset(-40)
            make.top.equalTo(bgImageView.snp.top).offset(20)
            make.size.equalTo(CGSize(width: 30, height: 30))
        }
        
        reportFormImageView.snp.makeConstraints { (make) in
            make.top.equalTo(reportFormBtn.snp.top).offset(2)
            make.centerX.equalTo(reportFormBtn)
            make.size.equalTo(CGSize(width: 25, height: 25))
        }
        
        reportFormLabel.snp.makeConstraints { (make) in
            make.centerX.equalTo(reportFormImageView)
            make.top.equalTo(reportFormImageView.snp.bottom).offset(2)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
