//
//  FilterBottomView.swift
//  GCB
//
//  Created by YTKJ on 2018/7/20.
//  Copyright © 2018年 YTKJ. All rights reserved.
//

import UIKit

class FilterBottomView: UIView {
    var resetBtn :UIButton!
    var finishBtn:UIButton!
//    var sepLine :UIView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        self.createUI()
        updateConstraints()
    }
    
    private func createUI() {
        resetBtn = UIButton()
        resetBtn.setTitle("重置", for: .normal)
        resetBtn.setTitleColor(UIColor(hex: "#2A2B37", alpha: 1.0), for: .normal)
        resetBtn.backgroundColor = UIColor(hex: "#EFF1F6",alpha: 1.0)
        resetBtn.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        resetBtn.layer.cornerRadius = 2
        self.addSubview(resetBtn)
        
        finishBtn = UIButton()
        finishBtn.setTitle("确定", for: .normal)
        finishBtn.setTitleColor(UIColor.white, for: .normal)
        finishBtn.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        finishBtn.backgroundColor = UIColor(hex: "#2B72F5",alpha: 1.0)
         finishBtn.layer.cornerRadius = 2
        self.addSubview(finishBtn)
      
        
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        resetBtn.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(24)
            make.top.equalToSuperview()
            make.height.equalTo(35)
        }
        finishBtn.snp.makeConstraints { (make) in
            make.left.equalTo(resetBtn.snp.right).offset(8)
            make.right.equalTo(self.snp.right).offset(-24)
            make.top.equalToSuperview()
            make.width.equalTo(resetBtn)
            make.height.equalTo(35)
        }
    
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
