//
//  MarkToastView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/6.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class MarkToastView: UIView {
    var bgView:UIView!
    var iconBtn:UIButton!
    var vehicleNameLabel:UILabel!
    var orgNameLabel:UILabel!
    var driverLabel:UILabel!
    var speedLabel:UILabel!
    var temperatureLabel:UILabel!
    var locationLabel:UILabel!
    var collectDriverBtn:UIButton!
    var collectDriverImageView:UIImageView!
    var collectionDriverLabel :UILabel!
    var collectVehicleBtn:UIButton!
    var collectVehicleImageView:UIImageView!
    var collectionVehicleLabel:UILabel!
    var reportBtn:UIButton!
    var telBtn:UIButton!
    var reportImageView:UIImageView!
    var reportLabel:UILabel!
    
    var telImageView:UIImageView!
    var telLabel:UILabel!
    var videoBtn:UIButton!
    var videoImageView:UIImageView!
    var videoLabel:UILabel!
    var chatBtn:UIView!
    var chatImageView:UIImageView!
    var chatLabel:UILabel!
    var lineView:UIView!
    var model:VehicleModel!
    var topLineView:UIView!
    var topView:UIView!
     var bottomView:UIView!
    

    @objc var collectDriverBtnClick:(()->Void)?
    @objc var collectVehicleBtnClick:(()->Void)?
    @objc var reportClick:(()->Void)?
    @objc var telClick:(()->Void)?
    @objc var driverClick:(()->Void)?
   
      override init(frame: CGRect) {
          super.init(frame: frame)
          self.backgroundColor = UIColor.white
          self.createUI()
          updateConstraints()
      }
      
      private func createUI() {
            
      
        iconBtn = UIButton()
        iconBtn.setImage(UIImage(named: "home_driver"), for: .normal)
        self.addSubview(iconBtn)
        vehicleNameLabel = UILabel()
        vehicleNameLabel.text = ""
        vehicleNameLabel.font = UIFont.boldSystemFont(ofSize: 17)
        self.addSubview(vehicleNameLabel)
        orgNameLabel = UILabel()
        orgNameLabel.text = ""
        orgNameLabel.font = UIFont.systemFont(ofSize: 10)
        orgNameLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.addSubview(orgNameLabel)
        driverLabel = UILabel()
        driverLabel.text = "驾驶员:"
        driverLabel.font = UIFont.systemFont(ofSize: 13)
        driverLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.addSubview(driverLabel)
        speedLabel = UILabel()
        speedLabel.text = "速度:"
        speedLabel.font = UIFont.systemFont(ofSize: 12)
        speedLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.addSubview(speedLabel)
        temperatureLabel = UILabel()
        temperatureLabel.text = "温度："
        temperatureLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        temperatureLabel.font = UIFont.systemFont(ofSize: 12)
        self.addSubview(temperatureLabel)
        locationLabel = UILabel()
        locationLabel.font = UIFont.systemFont(ofSize: 12)
        locationLabel.text = ""
        locationLabel.numberOfLines = 0
        locationLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.addSubview(locationLabel)
        
        collectDriverBtn = UIButton()
        self.addSubview(collectDriverBtn)
        collectDriverImageView = UIImageView()
        collectDriverImageView.image = UIImage(named: "home_mark_xin")
        collectDriverBtn.addSubview(collectDriverImageView)
        collectionDriverLabel = UILabel()
        collectionDriverLabel.text = "关注驾驶员"
        collectionDriverLabel.font = UIFont.systemFont(ofSize: 10)
        collectionDriverLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        collectDriverBtn.addSubview(collectionDriverLabel)


        collectVehicleBtn = UIButton()
        self.addSubview(collectVehicleBtn)
        collectVehicleImageView = UIImageView()
        collectVehicleImageView .image = UIImage(named: "home_mark_wuxing")
        collectVehicleBtn.addSubview(collectVehicleImageView )
        collectionVehicleLabel = UILabel()
        collectionVehicleLabel.text = "收藏车辆"
        collectionVehicleLabel.textAlignment = .right
        collectionVehicleLabel.font = UIFont.systemFont(ofSize: 10)
        collectionVehicleLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        collectVehicleBtn.addSubview(collectionVehicleLabel)

        reportBtn = UIButton()
        self.addSubview(reportBtn)
        reportImageView = UIImageView()
        reportImageView.image = UIImage(named: "home_mark_baobiao")
        reportImageView.isUserInteractionEnabled = false
        reportBtn.addSubview(reportImageView)
        reportLabel = UILabel()
        reportLabel.text = "车辆报表"
        reportLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        reportLabel.font = UIFont.systemFont(ofSize: 12)
        reportBtn.addSubview(reportLabel)

        telBtn = UIButton()
        telBtn.backgroundColor = UIColor.clear
        self.addSubview(telBtn )
        telImageView = UIImageView()
        telImageView.image = UIImage(named: "home_mark_tel")
        telBtn.addSubview(telImageView)
        telLabel = UILabel()
        telLabel.text = "拨打电话"
        telLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        telLabel.font = UIFont.systemFont(ofSize: 12)
        telBtn.addSubview(telLabel)


        videoBtn = UIButton()
        self.addSubview(videoBtn)
        videoImageView = UIImageView()
        videoImageView.image = UIImage(named: "home_mark_video")
        videoBtn.addSubview(videoImageView)
        videoLabel = UILabel()
        videoLabel.text = "实时视频"
        videoLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        videoLabel.font = UIFont.systemFont(ofSize: 12)
        videoBtn.addSubview(videoLabel)


        chatBtn = UIButton()
        self.addSubview(chatBtn)
        chatImageView = UIImageView()
        chatImageView .image = UIImage(named: "home_mark_chat")
        chatBtn.addSubview(chatImageView)
        chatLabel = UILabel()
        chatLabel.text = "远程对话"
        chatLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        chatLabel.font = UIFont.systemFont(ofSize: 12)
        chatBtn.addSubview(chatLabel)

        lineView = UIView()
        lineView.backgroundColor = UIColor(hex: "#E6E9EE", alpha: 1.0)
        self.addSubview(lineView)
        
        topLineView = UIView()
        topLineView.layer.cornerRadius = 2
        topLineView.backgroundColor = UIColor(hex: "#E6E9EE", alpha: 1.0)
        self.addSubview(topLineView)
        
        bottomView = UIView()
        bottomView.backgroundColor = UIColor.white
        self.addSubview(bottomView)
        
        collectDriverBtn.addTarget(self, action: #selector(self.collectDriverEvent), for: .touchUpInside)
        collectVehicleBtn.addTarget(self, action: #selector(self.collectVehicleEvent), for: .touchUpInside)
        reportBtn.addTarget(self, action: #selector(self.reportEvent), for: .touchUpInside)
        telBtn.addTarget(self, action: #selector(self.telEvent), for: .touchUpInside)
        iconBtn.addTarget(self, action: #selector(self.driverEvent), for: .touchUpInside)
        
       
        
      }
    @objc   func driverEvent() {
        self.driverClick?()
    }
    
    @objc   func telEvent() {
        self.telClick?()
    }
    
    @objc  func reportEvent() {
        self.reportClick?()
    }
    
    
    @objc   func collectDriverEvent() {
        self.collectDriverBtnClick?()
        
    }
    
    @objc   func collectVehicleEvent() {
        self.collectVehicleBtnClick?()
        
    }
    
    
    func configRectCorner(view: UIView, corner: UIRectCorner, radii: CGSize) -> CALayer {
        
        let maskPath = UIBezierPath.init(roundedRect: view.bounds, byRoundingCorners: corner, cornerRadii: radii)
        let maskLayer = CAShapeLayer.init()
        maskLayer.frame = view.bounds
        maskLayer.path = maskPath.cgPath
        return maskLayer
    }
      
    override func updateConstraints() {
        super.updateConstraints()
        
        topLineView.snp.makeConstraints { (make) in
            make.centerX.equalTo(self)
            make.top.equalTo(self.snp.top).offset(15)
            make.size.equalTo(CGSize(width: 30, height: 4))
        }
        
        iconBtn.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(topLineView.snp.bottom).offset(15)
            make.size.equalTo(CGSize(width: 88, height: 114))
        }
        vehicleNameLabel.snp.makeConstraints { (make) in
            make.left.equalTo(iconBtn.snp.right).offset(8)
            make.top.equalTo(iconBtn.snp.top).offset(8)
        }
        
        orgNameLabel.snp.makeConstraints { (make) in
            make.left.equalTo(vehicleNameLabel.snp.right).offset(5)
            make.top.equalTo(iconBtn.snp.top).offset(12)
        }
        
        driverLabel.snp.makeConstraints { (make) in
            make.left.equalTo(iconBtn.snp.right).offset(8)
            make.top.equalTo(vehicleNameLabel.snp.bottom).offset(4)
        }
        
        speedLabel.snp.makeConstraints { (make) in
            make.top.equalTo(driverLabel.snp.bottom).offset(5)
            make.left.equalTo(iconBtn.snp.right).offset(8)
        }
        
        temperatureLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(speedLabel)
            make.left.equalTo(speedLabel.snp.right).offset(20)
        }
        
        
        locationLabel.snp.makeConstraints { (make) in
            make.top.equalTo(speedLabel.snp.bottom).offset(5)
            make.right.equalTo(self.snp.right).offset(-15)
            make.left.equalTo(iconBtn.snp.right).offset(8)
        }
        
        collectVehicleBtn.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp.right).offset(-15)
            make.top.equalTo(locationLabel.snp.bottom).offset(14)
            make.size.equalTo(CGSize(width: 70, height: 20))
        }
        
        collectionVehicleLabel.snp.makeConstraints { (make) in
            make.right.equalTo(collectVehicleBtn.snp.right).offset(0)
            make.centerY.equalTo(collectVehicleBtn)
        }
        
        collectVehicleImageView.snp.makeConstraints { (make) in
            make.right.equalTo(collectionVehicleLabel.snp.left).offset(-1)
            make.centerY.equalTo(collectVehicleBtn)
            make.size.equalTo(CGSize(width: 20, height: 20))
        }
        
        
        collectDriverBtn.snp.makeConstraints { (make) in
            make.right.equalTo(collectVehicleBtn.snp.left).offset(-10)
            make.top.equalTo(locationLabel.snp.bottom).offset(14)
            make.size.equalTo(CGSize(width: 70, height: 20))
        }
        
        collectDriverImageView.snp.makeConstraints { (make) in
            make.left.equalTo(collectDriverBtn.snp.left).offset(2)
            make.centerY.equalTo(collectDriverBtn)
        }
        
        collectionDriverLabel.snp.makeConstraints { (make) in
            make.left.equalTo(collectDriverImageView.snp.right).offset(2)
            make.centerY.equalTo(collectDriverBtn)
        }
        
        lineView.snp.makeConstraints { (make) in
            make.top.equalTo(collectVehicleBtn.snp.bottom).offset(14)
            make.left.equalTo(self.snp.left).offset(15)
            make.size.equalTo(CGSize(width: KW - 30, height: 1))
        }
        
        reportBtn.snp.makeConstraints { (make) in
            make.top.equalTo(lineView.snp.bottom).offset(14)
            make.left.equalTo(self.snp.left).offset(0)
            make.size.equalTo(CGSize(width: KW/4.0, height: 65))
            
        }
        
        
        reportImageView.snp.makeConstraints { (make) in
            make.top.equalTo(reportBtn.snp.top).offset(0)
            make.centerX.equalTo(reportBtn)
        }
        
        reportLabel.snp.makeConstraints { (make) in
            make.top.equalTo(reportImageView.snp.bottom).offset(5)
            make.centerX.equalTo(reportBtn)
        }
        
        
        telBtn.snp.makeConstraints { (make) in
            make.top.equalTo(lineView.snp.bottom).offset(14)
            make.left.equalTo(reportBtn.snp.right).offset(0)
            make.size.equalTo(CGSize(width: KW/4.0, height: 65))
            
        }
        
        telImageView.snp.makeConstraints { (make) in
            make.top.equalTo(reportBtn.snp.top).offset(0)
            make.centerX.equalTo(telBtn)
        }
        
        telLabel.snp.makeConstraints { (make) in
            make.top.equalTo(telImageView.snp.bottom).offset(5)
            make.centerX.equalTo(telBtn)
        }
        
        videoBtn.snp.makeConstraints { (make) in
            make.top.equalTo(lineView.snp.bottom).offset(14)
            make.left.equalTo(telBtn.snp.right).offset(0)
            make.size.equalTo(CGSize(width: KW/4.0, height: 65))
            
        }
        
        videoImageView.snp.makeConstraints { (make) in
            make.top.equalTo(videoBtn.snp.top).offset(0)
            make.centerX.equalTo(videoBtn)
        }
        
        videoLabel.snp.makeConstraints { (make) in
            make.top.equalTo(videoImageView.snp.bottom).offset(5)
            make.centerX.equalTo(videoBtn)
        }
        
        chatBtn.snp.makeConstraints { (make) in
            make.top.equalTo(lineView.snp.bottom).offset(14)
            make.left.equalTo(videoBtn.snp.right).offset(0)
            make.size.equalTo(CGSize(width: KW/4.0, height: 65))
            
        }
        
        
        chatImageView.snp.makeConstraints { (make) in
            make.top.equalTo(chatBtn.snp.top).offset(0)
            make.centerX.equalTo(chatBtn)
        }
        
        chatLabel.snp.makeConstraints { (make) in
            make.top.equalTo(chatImageView.snp.bottom).offset(5)
            make.centerX.equalTo(chatBtn)
        }
        
        bottomView.snp.makeConstraints { (make) in
            make.bottom.equalTo(self.snp.bottom).offset(0)
            make.left.equalTo(self.snp.left).offset(0)
            make.size.equalTo(CGSize(width: KW, height: 30))
        }
    
    }
    
    
    
    func configData(model:VehicleModel) {
        if model.driverUrl != nil && model.driverUrl != "" {
            let url = URL.init(string: model.driverUrl ?? "")
            iconBtn.sd_setImage(with: url, for: .normal, completed: nil)
           
        }
        vehicleNameLabel.text = model.plateLicenseNo ?? ""
        orgNameLabel.text = model.orgName ?? ""
        driverLabel.text = String(format: "驾驶员:%@", model.driverName ?? "未知驾驶员")
        speedLabel.text = String(format: "速度:%.2fkm/h", model.speed ?? 0.0)
       
        locationLabel.text = String(format: "当前位置:%@", model.address ?? "")
        
        if model.temperatureDeviceStatus != 0  && model.temperatureDeviceStatus != nil{
            if model.temperature != nil {
                temperatureLabel.text = String(format: "温度:%.2fºC", model.temperature ?? 0.0)
            }else {
                temperatureLabel.text = String(format: "温度:%@", "--")
            }
             temperatureLabel.isHidden = false
        }else {
            temperatureLabel.isHidden = true
        }
        
       
        
        
        if model.isVehFocused  == true{
            collectVehicleImageView.image = UIImage(named: "home_mark_wuxing_selected")
        }else {
            collectVehicleImageView.image = UIImage(named: "home_mark_wuxing")
        }
        
        if model.isDriverFocused  == true{
            collectDriverImageView.image = UIImage(named: "home_mark_xin_selected")
        }else {
            collectDriverImageView.image = UIImage(named: "home_mark_xin")
        }
        if model.driverId != nil {
            self.collectDriverImageView.isHidden = false
            self.collectionDriverLabel.isHidden = false
            self.collectDriverBtn.isHidden = false
            
        }else {
            self.collectDriverImageView.isHidden = true
            self.collectionDriverLabel.isHidden = true
            self.collectDriverBtn.isHidden = true
            
        }
        
        
        
       
        
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }



}
