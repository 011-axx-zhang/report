//
//  homeTopSearchView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/6.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class HomeTopSearchView: UIView {
     var searchBtn:UIButton!
     var iconBtn:UIButton!
     var titleLabel:UILabel!
     var dotView:UIView!
     @objc var searchEvent:(()->Void)?
     @objc var myIconEvent:(()->Void)?

     override init(frame: CGRect) {
         super.init(frame: frame)
         self.backgroundColor = UIColor.white
         self.createUI()
         updateConstraints()
     }
     
     private func createUI() {
        searchBtn = UIButton()
        searchBtn.addTarget(self, action: #selector(self.searchClick), for: .touchUpInside)
        self.addSubview(searchBtn)
        iconBtn = UIButton()
        iconBtn.setImage(UIImage(named: "home_touxiang"), for: .normal)
        iconBtn.addTarget(self, action: #selector(self.iconEvent), for: .touchUpInside)
        iconBtn.contentMode = .center
        self.addSubview(iconBtn)
        
        titleLabel = UILabel()
        titleLabel.text = "搜索车牌号/驾驶员姓名"
        titleLabel.textColor = UIColor(hex: "#9395AC",alpha: 1.0)
        titleLabel.font = UIFont.systemFont(ofSize: 15)
        searchBtn.addSubview(titleLabel)
        
        dotView = UIView()
        dotView.backgroundColor = UIColor.red
        dotView.layer.cornerRadius =  4
        dotView.isHidden = true
        dotView.layer.masksToBounds = true
        self.addSubview(dotView)
      
     }
    
    @objc  func iconEvent()  {
        if self.myIconEvent != nil {
            self.myIconEvent?()
        }
        
        
    }
    
    @objc func searchClick() {
        if self.searchEvent != nil {
            self.searchEvent?()
        }
        
    }
    
    
    
    
    
     override func updateConstraints() {
         super.updateConstraints()
       
         iconBtn.snp.makeConstraints { (make) in
             make.left.equalTo(self.snp.left).offset(14)
             make.top.equalTo(self.snp.top).offset(6)
             make.size.equalTo(CGSize(width: 30, height: 30))
         }
         
         dotView.snp.makeConstraints { (make) in
             make.left.equalTo(iconBtn.snp.right).offset(-2)
             make.top.equalTo(iconBtn.snp.top).offset(-1)
             make.size.equalTo(CGSize(width: 8, height: 8))
         }
         
         searchBtn.snp.makeConstraints { (make) in
             make.left.equalTo(iconBtn.snp.right).offset(10)
             make.right.equalTo(self.snp.right).offset(0)
             make.top.equalTo(self.snp.top).offset(0)
         }
         titleLabel.snp.makeConstraints { (make) in
             make.left.equalTo(searchBtn.snp.left).offset(0)
             make.centerY.equalTo(iconBtn)
         }
         
     }
     
     required init?(coder aDecoder: NSCoder) {
         fatalError("init(coder:) has not been implemented")
     }


}
