//
//  HomeRightView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/6.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import SnapKit

class HomeRightView: UIView {

    var yunYingView:UIView!
    var filterView:UIView!
    var refreshView:UIView!
    var yunYingImageView:UIImageView!
    var filterImageView:UIImageView!
    var refreshImageView:UIImageView!
    var yunYingLabel:UILabel!
    
    @objc var yunYingEvent:(()->Void)?
    @objc var filterEvent:(()->Void)?
    @objc var refreshEvent:(()->Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.clear
        self.createUI()
        updateConstraints()
    }
    
    private func createUI() {
        yunYingView = UIView()
        yunYingView.backgroundColor = UIColor.white
        self.addSubview(yunYingView)
        filterView = UIView()
        filterView.backgroundColor = UIColor.white
        self.addSubview(filterView)
        refreshView = UIView()
        refreshView.backgroundColor = UIColor.white
        self.addSubview(refreshView)
        yunYingImageView = UIImageView()
        yunYingImageView.image = UIImage(named: "home_yunying")
        yunYingImageView.contentMode = .center
        yunYingView.addSubview(yunYingImageView)
        filterImageView = UIImageView()
        filterImageView.image = UIImage(named: "home_shaixuan")
        filterImageView.contentMode = .center
        filterView.addSubview(filterImageView)
        refreshImageView = UIImageView()
        refreshImageView.image = UIImage(named: "home_refresh")
        refreshImageView.contentMode = .center
        refreshView.addSubview(refreshImageView)
        yunYingLabel = UILabel()
        yunYingLabel.text = "运营"
        yunYingLabel.font = UIFont.systemFont(ofSize: 9)
        yunYingLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        yunYingView.addSubview(yunYingLabel)
        
        yunYingView.addSingleClick(target: self, action:#selector(self.yunYingClick))
        filterView.addSingleClick(target: self, action:#selector(self.filterClick))
        refreshView.addSingleClick(target: self, action:#selector(self.refreshClick))
        
    }
    
    @objc  func yunYingClick()  {
        if self.yunYingEvent != nil {
            self.yunYingEvent?()
        }
        
    }
    
    @objc func filterClick()  {
        if self.filterEvent != nil {
            self.filterEvent?()
        }
    }
    
    
    @objc  func refreshClick()  {
        if self.refreshEvent != nil {
            self.refreshEvent?()
        }
    }
    
    
    
    
    
    override func updateConstraints() {
        super.updateConstraints()
        
        yunYingView.snp.makeConstraints { (make ) in
            make.top.equalTo(self.snp.top)
            make.right.equalToSuperview()
            make.size.equalTo(CGSize(width: 40, height: 45))
        }
        
        filterView.snp.makeConstraints { (make ) in
            make.top.equalTo(yunYingView.snp.bottom).offset(12)
            make.right.equalToSuperview()
            make.size.equalTo(CGSize(width: 40, height: 40))
        }
        refreshView.snp.makeConstraints { (make ) in
            make.top.equalTo(filterView.snp.bottom).offset(5)
            make.right.equalTo(self.snp.right)
            make.size.equalTo(CGSize(width: 40, height: 40))
        }
        
        
        yunYingImageView.snp.makeConstraints { (make) in
            make.top.equalTo(yunYingView.snp.top).offset(5)
            make.centerX.equalTo(yunYingView)
            make.size.equalTo(CGSize(width: 26, height: 26))
        }
        
        yunYingLabel.snp.makeConstraints { (make) in
            make.top.equalTo(yunYingImageView.snp.bottom).offset(-1)
            make.centerX.equalTo(yunYingView)
        }
        
        filterImageView.snp.makeConstraints { (make) in
            make.center.equalTo(filterView)
            make.size.equalTo(CGSize(width: 26, height: 26))
        }
        
        refreshImageView.snp.makeConstraints { (make) in
            make.center.equalTo(refreshView)
            make.size.equalTo(CGSize(width: 26, height: 26))
        }
        
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
