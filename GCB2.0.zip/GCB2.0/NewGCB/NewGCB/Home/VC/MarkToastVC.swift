//
//  MarkToastVC.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/6.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class MarkToastVC: UIViewController {
    
    var markToastView:MarkToastView!
    var model:VehicleModel!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.clear
        self.createMarkToastView()
    }
    
    func createMarkToastView()  {
        markToastView = MarkToastView()
        markToastView.frame = CGRect(x: 0, y: KH - 270, width: KW, height: 270)
        self.view.addSubview(markToastView)
        markToastView.layer.mask = self.configRectCorner(view: markToastView, corner: [.topLeft, .topRight], radii: CGSize(width: 15, height:15))
        markToastView.configData(model: self.model)
        markToastView.collectDriverBtnClick = {
            
        }
        
        markToastView.collectVehicleBtnClick = {
            
        }
        
    }
    
    func configRectCorner(view: UIView, corner: UIRectCorner, radii: CGSize) -> CALayer {
        
        let maskPath = UIBezierPath.init(roundedRect: view.bounds, byRoundingCorners: corner, cornerRadii: radii)
        let maskLayer = CAShapeLayer.init()
        maskLayer.frame = view.bounds
        maskLayer.path = maskPath.cgPath
        return maskLayer
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        self.dismiss(animated: true, completion: nil)
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
