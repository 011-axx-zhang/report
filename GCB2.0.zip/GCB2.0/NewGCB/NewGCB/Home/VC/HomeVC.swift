//
//  HomeVC.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/4.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON
import SwiftyJSON


class HomeVC: UIViewController,MAMapViewDelegate ,AMapSearchDelegate{
    var bottomView:HomeBottomView!
    var homeTopSearchView:HomeTopSearchView!
    var rightView:HomeRightView!
    var isRefreshing=false
    //四叉树
    var coordinateQuadTree:CoordinateQuadTree=CoordinateQuadTree()
    var shouldRegionChangeReCalculate=false
    var isClustering=false//是否正在聚合运算
    var isBuildQuadTree=false//是否正在构建四叉树
    var mapview:MAMapView!
    var totalData:[VehicleModel] = []
    var isRunning:Bool = true
    var orgId:Int64?
    var vehGroupId:Int64?
    var focusDriver:Bool?
    var focusVeh:Bool?
    var key:String = ""
    var markToastView:MarkToastView?
  
    
//    var visibleRect :MAMapRect!
//    var zoomScale:Double!
//    var dis :Double!
//    var zoomLevel :Double!
    //
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        self.setDefaultValue()
        self.createMap()
        self.createBottomView()
        self.createTopSearchView()
        self.createRightView()
        NotificationCenter.default.addObserver(self, selector: #selector(self.updateApp), name: NSNotification.Name.init(rawValue: "version") , object: nil)
        
        
    }
    
    func setDefaultValue()  {
        let defaults = UserDefaults.standard
        if defaults.value(forKey: "orgId") != nil {
            self.orgId = defaults.value(forKey: "orgId") as? Int64
        }
        if defaults.value(forKey: "groupId") != nil {
            self.vehGroupId = defaults.value(forKey: "groupId") as? Int64
        }
        if defaults.value(forKey: "focusDriver") != nil {
            self.focusDriver = defaults.value(forKey: "focusDriver") as? Bool
        }
        
        if defaults.value(forKey: "focusVeh") != nil {
            self.focusVeh = defaults.value(forKey: "focusVeh") as? Bool
        }
        
    }
    
    
    
    
    
    @objc  func updateApp()  {
        let userDefault = UserDefaults.standard
        var isForce:Int?
        var version:Int?
        
        if userDefault.value(forKey: keyisForce) != nil {
            isForce = userDefault.value(forKey: keyisForce) as? Int
        }else {
            return
        }
        
        if userDefault.value(forKey:keyVersion) != nil  {
            version = userDefault.value(forKey:keyVersion) as? Int
        }else {
            return
        }
        let infoDictionary = Bundle.main.infoDictionary
        let appBuild = infoDictionary?["CFBundleVersion"] as! String
        let build = Int(appBuild)
        
        if version! > build ?? 0{
            
            if isForce == 1 {
                showCallAlert(msg: "是否更新版本")
            }else {
                showAlert(msg: "是否更新版本")
            }
        }
        
    }
         
    

    func createTopSearchView() {
        homeTopSearchView = HomeTopSearchView()
        homeTopSearchView.layer.cornerRadius = 5
        homeTopSearchView.layer.shadowOpacity = 0.2
        homeTopSearchView.layer.shadowColor = UIColor(hex: "#000000",alpha: 1.0)?.cgColor
        homeTopSearchView.layer.shadowOffset =  CGSize(width: 0, height: 2)
        homeTopSearchView.layer.shadowRadius = 10
        self.view.addSubview(homeTopSearchView)
        homeTopSearchView.snp.makeConstraints { (make) in
            make.left.equalTo(self.view.snp.left).offset(12)
            make.right.equalTo(self.view.snp.right).offset(-12)
            make.top.equalTo(self.view.snp.top).offset(statusHeight + 4)
            make.height.equalTo(40)
        }
        homeTopSearchView.myIconEvent = {
            self.toMyVC()
        }
        homeTopSearchView.searchEvent = {
            let vehicleVC = VehicleVC()
            self.navigationController?.pushViewController(vehicleVC  , animated: true)
        }
    }
    
    
    func toMyVC()  {
        let vc = MyVC()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    func createBottomView() {
        bottomView = HomeBottomView()
        bottomView.notiClick = {
            self.navigationController?.pushViewController(NotificationViewController(), animated: true)
        }
        bottomView.guanCheClick = {
            let vc  = VehicleManagerVC()
            vc.orgId = self.orgId
            vc.vehGroupId = self.vehGroupId
            self.navigationController?.pushViewController(vc, animated: true)
            
        }
        bottomView.baoBiaoClick = {
            let vc  = EnterpriseReportVC()
            self.navigationController?.pushViewController(vc, animated: true)
            
        }
        self.view.addSubview(bottomView)
        bottomView.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(self.view.snp.bottom).offset( -bottomHeight - 34)
            make.size.equalTo(CGSize(width: 246, height: 84))
        }
        
    }
    
    
    
    func createRightView()  {
        rightView = HomeRightView()
        self.view.addSubview(rightView)
        rightView.snp.makeConstraints { (make) in
            make.right.equalTo(self.view.snp.right).offset(-12)
            make.top.equalTo(homeTopSearchView.snp.bottom).offset(70)
            make.size.equalTo(CGSize(width: 43, height: 150))
        }
        
        rightView.yunYingEvent =  {
            self.isRunning = !self.isRunning
            if self.isRunning == true {
                self.rightView.yunYingLabel.text = "运营"
            }else {
                self.rightView.yunYingLabel.text = "未运营"
            }
            self.requestVehicle()
        }
        rightView.filterEvent = {
            let vc = FilterVC()
            vc.passValue = { (index,id) in
                self.handleFilterValue(index: index, id: id)
            }
            
            self.gy_showSide(configuration: { (config) in
                config.direction = .right
                config.animationType = .translationMask
            }, viewController: vc)
              
        }
        rightView.refreshEvent = {
            self.requestVehicle()
        }
    }
    
    
    func handleFilterValue(index:Int,id:Int64)  {
        
        if index == 1 {
            orgId = id
            vehGroupId = nil
            focusDriver = nil
            focusVeh = nil
        }else if index == 2 {
            vehGroupId = id
            orgId = nil
            focusDriver = nil
            focusVeh = nil
        }else if index == 3 {
            orgId = nil
            vehGroupId = nil
            focusDriver = true
            focusVeh = nil
        } else if index == 4{
            orgId = nil
            vehGroupId = nil
            focusDriver = nil
            focusVeh = true
        }else if index == 0 {
            orgId = nil
            vehGroupId = nil
            focusDriver = nil
            focusVeh = nil
        }
        let defaults = UserDefaults.standard
        defaults.set(orgId, forKey: "orgId")
        defaults.set(vehGroupId, forKey: "groupId")
        defaults.set(focusDriver, forKey: "focusDriver")
        defaults.set(focusVeh, forKey: "focusVeh")
        self.requestVehicle()
    }
    
    func requestVehicle()  {
        if self.isRefreshing || self.isBuildQuadTree || self.isClustering{
            self.view.makeToastMid(message: "正在刷新")
            return
        }
        self.isRefreshing = true
        var paramDic:Dictionary<String,Any> = [:]
        
        if orgId != nil {
            paramDic["orgId"] = self.orgId
        }else if self.vehGroupId != nil {
            paramDic["vehGroupId"] = self.vehGroupId
        }else if self.focusDriver != nil {
             paramDic["focusDriver"] = self.focusDriver
        }else if self.focusVeh != nil {
            paramDic["focusVeh"] = self.focusVeh
        }
         paramDic["isRunning"] = self.isRunning
        
        
        
        HttpRequest.loadData(target: InterfaceAPI.homeVehicle(param: paramDic), needCache: false, cache: nil, success: { (datas) in
             self.isRefreshing=false
            // swiftJson + handyJson 解析方法
            let json = JSON(datas)
            let data = JSONDeserializer<VehicleModel>.deserializeModelArrayFrom(json: json["data"].description)
            
            if data!.count == 0 {
                self.view.makeToastMid(message: "无数据")
                self.totalData = []
                self.coordinateQuadTree.clean()
                self.mapview.removeAnnotations(self.mapview.annotations)
              
            }else {
                self.totalData = data as! [VehicleModel]
                self.totalData  = self.totalData.filter({ (item) -> Bool in
                    item.latlng != nil
                })
                if self.totalData.count != 0 {
                    self.setVisibleMapRect(dataArr: self.totalData)
                    self.refreshCluster()
                }else {
                    self.coordinateQuadTree.clean()
                    self.mapview.removeAnnotations(self.mapview.annotations)
                }
               
            }
           
            
        }) { (stateCode ,message) in
            self.isRefreshing=false
            self.view.makeToastMid(message: message)
        }
        
    }
    
 
    
    func createMap()  {
        mapview=MAMapView(frame: CGRect(x: 0, y: 0, width: KW, height: KH))
        mapview.delegate = self
        self.view.addSubview(mapview)
        mapview.isRotateEnabled=false
        mapview.isRotateCameraEnabled=false
        mapview.showsCompass = false
    }
    
    deinit {
        coordinateQuadTree.clean()
    }
    //同步代码块
    func synchronized(lock: AnyObject, closure: () -> ()) {
        objc_sync_enter(lock)
        closure()
        objc_sync_exit(lock)
    }
    //打印log
    private func logQuad(msg:String){
        //  log.info("quad thread:\(String(describing: Thread.current.isMainThread)) msg:\(msg)")
    }
    
    
    //刷新四叉树
    func refreshCluster()  {
        logQuad(msg: "refresh begin")
        let aMapView=(self.mapview)!
        let visibleRect = aMapView.visibleMapRect
        let zoomScale = Double(aMapView.bounds.size.width) / visibleRect.size.width
        let zoomLevel = Double(aMapView.zoomLevel)
        synchronized(lock: self) { [weak self] in
            self?.mapview.removeAnnotations(self?.mapview.annotations)
            DispatchQueue.global(qos: .default).async(execute: { [weak self] in
                self?.isBuildQuadTree=true
                self?.coordinateQuadTree.build(withPOIs: self?.totalData)
                self?.logQuad(msg: "build over")
                self?.isBuildQuadTree=false
                self?.addAnnotations(toMapView: aMapView, visibleRect: visibleRect, zoomScale: zoomScale, zoomLevel: zoomLevel)
            })
        }
    }
    //添加marker
    func addAnnotations(toMapView aMapView: MAMapView,visibleRect:MAMapRect,zoomScale:Double,zoomLevel:Double) {
        
       
        synchronized(lock: self) { [weak self] in
            guard (self?.coordinateQuadTree.root != nil) || !isClustering else {
                NSLog("tree is not ready.")
                return
            }
            
            self?.isClustering = true
            self?.logQuad(msg: "add anno")
            
            NSLog("z%f", zoomLevel)
            NSLog("s%f", zoomScale)
            
            DispatchQueue.global(qos: .default).async(execute: { [weak self] in
                self?.logQuad(msg: "clustered begin")
               // let annotations = self?.coordinateQuadTree.clusteredAnnotations(within: visibleRect, withDistance:dis)
                let annotations = self?.coordinateQuadTree.clusteredAnnotations(within: visibleRect, withZoomScale: zoomScale, andZoomLevel: zoomLevel)

                self?.logQuad(msg: "clustered over")
                self?.updateMapViewAnnotations(annotations: annotations as! Array<ClusterAnnotation>)
            })
        }
    }
    //更新markers
    func updateMapViewAnnotations(annotations: Array<ClusterAnnotation>) {
        self.logQuad(msg: "update anno begin ")
        /* 用户滑动时，保留仍然可用的标注，去除屏幕外标注，添加新增区域的标注 */
        let before = NSMutableSet(array: mapview.annotations)
        before.remove(self.mapview.userLocation)
        let after: Set<NSObject> = NSSet(array: annotations) as Set<NSObject>
        /* 保留仍然位于屏幕内的annotation. */
        var toKeep: Set<NSObject> = NSMutableSet(set: before) as Set<NSObject>
        toKeep = toKeep.intersection(after)
        /* 需要添加的annotation. */
        let toAdd = NSMutableSet(set: after)
        toAdd.minus(toKeep)
        /* 删除位于屏幕外的annotation. */
        let toRemove = NSMutableSet(set: before)
        toRemove.minus(after)
        DispatchQueue.main.async(execute: { [weak self] () -> Void in
            self?.mapview.addAnnotations(toAdd.allObjects)
            self?.mapview.removeAnnotations(toRemove.allObjects)
            self?.isClustering=false
        })
    }
    /// 根据传入的annotation来展现：保持中心点不变的情况下，展示所有传入annotation
    ///
    /// - Parameters:
    ///   - annotations: annotation
    ///   - insets: 填充框，用于让annotation不会靠在地图边缘显示
    ///   - mapView: 地图view
    func showsAnnotations(_ annotations:Array<MAPointAnnotation>, edgePadding insets:UIEdgeInsets, andMapView mapView:MAMapView!) {
        var rect:MAMapRect = MAMapRectZero
        
        for annotation:MAPointAnnotation in annotations {
            let diagonalPoint:CLLocationCoordinate2D = CLLocationCoordinate2DMake(mapView.centerCoordinate.latitude - (annotation.coordinate.latitude - mapView.centerCoordinate.latitude),mapView.centerCoordinate.longitude - (annotation.coordinate.longitude - mapView.centerCoordinate.longitude))
            
            let annotationMapPoint: MAMapPoint = MAMapPointForCoordinate(annotation.coordinate)
            let diagonalPointMapPoint: MAMapPoint = MAMapPointForCoordinate(diagonalPoint)
            
            let annotationRect:MAMapRect = MAMapRectMake(min(annotationMapPoint.x, diagonalPointMapPoint.x), min(annotationMapPoint.y, diagonalPointMapPoint.y), abs(annotationMapPoint.x - diagonalPointMapPoint.x), abs(annotationMapPoint.y - diagonalPointMapPoint.y));
            
            rect = MAMapRectUnion(rect, annotationRect)
        }
        
        mapView.setVisibleMapRect(rect, edgePadding: insets, animated: true)
    }
    
    func mapView(_ mapView: MAMapView!, mapDidZoomByUser wasUserAction: Bool) {
        if wasUserAction {
            
          
            let aMapView=(mapView)!
            let visibleRect = aMapView.visibleMapRect
            var zoomScale = Double(aMapView.bounds.size.width) / visibleRect.size.width
            var zoomLevel = Double(aMapView.zoomLevel)
            
            if zoomLevel == 3.0 {
                zoomLevel = 4.071744
                zoomScale = 0.000013
                self.addAnnotations(toMapView: aMapView, visibleRect: visibleRect, zoomScale: zoomScale, zoomLevel: zoomLevel)
            }else {
                self.addAnnotations(toMapView: aMapView, visibleRect: visibleRect, zoomScale: zoomScale, zoomLevel: zoomLevel)
            }
            
            
            
        }
    }
    func mapView(_ mapView: MAMapView!, mapDidMoveByUser wasUserAction: Bool) {
        if wasUserAction {
            let aMapView=(mapView)!
            let visibleRect = aMapView.visibleMapRect
            var zoomScale = Double(aMapView.bounds.size.width) / visibleRect.size.width
            var zoomLevel = Double(aMapView.zoomLevel)
            self.addAnnotations(toMapView: aMapView, visibleRect: visibleRect, zoomScale: zoomScale, zoomLevel: zoomLevel)
            if zoomLevel == 3.0 {
                zoomLevel = 4.071744
                zoomScale = 0.000013
                self.addAnnotations(toMapView: aMapView, visibleRect: visibleRect, zoomScale: zoomScale, zoomLevel: zoomLevel)
            }else {
                self.addAnnotations(toMapView: aMapView, visibleRect: visibleRect, zoomScale: zoomScale, zoomLevel: zoomLevel)
            }
        }
    }
    
    func mapView(_ mapView: MAMapView!, viewFor annotation: MAAnnotation!) -> MAAnnotationView! {
        if annotation is ClusterAnnotation {
            let pointReuseIndetifier="pointReuseIndetifier"
            var annotationView=mapView.dequeueReusableAnnotationView(withIdentifier: pointReuseIndetifier) as? ClusterAnnotationView
            if annotationView==nil{
                annotationView=ClusterAnnotationView(annotation: annotation, reuseIdentifier: pointReuseIndetifier)
            }
            annotationView?.annotation=annotation
            annotationView?.count=UInt((annotation as? ClusterAnnotation)?.count ?? 0)
            annotationView?.centerOffset=CGPoint(x: 0, y: -20)
            return annotationView
        }
        return nil
    }
    
    //MARK: - mapview delegate
    func mapView(_ mapView: MAMapView!, didSelect view: MAAnnotationView!) {
        mapView.deselectAnnotation(view.annotation, animated: true)
        guard let vehs  = (view.annotation as? ClusterAnnotation)?.pois as? [VehicleModel] else {
            self.view.makeToastMid(message:"未选择车辆")
            return
        }
        if vehs.count == 1 {
            self.markToastHandle(model:vehs[0])
        }else {
            self.setVisibleMapRect(dataArr: vehs)
            self.refreshCluster()
        }
        
    }
    
    func setVisibleMapRect(dataArr:Array<VehicleModel>)  {
        let ary  = dataArr.map({ (model ) -> CLLocationCoordinate2D in
            return  CLLocationCoordinate2D(latitude: model.latlng!.lat, longitude: model.latlng!.lng)
        })
        var annotations: Array<MAPointAnnotation> = []
        for (idx, coor) in ary.enumerated() {
            let anno = MAPointAnnotation()
            anno.coordinate = coor
            anno.title = " "
            annotations.append(anno)
        }
        self.mapview.showAnnotations(annotations, edgePadding: UIEdgeInsets(top: 60, left: 30, bottom: 40, right: 70), animated: false)
        
    }
    
    
    
    
    
    func markToastHandle(model:VehicleModel)  {
        self.view.addSubview(self.transparentView)
        markToastView = MarkToastView()
        self.markToastView?.layer.cornerRadius = 10
        markToastView?.backgroundColor = UIColor.white
        markToastView!.frame = CGRect(x: 0, y:KH, width: KW, height: 0)
        self.view.addSubview(markToastView!)
        UIView.animate(withDuration: 0.2, animations: {
        self.markToastView!.frame = CGRect(x: 0, y: KH - 300, width: KW, height: 300)
//           self.markToastView!.layer.mask = self.configRectCorner(view: self.markToastView!, corner: [.topLeft, .topRight], radii: CGSize(width: 10, height:10))
        }) { (finished) in
           
        }
  
        self.markToastView!.layer.shadowColor = UIColor.black.cgColor
        self.markToastView!.layer.masksToBounds = false
        self.markToastView!.layer.shadowOffset = CGSize(width: 0, height: -8)
        self.markToastView!.layer.shadowOpacity = 0.14
        self.markToastView!.layer.shadowRadius = 5
        
        markToastView!.configData(model: model)
        markToastView!.collectDriverBtnClick = {
            self.focusDriverRequest(model: model)
        }
        markToastView!.collectVehicleBtnClick = {
            self.focusVehRequest(model: model)
        }
        markToastView!.reportClick = {
            let vc = VehicleReportVC()
            vc.vehId = model.vehId!
            self.navigationController?.pushViewController(vc, animated: true)
        }
        markToastView!.telClick = {
            if model.driverPhone != nil && model.driverPhone != "" {
                UIApplication.shared.openURL(NSURL.init(string: "tel:" + model.driverPhone!)! as URL)
            }else {
                self.view.makeToastMid(message: "驾驶员身份识别失败,无法拨打电话")
            }
        }
        markToastView!.driverClick = {
            if model.driverId != nil {
                let vc = DriverDetailsViewController()
                vc.driverID = model.driverId!
                self.navigationController?.pushViewController(vc, animated: true)
            }else {
                self.view.makeToastMid(message: "驾驶员身份识别失败，无法查看驾驶员档案")
            }
            
        }
        
        let swip = UISwipeGestureRecognizer(target: self, action: #selector(self.markEdgePanEvent))
        swip.direction = .down
        self.markToastView?.addGestureRecognizer(swip)
        
    }
    
    
    @objc func markEdgePanEvent()  {
       self.tapEvent()
    }
    
    
    func configRectCorner(view: UIView, corner: UIRectCorner, radii: CGSize) -> CALayer {
           
        let maskPath = UIBezierPath.init(roundedRect: view.bounds, byRoundingCorners: corner, cornerRadii: radii)
        let maskLayer = CAShapeLayer.init()
        maskLayer.frame = view.bounds
        maskLayer.path = maskPath.cgPath
        return maskLayer
       }
    
    lazy var transparentView:UIView = {
          let transparentView = UIView()
          transparentView.backgroundColor = UIColor(red: 51.0/255.0, green: 51.0/255.0, blue: 51.0/255.0, alpha: 0.5)
        //  transparentView.backgroundColor = UIColor.clear
          transparentView.frame = CGRect(x: 0, y: 0, width: KW, height: KH )
          transparentView.isUserInteractionEnabled = true
          transparentView.addSingleClick(target: self, action: #selector(self.tapEvent))
          return transparentView
      }()
    
    
    @objc   func tapEvent() {
        if self.markToastView !=  nil {
            UIView.animate(withDuration: 0.3, animations: {
                self.transparentView.backgroundColor = UIColor(red: 51.0/255.0, green: 51.0/255.0, blue: 51.0/255.0, alpha: 0.0)
                self.markToastView!.frame = CGRect(x: 0, y:KH, width: KW, height: 300)
            }) { (finished) in
                self.transparentView.backgroundColor = UIColor(red: 51.0/255.0, green: 51.0/255.0, blue: 51.0/255.0, alpha: 0.5)
                self.markToastView?.removeFromSuperview()
                self.transparentView.removeFromSuperview()
            }
            
        }
    }
    
    
    
    func focusDriverRequest(model:VehicleModel) {
        if model.driverId != nil {
            var flag = true
            if model.isDriverFocused != nil {
                flag = !(model.isDriverFocused!)
            }
            let param = ["driverId":model.driverId!,"isFocused":flag] as [String : Any]
            HttpRequest.loadData(target: InterfaceAPI.focusDriver(param: param), needCache: false, cache: nil, success: { (datas) in
                if model.isDriverFocused != nil {
                    model.isDriverFocused = !(model.isDriverFocused!)
                }else {
                    model.isDriverFocused = true
                }
                self.markToastView!.configData(model: model)
                
                if model.isDriverFocused! {
                   self.view.makeToastMid(message: "已关注该驾驶员")
                }else {
                   self.view.makeToastMid(message: "已取消关注该驾驶员")
                }
                
                
            }) { (stateCode ,message) in
              self.view.makeToastMid(message: message)
            }
        }else {
            self.view.makeToastMid(message: "驾驶员身份识别失败，无法查看驾驶员档案")
        }
       
    }
    
    func focusVehRequest(model:VehicleModel)  {
        
        var flag = true
        if model.isVehFocused != nil {
            flag = !(model.isVehFocused!)
        }
        
        let param = ["vehId": model.vehId!,"isFocused":flag] as [String : Any]
        HttpRequest.loadData(target: InterfaceAPI.focusVeh(param: param), needCache: false, cache: nil, success: { (datas) in
           
            if model.isVehFocused != nil {
                model.isVehFocused = !(model.isVehFocused!)
            }else {
                model.isVehFocused = true
            }
            self.markToastView!.configData(model: model)
            
            if model.isVehFocused! {
               self.view.makeToastMid(message: "已收藏该车辆")
            }else {
               self.view.makeToastMid(message: "已取消收藏该车辆")
            }
            
        }) { (stateCode ,message) in
            
        }
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        self.setDefaultValue()
        self.requestVehicle()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        
        
    }
    
    
     func showAlert(msg:String)  {
         
         let alertController = UIAlertController(title: "",
                                                 message:msg, preferredStyle: .alert)
         let messageFont = UIFont.systemFont(ofSize: 15)
         let messageAttribute = NSMutableAttributedString.init(string:alertController.message!)
           messageAttribute.addAttributes([NSAttributedString.Key.font:messageFont],
                                        range:NSMakeRange(0, (alertController.message?.count)!))
         alertController.setValue(messageAttribute, forKey: "attributedMessage")
           alertController.view.tintColor = UIColor(hex: "#0FA59E", alpha: 1.0)!
         let cancelAction = UIAlertAction(title: "取消", style: .cancel, handler: nil)
         let okAction = UIAlertAction(title: "确定", style: .default, handler: {
             action in
             UIApplication.shared.openURL(NSURL.init(string: "https://itunes.apple.com/cn/app/id1495281943") as! URL)
             
         })
         alertController.addAction(cancelAction)
         alertController.addAction(okAction)
         self.present(alertController, animated: true, completion: nil)
     }
       
       
       func showCallAlert(msg:String)  {
           
           
           let alertController = UIAlertController(title: "",
                                                   message:msg, preferredStyle: .alert)
           let messageFont = UIFont.systemFont(ofSize: 15)
           let messageAttribute = NSMutableAttributedString.init(string:alertController.message!)
           messageAttribute.addAttributes([NSAttributedString.Key.font:messageFont],
                                          range:NSMakeRange(0, (alertController.message?.count)!))
           alertController.setValue(messageAttribute, forKey: "attributedMessage")
           alertController.view.tintColor = UIColor(hex: "#0FA59E", alpha: 1.0)!
           
           
           let okAction = UIAlertAction(title: "确定", style: .default, handler: {
               action in
            UIApplication.shared.openURL(NSURL.init(string: "https://itunes.apple.com/cn/app/id1495281943") as! URL)
               
           })
           
           alertController.addAction(okAction)
           self.present(alertController, animated: true, completion: nil)
       }
    
    
  
     
    
    
}

