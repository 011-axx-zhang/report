//
//  CVehicleModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/8.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class CVehicleModel: Codable {
    
    
      var code: StrInt
      var data: [DMRankingList]?
      var msg:String
      
     
      
      struct DMRankingList: Codable {
          var vin:String!
          var angle:Float?
          var plateLicenseNo:String!
          var modelName:String?
          var useType:String?
          var company:String?
          var address:String?
      }
    

}
