//
//  LatestDriverModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/26.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class LatestDriverModel: NSObject,HandyJSON {
    
    var driverId:Int64?
    var driverName:String?
    var licenseUrl:String?

    override required init() {
        super.init()
    }
    
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.driverId<--"driverId"
        mapper<<<self.driverName<--"driverName"
        mapper<<<self.licenseUrl<--"licenseUrl"
    }
}
