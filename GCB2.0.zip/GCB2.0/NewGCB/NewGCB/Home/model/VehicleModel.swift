//
//  VehicleModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/5.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

@objc
class VehicleModel: NSObject,HandyJSON,NSCopying,PosLatLng{

    func getLat() -> Double {
        return self.latlng?.lat ?? 0
    }
    func getLng() -> Double {
        return self.latlng?.lng ?? 0
    }
    var vehId:Int64! //车辆id
    var vin:String!
    var plateLicenseNo:String!  //车牌号
    var modelName:String?  //车型
    var isVehFocused:Bool?   //车辆是否被关注
    var isDriverFocused:Bool?  //司机是否被关注
    var orgName:String?   //组织名称
    @objc
    var isRunning:Int = 0 //是否运营中
    var latlng:MyLatlng?  //经纬度
    var address:String?
     @objc
    var level:Float = 0// 风险等级
    @objc
    var speed: Float = 0
    @objc
    var status: Int = 0
    var isDriving:Bool? // 是否正在行驶
    var temperature:Float? //温度
    var driverId:Int64?
    var driverUrl:String?
    var driverName:String?
    var driverPhone:String?
    var latestDate:String?
    var lat:Double?
    var lng:Double?
    var milsToday:Double?
    var temperatureDeviceStatus:Int?
    
    
    var latestDrivers:[LatestDriverModel]?
     var time:String?

    override required init() {
        super.init()
    }
    
    func copy(with zone: NSZone? = nil) -> Any {
        let veh = VehicleModel.init()
        veh.vehId = self.vehId
        veh.plateLicenseNo=self.plateLicenseNo
        veh.modelName=self.modelName
        veh.isVehFocused=self.isVehFocused
        veh.isDriverFocused=self.isDriverFocused
        veh.orgName=self.orgName
        veh.isRunning=self.isRunning
        veh.temperature=self.temperature
        veh.latlng=self.latlng?.copy() as? MyLatlng
        veh.speed=self.speed
        veh.address=self.address
        veh.level=self.level
        veh.isDriving=self.isDriving
        veh.address = self.address
        veh.vin = self.vin
        veh.driverId = self.driverId
        veh.driverUrl = self.driverUrl
        veh.driverName = self.driverName
        veh.driverPhone = self.driverPhone
        veh.latestDate = self.latestDate
        veh.latestDrivers = self.latestDrivers
         veh.time = self.time
         veh.temperatureDeviceStatus = self.temperatureDeviceStatus
        return veh
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.vehId<--"vehId"
        mapper<<<self.plateLicenseNo<--"plateNo"
        mapper<<<self.vin<--"vin"
        mapper<<<self.modelName<--"model"
        mapper<<<self.isVehFocused<--"isVehFocused"
        mapper<<<self.isDriverFocused<--"isDriverFocused"
        mapper<<<self.orgName<--"orgName"
        mapper<<<self.temperature<--"temperature"
        mapper<<<self.isRunning<--"isRunning"
        mapper<<<self.latlng<--"latlng"
        mapper<<<self.speed<--"speed"
        mapper<<<self.address<--"address"
        mapper<<<self.level<--"level"
        mapper<<<self.speed<--"speed"
        mapper<<<self.address<--"address"
        mapper<<<self.isDriving<--"isDriving"
         mapper<<<self.isRunning<--"isRunning"
         mapper<<<self.temperature<--"temperature"
        mapper<<<self.driverId<--"driverId"
        mapper<<<self.driverUrl<--"driverUrl"
        mapper<<<self.driverName<--"driverName"
        mapper<<<self.driverPhone<--"driverPhone"
        mapper<<<self.latestDate<--"latestDate"
        mapper<<<self.latestDrivers<--"latestDrivers"
         mapper<<<self.lat<--"lat"
         mapper<<<self.lng<--"lng"
        mapper<<<self.time<--"time"
        mapper<<<self.milsToday<--"milsToday"
        mapper<<<self.temperatureDeviceStatus<--"temperatureDeviceStatus"
    }
}



