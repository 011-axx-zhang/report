//
//  MyLatlng.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/5.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class MyLatlng:NSObject,HandyJSON,NSCopying {
    
    var lat:Double = 0.0
    var lng:Double=0.0
    override required init() {
        super.init()
    }
    init(lat:Double,lng:Double) {
        super.init()
        self.lat=lat
        self.lng=lng
    }
    func copy(with zone: NSZone? = nil) -> Any {
        return MyLatlng.init(lat: self.lat, lng: self.lng)
    }
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.lat<--"lat"
        mapper<<<self.lng<--"lng"
    }
    override var description: String{
        return "lat:\(lat) lng:\(lng)"
    }
}
