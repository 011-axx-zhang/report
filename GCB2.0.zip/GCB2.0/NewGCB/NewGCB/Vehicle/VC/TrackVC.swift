//
//  TrackVC.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/13.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON
import SwiftyJSON

class TrackVC: BaseVC,MAMapViewDelegate {
    var bottomView:TrackBottomView!
    var mapview:MAMapView!
    var tspTimer:DispatchSourceTimer?
    var model:VehInfoModel!
    var vehAnnotation:VehAnnotation!
    var vehAnnoView:TrackAnnotationView!
    var vehLine:MAPolyline?
    var cacheTsps:[VehConditionModel] = []
    var cacheCoors:[CLLocationCoordinate2D]=[]
   // var latlng:MyLatlng!
    var latlng:Dictionary<String,Double>!
    var conditionModel:VehConditionModel!
    
    var toTimeStr:String = ""
    var days:Int = 1
    var vehId:Int64?

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        self.createMarkToastView()
        self.createMap()
        self.initTimer()
        navBar.title = "车辆定位"
    }
   
    
//    @objc func backEvent(){
//        self.navigationController?.popViewController(animated: true)
//        
//    }
    
    func getVehHisTrackRequest() {
        let param = ["vehId":self.vehId ?? 0]
        HttpRequest.loadData(target: InterfaceAPI.getVehCondition(param: param), needCache: false, cache: nil, success: { (datas) in
            let json = JSON(datas)
            let data = JSONDeserializer<VehConditionModel>.deserializeFrom(json: json["data"].description)
            self.conditionModel = data
            if self.conditionModel.latlng != nil {
              self.drawLine(tsp:  self.conditionModel)
            }else {
                self.view.makeToastMid(message: "无GPS信息,车辆定位失败")
            }
            self.mapview.setZoomLevel(16.1, animated: true)
            self.bottomView.configData(model: self.conditionModel)
        }) { (stateCode, message) in
            self.view.makeToastMid(message: message)
        }
    }
    
    func createMap(){
        mapview=MAMapView(frame:CGRect(x: 0, y: kNavBarBottom, width: KW, height: KH - 240 - kNavBarBottom))
        mapview.delegate = self
        mapview.isRotateEnabled = false
        mapview.isRotateCameraEnabled = false
        mapview.setZoomLevel(1.1, animated: true)
        self.view.addSubview(mapview)
    }
       
    
    func createMarkToastView()  {
        bottomView = TrackBottomView()
        bottomView.frame = CGRect(x: 0, y: KH - 240, width: KW, height: 240)
        self.view.addSubview(bottomView)
        bottomView.layer.mask = self.configRectCorner(view: bottomView, corner: [.topLeft, .topRight], radii: CGSize(width: 15, height:15))
        
        bottomView!.reportClick = {
            let vc = VehicleReportVC()
            vc.vehId = self.conditionModel.vehId
            self.navigationController?.pushViewController(vc, animated: true)
        }
        bottomView!.telClick = {
            if self.conditionModel.driverPhone != nil && self.conditionModel.driverPhone != "" {
                UIApplication.shared.openURL(NSURL.init(string: "tel:" + self.conditionModel.driverPhone!)! as URL)
            }else {
                self.view.makeToastMid(message: "驾驶员身份识别失败,无法拨打电话")
            }
        }
        
    }
    
    func configRectCorner(view: UIView, corner: UIRectCorner, radii: CGSize) -> CALayer {
        
        let maskPath = UIBezierPath.init(roundedRect: view.bounds, byRoundingCorners: corner, cornerRadii: radii)
        let maskLayer = CAShapeLayer.init()
        maskLayer.frame = view.bounds
        maskLayer.path = maskPath.cgPath
        return maskLayer
    }
    
    private func initTimer(){
        self.tspTimer=DispatchSource.makeTimerSource(flags: [], queue: DispatchQueue.global())
        self.tspTimer?.schedule(deadline: DispatchTime.now(), repeating: .seconds(30), leeway: .milliseconds(10))
        self.tspTimer?.setEventHandler(handler: {
            DispatchQueue.main.async {
                self.getVehHisTrackRequest()
            }
        })
    }
    
    func addVehAnno(){
        vehAnnotation=VehAnnotation()
        vehAnnotation.veh = self.conditionModel
        if let latlng  = conditionModel.latlng {
            vehAnnotation.coordinate=CLLocationCoordinate2DMake(latlng.lat, latlng.lng)
        }
        mapview.addAnnotation(vehAnnotation)
        mapview.showAnnotations([vehAnnotation], animated: true)
    }
    
    func drawLine(tsp:VehConditionModel){
        var angle:Float=0.0
        if !cacheTsps.isEmpty,let last=cacheTsps.last  {
            angle = Float(computeAzimuth(lat1: (last.latlng?.lat)!, lon1: (last.latlng?.lng)!, lat2: (tsp.latlng?.lat)!, lon2: (tsp.latlng?.lng)!))
        }
        tsp.angle = angle
        cacheTsps.append(tsp)
        cacheCoors.append(CLLocationCoordinate2DMake((tsp.latlng?.lat)!, (tsp.latlng?.lng)!))
        if cacheTsps.count==1{
            conditionModel = tsp
            addVehAnno()
        }else{
            var coors=[vehAnnotation.coordinate,CLLocationCoordinate2DMake((tsp.latlng?.lat)!, (tsp.latlng?.lng)!)]
            vehAnnotation.addMoveAnimation(withKeyCoordinates: &coors, count: UInt(2), withDuration: CGFloat(0.3), withName: nil, completeCallback: { (isOver) in
            })
        }
        if vehLine != nil {
            mapview.remove(vehLine!)
        }
        vehLine=MAPolyline(coordinates: &cacheCoors, count: UInt(cacheCoors.count))
        self.mapview.add(vehLine)
        self.mapview.showOverlays([vehLine!], animated: true)
    }
    
    //MARK: - mapview delegate
    func mapView(_ mapView: MAMapView!, viewFor annotation: MAAnnotation!) -> MAAnnotationView! {
        if annotation.isKind(of: VehAnnotation.self){
            let pointReuseIndetifier="vehicleTrackReuseIndetifier"
            var annoView = mapview.dequeueReusableAnnotationView(withIdentifier: pointReuseIndetifier) as? TrackAnnotationView
            if annoView == nil{
                annoView = TrackAnnotationView(annotation: annotation, reuseIdentifier: pointReuseIndetifier)
                annoView?.isDraggable=false
                annoView?.centerOffset=CGPoint(x: -2, y: -93)
                annoView?.canShowCallout=false
            }
            annoView?.setModel(tspe: (annotation as? VehAnnotation)?.veh)
            self.vehAnnoView = annoView!
            return annoView!
        }
        return nil
    }
    
    func mapView(_ mapView: MAMapView!, rendererFor overlay: MAOverlay!) -> MAOverlayRenderer! {
        if overlay.isKind(of: MAPolyline.self) {
            let polylineRenderer = MAPolylineRenderer(overlay: overlay)
            polylineRenderer?.lineWidth = 5
            polylineRenderer?.strokeColor = UIColor(hex: "#0DB423",alpha: 1.0)
            return polylineRenderer
        }
        return nil
    }
    
     override func viewWillAppear(_ animated: Bool) {
          super.viewWillAppear(true)
          self.tspTimer?.resume()
      }
      override func viewWillDisappear(_ animated: Bool) {
          super.viewWillDisappear(true)
           self.tspTimer?.suspend()
      }
      
      override func didReceiveMemoryWarning() {
          super.didReceiveMemoryWarning()
           self.tspTimer?.cancel()
      }
      
   
    
    class VehAnnotation: MAAnimatedAnnotation {
        var veh:VehConditionModel!
    }

}
