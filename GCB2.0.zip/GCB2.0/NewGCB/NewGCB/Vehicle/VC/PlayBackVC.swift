//
//  PlayBackVC.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/13.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON
import SwiftyJSON

class PlayBackVC: BaseVC,MAMapViewDelegate  {
    var bottomView:PlayBackBottomView!
    var mapview:MAMapView!
    var rightBarBtn:UIBarButtonItem!
    var vehLine:MAPolyline?
    var dataArr:[VehHisTrackModel]?
    var vehAnnoView:PlayBackAnnotationView!
    var vehAnno:VehPlaybackAnnotation?
    var formTimeStr:String = ""
    var toTimeStr:String = ""
    var mapPlay:MapPlay!
    var curRate:Float=1
    var rateView:RateChooseView!
    var days:Int = 1
    var vehId:Int64?
    var index:Int = 2
    
    var playBackDrawView:PlayBackDrawView!
    var bottomChartView:PlayBackBottomChartView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setFromAndToTime()
        self.view.backgroundColor = UIColor.white
        mapPlay=MapPlay(block: { (tsp , pos) in
            self.bottomChartView.progress = pos
            self.addAndMoveAnnotation(tsp: tsp,pos:pos)
        
        })
        mapPlay.pauseEvent =  {
            ()->Void in
            let pause = UIImage(named: "playback_zanting")
            DispatchQueue.main.async {
                self.bottomView.playBtn.setImage(pause, for: .normal)
            }
        }
        self.createBottomView()
        self.createMap()
        self.createBottomChartView()
        self.getVehHisTrackRequest()
        navBar.title = "历史轨迹"
        navBar.wr_setRightButton(image: UIImage(named: "playback_timeChoose")!)
        navBar.onClickRightButton = {
            self.timeChooseEvent()
        }
    }
    
    func setFromAndToTime()  {
        let m = Date()
        formTimeStr = m.getMorningDate(date: m)
        toTimeStr = m.getDayService()
    }
    
    func getVehHisTrackRequest() {
        let fromStr = self.formTimeStr + ":00"
        let toStr = self.toTimeStr + ":00"
         let param = ["vehId":self.vehId,"beginDate": fromStr ,"endDate":toStr] as [String : Any]
        HttpRequest.loadData(target: InterfaceAPI.playback(param: param), needCache: false, cache: nil, success: { (datas) in
            let json = JSON(datas)
            let data = JSONDeserializer<VehHisTrackModel>.deserializeModelArrayFrom(json: json["data"].description)
            if data != nil {
                self.dataArr = data as! [VehHisTrackModel]
                
                self.dataArr  = self.dataArr!.filter({ (item) -> Bool in
                    item.latlng?.lat != 0
                })
                self.dataArr  = self.dataArr!.filter({ (item) -> Bool in
                    item.latlng?.lat != nil
                })
                
                self.mapPlay.data = self.dataArr
                if self.dataArr != nil,self.dataArr!.count>0{
                    self.bottomView.slider.maximumValue = Float.init(exactly: self.dataArr!.count - 1) ?? 0
                    self.bottomView.slider.minimumValue = Float.init(exactly: 0) ?? 0
                }
                
                if self.dataArr != nil && self.dataArr?.count != 0 {
                    self.drawLine()
                    self.bottomChartView.dataArr = self.dataArr!
                    self.bottomChartView.configData()
                    self.bottomView.configVehiInfo(model: self.dataArr![0])
                }else {
                    self.view.makeToastMid(message: "无车辆轨迹数据")
                }
            }else {
                self.view.makeToastMid(message: "无车辆轨迹数据")
            }
            
            
            
            
        }) { (stateCode, message) in
            self.view.makeToastMid(message: message)
        }
    }
    
    func createBottomChartView()  {
        bottomChartView = PlayBackBottomChartView()
        bottomChartView.frame = CGRect(x: 0, y: KH - 180 - bottomHeight, width: KW , height: 180)
        self.view.addSubview(bottomChartView)
    }
       
 
    func createDrawView() {
        let arr:Array<Float> = [1,2,3,1,2,1,3,4,10,15,18,20,73,79,82,88,100,110,25,28,32,36,42,48,52,58,62,68,120,130,140,150,160,25,28,32,36,42,48,52,58,62,70,75,80,85,90,100,105,15,18,20,73,79,82,88,100,110,25,48,52,58,62,68,120,130,140,150,160,25,28,32]
          let tempArr:Array<Float> =  [0,-2,-3,-15,-6,-20,-3]
        playBackDrawView = PlayBackDrawView()
        playBackDrawView.speedDataArr = arr
        playBackDrawView.tempraArr = tempArr
        playBackDrawView.frame = CGRect(x: 0, y: KH - 160, width: KW , height: KH)
        self.view.addSubview(playBackDrawView)
    }

    
    @objc func timeChooseEvent(){
        let dropList = DropListView(frame:CGRect(x: KW - 60, y: navigationBarHeight - 30 , width: 30, height: 30), arrData: ["当日","前3天","前一周","自定义"]) { (str:NSString) in
            self.dateStrHandle(str: str as String)
        }
        dropList.tabWidth = 120
        dropList.tabOffset = -110
        dropList.showList()
    }
    
    
    

    
    
    func dateStrHandle(str:String)  {
        let m = Date()
        if str == "当日"{
            formTimeStr = m.getMorningDate(date: m)
            toTimeStr = m.getDayService()
            self.bottomView.beginTimeLabel.text = m.updateDateStr(item: self.formTimeStr)
            self.bottomView.endTimeLabel.text = m.updateDateStr(item: self.toTimeStr)
            
            self.getVehHisTrackRequest()
        }else if str == "前3天"{
            formTimeStr = m.getThreeDaykService()
            toTimeStr = m.getDayService()
            self.bottomView.beginTimeLabel.text = m.updateDateStr(item: self.formTimeStr)
            self.bottomView.endTimeLabel.text = m.updateDateStr(item: self.toTimeStr)
            
            self.getVehHisTrackRequest()
        }else if str == "前一周"{
            formTimeStr = m.getLastWeekService()
            toTimeStr = m.getDayService()
            self.bottomView.beginTimeLabel.text = m.updateDateStr(item: self.formTimeStr)
            self.bottomView.endTimeLabel.text = m.updateDateStr(item: self.toTimeStr)
            self.getVehHisTrackRequest()
        }else if str == "自定义"{
            self.defineTimeIndex()
        }
        
    }
    
    @objc func defineTimeIndex() {
        let myCalendar = MyCalendarView(x:0,y:navigationBarHeight)
        myCalendar.tagFromStr = "playBack"
        self.view.addSubview(myCalendar)
        myCalendar.resultDate = { (startStr, endStr,startTimeStr1,endTimeStr2) in

            if startStr == nil && endStr == nil  &&  startTimeStr1 == nil && endTimeStr2 == nil{
                
            }else {
                if  startTimeStr1 == nil {
                    self.formTimeStr = startStr!  + " "  + "00:00"
                    self.bottomView.beginTimeLabel.text = self.updateDate1(item: self.formTimeStr)
                }else {
                    self.formTimeStr = startStr! + " " + startTimeStr1!
                    self.bottomView.beginTimeLabel.text = self.updateDate1(item: self.formTimeStr)
                }
                
                if  endTimeStr2 == nil {
                    if startStr == endStr  {
                        if startTimeStr1 != nil {
                            let temp = self.formTimeStr
                            self.toTimeStr = temp
                            self.formTimeStr =  endStr! + " "  + "00:00"
                            self.bottomView.beginTimeLabel.text = self.updateDate1(item: self.formTimeStr)
                            self.bottomView.endTimeLabel.text = self.updateDate1(item: self.toTimeStr)
                        }else{
                            self.toTimeStr =  endStr! + " "  + "00:00"
                            self.bottomView.endTimeLabel.text = self.updateDate1(item: self.toTimeStr)
                        }
                    }else {
                        self.toTimeStr =  endStr! + " "  + "00:00"
                        self.bottomView.endTimeLabel.text = self.updateDate1(item: self.toTimeStr)
                    }
                    
                    
                }else {
                    self.toTimeStr = endStr! + " " + endTimeStr2!
                    self.bottomView.endTimeLabel.text = self.updateDate1(item: self.toTimeStr)
                }
                
                
                
                self.getVehHisTrackRequest()
            }
            
            
        }
    }
    
    
    
    
  
    func createBottomView()  {
        bottomView = PlayBackBottomView()
        self.view.addSubview(bottomView)
        bottomView.snp.makeConstraints { (make) in
            make.bottom.equalTo(self.view.snp.bottom).offset(-bottomHeight-180)
            make.left.equalToSuperview()
            make.size.equalTo(CGSize(width: KW, height: 110))
        }
        bottomView.playClick = {
            self.palyEvent()
        }
        
        bottomView.slideValueChange = { slide  in
            let sli = slide.value
            self.mapPlay.curProgress = Int.init(sli)
            
        }
        
        bottomView.rateClick = {
            self.rateHandle()
        }
        
        bottomView.beginTimeLabel.text = self.getMorningDate()
        bottomView.endTimeLabel.text = self.getDayStr()
        
    }
    func getMorningDate() -> String{
        let date = Date()
        let calendar = NSCalendar.init(identifier: .chinese)
        let components = calendar?.components([.year,.month,.day], from: date)
        let date1 = calendar?.date(from: components!)
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "MM/dd HH:mm"
        return  dateFmt.string(from: date1!)
    }
    func getDayStr() ->String{
        let date = Date()
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "MM/dd HH:mm"
        return dateFmt.string(from: date)
    }
    
    func rateHandle(){
        self.view.addSubview(transparentView)
        rateView = RateChooseView.init(frame: CGRect(x: 15, y: KH - 341, width: KW - CGFloat(30), height: 40),index:self.index)
        rateView.layer.cornerRadius = 4
        self.transparentView.addSubview(rateView)
        rateView.passRateValue = { (rate,index) in
            self.curRate = rate*2
            let str = String(format: "%.fX", rate)
            self.bottomView.rateBtn.setTitle(str, for: .normal)
            self.mapPlay.curRate = rate*2
            self.index = index
            self.rateView.removeFromSuperview()
            self.transparentView.removeFromSuperview()
        }
        
        
        
    }
    
    
    lazy var transparentView:UIView = {
        let transparentView = UIView()
        transparentView.backgroundColor = UIColor.clear
        transparentView.frame = CGRect(x: 0, y: 0, width: KW, height: KH)
        transparentView.isUserInteractionEnabled = true
        return transparentView
    }()
    
    @objc func palyEvent() {
        mapPlay.pauseOrPlay()
        let pause = UIImage(named: "playback_zanting")
        let play =  UIImage(named: "playback_bofang")
        let image = mapPlay.isPaused ? pause : play
        self.bottomView.playBtn.setImage(image, for: .normal)
    }
    
    
    
    
    func createMap(){
        mapview=MAMapView(frame:CGRect(x: 0, y: kNavBarBottom, width: KW, height: KH - 290 - kNavBarBottom - bottomHeight))
        mapview.delegate = self
        mapview.isRotateEnabled = false
        mapview.isRotateCameraEnabled = false
        self.view.addSubview(mapview)
    }
    
    private func drawLine(){
        var ary  = self.dataArr?.map({ (tsp ) -> CLLocationCoordinate2D in
            return CLLocationCoordinate2DMake((tsp.latlng?.lat)!, (tsp.latlng?.lng)!)
        })
        if ary == nil || ary!.isEmpty {
            return
        }
        if vehLine != nil {
            self.mapview.remove(vehLine)
        }
        
        
        
        vehLine=MAPolyline(coordinates: &ary!, count: UInt(ary!.count))
        self.mapview.add(vehLine)
        self.mapview.showOverlays([vehLine!], animated: true)
        addAndMoveAnnotation(tsp: self.dataArr![0],pos:0)
        self.setVisibleMapRect(dataArr: self.dataArr!)
//        let rec = CommonUtility.mapRect(forOverlays: [self.vehLine!])
//        self.mapview.setVisibleMapRect(rec, edgePadding: UIEdgeInsets(top: 40, left: 40, bottom: 40, right: 40), animated: false)
        
    }
    
    
    func setVisibleMapRect(dataArr:Array<VehHisTrackModel>)  {
        let ary  = dataArr.map({ (model ) -> CLLocationCoordinate2D in
            return  CLLocationCoordinate2D(latitude: model.latlng!.lat, longitude: model.latlng!.lng)
        })
        var annotations: Array<MAPointAnnotation> = []
        for (idx, coor) in ary.enumerated() {
            let anno = MAPointAnnotation()
            anno.coordinate = coor
            anno.title = " "
            annotations.append(anno)
        }
        self.mapview.showAnnotations(annotations, edgePadding: UIEdgeInsets(top: 200, left: 30, bottom: 40, right: 70), animated: false)
        
    }
    
    var  annoAnimate:MAAnnotationMoveAnimation?
    var preCoor:CLLocationCoordinate2D?
    
    func addAndMoveAnnotation(tsp:VehHisTrackModel,pos:Int){
        
        if vehAnno == nil {
            vehAnno=VehPlaybackAnnotation()
            vehAnno?.coordinate=CLLocationCoordinate2DMake((tsp.latlng?.lat)!, (tsp.latlng?.lng)!)
            vehAnno?.tsp=tsp
            self.mapview.addAnnotation(vehAnno)
            self.mapview.showAnnotations([vehAnno!], animated: true)
        }
        let coor=CLLocationCoordinate2DMake((tsp.latlng?.lat)!, (tsp.latlng?.lng)!)
        var coors=[preCoor ?? vehAnno!.coordinate,coor]
        let dura=CGFloat(1.0/self.curRate)*0.7
        if let animate=annoAnimate,!animate.isCancelled(){
            animate.cancel()
        }
        self.preCoor=coor
        annoAnimate=vehAnno?.addMoveAnimation(withKeyCoordinates: &coors, count: UInt(2), withDuration: dura, withName: nil, completeCallback: { (isOver) in
            self.vehAnno?.coordinate=coor
            self.vehAnno?.tsp=tsp
            self.vehAnnoView.setModel (tspe :tsp)
            self.bottomView.slider.value = Float(pos)
        })
    }
    
    //MARK: - mapview delegate
    func mapView(_ mapView: MAMapView!, viewFor annotation: MAAnnotation!) -> MAAnnotationView! {
        if annotation.isKind(of: MAPointAnnotation.self) {
            let pointReuseIndetifier="annomationReuseIndetifier"
            var annoV=mapview.dequeueReusableAnnotationView(withIdentifier: pointReuseIndetifier) as? PlayBackAnnotationView
            if annoV==nil{
                annoV = PlayBackAnnotationView(annotation: annotation, reuseIdentifier: pointReuseIndetifier)
                annoV?.isDraggable=false
                annoV?.canShowCallout=false
                annoV?.centerOffset=CGPoint(x: 0, y: -80)
                vehAnnoView=annoV!
            }
            return annoV
        }
        return nil
    }
    
    func mapView(_ mapView: MAMapView!, rendererFor overlay: MAOverlay!) -> MAOverlayRenderer! {
        if overlay.isKind(of: MAPolyline.self) {
            let polylineRenderer=MAPolylineRenderer(overlay: overlay)
            polylineRenderer?.lineWidth=20
            polylineRenderer?.strokeImage = UIImage(named: "custtexture_green")
          //  polylineRenderer?.lineJoinType = kMALineJoinRound
            polylineRenderer?.lineCapType  = kMALineCapRound
          //  polylineRenderer?.strokeColor = UIColor(hex: "#0DB423",alpha: 1.0)
            return polylineRenderer
        }
        return nil
    }
    

func str2Date(dateStr:String?)->Date?{
    let formater=DateFormatter()
    formater.dateFormat="HH:mm"
    formater.timeZone=NSTimeZone.local
    return formater.date(from: dateStr ?? "")
}

    
    
    
    
func updateDate1(item:String) -> String {
    let dateFmt = DateFormatter()
    dateFmt.dateFormat = "yyyy-MM-dd HH:mm"
    let date = dateFmt.date(from: item)
    let dateFmt1 = DateFormatter()
    dateFmt1.dateFormat = "MM/dd HH:mm"
    return dateFmt1.string(from: date!)
}


    
}



class VehPlaybackAnnotation : MAAnimatedAnnotation {
    var tsp:VehHisTrackModel?
}
