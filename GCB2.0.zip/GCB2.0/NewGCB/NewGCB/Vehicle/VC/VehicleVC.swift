//
//  VehicleVC.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/11.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import SwiftyJSON
import HandyJSON

class VehicleVC: UIViewController,UITextFieldDelegate ,UITableViewDelegate,UITableViewDataSource{
    var searchView:VehicleSearchTopView!
    var tableView :UITableView!
    var dataArr:Array<VehicleModel> = []
    var filterView:VehicleChooseView!
    var orgId:Int64?
    var vehGroupId:Int64?
    var focusDriver:Bool?
    var focusVeh:Bool?
    var key:String = ""
    var isRunning:Bool = true
    var orgArr:Array<OrgAndGroupContent> = []
    var vehicleGroupArr:Array<OrgAndGroupContent> = []
    var collectArr:Array<String> = ["关注驾驶员","收藏车辆"]
    //var totalFilterView:VehicleTotalFilterView!
    var totalFilterView:DriverOptionView!
    var typeIndex:Int = 1   //  类型标记
    var noDataView:NoDataView!
    var leftFlag:Bool = false
    var rightFlag:Bool = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        let defaults = UserDefaults.standard
        if defaults.value(forKey: "orgId") != nil {
            self.orgId = defaults.value(forKey: "orgId") as? Int64
        }
        if defaults.value(forKey: "groupId") != nil {
            self.vehGroupId = defaults.value(forKey: "groupId") as? Int64
        }
       
        if defaults.value(forKey: "focusVeh") != nil {
            self.focusVeh = defaults.value(forKey: "focusVeh") as? Bool
        }
        
        self.createNoDataView()
        self.createSearchView()
        self.createTableView()
        self.requestVehicle()
        self.getOrgsAndVehGroups()
        
    }
    
    
    func createNoDataView()  {
        noDataView = NoDataView.init(frame: CGRect(x: 0, y: 100 + statusHeight, width: KW, height: KH - 100 - statusHeight))
        self.view.addSubview(noDataView)
    }
    
    
    
    fileprivate func extractedFunc() -> UIView {
        return VehicleSearchTopView()
    }
    
    func createSearchView(){
        searchView = VehicleSearchTopView()
        searchView.filterClick = {
            if self.leftFlag != true {
               self.createFilterView()
            }
           
        }
        searchView.searchTf.delegate  = self
        self.view.addSubview(searchView)
        searchView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(self.view.snp.top).offset(statusHeight)
            make.size.equalTo(CGSize(width: KW, height: 90))
        }
        searchView.backClick = {
            self.navigationController?.popViewController(animated: true)
        }
        
        searchView.searchClick = {
            self.requestVehicle()
        }
        
        searchView.sortClick = {
            if self.rightFlag != true {
               self.createTotalSortView()
            }
        }
    }
    
    @objc func createTotalSortView () {
        print("今日行驶公里数点击事件")
        self.leftFlag = !self.leftFlag
        if self.leftFlag == true {
            self.view.addSubview(transparentView)
            self.totalFilterView = DriverOptionView.init(frame: CGRect(x: 0, y: 0 , width: KW, height: KH - searchView.frame.maxY ), index: typeIndex-1, titleArr: ["综合排序","今日驾驶里程从高到低","今日驾驶里程从低到高"])
            transparentView.addSubview(totalFilterView)
            totalFilterView.selectedCellBlock = { selectIndex, cellText in
                self.typeIndex = selectIndex
                self.leftFlag = false
                self.searchView.totalLabel.text = cellText
                self.totalFilterView.removeFromSuperview()
                self.transparentView.removeFromSuperview()
                self.requestVehicle()
            }
        }else {
            self.leftFlag = false
            self.totalFilterView.removeFromSuperview()
            self.transparentView.removeFromSuperview()
        }
        totalFilterView.closeOptionView = {
            self.leftFlag = false
            self.totalFilterView.removeFromSuperview()
            self.transparentView.removeFromSuperview()
        }
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.requestVehicle()
        textField.resignFirstResponder()
        return true
    }
    
    
    func requestVehicle()  {
        key = searchView.searchTf.text ?? ""
        var paramDic:Dictionary<String,Any> = [:]
        if orgId != nil {
            paramDic["orgId"] = self.orgId
        }else if self.vehGroupId != nil {
            paramDic["vehGroupId"] = self.vehGroupId
        }else if self.focusVeh != nil {
            paramDic["focusVeh"] = self.focusVeh
        }
        paramDic["key"] = self.key
        paramDic["sortby"] = self.typeIndex
        
        NSLog("%@", paramDic);

        HttpRequest.loadData(target: InterfaceAPI.homeVehicle(param: paramDic), needCache: false, cache: nil, success: { (datas) in
            // swiftJson + handyJson 解析方法
            let json = JSON(datas)
            let data = JSONDeserializer<VehicleModel>.deserializeModelArrayFrom(json: json["data"].description)
            self.dataArr = data as! Array<VehicleModel>
            if self.dataArr.count == 0 {
               
                self.view.bringSubviewToFront(self.noDataView)
            }else {
                self.view.bringSubviewToFront(self.tableView)
            }
             self.tableView.reloadData()
    
        }) { (stateCode ,message) in
            self.view.makeToastMid(message: message)
        }
    }

    func getOrgsAndVehGroups() {
        HttpRequest.loadData(target: InterfaceAPI.getOrgsAndVehGroups, needCache: false, cache: nil, success: { (datas) in
            let json = JSON(datas)
            let data = JSONDeserializer<OrgAndVehGroupsModel>.deserializeFrom(json: json["data"].description)
            self.orgArr = data?.orgs ?? []
            self.vehicleGroupArr = data?.vehGroups ?? []
            
            
        }) { (stateCode, message) in
            
        }
    }
    
    
    
    func createFilterView()  {
        self.rightFlag = !self.rightFlag
        if self.rightFlag == true {
            self.view.addSubview(transparentView)
            filterView = VehicleChooseView.init(frame: CGRect(x: 0, y: 0, width: KW, height: KH - statusHeight - 90),orgArr:self.orgArr,vehicleGroupArr:self.vehicleGroupArr)
            transparentView.addSubview(filterView)
            filterView.passValue = { (index,id,isFocus) in
                self.handleFilterValue(index: index, id: id)
            }
            
        }else {
            self.rightFlag = false
            self.filterView.removeFromSuperview()
            self.transparentView.removeFromSuperview()
        }
        
        
        filterView.closeClick = {
            self.rightFlag = false
            self.filterView.removeFromSuperview()
            self.transparentView.removeFromSuperview()
        }
        
    }
    
    func handleFilterValue(index:Int,id:Int64)  {
        
       
        if index == 1 {
            orgId = id
            vehGroupId = nil
            focusVeh = nil
        }else if index == 2 {
            orgId = nil
            vehGroupId = id
            focusVeh = nil
        }else if index == 3 {
            orgId = nil
            vehGroupId = nil
            focusVeh = true
        }else if index == 0 {
            orgId = nil
            vehGroupId = nil
            focusVeh = nil
        }
        let defaults = UserDefaults.standard
        defaults.set(orgId, forKey: "orgId")
        defaults.set(vehGroupId, forKey: "groupId")
        defaults.set(focusVeh, forKey: "focusVeh")
        self.filterView.removeFromSuperview()
        self.transparentView.removeFromSuperview()
        self.rightFlag = false
        self.requestVehicle()
        
        
    }
    
    
    
    
    
    lazy var transparentView:UIView = {
        let transparentView = UIView()
        transparentView.backgroundColor = UIColor.clear
        transparentView.frame = CGRect(x: 0, y: 90 + statusHeight, width: KW, height: KH - 90 - statusHeight)
        transparentView.isUserInteractionEnabled = true
        return transparentView
    }()
    
    
    func configData() {
        for _ in 0..<5 {
            let model = VehicleModel()
            model.plateLicenseNo = "沪DG780"
            model.modelName = "江玲顺达"
            model.orgName = "【冰徕(杭州)科技有限公司】"
           // model.isRunning = false
            model.latestDate = "2019-12-3"
            self.dataArr.append(model)
        }
        self.tableView.reloadData()
    }
    
    
    func createTableView() {
        tableView = UITableView()
        tableView.backgroundColor = UIColor.white
        tableView.frame = CGRect(x: 0, y: 90 + statusHeight, width: KW, height: KH - 90 - statusHeight)
        tableView.estimatedRowHeight = 150
        tableView.dataSource = self
        tableView.delegate = self
        tableView.separatorStyle = .none
        tableView!.register(VehicleTableViewCell.self, forCellReuseIdentifier: "vehicleTableViewCell")
        self.view.addSubview(tableView)
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataArr.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "vehicleTableViewCell", for: indexPath) as! VehicleTableViewCell
        cell.selectionStyle = .none
        let model = self.dataArr[indexPath.row]
        cell.configData(model:model)
        cell.collectClick = {
            self.focusVehRequest(model: model)
        }
        return cell
    }
    
    func focusVehRequest(model:VehicleModel)  {
           
           var flag = true
           if model.isVehFocused != nil {
               flag = !(model.isVehFocused!)
           }
           
           let param = ["vehId": model.vehId!,"isFocused":flag] as [String : Any]
           HttpRequest.loadData(target: InterfaceAPI.focusVeh(param: param), needCache: false, cache: nil, success: { (datas) in
              
               if model.isVehFocused != nil {
                   model.isVehFocused = !(model.isVehFocused!)
               }else {
                   model.isVehFocused = true
               }
            
            if model.isVehFocused! {
               self.view.makeToastMid(message: "已收藏该车辆")
            }else {
               self.view.makeToastMid(message: "已取消收藏该车辆")
            }
 
            self.tableView.reloadData()
           }) { (stateCode ,message) in
            self.view.makeToastMid(message: message)
           }
       }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 143
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let model = self.dataArr[indexPath.row]
        let vc = VehicleReportVC()
        vc.vehId = model.vehId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
         super.viewWillAppear(animated)
         self.navigationController?.navigationBar.isHidden = true
     }
     
   

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
