//
//  VehicleReportVC.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/12.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON
import SwiftyJSON

class VehicleReportVC: BaseVC,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    
    var collectView :UICollectionView!
    var bottomView:VehicleBottomView!
    var vehInfoModel:VehInfoModel!
    var vehRunningReportModel:VehRunningReportModel!
    var fromTimeStr:String = ""
    var toTimeStr:String = ""
    var days:Int = 1
    var vehId:Int64?
    var todayStr:String = ""
    var  deviceArrCount = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setNowTime()
        self.view.backgroundColor = UIColor.white
        self.createCollectionView()
        self.createBottomView()
        self.getVehInfoRequest()
        self.getVehRunningReportRequest()
        
        if #available(iOS 11.0, *) {
            collectView.contentInsetAdjustmentBehavior = .never
        }
        view.insertSubview(navBar, aboveSubview: collectView)
        navBar.title = "车辆运营报告"
        
    }
    

    func setNowTime() {
        let date = Date()
        let dateFmt = DateFormatter()
        dateFmt.dateFormat = "yyyy-MM-dd"
        todayStr = dateFmt.string(from: date)
        let timeS:TimeInterval = TimeInterval(24*60*60)
        let nowTimeS:TimeInterval = date.timeIntervalSince1970
        let totalTime :TimeInterval = nowTimeS - timeS
        let needDate :Date  = Date.init(timeIntervalSince1970: totalTime)
        toTimeStr = dateFmt.string(from: needDate)
    }
    

    
    func createBottomView()  {
        bottomView = VehicleBottomView()
        bottomView.frame = CGRect(x: 0, y: KH - 60 - bottomHeight, width: KW, height: 60)
        self.view.addSubview(bottomView)
        bottomView.playBackClick = {
            let vc = PlayBackVC()
           vc.days = self.days
           vc.vehId = self.vehId
           vc.toTimeStr = self.toTimeStr
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
        bottomView.trackClick = {
            let vc = TrackVC()
            vc.days = self.days
            vc.vehId = self.vehId
            vc.toTimeStr = self.toTimeStr
            vc.model = self.vehInfoModel
           // vc.conditionModel = self.vehRunningReportModel
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func getVehInfoRequest() {
        let param = ["vehId":vehId]
        HttpRequest.loadData(target: InterfaceAPI.getVehInfo(param: param), needCache: false, cache: nil, success: { (datas) in
            let json = JSON(datas)
            let data = JSONDeserializer<VehInfoModel>.deserializeFrom(json: json["data"].description)
            self.vehInfoModel = data
            let totalModel = self.vehInfoModel
            let deviceArr = totalModel!.devices
            self.deviceArrCount = deviceArr?.count ?? 0

            self.collectView.reloadData()
        }) { (stateCode, message) in
            self.view.makeToastMid(message: message)
        }
    }
    
    
    func getVehRunningReportRequest() {
        let param = ["vehId":self.vehId,"days":self.days,"endDate":self.toTimeStr] as [String : Any]
        HttpRequest.loadData(target: InterfaceAPI.getVehRunningReport(param: param), needCache: false, cache: nil, success: { (datas) in
            let json = JSON(datas)
            let data = JSONDeserializer<VehRunningReportModel>.deserializeFrom(json: json["data"].description)
            self.vehRunningReportModel = data
             self.collectView.reloadData()
        }) { (stateCode, message) in
            
        }
      }
    
    func createCollectionView()  {
        let layout = UICollectionViewFlowLayout()

        layout.sectionHeadersPinToVisibleBounds = true

       // let layout = VehicleReportFlowLayout.init()
        //layout.naviHeight = navigationBarHeight
       // layout.headerReferenceSize=CGSize(width: 100, height: 32)
        layout.sectionInset = UIEdgeInsets(top: 5, left: 5,bottom: 5, right: 5)
//        layout.minimumInteritemSpacing = 10
//        layout.minimumLineSpacing  = 10
        collectView = UICollectionView(frame:CGRect(x: 0, y: kNavBarBottom, width: KW, height: KH - kNavBarBottom - 60 - bottomHeight), collectionViewLayout: layout)
        collectView.backgroundColor = UIColor.white
        collectView!.register(VehicleReportFirstCollectionViewCell.self, forCellWithReuseIdentifier:"vehicleReportFirstCollectionViewCell")
        collectView!.register(EquipmentCollectionViewCell.self, forCellWithReuseIdentifier:"equipmentCollectionViewCell")
        collectView!.register(MileageCollectionViewCell.self, forCellWithReuseIdentifier:"mileageCollectionViewCell")
        collectView!.register(YunYingCollectionViewCell.self, forCellWithReuseIdentifier:"yunYingCollectionViewCell")
        collectView!.register(TrafficCollectionViewCell.self, forCellWithReuseIdentifier:"trafficCollectionViewCell")
        collectView!.register(TrafficCollectionViewCell.self, forCellWithReuseIdentifier:"trafficCollectionViewCell")
        collectView!.register(EquipmentCollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionHeader, withReuseIdentifier: "headerID")
        collectView!.register( DriverCollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionHeader, withReuseIdentifier: "driverCollectionReusableView")
        collectView!.register(MileageHeaderCollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionHeader, withReuseIdentifier: "mileageHeaderCollectionReusableView")
        collectView!.register(UICollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionHeader, withReuseIdentifier: "noHeaderID")

         collectView!.register(UICollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionFooter, withReuseIdentifier: "nofooterID")
         collectView!.register(DriverImageParentCell.self, forCellWithReuseIdentifier:"driverImageParentCell")
         collectView!.register(VehicelReportBottomCollectionViewCell.self, forCellWithReuseIdentifier:"vehicelReportBottomCollectionViewCell")
        collectView!.delegate = self
        collectView!.dataSource = self
        
        self.view.addSubview(collectView!)
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 5
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        }else if section == 1 {
            return self.deviceArrCount
        }else  if section == 2{
            return 1
        }else if section == 3{
            return 1
        }else {
             return 1
        }
        
       
      
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if indexPath.section == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "vehicleReportFirstCollectionViewCell", for: indexPath) as! VehicleReportFirstCollectionViewCell
            if self.vehInfoModel != nil {
                cell.conigData(model: self.vehInfoModel)
                cell.collectClick = {
                    self.focusVehRequest(model: self.vehInfoModel )
                }
            }
            
            return cell
        } else  if indexPath.section == 1{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "equipmentCollectionViewCell", for: indexPath) as! EquipmentCollectionViewCell
            if indexPath.row == self.deviceArrCount - 1 {
                cell.lineView.isHidden = true
            }else {
                cell.lineView.isHidden = false
            }
            if self.vehInfoModel != nil {
                let totalModel = self.vehInfoModel
                let deviceArr = totalModel!.devices
                self.deviceArrCount = deviceArr?.count ?? 0
                if deviceArr != nil {
                     cell.configData(model: deviceArr![indexPath.row])
                }
               
            }
           
            return cell
        }else  if indexPath.section == 2{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "vehicelReportBottomCollectionViewCell", for: indexPath) as! VehicelReportBottomCollectionViewCell
            if self.vehRunningReportModel != nil {
                cell.configData(model: self.vehRunningReportModel)
            }
            return cell
        }else if indexPath.section == 3{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "trafficCollectionViewCell", for: indexPath) as! TrafficCollectionViewCell
            if self.vehRunningReportModel != nil {
                cell.configData(model: self.vehRunningReportModel)
            }
            cell.checkClick = { index in
                //index = 1 到交通违章页面。2事故页面
                let vc = NotificationViewController()
                vc.selectIndex = index
                vc.isOtherPage = true
                 // 此处需要传一个车辆ID  self.vehId
                vc.vehicleID = self.vehId!
                self.navigationController?.pushViewController(vc, animated: true)
            }
            return cell
        }else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "driverImageParentCell", for: indexPath) as! DriverImageParentCell
            cell.toDriverVC = { driverId in
                let vc = DriverDetailsViewController()
                vc.driverID = driverId
                self.navigationController?.pushViewController(vc, animated: true)
                
            }
            
            if self.vehInfoModel != nil {
                if self.vehInfoModel.hasAdas == false {
                    cell.imageView.isHidden = false
                    cell.deslabel.isHidden = false
                }else {
                    cell.imageView.isHidden = true
                    cell.deslabel.isHidden = true
                    if self.vehRunningReportModel != nil {
                        let model  = self.vehRunningReportModel.drivers
                        cell.configData(dataArr: model!)
                    }
                }
            }
         
            
            return cell
        }
    }
    
    func focusVehRequest(model:VehInfoModel)  {
        
        var flag = true
        if model.isFocused != nil {
            flag = !(model.isFocused!)
        }
        let param = ["vehId": model.vehId!,"isFocused":flag] as [String : Any]
        HttpRequest.loadData(target: InterfaceAPI.focusVeh(param: param), needCache: false, cache: nil, success: { (datas) in
            
            if model.isFocused != nil {
                model.isFocused = !(model.isFocused!)
            }else {
                model.isFocused = true
            }
            
            if model.isFocused! {
               self.view.makeToastMid(message: "已收藏该车辆")
            }else {
                self.view.makeToastMid(message: "已取消收藏该车辆")
            }
            
            self.collectView.reloadData()
        }) { (stateCode ,message) in
            self.view.makeToastMid(message: message)
        }
    }
    
  
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        if section == 0  || section == 1 {
            return CGSize(width: KW, height: 0.01)
        }else if section == 2{
            return CGSize(width: KW, height: 88)
        }else if section == 3{
            return CGSize(width: KW, height: 20)
        }else {
            return CGSize(width: KW, height: 56)
            
        }
        
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        return CGSize(width: KW, height: 0.01)
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if indexPath.section == 0 {
            return CGSize(width: KW , height: 185)
        }else if indexPath.section == 1 {
           return CGSize(width: KW , height: 45)
        }else if indexPath.section == 2  {
            return CGSize(width: KW , height: 238 + 228)
        }else if indexPath.section == 3 {
             return CGSize(width: KW , height: 152)
        }else {
             return CGSize(width: KW , height: 150)
        }
    }
    
 
    
    
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String,
                        at indexPath: IndexPath) -> UICollectionReusableView {
       // var  reusableview:EquipmentCollectionReusableView!
        var noneReusableview:UICollectionReusableView!
        var  mileageHeaderreusableview:MileageHeaderCollectionReusableView!
        var  driverHeaderCollectionReusableView:DriverCollectionReusableView!
        
    
        if kind == UICollectionView.elementKindSectionHeader{
         if  indexPath.section == 2{
                mileageHeaderreusableview = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "mileageHeaderCollectionReusableView", for: indexPath) as!
                MileageHeaderCollectionReusableView
                mileageHeaderreusableview.passDay = { day in
                    self.days = day
                    self.setFromTime(index: day)
                    if self.days == 1 {
                        mileageHeaderreusableview.dateValueLabel.text = String(format: "%@", self.toTimeStr)
                    }else {
                        mileageHeaderreusableview.dateValueLabel.text = String(format: "%@至%@", self.fromTimeStr,self.toTimeStr)
                    }
                    self.getVehRunningReportRequest()
                }
                mileageHeaderreusableview.dateClick = {
                    let picker = QCalendarPicker { (date: String) in
                        if self.judgeTime(dateStr: date) {
                            self.view.makeToastMid(message: "只能选择当天之前的日期")
                        }else {
                            mileageHeaderreusableview.dateLabel.text = date
                            self.toTimeStr = date
                            if self.days == 1 {
                                mileageHeaderreusableview.dateValueLabel.text = String(format: "%@", self.toTimeStr)
                            }else {
                                self.setFromTime(index: self.days)
                                mileageHeaderreusableview.dateValueLabel.text = String(format: "%@至%@", self.fromTimeStr,self.toTimeStr)
                            }
                        }


                    }
                    picker.isAllowSelectTime = false
                    picker.show()
                }
                return mileageHeaderreusableview
            }else  if indexPath.section == 4{
                driverHeaderCollectionReusableView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "driverCollectionReusableView", for: indexPath) as! DriverCollectionReusableView
                return  driverHeaderCollectionReusableView
            }else {
                noneReusableview = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "noHeaderID", for: indexPath)
               noneReusableview.backgroundColor = UIColor(hex: "#F0F0F7", alpha: 1.0)
                return noneReusableview
            }

        }else {
            noneReusableview = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "nofooterID", for: indexPath)
            noneReusableview.backgroundColor = UIColor(hex: "#F0F0F7", alpha: 1.0)
            return noneReusableview
        }
     
        
    }

    
     func judgeTime(dateStr:String) -> Bool {
              let date = Date()
              let dateFmt = DateFormatter()
              dateFmt.dateFormat = "yyyy-MM-dd"
              let str = dateFmt.string(from: date)
              let date0 = date.strToDate(item: str)
              let date1 = date.strToDate(item: dateStr)
              if date1.compare(date0 as Date) == ComparisonResult.orderedSame {
                  return true
              } else if date1.compare(date0 as Date) == ComparisonResult.orderedDescending {
                  return true
              } else if date1.compare(date0 as Date) == ComparisonResult.orderedAscending {
                  return false
              }
               return true
             
          }
    
    
     func setFromTime(index:Int)  {
       if index == 1 {
           fromTimeStr = ""
       }else {
           let dateFmt = DateFormatter()
           dateFmt.dateFormat = "yyyy-MM-dd"
           let date = dateFmt.date(from: self.toTimeStr)
           let index1 = index - 1
           let timeS:TimeInterval = TimeInterval(24*60*60*index1)
           let nowTimeS:TimeInterval = date!.timeIntervalSince1970
           let totalTime :TimeInterval = nowTimeS - timeS
           let needDate :Date  = Date.init(timeIntervalSince1970: totalTime)
           fromTimeStr = dateFmt.string(from: needDate)
       }
       
   }
    
//
//    func scrollViewDidScroll(_ scrollView: UIScrollView) {
//        let offsetY  = scrollView.contentOffset.y;
//        if offsetY > 200 {
//            scrollView.contentInset = UIEdgeInsets(top: 100, left: 0, bottom: 0, right: 0);
//        }else {
//            scrollView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0);
//        }
//    }
    
   
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
      //  self.navigationController?.navigationBar.isHidden = false
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
