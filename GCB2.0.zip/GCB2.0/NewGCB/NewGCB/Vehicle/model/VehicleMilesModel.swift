//
//  VehicleMilesModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/30.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class VehicleMilesModel: NSObject,HandyJSON {
    var milsSum:Double? //车辆id
    var riskPerHundred:Double?
    var milsDay:Double?  //车牌号
    var milsNight:Double?  //车牌号
    
    
    override required init() {
        super.init()
    }

    func mapping(mapper: HelpingMapper) {
        mapper<<<self.milsSum<--"milsSum"
        mapper<<<self.riskPerHundred<--"riskPerHundred"
        mapper<<<self.milsDay<--"milsDay"
        mapper<<<self.milsNight<--"milsNight"
    }
}
