//
//  VehInfoModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/30.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class VehInfoModel: NSObject,HandyJSON {

    var vehId:Int64! //车辆id
    var vin:String!
    var plateLicenseNo:String!  //车牌号
    var modelName:String?  //车型
    var orgName:String?   //组织名称
    var company:String?   //组织名称
    var isFocused:Bool?   //车辆是否被关注
    var vehUrl:String?
    var sumDays:Int64?  //累计行驶天数
    var insuranceExpires:String?  //保险到期日
    var devices:[DevicesModel]?
     var hasAdas:Bool?
    
    override required init() {
        super.init()
    }
    
    
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.vehId<--"vehId"
        mapper<<<self.plateLicenseNo<--"plateNo"
        mapper<<<self.vin<--"vin"
        mapper<<<self.modelName<--"model"
        mapper<<<self.orgName<--"orgName"
        mapper<<<self.company<--"company"
        mapper<<<self.orgName<--"orgName"
        mapper<<<self.isFocused<--"isFocused"
        mapper<<<self.vehUrl<--"vehUrl"
        mapper<<<self.sumDays<--"sumDays"
        mapper<<<self.insuranceExpires<--"insuranceExpires"
        mapper<<<self.devices<--"devices"
         mapper<<<self.hasAdas<--"hasAdas"
    }
}
