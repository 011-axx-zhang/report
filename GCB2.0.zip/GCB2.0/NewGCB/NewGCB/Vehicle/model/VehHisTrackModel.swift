//
//  VehHisTrackModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/30.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class VehHisTrackModel: NSObject,HandyJSON,PosLatLng{
    func getLat() -> Double {
        return self.latlng?.lat ?? 0
    }
    
    func getLng() -> Double {
        return self.latlng?.lng ?? 0
    }
    var vehId:Int64! //车辆id
    var vin:String!
    var plateLicenseNo:String!  //车牌号
    var modelName:String?  //车型
    var orgName:String?   //组织名称
    var time:String!
    var latlng:MyLatlng?
    var address:String?
    var isOnline:Bool?
    var risk:Double?
    var milsToday:Double?
    var milsSum:Double?
    var driver:String?
    var speed:Double?
    var temperature:Double?
    var humidity:Double?
    var voltage:Double?
    var adasStatus:Int?
    var dmsStatus:Int?
    var temperatureDeviceStatus:Int?
    var tboxStatus:Int?
    
    func copy(with zone: NSZone? = nil) -> Any {
        let veh = VehHisTrackModel.init()
        veh.vehId = self.vehId
        veh.vin = self.vin
        veh.plateLicenseNo=self.plateLicenseNo
        veh.modelName=self.modelName
        veh.orgName=self.orgName
        veh.time = self.time
        veh.latlng=self.latlng?.copy() as? MyLatlng
        veh.address=self.address
        veh.temperature=self.temperature
        veh.isOnline=self.isOnline
        veh.risk=self.risk
        veh.milsToday = self.milsToday
        veh.milsSum = self.milsSum
        veh.driver = self.driver
        veh.speed = self.speed
        veh.temperature = self.temperature
        veh.humidity = self.humidity
        veh.voltage=self.voltage
        veh.adasStatus = self.adasStatus
        veh.dmsStatus = self.dmsStatus
        veh.temperatureDeviceStatus = self.temperatureDeviceStatus
        veh.tboxStatus = self.tboxStatus
        return veh
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.vehId<--"vehId"
        mapper<<<self.vin<--"vin"
        mapper<<<self.plateLicenseNo<--"plateNo"
        mapper<<<self.modelName<--"model"
        mapper<<<self.orgName<--"orgName"
        mapper<<<self.time<--"time"
        mapper<<<self.latlng<--"latlng"
        mapper<<<self.address<--"address"
        mapper<<<self.isOnline<--"isOnline"
        mapper<<<self.address<--"address"
        mapper<<<self.risk<--"risk"
        mapper<<<self.milsToday<--"milsToday"
        mapper<<<self.milsSum<--"milsSum"
        mapper<<<self.driver<--"driver"
        mapper<<<self.speed<--"speed"
        mapper<<<self.temperature<--"temperature"
        mapper<<<self.humidity<--"humidity"
        mapper<<<self.voltage<--"voltage"
        mapper<<<self.adasStatus<--"adasStatus"
        mapper<<<self.dmsStatus<--"dmsStatus"
        mapper<<<self.temperatureDeviceStatus<--"temperatureDeviceStatus"
        mapper<<<self.tboxStatus<--"tboxStatus"
        
    }
    
    
        
          override required init() {
              super.init()
          }

    
}
