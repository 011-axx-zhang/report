//
//  VehicleAccidentModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/30.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class VehicleAccidentModel: NSObject,HandyJSON {
    var count:Int64? //总数
    var processed:Int64?
    
    
    
    override required init() {
        super.init()
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.count<--"count"
        mapper<<<self.processed<--"processed"
    }
}
