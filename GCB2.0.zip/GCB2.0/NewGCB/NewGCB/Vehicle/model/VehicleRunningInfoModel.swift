//
//  VehicleRunningInfoModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/30.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class VehicleRunningInfoModel: NSObject,HandyJSON {
    var days:Int64? //车辆id
    var rate:Double?
    var milsPerDay:Double?  //车牌号
    var durationPerDay:Double?  //车牌号
    
    
    override required init() {
        super.init()
    }

    func mapping(mapper: HelpingMapper) {
        mapper<<<self.days<--"days"
        mapper<<<self.rate<--"rate"
        mapper<<<self.milsPerDay<--"milsPerDay"
        mapper<<<self.durationPerDay<--"durationPerDay"
    }
}
