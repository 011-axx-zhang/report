//
//  VehRunningReportModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/30.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class VehRunningReportModel: NSObject,HandyJSON {
    var mils:VehicleMilesModel? //车辆id
    var runningInfo:VehicleRunningInfoModel?
    var violateRule:VehicleVehViolateRuleModel?  //车牌号
    var accident:VehicleAccidentModel?  //车牌号
    var drivers:[VehicleDriversModel]?  //车牌号
    var hasAdas:Bool?
    
    override required init() {
        super.init()
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.mils<--"mils"
        mapper<<<self.runningInfo<--"runningInfo"
        mapper<<<self.violateRule<--"violateRule"
        mapper<<<self.accident<--"accident"
        mapper<<<self.drivers<--"drivers"
        mapper<<<self.hasAdas<--"hasAdas"
    }
}
