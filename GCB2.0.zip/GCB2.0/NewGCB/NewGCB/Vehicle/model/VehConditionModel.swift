//
//  VehConditionModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/30.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class VehConditionModel: NSObject,HandyJSON {
    func getLat() -> Double {
        return self.latlng?.lat ?? 0
    }
    
    func getLng() -> Double {
        return self.latlng?.lng ?? 0
    }
    var vehId:Int64! //车辆id
    var vin:String!
    var plateLicenseNo:String!  //车牌号
    var modelName:String?  //车型
    var orgName:String?   //组织名称
    var time:String!
    var latlng:MyLatlng?
    var address:String?
    var isOnline:Bool?
    var risk:Double?
    var milsToday:Double?
    var milsSum:Double?
    var driver:String?
    var driverPhone:String?
    var speed:Double?
    var temperature:Double?
    var humidity:Double?
    var voltage:Double?
    var adasStatus:Int?
    var dmsStatus:Int?
    var temperatureDeviceStatus:Int?
    var angle:Float?
    var driverUrl:String?
    var tboxStatus:Int?
     var isDriving:Bool?
     var isRunning:Bool?
    
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.vehId<--"vehId"
        mapper<<<self.vin<--"vin"
        mapper<<<self.plateLicenseNo<--"plateNo"
        mapper<<<self.modelName<--"model"
        mapper<<<self.orgName<--"orgName"
        mapper<<<self.time<--"time"
        mapper<<<self.latlng<--"latlng"
        mapper<<<self.address<--"address"
        mapper<<<self.isOnline<--"isOnline"
        mapper<<<self.address<--"address"
        mapper<<<self.risk<--"risk"
        mapper<<<self.milsToday<--"milsToday"
        mapper<<<self.milsSum<--"milsSum"
        mapper<<<self.driver<--"driver"
        mapper<<<self.speed<--"speed"
        mapper<<<self.temperature<--"temperature"
        mapper<<<self.humidity<--"humidity"
        mapper<<<self.voltage<--"voltage"
        mapper<<<self.adasStatus<--"adasStatus"
        mapper<<<self.dmsStatus<--"dmsStatus"
        mapper<<<self.driverPhone<--"driverPhone"
        mapper<<<self.temperatureDeviceStatus<--"temperatureDeviceStatus"
        mapper<<<self.driverUrl<--"driverUrl"
         mapper<<<self.tboxStatus<--"tboxStatus"
        mapper<<<self.isDriving<--"isDriving"
         mapper<<<self.isRunning<--"isRunning"
        
    }
    
    
    
    override required init() {
        super.init()
    }
}
