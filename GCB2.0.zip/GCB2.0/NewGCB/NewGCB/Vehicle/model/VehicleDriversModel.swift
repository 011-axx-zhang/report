//
//  VehicleDriversModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/30.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class VehicleDriversModel: NSObject ,HandyJSON{
    var licenseUrl:String? //证件照
    var driverId:Int64?
    var driverName:String?  

    override required init() {
        super.init()
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.licenseUrl<--"licenseUrl"
        mapper<<<self.driverId<--"driverId"
        mapper<<<self.driverName<--"driverName"
    }
}
