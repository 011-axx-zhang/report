//
//  PlayBackModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/13.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

import HandyJSON
@objc
class PlayBackModel:  NSObject,HandyJSON,PosLatLng,NSCopying{
    
    func getLat() -> Double {
        return self.latlng?.lat ?? 0
    }
    
    func getLng() -> Double {
        return self.latlng?.lng ?? 0
    }
    
    var angle:Float?
    var latlng:MyLatlng?
    var time:String!
    var odometer:Double?
    var speed:Double?
    var temperature:String?
    var humidity:[Int]?
    var batteryVoltage:Float?
    var location:String?
     var address:String?
    var totalMile:Double?
    var useMile:Double?
    var tem:Double?
    
  
    override required init() {
        super.init()
    }

    func copy(with zone: NSZone? = nil) -> Any {
        let veh = PlayBackModel.init()
        veh.angle = self.angle
        veh.latlng=self.latlng?.copy() as? MyLatlng
        veh.time = self.time
        veh.odometer=self.odometer
        veh.speed = self.speed
        veh.temperature=self.temperature
        veh.batteryVoltage=self.batteryVoltage
        veh.humidity  = self.humidity
        veh.location = self.location
        veh.address = self.address
        veh.totalMile = self.totalMile
        veh.useMile = self.useMile
        return veh
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.angle<--"angle"
        mapper<<<self.latlng<--"latlng"
        mapper<<<self.time<--"time"
        mapper<<<self.odometer<--"odometer"
        mapper<<<self.speed<--"speed"
        mapper<<<self.temperature<--"temperature"
        mapper<<<self.batteryVoltage<--"batteryVoltage"
        mapper<<<self.humidity<--"humidity"
         mapper<<<self.location<--"location"
         mapper<<<self.address<--"address"
        mapper<<<self.totalMile<--"totalMile"
        mapper<<<self.useMile<--"useMile"
         mapper<<<self.tem<--"tem"
        
    }
}
