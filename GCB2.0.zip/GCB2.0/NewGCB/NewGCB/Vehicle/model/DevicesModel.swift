//
//  DevicesModel.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/30.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class DevicesModel: NSObject,HandyJSON {
    
    var name:String? //车辆id
    var activeTime:String?
    var status:String?  //车牌号
 
    
    override required init() {
        super.init()
    }
    
    
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.name<--"name"
        mapper<<<self.activeTime<--"activeTime"
        mapper<<<self.status<--"status"
    }
}
