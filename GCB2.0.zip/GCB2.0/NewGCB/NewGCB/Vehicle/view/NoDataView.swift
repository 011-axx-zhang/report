//
//  NoDataView.swift
//  NewGCB
//
//  Created by YTKJ on 2020/2/11.
//  Copyright © 2020 YTKJ. All rights reserved.
//

import UIKit

class NoDataView: UIView {
    var imageView :UIImageView!
    var label:UILabel!
  
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        self.createUI()
        updateConstraints()
    }
    
    private func createUI() {
        imageView = UIImageView()
        imageView.image = UIImage(named: "zanwushuju")
        self.addSubview(imageView)
        label = UILabel()
        label.text = "暂无搜索结果"
        label.font = UIFont.systemFont(ofSize: 18)
        label.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.addSubview(label)
    }
    
    
    
   
    override func updateConstraints() {
        super.updateConstraints()
        imageView.snp.makeConstraints { (make) in
            make.centerX.equalTo(self).offset(5)
            make.centerY.equalTo(self).offset(-60)
            make.size.equalTo(CGSize(width: 140, height: 154))
        }
        label.snp.makeConstraints { (make) in
            make.top.equalTo(imageView.snp.bottom).offset(40)
            make.centerX.equalTo(self).offset(0)
        }
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
