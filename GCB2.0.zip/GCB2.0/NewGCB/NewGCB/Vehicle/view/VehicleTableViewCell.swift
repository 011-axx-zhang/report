//
//  VehicleTableViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/17.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class VehicleTableViewCell: UITableViewCell {
    var plateLicenseNoLabel :UILabel!
    var modelNameLabel :UILabel!
    var companyLabel :UILabel!
    var wuxingImageView:UIImageView!
    var dateLabel:UILabel!
    var statusLabel :UILabel!
    var firstImageView:UIImageView!
    var secImageView:UIImageView!
    var thirdImageView:UIImageView!
    var firstLabel:UILabel!
    var secLabel:UILabel!
    var thirdLabel:UILabel!
    var lineView:UIView!
    var mileLabel:UILabel!
    
     @objc var collectClick:(()->Void)?
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        createUI()
        self .updateConstraints()
        self.backgroundColor = UIColor.white
        self.contentView.backgroundColor=UIColor.white
    }
    
    private func createUI() {
        plateLicenseNoLabel = UILabel()
        plateLicenseNoLabel.textColor = UIColor(hex: "#363847",alpha: 1.0)
        plateLicenseNoLabel.font = UIFont.boldSystemFont(ofSize: 15.0)
        plateLicenseNoLabel.text = ""
        self.contentView.addSubview(plateLicenseNoLabel)
        modelNameLabel  = UILabel()
        modelNameLabel.font = UIFont.systemFont(ofSize: 10)
        modelNameLabel.layer.borderWidth = 1
        modelNameLabel.layer.borderColor = UIColor(hex: "#E6E9EE",alpha: 1.0)?.cgColor
        modelNameLabel.textColor =  UIColor(hex: "#5C5E74", alpha: 1.0)
        modelNameLabel.textAlignment = .center
        modelNameLabel.text = ""
        self.contentView.addSubview(modelNameLabel)
        companyLabel = UILabel()
        companyLabel.font = UIFont.systemFont(ofSize: 14)
        companyLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        companyLabel.font = UIFont.systemFont(ofSize: 10)
        companyLabel.text = ""
        self.contentView.addSubview(companyLabel)
        statusLabel = UILabel()
        statusLabel.textAlignment  = .center
        statusLabel.font = UIFont.systemFont(ofSize: 9)
        statusLabel.textColor = UIColor.white
        statusLabel.backgroundColor = UIColor(hex: "#3CA34B", alpha: 1.0)
        statusLabel.text = ""
        self.contentView.addSubview(statusLabel)
        dateLabel = UILabel()
        dateLabel.font = UIFont.systemFont(ofSize: 11)
        dateLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        dateLabel.text = ""
        self.contentView.addSubview(dateLabel)
        wuxingImageView = UIImageView()
        wuxingImageView.image = UIImage(named: "home_mark_wuxing")
        wuxingImageView.contentMode = .center
        self.contentView.addSubview(wuxingImageView)
        
        firstImageView = UIImageView()
        firstImageView.image = UIImage(named: "vehicle_driverIcon")
        firstImageView.contentMode = .scaleToFill
        self.contentView.addSubview(firstImageView)
//
        secImageView = UIImageView()
        secImageView.image = UIImage(named: "vehicle_driverIcon")
        secImageView.contentMode = .scaleToFill
        self.contentView.addSubview(secImageView)

        thirdImageView = UIImageView()
        thirdImageView.image = UIImage(named: "vehicle_driverIcon")
        thirdImageView.contentMode = .scaleToFill
        self.contentView.addSubview(thirdImageView)
        
        firstLabel = UILabel()
        firstLabel.text = ""
        firstLabel.font = UIFont.systemFont(ofSize: 11)
        firstLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(firstLabel)
        
        
        secLabel = UILabel()
        secLabel.text = ""
        secLabel.font = UIFont.systemFont(ofSize: 11)
        secLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(secLabel)
        
        
        thirdLabel = UILabel()
        thirdLabel.text = ""
        thirdLabel.font = UIFont.systemFont(ofSize: 11)
        thirdLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(thirdLabel)
        
        
        lineView  = UIView()
        lineView.backgroundColor = UIColor(hex: "#E6E9EE", alpha: 1.0)
        self.contentView.addSubview(lineView)
        
        wuxingImageView.addSingleClick(target: self, action: #selector(self.collectEvent))
        
        mileLabel = UILabel()
        mileLabel.text = ""
        mileLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        mileLabel.font = UIFont.systemFont(ofSize: 11)
        self.contentView.addSubview(mileLabel)
        
        
    }
    
    
    @objc  func collectEvent()  {
        self.collectClick?()
    }
    
    override func updateConstraints() {
        super.updateConstraints()
       
        plateLicenseNoLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.top.equalTo(self.contentView.snp.top).offset(10)
        }
        
        modelNameLabel.snp.makeConstraints { (make) in
            make.left.equalTo(plateLicenseNoLabel.snp.right).offset(8)
            make.centerY.equalTo(plateLicenseNoLabel)
            make.width.greaterThanOrEqualTo(50)
            make.height.equalTo(16)
        }
        
        companyLabel.snp.makeConstraints { (make) in
            make.left.equalTo(modelNameLabel.snp.right).offset(5)
            make.centerY.equalTo(plateLicenseNoLabel)
        }
        
        wuxingImageView.snp.makeConstraints { (make) in
            make.right.equalTo(self.contentView.snp.right).offset(-10)
            make.top.equalTo(self.contentView.snp.top).offset(10)
            make.size.equalTo(CGSize(width: 50, height: 50))
        }

        firstImageView.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.top.equalTo(plateLicenseNoLabel.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: 60, height: 76))
        }

        secImageView.snp.makeConstraints { (make) in
            make.left.equalTo(firstImageView.snp.right).offset(5)
            make.top.equalTo(plateLicenseNoLabel.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: 60, height: 76))
        }

        thirdImageView.snp.makeConstraints { (make) in
            make.left.equalTo(secImageView.snp.right).offset(5)
            make.top.equalTo(plateLicenseNoLabel.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: 60, height: 76))
        }

        statusLabel.snp.makeConstraints { (make) in
            make.left.equalTo(thirdImageView.snp.right).offset(10)
            make.top.equalTo(thirdImageView.snp.top).offset(15)
            make.width.greaterThanOrEqualTo(40)
            make.height.equalTo(15)
        }

        dateLabel.snp.makeConstraints { (make) in
            make.left.equalTo(statusLabel)
            make.top.equalTo(statusLabel.snp.bottom).offset(10)
        }
        mileLabel.snp.makeConstraints { (make) in
            make.left.equalTo(statusLabel)
            make.top.equalTo(dateLabel.snp.bottom).offset(10)
            
        }
        
        firstLabel.snp.makeConstraints { (make) in
            make.centerX.equalTo(firstImageView)
            make.top.equalTo(firstImageView.snp.bottom).offset(5)
        }
        secLabel.snp.makeConstraints { (make) in
            make.centerX.equalTo(secImageView)
            make.top.equalTo(secImageView.snp.bottom).offset(5)
        }
        
        thirdLabel.snp.makeConstraints { (make) in
            make.centerX.equalTo(thirdImageView)
            make.top.equalTo(thirdImageView.snp.bottom).offset(5)
        }
        
        lineView.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.right.equalTo(self.contentView.snp.right).offset(-15)
            make.bottom.equalTo(self)
            make.height.equalTo(1)
            
        }
        
    }
    
    
    
    
    
    func configData(model:VehicleModel) {
        plateLicenseNoLabel.text = model.plateLicenseNo ?? ""
        modelNameLabel.text = model.modelName ?? ""
        companyLabel.text = model.orgName ?? ""
        if model.isDriving == true {
           statusLabel.text = "行驶中"
        }else {
            statusLabel.text = "未行驶"
        }
        
        dateLabel.text = String(format: "最近行驶日期：%@", model.latestDate ?? "")
        
        let driverArr = model.latestDrivers
        if driverArr?.count != 0 {
            if driverArr?.count == 1 {
                let driverModel1 = driverArr?[0]
                
                if driverModel1?.licenseUrl != nil && driverModel1?.licenseUrl != "" {
                    let url = URL.init(string: driverModel1?.licenseUrl ?? "")
                    self.firstImageView?.sd_setImage(with: url, placeholderImage: UIImage(named: "vehicle_driverIcon"), options: .highPriority, completed: nil)
                    
                }else {
                    firstImageView.image = UIImage(named: "vehicle_driverIcon")
                }
                firstLabel.text = driverModel1?.driverName ?? "未知驾驶员"
    
            }else if driverArr?.count == 2 {
                let driverModel1 = driverArr?[0]
                let driverModel2 = driverArr?[1]
                if driverModel1?.licenseUrl != nil && driverModel1?.licenseUrl != "" {
                    let url = URL.init(string: driverModel1?.licenseUrl ?? "")
                    self.firstImageView?.sd_setImage(with: url, placeholderImage: UIImage(named: "vehicle_driverIcon"), options: .highPriority, completed: nil)
                    
                }else {
                    firstImageView.image = UIImage(named: "vehicle_driverIcon")
                }
               
                if driverModel2?.licenseUrl != nil && driverModel2?.licenseUrl != "" {
                    let url = URL.init(string: driverModel2?.licenseUrl ?? "")
                    self.secImageView?.sd_setImage(with: url, placeholderImage: UIImage(named: "vehicle_driverIcon"), options: .highPriority, completed: nil)
                    
                }else {
                    secImageView.image = UIImage(named: "vehicle_driverIcon")
                }
                firstLabel.text = driverModel1?.driverName ?? "未知驾驶员"
                secLabel.text  =  driverModel2?.driverName ?? "未知驾驶员"
  
            }else if driverArr?.count == 3{
                let driverModel1 = driverArr?[0]
                let driverModel2 = driverArr?[1]
                let driverModel3 = driverArr?[2]
                if driverModel1?.licenseUrl != nil && driverModel1?.licenseUrl != "" {
                    let url = URL.init(string: driverModel1?.licenseUrl ?? "")
                    self.firstImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "vehicle_driverIcon"), options: .highPriority, completed: nil)
                    
                }else {
                    firstImageView.image = UIImage(named: "vehicle_driverIcon")
                }
                
                if driverModel2?.licenseUrl != nil && driverModel2?.licenseUrl != "" {
                    let url = URL.init(string: driverModel2?.licenseUrl ?? "")
                    self.secImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "vehicle_driverIcon"), options: .highPriority, completed: nil)
                    
                }else {
                    secImageView.image = UIImage(named: "vehicle_driverIcon")
                }
                
                
                if driverModel3?.licenseUrl != nil && driverModel3?.licenseUrl != "" {
                    let url = URL.init(string: driverModel3?.licenseUrl ?? "")
                    self.thirdImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "vehicle_driverIcon"), options: .highPriority, completed: nil)
                    
                }else {
                    thirdImageView.image = UIImage(named: "vehicle_driverIcon")
                }
                
                firstLabel.text = driverModel1?.driverName ?? "未知驾驶员"
                secLabel.text  =  driverModel2?.driverName ?? "未知驾驶员"
                thirdLabel.text =  driverModel3?.driverName ?? "未知驾驶员"
            }
        }else {
            firstImageView.image = UIImage(named: "vehicle_driverIcon")
            secImageView.image = UIImage(named: "vehicle_driverIcon")
            thirdImageView.image = UIImage(named: "vehicle_driverIcon")
            firstLabel.text = "未知驾驶员"
            secLabel.text  =   "未知驾驶员"
            thirdLabel.text =   "未知驾驶员"
        }
        
        if model.isVehFocused  == true{
            wuxingImageView.image = UIImage(named: "home_mark_wuxing_selected")
        }else {
            wuxingImageView.image = UIImage(named: "home_mark_wuxing")
        }
        
        mileLabel.text = String(format: "今日行驶里程:%.2f公里", model.milsToday ?? 0)
      
        
    }
    
    
    
    
    
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
