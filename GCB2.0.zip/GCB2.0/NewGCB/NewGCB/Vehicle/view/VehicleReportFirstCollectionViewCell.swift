//
//  VehicleReportFirstCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/12.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class VehicleReportFirstCollectionViewCell: UICollectionViewCell {
    
    var vehicleImageView:UIImageView!
    var vehicleNumLabel:UILabel!
    var vehicleModelLabel:UILabel!
    var vehicleModelValueLabel:UILabel!
    var companyLabel:UILabel!
    var orgNameLabel:UILabel!
    var totalRunLabel:UILabel!
    var totalRunValueLabel:UILabel!
    var insureExpireLabel:UILabel!
    var insureExpireValueLabel:UILabel!
    var wuxingImageView:UIImageView!
    var lineView:UIView!
    var equipmentlabel:UILabel!
       
    @objc var collectClick:(()->Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        initView()
        updateConstraints()
    }
    
 
    
    
    func initView(){
        vehicleImageView = UIImageView()
        vehicleImageView.image = UIImage(named: "vehicle")
        self.contentView.addSubview(vehicleImageView)
        vehicleNumLabel = UILabel()
        vehicleNumLabel.text = "沪FG874"
        vehicleNumLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        vehicleNumLabel.font = UIFont.boldSystemFont(ofSize: 16)
        self.contentView.addSubview(vehicleNumLabel)
        vehicleModelLabel = UILabel()
        vehicleModelLabel.text = "车型"
        vehicleModelLabel.textColor = UIColor(hex: "#9395AC", alpha: 1.0)
        vehicleModelLabel.font = UIFont.systemFont(ofSize: 10)
        self.contentView.addSubview(vehicleModelLabel)
        vehicleModelValueLabel = UILabel()
        vehicleModelValueLabel.text = ""
        vehicleModelValueLabel.font = UIFont.systemFont(ofSize: 10)
        vehicleModelValueLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        vehicleModelValueLabel.layer.borderColor = UIColor(hex: "#E6E9EE", alpha: 1.0)?.cgColor
        vehicleModelValueLabel.layer.borderWidth = 1
        vehicleModelValueLabel.textAlignment = .center
        self.contentView.addSubview(vehicleModelValueLabel)
        companyLabel = UILabel()
        companyLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        companyLabel.text = "冰徕(上海)科技有限公司"
        companyLabel.font = UIFont.systemFont(ofSize: 13)
        self.contentView.addSubview(companyLabel)
        orgNameLabel = UILabel()
        orgNameLabel.font = UIFont.systemFont(ofSize: 11)
        orgNameLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        orgNameLabel.text = "上海冰徕总部"
        self.contentView.addSubview(orgNameLabel)
        totalRunLabel = UILabel()
        totalRunLabel.text = "累计行驶天数："
        totalRunLabel.font = UIFont.systemFont(ofSize: 13)
        totalRunLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(totalRunLabel)
        totalRunValueLabel = UILabel()
        totalRunValueLabel.text = "389"
        totalRunValueLabel.textColor = UIColor(hex: "#1D69F5", alpha: 1.0)
        totalRunValueLabel.font = UIFont.systemFont(ofSize: 18)
        self.contentView.addSubview(totalRunValueLabel)
        
        insureExpireLabel = UILabel()
        insureExpireLabel.text = "保险到期日期："
        insureExpireLabel.font = UIFont.systemFont(ofSize: 11)
        insureExpireLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.contentView.addSubview(insureExpireLabel)
        
        insureExpireValueLabel = UILabel()
        insureExpireValueLabel.font = UIFont.systemFont(ofSize: 11)
        insureExpireValueLabel.text = "2020年11月30日"
        insureExpireValueLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.contentView.addSubview(insureExpireValueLabel)
        
        
        wuxingImageView = UIImageView()
        wuxingImageView.image = UIImage(named: "home_mark_wuxing")
        wuxingImageView.contentMode = .center
        self.contentView.addSubview(wuxingImageView)

        equipmentlabel = UILabel()
        equipmentlabel.text = "设备信息"
        equipmentlabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        equipmentlabel.font = UIFont.boldSystemFont(ofSize: 17)
        equipmentlabel.textAlignment = .left
        self.contentView.addSubview(equipmentlabel)
        
        lineView = UIView()
        lineView.backgroundColor = UIColor(hex: "#F0F0F7", alpha: 1.0)
        self.contentView.addSubview(lineView)
        wuxingImageView.addSingleClick(target: self, action: #selector(self.collectEvent))
        
        
    }
    
    
    @objc  func collectEvent()  {
        self.collectClick?()
    }
    
    func conigData(model:VehInfoModel)  {
        if model.vehUrl != nil && model.vehUrl != "" {
            let url = URL.init(string: model.vehUrl!)
            vehicleImageView.sd_setImage(with: url, completed: nil)
        }else {
             vehicleImageView.image = UIImage(named: "vehicle")
        }
        
        vehicleNumLabel.text = model.plateLicenseNo ?? ""
        orgNameLabel.text = model.orgName ?? ""
        companyLabel.text = model.company ?? ""
        totalRunValueLabel.text = String(format: "%d", model.sumDays ?? 0)
        insureExpireValueLabel.text = model.insuranceExpires ?? ""
        
        if model.isFocused  == true{
            wuxingImageView.image = UIImage(named: "home_mark_wuxing_selected")
        }else {
            wuxingImageView.image = UIImage(named: "home_mark_wuxing")
        }
        
        if model.modelName != nil && model.modelName != "" {
            vehicleModelValueLabel.text = String(format: "%@", model.modelName ?? "")
            vehicleModelValueLabel.layer.borderColor = UIColor(hex: "#E6E9EE", alpha: 1.0)?.cgColor
            
        }else {
            vehicleModelValueLabel.layer.borderWidth = 0
        }
        
       
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        vehicleImageView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self.snp.top).offset(18)
            make.size.equalTo(CGSize(width: 100, height: 124))
        }
        
        vehicleNumLabel.snp.makeConstraints { (make) in
            make.left.equalTo(vehicleImageView.snp.right).offset(18)
            make.top.equalTo(self.snp.top).offset(26)
        }
        vehicleModelLabel.snp.makeConstraints { (make) in
            make.left.equalTo(vehicleNumLabel.snp.right).offset(5)
            make.centerY.equalTo(vehicleNumLabel)
        }
        vehicleModelValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(vehicleModelLabel.snp.right).offset(5)
            make.centerY.equalTo(vehicleNumLabel)
            make.width.greaterThanOrEqualTo(50)
            make.height.equalTo(16)
        }
       
        companyLabel.snp.makeConstraints { (make) in
            make.left.equalTo(vehicleNumLabel.snp.left)
            make.top.equalTo(vehicleNumLabel.snp.bottom).offset(4)
        }
        
        orgNameLabel.snp.makeConstraints { (make) in
            make.left.equalTo(vehicleNumLabel.snp.left)
            make.top.equalTo(companyLabel.snp.bottom).offset(4)
        }
        
        totalRunLabel.snp.makeConstraints { (make) in
            make.top.equalTo(orgNameLabel.snp.bottom).offset(12)
            make.left.equalTo(vehicleNumLabel.snp.left)

        }
        
        totalRunValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(totalRunLabel.snp.right).offset(5)
            make.centerY.equalTo(totalRunLabel)
        }
        
        insureExpireLabel.snp.makeConstraints { (make) in
            make.left.equalTo(vehicleNumLabel.snp.left)
            make.top.equalTo(totalRunLabel.snp.bottom).offset(5)
        }
        
        insureExpireValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(insureExpireLabel.snp.right).offset(5)
            make.centerY.equalTo(insureExpireLabel)
        }
        
        wuxingImageView.snp.makeConstraints { (make) in
            make.centerY.equalTo(vehicleNumLabel)
            make.right.equalTo(self.snp.right).offset(-5)
            make.size.equalTo(CGSize(width: 44, height: 44))
        }
        
        
        lineView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.size.equalTo(CGSize(width: KW, height: 1))
            make.top.equalTo(vehicleImageView.snp.bottom).offset(18)
        }
        
        equipmentlabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(14)
            make.top.equalTo(lineView.snp.bottom).offset(8)
        }
        
     
        
    }
    
    required init?(coder: NSCoder) {
         fatalError("init(coder:) has not been implemented")
     }
}
