//
//  VehicleFilterCollectionReusableView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/18.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class VehicleFilterCollectionReusableView: UICollectionReusableView {
    var leftLabel:UILabel!
    var rightBtn:UIButton!
    var rightLabel:UILabel!
    var rightIcon:UIImageView!
    @objc var expendClick:(()->Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.createUI()
        self.updateConstraints()
    }
    
    private func createUI() {
        leftLabel = UILabel()
        leftLabel.text = ""
        leftLabel.font = UIFont.boldSystemFont(ofSize: 15)
        leftLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        leftLabel.numberOfLines = 0
        self.addSubview(leftLabel)
        rightBtn = UIButton()
        self.addSubview(rightBtn)
        rightLabel = UILabel()
        rightLabel.text = "展开"
        rightLabel.textColor = UIColor(hex: "#1D69F5", alpha: 1.0)
        rightLabel.font = UIFont.systemFont(ofSize: 13)
        rightBtn.addSubview(rightLabel)
        rightIcon = UIImageView()
        rightIcon.image = UIImage(named: "vehicle_filterDownIcon")
        rightIcon.contentMode = .center
        rightBtn.addSubview(rightIcon)
        rightBtn.addTarget(self, action: #selector(self.rightBtnEvent), for: .touchUpInside)
    }
    
    
    @objc  func rightBtnEvent() {
        self.expendClick?()
        
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        leftLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.bottom.equalTo(self.snp.bottom).offset(-10)
        }
        
        rightBtn.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp.right).offset(-15)
            make.centerY.equalTo(leftLabel)
            make.size.equalTo(CGSize(width: 40, height: 30))
        }
        rightLabel.snp.makeConstraints { (make) in
            make.left.equalTo(rightBtn.snp.left).offset(2)
            make.centerY.equalTo(rightBtn)
        }
        
        rightIcon.snp.makeConstraints { (make) in
            make.left.equalTo(rightLabel.snp.right).offset(1)
            make.centerY.equalTo(rightBtn)
            make.size.equalTo(CGSize(width: 10, height: 10))
        }
        
    }
    
    func hiddenRightContent() -> Void {
        rightBtn.isHidden = true
        rightIcon.isHidden = true
        rightLabel.isHidden = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
