//
//  PlayBackLineChartRenderer.swift
//  NewGCB
//
//  Created by YTKJ on 2020/1/2.
//  Copyright © 2020 YTKJ. All rights reserved.
//

import UIKit
import Charts

class PlayBackLineChartRenderer: LineChartRenderer {
    
    @objc open override func drawDataSet(context: CGContext, dataSet: ILineChartDataSet)
    {
        if dataSet.entryCount < 1
        {
            return
        }
        
        context.saveGState()
        
        context.setLineWidth(dataSet.lineWidth)
        if dataSet.lineDashLengths != nil
        {
            context.setLineDash(phase: dataSet.lineDashPhase, lengths: dataSet.lineDashLengths!)
        }
        else
        {
            context.setLineDash(phase: 0.0, lengths: [])
        }
        
        context.setLineCap(dataSet.lineCapType)
        
        // if drawing cubic lines is enabled
        switch dataSet.mode
        {
        case .linear: fallthrough
        case .stepped:
            drawLinear(context: context, dataSet: dataSet)
            
        case .cubicBezier:
            drawCubicBezier(context: context, dataSet: dataSet)
            
        case .horizontalBezier:
            drawHorizontalBezier(context: context, dataSet: dataSet)
        }
        
        context.restoreGState()
    }
    
     internal var _xBounds = XBounds() // Reusable XBounds object
    
    @objc open override func drawHorizontalBezier(context: CGContext, dataSet: ILineChartDataSet)
    {
        guard let dataProvider = dataProvider else { return }
        
           let mydata=dataSet as! PlayBackLineChartDataSet
        
        let trans = dataProvider.getTransformer(forAxis: dataSet.axisDependency)
        let phaseY = animator.phaseY
        _xBounds.set(chart: dataProvider, dataSet: dataSet, animator: animator)
        // get the color that is specified for this position from the DataSet
        let drawingColor = dataSet.colors.first!
        // the path for the cubic-spline
        let cubicPath = CGMutablePath()
        let cubicPath2 = CGMutablePath()
        
        let valueToPixelMatrix = trans.valueToPixelMatrix
        if _xBounds.range >= 1
        {
            var prev: ChartDataEntry! = dataSet.entryForIndex(_xBounds.min)
            var cur: ChartDataEntry! = prev
            
            if cur == nil { return }
            
            // let the spline start
            cubicPath.move(to: CGPoint(x: CGFloat(cur.x), y: CGFloat(cur.y * phaseY)), transform: valueToPixelMatrix)
            
            let num = mydata.count

            for j in _xBounds.dropFirst()
            {
                if (j <= mydata.progressIndex  || mydata.progressIndex == 0){
                    
                    prev = cur
                    cur = dataSet.entryForIndex(j)
                    let cpx = CGFloat(prev.x + (cur.x - prev.x) / 2.0)
                    cubicPath.addCurve(
                        to: CGPoint(
                            x: CGFloat(cur.x),
                            y: CGFloat(cur.y * phaseY)),
                        control1: CGPoint(
                            x: cpx,
                            y: CGFloat(prev.y * phaseY)),
                        control2: CGPoint(
                            x: cpx,
                            y: CGFloat(cur.y * phaseY)),
                        transform: valueToPixelMatrix)
                    
                }else  {
                    
                    prev = cur
                    cur = dataSet.entryForIndex(j-1)
                    let cpx = CGFloat(prev.x + (cur.x - prev.x) / 2.0)
                    if mydata.progressIndex == j - 1 {
                        cubicPath2.move(to: CGPoint(x: CGFloat(cur.x), y: CGFloat(cur.y * phaseY)), transform: valueToPixelMatrix)
                    }else {
                        cubicPath2.addCurve(
                            to: CGPoint(
                                x: CGFloat(cur.x),
                                y: CGFloat(cur.y * phaseY)),
                            control1: CGPoint(
                                x: cpx,
                                y: CGFloat(prev.y * phaseY)),
                            control2: CGPoint(
                                x: cpx,
                                y: CGFloat(cur.y * phaseY)),
                            transform: valueToPixelMatrix)
                        
                       
                    }
                    if j == mydata.count - 1 {
                        prev = cur
                        cur = dataSet.entryForIndex(j)
                        let cpx = CGFloat(prev.x + (cur.x - prev.x) / 2.0)
                        cubicPath2.addCurve(
                            to: CGPoint(
                                x: CGFloat(cur.x),
                                y: CGFloat(cur.y * phaseY)),
                            control1: CGPoint(
                                x: cpx,
                                y: CGFloat(prev.y * phaseY)),
                            control2: CGPoint(
                                x: cpx,
                                y: CGFloat(cur.y * phaseY)),
                            transform: valueToPixelMatrix)
                    }
                    
                    
                }
            }
        }
        
       
        
         context.saveGState()
        
        if dataSet.isDrawFilledEnabled
        {
            // Copy this path because we make changes to it
            let fillPath = cubicPath.mutableCopy()
            drawCubicFill(context: context, dataSet: dataSet, spline: fillPath!, matrix: valueToPixelMatrix, bounds: _xBounds)
        }
      
        if mydata.progressIndex  == 0 {
            context.beginPath()
            context.addPath(cubicPath)
            context.setStrokeColor(UIColor.gray.cgColor)
            context.strokePath()
        }else {
            context.beginPath()
            context.addPath(cubicPath)
            context.setStrokeColor(UIColor.blue.cgColor)
            context.strokePath()
            
            context.beginPath()
            context.addPath(cubicPath2)
            context.setStrokeColor(UIColor.gray.cgColor)
            context.strokePath()
            
        }
        context.restoreGState()
    }
    
 
}
