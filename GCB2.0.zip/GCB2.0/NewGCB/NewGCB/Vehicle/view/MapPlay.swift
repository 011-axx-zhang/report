//
//  MapPlay.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/17.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import Foundation
//地图播放类
class MapPlay {
     var pauseEvent:(()->Void)?
    //当前速率
    var curRate:Float=1
    //播放的数据
    var data:[VehHisTrackModel]?{
        didSet{
            curProgress=0
        }
    }
    
    var thread:Thread!
    var condition:NSCondition=NSCondition()
    //回调
    var uiBlock:(VehHisTrackModel,Int)->Void
    //当前进度
    var curProgress:Int = 0{
        didSet{
            if oldValue != curProgress, let da=self.data, curProgress>0 &&  curProgress < da.count  {
                self.uiBlock(da[curProgress],curProgress)
            }
        }
    }
    
    var isExecuting=false
    var isFinished=false
    var isPaused=false
    
    var isRunning:Bool{
        return isExecuting && !isFinished && !isPaused
    }
    
    init(block:@escaping (VehHisTrackModel,Int)->Void) {
        self.uiBlock=block
        thread=Thread(target: self, selector: #selector(self.async), object: nil)
    }
    //开始播放
    private func beginPlay() {
        if !isExecuting {
            thread.start()
            isExecuting=true
        }
    }
    //暂停或重新播放
    func pauseOrPlay () {
        if !isExecuting {
            beginPlay()
        }else{
            isPaused = !isPaused
            if !isPaused {
                condition.signal()
            }
        }
    }
    
    func finish ()  {
        isFinished=true
    }
    
    
    @objc func async() {
        while true {
            if isFinished {
                return
            }
            if data == nil  || data!.isEmpty  {
                isPaused=true
            }
            if isPaused{
                condition.wait()
            }
            
            DispatchQueue.main.async {
                self.curProgress = self.curProgress+1
            }
            Thread.sleep(forTimeInterval: TimeInterval(1.0/curRate))
            if curProgress==data!.count{
                isPaused=true
            
                self.pauseEvent!()
          
                DispatchQueue.main.async {
                    self.curProgress=0
                }
                
            }
        }
    }
    
}

