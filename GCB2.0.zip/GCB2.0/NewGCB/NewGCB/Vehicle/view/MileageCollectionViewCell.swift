//
//  MileageCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/12.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class MileageCollectionViewCell: UICollectionViewCell {
    var titleLabel:UILabel!
    var firstView:UIView!
    var seconView:UIView!
    var thirdView:UIView!
    var fourView:UIView!
    var mileageValueLabel:UILabel!
    var mileageLabel:UILabel!
    var riskLabel:UILabel!
    var riskValueLabel:UILabel!
    var rijianIcon:UIImageView!
    var rijianTimeLabel:UILabel!
    var rijianMileLabel:UILabel!
    var rijianMileValueLabel:UILabel!
    var yejianIcon:UIImageView!
    var yejiianTimeLabel:UILabel!
    var yejiianMileLabel:UILabel!
    var yejiianMileValueLabel:UILabel!
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        initView()
        updateConstraints()
    }
    
    
    func initView(){
        titleLabel = UILabel()
        titleLabel.font = UIFont.boldSystemFont(ofSize: 17)
        titleLabel.text = "行驶里程"
        titleLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(titleLabel)
        
        firstView = UIView()
        firstView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        firstView.layer.cornerRadius = 4
        self.contentView.addSubview(firstView)
        
        seconView = UIView()
        seconView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        seconView.layer.cornerRadius = 4
        self.contentView.addSubview( seconView)
        
        
        thirdView = UIView()
        thirdView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        thirdView.layer.cornerRadius = 4
        self.contentView.addSubview(thirdView)
        
        fourView = UIView()
        fourView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        fourView.layer.cornerRadius = 4
        self.contentView.addSubview(fourView)
        
        mileageValueLabel = UILabel()
        mileageValueLabel.text = "23.32"
        mileageValueLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        mileageValueLabel.font = UIFont.systemFont(ofSize: 20)
        firstView.addSubview(mileageValueLabel)
        mileageLabel = UILabel()
        mileageLabel.text = "累计行驶公里"
        mileageLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        mileageLabel.font = UIFont.systemFont(ofSize: 13)
        firstView.addSubview(mileageLabel)
        
    
        riskValueLabel = UILabel()
        riskValueLabel.text = "1.4"
        riskValueLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        riskValueLabel.font = UIFont.systemFont(ofSize: 20)
        seconView.addSubview(riskValueLabel)
        riskLabel = UILabel()
        riskLabel.text = "百公里高/中风险数"
        riskLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        riskLabel.font = UIFont.systemFont(ofSize: 13)
        seconView.addSubview(riskLabel)
        
        rijianIcon = UIImageView()
        rijianIcon.image = UIImage(named: "baobiao_rijian")
        thirdView.addSubview(rijianIcon)
        rijianTimeLabel = UILabel()
        rijianTimeLabel.text = "(7:00～21:00)"
        rijianTimeLabel.font = UIFont.systemFont(ofSize: 10)
        rijianTimeLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        thirdView.addSubview(rijianTimeLabel)
        rijianMileValueLabel = UILabel()
        rijianMileValueLabel.text = "1.56"
        rijianMileValueLabel.font = UIFont.systemFont(ofSize: 20)
        rijianMileValueLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        thirdView.addSubview(rijianMileValueLabel)
        rijianMileLabel = UILabel()
        rijianMileLabel.text = "日间行驶公里数"
        rijianMileLabel.font = UIFont.systemFont(ofSize: 13)
        rijianMileLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        thirdView.addSubview(rijianMileLabel)
        
        yejianIcon = UIImageView()
        yejianIcon.image = UIImage(named: "baobiao_yejian")
        fourView.addSubview(yejianIcon)
        yejiianTimeLabel = UILabel()
        yejiianTimeLabel.text = "(7:00～21:00)"
        yejiianTimeLabel.font = UIFont.systemFont(ofSize: 10)
        yejiianTimeLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        fourView.addSubview(yejiianTimeLabel)
        yejiianMileValueLabel = UILabel()
        yejiianMileValueLabel.text = "1.56"
        yejiianMileValueLabel.font = UIFont.systemFont(ofSize: 20)
        yejiianMileValueLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        fourView.addSubview(yejiianMileValueLabel)
        yejiianMileLabel = UILabel()
        yejiianMileLabel.text = "日间行驶公里数"
        yejiianMileLabel.font = UIFont.systemFont(ofSize: 13)
        yejiianMileLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        fourView.addSubview(yejiianMileLabel)

    }
    
    
    func configData(model:VehRunningReportModel)  {
        let model = model.mils
        mileageValueLabel.text = String(format: "%.2f", model?.milsSum ?? 0)
        riskValueLabel.text = String(format: "%.2f", model?.riskPerHundred ?? 0)
        rijianMileValueLabel.text = String(format: "%.2f", model?.milsDay ?? 0)
        yejiianMileValueLabel.text = String(format: "%.2f", model?.milsNight ?? 0)
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self.snp.top).offset(12)
        }
        
        firstView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(titleLabel.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 38)/2, height: 68))
        }
        seconView.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.right).offset(8)
            make.top.equalTo(titleLabel.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 38)/2, height: 68))
        }
        
        
        thirdView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(firstView.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 38)/2, height: 84))
        }
        
        fourView.snp.makeConstraints { (make) in
            make.left.equalTo( thirdView.snp.right).offset(8)
            make.top.equalTo(firstView.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 38)/2, height: 84))
        }
        
        
        mileageValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.left).offset(20)
            make.top.equalTo(firstView.snp.top).offset(13)
        }
        mileageLabel.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.left).offset(20)
            make.top.equalTo(mileageValueLabel.snp.bottom).offset(4)
        }
        
        
        riskValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(seconView.snp.left).offset(26)
            make.top.equalTo(seconView.snp.top).offset(13)
        }
        riskLabel.snp.makeConstraints { (make) in
            make.left.equalTo(seconView.snp.left).offset(26)
            make.top.equalTo(riskValueLabel.snp.bottom).offset(4)
        }
        
        rijianIcon.snp.makeConstraints { (make) in
            make.left.equalTo(thirdView.snp.left).offset(5)
            make.top.equalTo(thirdView.snp.top).offset(13)
            make.size.equalTo(CGSize(width: 20, height: 20))
        }
        rijianTimeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(rijianIcon.snp.right).offset(2)
            make.top.equalTo(thirdView.snp.top).offset(13)
        }
        rijianMileValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(thirdView.snp.left).offset(26)
            make.top.equalTo(rijianTimeLabel.snp.bottom).offset(4)
        }
        
        rijianMileLabel.snp.makeConstraints { (make) in
            make.left.equalTo(thirdView.snp.left).offset(26)
            make.top.equalTo(rijianMileValueLabel.snp.bottom).offset(4)
        }
        
        yejianIcon.snp.makeConstraints { (make) in
            make.left.equalTo(fourView.snp.left).offset(5)
            make.top.equalTo(fourView.snp.top).offset(13)
            make.size.equalTo(CGSize(width: 20, height: 20))
        }
        yejiianTimeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(yejianIcon.snp.right).offset(2)
            make.top.equalTo(fourView.snp.top).offset(13)
        }
        yejiianMileValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(fourView.snp.left).offset(26)
            make.top.equalTo(yejiianTimeLabel.snp.bottom).offset(4)
        }
        
        yejiianMileLabel.snp.makeConstraints { (make) in
            make.left.equalTo(fourView.snp.left).offset(26)
            make.top.equalTo(yejiianMileValueLabel.snp.bottom).offset(4)
        }
        
    }
    
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
