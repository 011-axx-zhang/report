//
//  TrafficCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/13.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class TrafficCollectionViewCell: UICollectionViewCell {
    var titleLabel:UILabel!
    var weizhuangLabel:UILabel!
    var weizhuangNumLabel:UILabel!
    var weizhuangNumValueLabel:UILabel!
    var weizhangHandleLabel:UILabel!
    var weizhangHandleValueLabel:UILabel!
    var searchMoreBtn:UIButton!
    var searchLabel:UILabel!
    var searchIcon:UIImageView!
    var lineView:UIView!
    var shiguLabel:UILabel!
    var shiguNumLabel:UILabel!
    var shiguNumValueLabel:UILabel!
    var shiguHandleLabel:UILabel!
    var shiguHandleValueLabel:UILabel!
    var shiguSearchMoreBtn:UIButton!
    var shiguSearchLabel:UILabel!
    var shiguSearchIcon:UIImageView!
    
     @objc var checkClick:((Int)->Void)?
   
    
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        initView()
        updateConstraints()
    }
    
    
    func initView(){
        titleLabel = UILabel()
        titleLabel.font = UIFont.boldSystemFont(ofSize: 17)
        titleLabel.text = "交通状况"
        titleLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(titleLabel)
        
        weizhuangLabel = UILabel()
        weizhuangLabel.text = "交通违章："
        weizhuangLabel.font = UIFont.systemFont(ofSize: 15)
        weizhuangLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(weizhuangLabel)
        
        weizhuangNumLabel = UILabel()
        weizhuangNumLabel.text = "违章次数:"
        weizhuangNumLabel.font = UIFont.systemFont(ofSize: 13)
        weizhuangNumLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.contentView.addSubview(weizhuangNumLabel)
        
        weizhuangNumValueLabel = UILabel()
        weizhuangNumValueLabel.text = ""
        weizhuangNumValueLabel.font = UIFont.systemFont(ofSize: 20)
        weizhuangNumValueLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(weizhuangNumValueLabel)
        
        weizhangHandleLabel = UILabel()
        weizhangHandleLabel.text = "已处理:"
        weizhangHandleLabel.font = UIFont.systemFont(ofSize: 13)
        weizhangHandleLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.contentView.addSubview(weizhangHandleLabel)
        
        weizhangHandleValueLabel = UILabel()
        weizhangHandleValueLabel.text = ""
        weizhangHandleValueLabel.font = UIFont.systemFont(ofSize: 20)
        weizhangHandleValueLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(weizhangHandleValueLabel)
        
        searchMoreBtn = UIButton()
        self.contentView.addSubview(searchMoreBtn)
        searchLabel = UILabel()
        searchLabel.text = "查看更多"
        searchLabel.font = UIFont.systemFont(ofSize: 12)
        searchLabel.textColor = UIColor(hex: "#1D69F5", alpha: 1.0)
        searchMoreBtn.addSubview(searchLabel)
        searchIcon = UIImageView()
        searchIcon.image = UIImage(named: "baobiao_chakan")
        searchIcon.contentMode = .center
        searchMoreBtn.addSubview(searchIcon)
        searchMoreBtn.tag = 210001
        
        searchMoreBtn.addTarget(self, action: #selector(self.checkMoreEvent(btn:)), for: .touchUpInside)
        
        
        
        
        shiguLabel = UILabel()
        shiguLabel.text = "交通事故："
        shiguLabel.font = UIFont.systemFont(ofSize: 15)
        shiguLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(shiguLabel)
        
        shiguNumLabel = UILabel()
        shiguNumLabel.text = "事故次数:"
        shiguNumLabel.font = UIFont.systemFont(ofSize: 13)
        shiguNumLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(shiguNumLabel)
        
        shiguNumValueLabel = UILabel()
        shiguNumValueLabel.text = ""
        shiguNumValueLabel.font = UIFont.systemFont(ofSize: 20)
        shiguNumValueLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(shiguNumValueLabel)
        
        shiguHandleLabel = UILabel()
        shiguHandleLabel.text = "已处理:"
        shiguHandleLabel.font = UIFont.systemFont(ofSize: 13)
        shiguHandleLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(shiguHandleLabel)
        
        
        shiguHandleValueLabel = UILabel()
        shiguHandleValueLabel.text = ""
        shiguHandleValueLabel.font = UIFont.systemFont(ofSize: 20)
        shiguHandleValueLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(shiguHandleValueLabel)
        
      
        
        shiguSearchMoreBtn = UIButton()
        self.contentView.addSubview(shiguSearchMoreBtn)
        shiguSearchLabel = UILabel()
        shiguSearchLabel.text = "查看更多"
        shiguSearchLabel.font = UIFont.systemFont(ofSize: 12)
        shiguSearchLabel.textColor = UIColor(hex: "#1D69F5", alpha: 1.0)
        shiguSearchMoreBtn.addSubview(shiguSearchLabel)
        shiguSearchIcon = UIImageView()
        shiguSearchIcon.image = UIImage(named: "baobiao_chakan")
        shiguSearchIcon.contentMode = .center
        shiguSearchMoreBtn.addSubview(shiguSearchIcon)
        shiguSearchMoreBtn.tag = 210002
        shiguSearchMoreBtn.addTarget(self, action: #selector(self.checkMoreEvent(btn:)), for: .touchUpInside)
        
        lineView = UIView()
        lineView.backgroundColor = UIColor(hex: "#E6E9EE", alpha: 1.0)
        self.contentView.addSubview(lineView)
   
    }
    
    
    

    func configData(model:VehRunningReportModel)  {
        let violateRuleModel = model.violateRule
        let accidentModel = model.accident
         weizhuangNumValueLabel.text = String(format: "%d", violateRuleModel?.count ?? 0)
         weizhangHandleValueLabel.text = String(format: "%d", violateRuleModel?.processed ?? 0)
         shiguNumValueLabel.text = String(format: "%d", accidentModel?.count ?? 0)
         shiguHandleValueLabel.text = String(format: "%d", accidentModel?.processed ?? 0)
        
       
        

     }
     
    
    
    
    @objc func checkMoreEvent(btn:UIButton)  {
        if btn.tag == 210001 {
            self.checkClick?(1)
        }else {
            self.checkClick?(2)
        }
    }
    
    
    
    override func updateConstraints() {
        super.updateConstraints()
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self.snp.top).offset(12)
        }
        
        weizhuangLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(titleLabel.snp.bottom).offset(25)
        }
        
        weizhuangNumLabel.snp.makeConstraints { (make) in
            make.left.equalTo(weizhuangLabel.snp.right).offset(24)
            make.centerY.equalTo(weizhuangLabel)
        }
        
        weizhuangNumValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(weizhuangNumLabel.snp.right).offset(5)
            make.centerY.equalTo(weizhuangLabel)
        }
        
        weizhangHandleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(weizhuangNumValueLabel.snp.right).offset(26)
            make.centerY.equalTo(weizhuangLabel)
            
        }
        
        weizhangHandleValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(weizhangHandleLabel.snp.right).offset(5)
            make.centerY.equalTo(weizhuangLabel)
            
        }
        
        searchMoreBtn.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp.right).offset(-15)
            make.centerY.equalTo(weizhuangLabel)
            make.size.equalTo(CGSize(width: 65, height: 20))
        }
        
        searchLabel.snp.makeConstraints { (make) in
            make.left.equalTo(searchMoreBtn.snp.left).offset(0)
            make.centerY.equalTo(searchMoreBtn)
        }
        
        searchIcon.snp.makeConstraints { (make) in
            make.left.equalTo(searchLabel.snp.right).offset(2)
            make.centerY.equalTo(searchMoreBtn)
            make.size.equalTo(CGSize(width: 10, height: 20))
        }
      
        lineView.snp.makeConstraints { (make) in
            make.top.equalTo(weizhuangLabel.snp.bottom).offset(13)
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.size.equalTo(CGSize(width: KW - 30, height: 1))
        }
        
        
        shiguLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(lineView.snp.bottom).offset(12)
        }
        
        shiguNumLabel.snp.makeConstraints { (make) in
            make.left.equalTo(shiguLabel.snp.right).offset(24)
            make.centerY.equalTo(shiguLabel)
        }
        
        shiguNumValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(shiguNumLabel.snp.right).offset(5)
            make.centerY.equalTo(shiguLabel)
        }
        
        shiguHandleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(shiguNumValueLabel.snp.right).offset(26)
            make.centerY.equalTo(shiguLabel)
            
        }
        
        shiguHandleValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(shiguHandleLabel.snp.right).offset(5)
            make.centerY.equalTo(shiguLabel)
            
        }
        
        shiguSearchMoreBtn.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp.right).offset(-15)
            make.centerY.equalTo(shiguLabel)
            make.size.equalTo(CGSize(width: 65, height: 20))
        }
        
        shiguSearchLabel.snp.makeConstraints { (make) in
            make.left.equalTo(shiguSearchMoreBtn.snp.left).offset(0)
            make.centerY.equalTo(shiguSearchMoreBtn)
        }
        
        shiguSearchIcon.snp.makeConstraints { (make) in
            make.left.equalTo(shiguSearchLabel.snp.right).offset(2)
            make.centerY.equalTo(shiguSearchMoreBtn)
             make.size.equalTo(CGSize(width: 10, height: 20))
        }
        
        
    }
    
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
