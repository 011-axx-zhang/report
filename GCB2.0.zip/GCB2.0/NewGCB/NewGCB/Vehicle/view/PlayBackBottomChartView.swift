//
//  PlayBackBottomChartView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/24.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import Charts


class PlayBackBottomChartView: UIView {
    var dataArr:Array<VehHisTrackModel> = []
    var barChartDataSet:PlayBackBarChartDataSet!
    var lineChartDataSet:PlayBackLineChartDataSet!
    var leftLabel:UILabel!
    var rightLabel:UILabel!
    
    var progress:Int=0{
        didSet{
            barChartDataSet.progressIndex=progress
            lineChartDataSet.progressIndex = progress
            self.chartView.setNeedsDisplay()
//            self.configData()
        }
    }
    
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        self.createUI()
        self.updateConstraints()
       
//
    }
    
    private func createUI() {
       
        leftLabel = UILabel()
        leftLabel.font = UIFont.systemFont(ofSize: 11)
        leftLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        leftLabel.text = "车厢温度表(℃)"
        self.addSubview(leftLabel)
        
        rightLabel = UILabel()
        rightLabel.font = UIFont.systemFont(ofSize: 11)
        rightLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        rightLabel.text = "时速变化表(km/h)"
        self.addSubview(rightLabel)
        
    }
    
    
    override func updateConstraints() {
        super.updateConstraints()
        leftLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self.snp.top).offset(8)
        }
        rightLabel.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp.right).offset(-15)
            make.top.equalTo(self.snp.top).offset(8)
        }
    }
    
    lazy var  chartView: CombinedChartView = {
     //   DefaultValueFormatter
        let  chartView = CombinedChartView.init(frame: CGRect.init(x: 15, y: 30, width: KW - 30, height: 150));
        chartView.leftAxis.drawGridLinesEnabled = false
        chartView.rightAxis.drawGridLinesEnabled = false
        chartView.xAxis.drawGridLinesEnabled = false
        chartView.xAxis.drawAxisLineEnabled = false
        chartView.xAxis.labelFont = UIFont.systemFont(ofSize: 0.0)
        chartView.leftAxis.axisMaximum = 30
        chartView.leftAxis.axisMinimum = -30
        chartView.rightAxis.axisMaximum = 150
        chartView.rightAxis.axisMinimum = -150
        chartView.leftAxis.labelCount = 7
        chartView.rightAxis.labelCount = 6
        chartView.rightAxis.valueFormatter = PlayBackChartAxisValueFormatter.init();
       
//        chartView.renderer = PlayBackCombinedChartRenderer(chart: chartView, animator: chartView.chartAnimator, viewPortHandler: chartView.viewPortHandler)
        return chartView;
    }()
    
    func configData() {
        //各类型图表的显示次序（后面的覆盖前面的）
        chartView.drawOrder = [DrawOrder.bar.rawValue,
                               DrawOrder.line.rawValue];
        
        //组合图数据
        let chartData = CombinedChartData()
        chartData.barData = generateBarData()
        chartData.lineData = generateLineData()
        
        chartView.data = chartData
        
        let comRen=(chartView.renderer as? CombinedChartRenderer)
        comRen?.subRenderers=[
            PlayBackBarChartRenderer(dataProvider: chartView,animator: chartView.chartAnimator,viewPortHandler: chartView.viewPortHandler),
            PlayBackLineChartRenderer(dataProvider: chartView,animator: chartView.chartAnimator,viewPortHandler: chartView.viewPortHandler)
        ]
        comRen?.initBuffers()
    }
    
    //生成柱状图数据
    func generateBarData() -> BarChartData {
        //生成10条随机数据
        var dataEntries = [BarChartDataEntry]()
        for i in 0..<dataArr.count {
            let model = self.dataArr[i]
           
            let entry = BarChartDataEntry(x: Double(i), y: model.speed ?? 0)
            dataEntries.append(entry)
           
        }
        //这10条数据作为柱状图的所有数据
        barChartDataSet = PlayBackBarChartDataSet(entries: dataEntries, label: "")
        
        let color = UIColor(hex: "#C9CCD1", alpha: 1.0)!
        barChartDataSet.colors = [color] //全部使用橙色
        //目前柱状图只包括1组立柱
       let chartData = BarChartData(dataSet: barChartDataSet)
        
        barChartDataSet.formSize = 0
        //是否显示值
        barChartDataSet.drawValuesEnabled = false
        
        barChartDataSet.axisDependency = .right
        return chartData
    }
    
    //生成折线图数据
    func generateLineData() -> LineChartData {
        //生成10条随机数据
        var dataEntries = [ChartDataEntry]()
        for i in 0..<dataArr.count {
            let model = self.dataArr[i]
            if model.temperature != nil {
                let entry = BarChartDataEntry(x: Double(i), y: model.temperature ?? 0.0)
                dataEntries.append(entry)
            }
            
        }
        //这10条数据作为折线图的所有数据
        lineChartDataSet = PlayBackLineChartDataSet(entries: dataEntries, label: "")
        let color = UIColor(hex: "#1D69F5", alpha: 1.0)!
        lineChartDataSet.colors = [color] //全部使用橙色
        //目前柱状图只包括1组折线
        let chartData = LineChartData(dataSets: [lineChartDataSet])
        lineChartDataSet.formSize = 0
        //是否显示值
        lineChartDataSet.drawValuesEnabled = false
        lineChartDataSet.lineWidth = 1
        lineChartDataSet.drawCirclesEnabled = false
        // 线条样式贝塞尔曲线
        lineChartDataSet.mode = .horizontalBezier
        
        lineChartDataSet.axisDependency = .left
        return chartData
    }

    
    

    
    override func draw(_ rect: CGRect) {
        self.addSubview(self.chartView)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
