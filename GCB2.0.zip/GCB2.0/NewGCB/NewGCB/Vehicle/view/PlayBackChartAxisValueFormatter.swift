//
//  PlayBackChartAxisValueFormatter.swift
//  NewGCB
//
//  Created by YTKJ on 2020/2/13.
//  Copyright © 2020 YTKJ. All rights reserved.
//

import UIKit
import Charts

class PlayBackChartAxisValueFormatter: NSObject,IAxisValueFormatter {
   
    override init() {
        super.init();
    }
    init(_ values: NSArray) {
        super.init();
    }
    
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
       
        let str = String(format: "%.0f", value)
  
        if value >= 0.0 {
            return str;
        }else {
            return "";
        }
        
    }
}



