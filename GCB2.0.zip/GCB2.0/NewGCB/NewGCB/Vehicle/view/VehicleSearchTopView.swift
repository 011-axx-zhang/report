//
//  VehicleSearchTopView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/11.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class VehicleSearchTopView: UIView {
    var backImageView :UIImageView!
    var searchTf:UITextField!
    var searchBtn:UIButton!
    var dateSortBtn:UIButton!
    var filterBtn:UIButton!
    var filterLabel:UILabel!
    var filterImageView:UIImageView!
    var lineView:UIView!
    var totalSortBtn:UIButton!
    var totalLabel:UILabel!
    var totalIcon:UIImageView!
    
    let placeHolderColor = UIColor(hex: "#9395AC", alpha: 1.0)?.cgColor
    
    @objc var filterClick:(()->Void)?
    @objc var backClick:(()->Void)?
    @objc var searchClick:(()->Void)?
    @objc var sortClick:(()->Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        self.createUI()
        updateConstraints()
    }
    
    private func createUI() {
       
        
        backImageView = UIImageView()
        backImageView.image = UIImage(named: "nav_back")
        backImageView.contentMode = .center
        backImageView.addSingleClick(target: self, action: #selector(self.backEvent))
        self.addSubview(backImageView)
        
        searchTf = UITextField()
        searchTf.placeholder = "搜索车牌号/驾驶员姓名"
        searchTf.backgroundColor = UIColor(hex: "#EFF1F6", alpha: 1.0)
        searchTf.layer.cornerRadius = 3
        searchTf.layer.masksToBounds = true
        searchTf.returnKeyType = .search
        searchTf.attributedPlaceholder = NSAttributedString.init(string: "搜索车牌号/驾驶员姓名", attributes: [NSAttributedString.Key.foregroundColor: placeHolderColor!,NSAttributedString.Key.font:UIFont.systemFont(ofSize: 13)])
        var frame = searchTf.frame
        frame.size.width = 15
        let leftView = UIView()
        leftView.frame = frame
        searchTf.leftViewMode = .always
        searchTf.leftView = leftView
        searchTf.clearButtonMode = .whileEditing
        self.addSubview(searchTf)
        
        searchBtn = UIButton()
        searchBtn.setTitle("搜索", for: .normal)
        searchBtn.titleLabel?.font =  UIFont.systemFont(ofSize: 15)
        searchBtn.setTitleColor(UIColor(hex: "#325AEF", alpha: 1.0), for: .normal)
        self.addSubview(searchBtn)
        

        
        
        filterBtn = UIButton()
        filterBtn.addTarget(self, action: #selector(self.filterEvent), for: .touchUpInside)
        self.addSubview(filterBtn)
        filterLabel = UILabel()
        filterLabel.text = "筛选"
        filterLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        filterLabel.font = UIFont.systemFont(ofSize: 13)
        filterBtn.addSubview(filterLabel)
        filterImageView = UIImageView()
        filterImageView.image = UIImage(named: "vehicle_shaixuan")
        filterImageView.contentMode = .center
        filterBtn.addSubview(filterImageView)
        
        lineView = UIView()
        lineView.backgroundColor = UIColor(hex: "#F5F5F9", alpha: 1.0)
        self.addSubview(lineView)
        
    
        
        
        totalSortBtn = UIButton()
        self.addSubview(totalSortBtn)
        
        totalLabel = UILabel()
        totalLabel.text = "综合排序"
        totalLabel.font = UIFont.systemFont(ofSize: 13)
        totalLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        totalSortBtn.addSubview(totalLabel)
        totalIcon = UIImageView()
        totalIcon.image = UIImage(named: "notification_pull_down")
        totalIcon.isUserInteractionEnabled = false
        totalSortBtn.addSubview(totalIcon)
        
 
        searchBtn.addTarget(self, action: #selector(self.searchEvent), for: .touchUpInside)
        totalSortBtn.addTarget(self, action: #selector(self.totalSortBtnEvent), for: .touchUpInside)
        
    }
    
    @objc   func totalSortBtnEvent() {
        self.sortClick?()
    }
    
    
    
    @objc  func searchEvent()  {
        self.searchClick?()
    }
    
    
    
    
   @objc  func filterEvent() {
    if self.filterClick != nil {
        self.filterClick?()
    }
        
    }
    
    @objc  func backEvent() {
        if self.backClick != nil {
            self.backClick?()
        }
        
    }
    
    
    override func updateConstraints() {
        super.updateConstraints()
        
       
    
        backImageView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left)
            make.top.equalTo(self)
            make.size.equalTo(CGSize(width: 44, height: 44))
        }
        
        searchBtn.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp.right).offset(-15)
            make.centerY.equalTo(backImageView)
            make.size.equalTo(CGSize(width: 40, height: 40))
        }
        
        searchTf.snp.makeConstraints { (make) in
            make.left.equalTo(backImageView.snp.right).offset(1)
            make.right.equalTo(searchBtn.snp.left).offset(-12)
            make.height.equalTo(40)
            make.centerY.equalTo(backImageView)
        }
        
        totalSortBtn.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(32)
            make.top.equalTo(searchTf.snp.bottom).offset(2)
            make.size.equalTo(CGSize(width: 150, height: 44))
        }
        totalLabel.snp.makeConstraints { (make) in
            make.left.equalTo(totalSortBtn.snp.left).offset(0)
            make.centerY.equalTo(totalSortBtn)
        }
        totalIcon.snp.makeConstraints { (make) in
            make.left.equalTo(totalLabel.snp.right).offset(5)
            make.centerY.equalTo(totalSortBtn)
        }
        
    
      filterBtn.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp.right).offset(-32)
            make.centerY.equalTo(totalSortBtn)
            make.size.equalTo(CGSize(width: 44, height: 44))
        }
        
        filterLabel.snp.makeConstraints { (make) in
            make.left.equalTo(filterBtn)
            make.centerY.equalTo(filterBtn)
        }
        
        filterImageView.snp.makeConstraints { (make) in
            make.left.equalTo(filterLabel.snp.right).offset(2)
            make.centerY.equalTo(filterBtn)
            make.size.equalTo(CGSize(width: 15, height: 25))
        }
        
        lineView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(0)
            make.bottom.equalTo(self.snp.bottom).offset(0)
            make.size.equalTo(CGSize(width: KW, height: 1))
        }
        
       
        
        
        
        
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

}
