//
//  DriverImageParentCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/12.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class DriverImageParentCell: UICollectionViewCell,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    var collectView :UICollectionView!
    var dataArr:Array<VehicleDriversModel> = []
    @objc var toDriverVC:((Int64)->Void)?
    var imageView:UIImageView!
    var deslabel:UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        self.createCollectionView()
        self.createUI()
        updateConstraints()
    }
    func createUI()  {
        imageView = UIImageView()
        imageView.image = UIImage(named: "wushebei")
        imageView.contentMode = .center
        imageView.isHidden = true
        self.addSubview(imageView)
        
        deslabel = UILabel()
        deslabel.font = UIFont.systemFont(ofSize: 14)
        deslabel.text = "没有驾驶辅助设备，无法识别驾驶员"
        deslabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.addSubview(deslabel)
    }
    
    
    
    func createCollectionView()  {
        let layout = UICollectionViewFlowLayout()
         layout.scrollDirection = .horizontal
         layout.sectionInset = UIEdgeInsets(top: 5, left:10,bottom: 5, right: 10)
        layout.minimumInteritemSpacing = 10
        layout.minimumLineSpacing  = 10
        collectView = UICollectionView(frame:CGRect(x: 0, y: 0, width: KW, height: 150), collectionViewLayout: layout)
        collectView.backgroundColor = UIColor.white
        collectView.register(VehicleReportDriverImageCollectionViewCell.self, forCellWithReuseIdentifier:"vehicleReportDriverImageCollectionViewCell")
        collectView.delegate = self
        collectView.dataSource = self
        collectView.showsHorizontalScrollIndicator = false
        self.addSubview(collectView)
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
       let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "vehicleReportDriverImageCollectionViewCell", for: indexPath) as! VehicleReportDriverImageCollectionViewCell
        if self.dataArr.count != 0 {
           cell.configData(model: self.dataArr[indexPath.row])
        }
        return cell
    }
    
    
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.dataArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let model = self.dataArr[indexPath.row]
        if model.driverId != nil {
           self.toDriverVC?(model.driverId!)
        }else {
            self.makeToastMid(message: "驶员身份识别失败，无法查看驾驶员档案")
        }
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
         return CGSize(width: 88 , height: 150)
      }
    
    func configData(dataArr:Array<VehicleDriversModel>) {
        self.dataArr = dataArr
        self.collectView.reloadData()
    }
    
    
   
    
    override func updateConstraints() {
        super.updateConstraints()
        imageView.snp.makeConstraints { (make) in
            make.centerX.equalTo(self)
            make.top.equalTo(self.snp.top).offset(25)
            make.size.equalTo(CGSize(width: 82, height: 53))
        }
        deslabel.snp.makeConstraints { (make) in
            make.centerX.equalTo(imageView)
            make.top.equalTo(imageView.snp.bottom).offset(15)
        }
  
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
