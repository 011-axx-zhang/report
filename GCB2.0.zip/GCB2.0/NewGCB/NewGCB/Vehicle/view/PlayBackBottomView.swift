//
//  PlayBackBottomView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/16.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import Charts

class PlayBackBottomView: UIView {
    
    var plateLicenseNoLabel :UILabel!
    var modelNameLabel :UILabel!
    var companyLabel :UILabel!
    var rateBtn:UIButton!
    var playBtn:UIButton!
    var slider:UISlider!
    var beginTimeLabel :UILabel!
    var endTimeLabel:UILabel!
    var lineView:UIView!
    @objc var playClick:(()->Void)?
    @objc var slideValueChange:((UISlider)->Void)?
    @objc var rateClick:(()->Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        self.createUI()
        updateConstraints()

    }
    
    private func createUI() {
        plateLicenseNoLabel = UILabel()
        plateLicenseNoLabel.textColor = UIColor(hex: "#363847",alpha: 1.0)
        plateLicenseNoLabel.font =  UIFont.boldSystemFont(ofSize: 17.0)
        plateLicenseNoLabel.text = ""
        self.addSubview(plateLicenseNoLabel)
        modelNameLabel  = UILabel()
        modelNameLabel.font = UIFont.systemFont(ofSize: 10)
        modelNameLabel.layer.borderColor = UIColor(hex: "#E6E9EE", alpha: 1.0)?.cgColor
        modelNameLabel.layer.borderWidth = 1
        modelNameLabel.text = ""
        modelNameLabel.textAlignment = .center
        modelNameLabel.isHidden = true
        self.addSubview(modelNameLabel)
        companyLabel = UILabel()
        companyLabel.font = UIFont.systemFont(ofSize: 10)
        companyLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        companyLabel.text = ""
        self.addSubview(companyLabel)
        
        rateBtn =  UIButton()
        rateBtn.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        rateBtn.setTitle("1X", for: .normal)
        rateBtn.setTitleColor(UIColor(hex: "#363847", alpha: 1.0), for: .normal)
        rateBtn.addTarget(self, action: #selector(self.rateEvent), for: .touchUpInside)
        self.addSubview(rateBtn)
        
        slider = UISlider()
        slider.isContinuous=false
        slider.addTarget(self, action: #selector(self.sliderValueChangeEvent(slide:)), for: .touchUpInside)
        self.addSubview(slider)
        
        playBtn=UIButton()
        playBtn.setImage(UIImage(named: "playback_zanting"), for: .normal)
        playBtn.addTarget(self, action: #selector(self.playEvent), for: .touchUpInside)
        self.addSubview(playBtn)
        
        
        beginTimeLabel = UILabel()
        beginTimeLabel.font=UIFont.systemFont(ofSize: 11)
        beginTimeLabel.textAlignment = .left
        beginTimeLabel.text = "18:40"
        self.addSubview(beginTimeLabel)
        
        endTimeLabel = UILabel()
        endTimeLabel.font=UIFont.systemFont(ofSize: 11)
        endTimeLabel.textAlignment = .right
        endTimeLabel.text = "32:54"
        self.addSubview( endTimeLabel)
        
        lineView = UIView()
        lineView.backgroundColor = UIColor(hex: "#E6E9EE", alpha: 1.0)
        self.addSubview(lineView)
  
    }
    
    @objc  func playEvent() {
        if self.playClick != nil {
            self.playClick?()
        }
        
    }
    
    @objc func sliderValueChangeEvent(slide:UISlider){
        self.slideValueChange?(slide)
       
    }
    
    @objc func rateEvent(){
        if self.rateClick != nil {
            self.rateClick?()
        } 
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        plateLicenseNoLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self.snp.top).offset(16)
            make.height.equalTo(16)
        }
        modelNameLabel.snp.makeConstraints { (make) in
            make.left.equalTo(plateLicenseNoLabel.snp.right).offset(4)
            make.centerY.equalTo(plateLicenseNoLabel)
            make.height.equalTo(16)
            make.width.greaterThanOrEqualTo(50)
        }
        companyLabel.snp.makeConstraints { (make) in
            make.left.equalTo(modelNameLabel.snp.right).offset(4)
            make.centerY.equalTo(plateLicenseNoLabel)
        }
        
        playBtn.snp.makeConstraints { (make) in
            make.top.equalTo(plateLicenseNoLabel.snp.bottom).offset(25)
            make.left.equalTo(self.snp.left).offset(15)
            make.size.equalTo(CGSize(width: 40, height: 40))
        }
        
        
        rateBtn.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp.right).offset(-15)
            make.centerY.equalTo(playBtn)
        }
        
        slider.snp.makeConstraints { (make) in
            make.left.equalTo(playBtn.snp.right).offset(5)
            make.right.equalTo(rateBtn.snp.left).offset(-10)
            make.centerY.equalTo(playBtn)
        }
        
        beginTimeLabel.snp.makeConstraints { (make) in
            make.bottom.equalTo(slider.snp.top).offset(-4)
            make.left.equalTo(slider.snp.left)
        }
        endTimeLabel.snp.makeConstraints { (make) in
            make.bottom.equalTo(slider.snp.top).offset(-4)
            make.right.equalTo(slider.snp.right)
        }
        
        lineView.snp.makeConstraints { (make) in
            make.bottom.equalTo(self.snp.bottom).offset(-1)
            make.left.equalToSuperview()
            make.right.equalToSuperview()
            make.height.equalTo(1)
        }
    }
    
    
    
    func configVehiInfo(model:VehHisTrackModel)  {
        modelNameLabel.isHidden = false
        plateLicenseNoLabel.text = model.plateLicenseNo ?? ""
        modelNameLabel.text = model.modelName ?? ""
        companyLabel.text = model.orgName ?? ""
    }
    
    

    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}
