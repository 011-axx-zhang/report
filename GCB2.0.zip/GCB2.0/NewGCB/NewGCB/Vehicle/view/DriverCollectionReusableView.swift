//
//  DriverCollectionReusableView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/13.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class DriverCollectionReusableView: UICollectionReusableView {
    var topBgView:UIView!
    var label:UILabel!
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.createUI()
        self.updateConstraints()
    }
    
    private func createUI() {
        label = UILabel()
        label .font = UIFont.boldSystemFont(ofSize: 17)
        label.textAlignment = .left
        label.text = "驾驶司机"
        label.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.addSubview(label)
        topBgView = UIView()
        topBgView.backgroundColor = UIColor(hex: "#F0F0F7", alpha: 1.0)
        self.addSubview(topBgView)
    }
    override func updateConstraints() {
        super.updateConstraints()
        topBgView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(0)
             make.top.equalTo(self.snp.top).offset(0)
            make.size.equalTo(CGSize(width: KW, height: 20))
        }
        label .snp.makeConstraints {[unowned self] (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(topBgView.snp.bottom).offset(12)
        }
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
