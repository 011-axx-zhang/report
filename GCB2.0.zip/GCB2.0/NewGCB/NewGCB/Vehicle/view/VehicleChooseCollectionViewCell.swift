//
//  VehicleChooseCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/18.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class VehicleChooseCollectionViewCell: UICollectionViewCell {
    var contentLabel :UILabel!
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor(hex: "#EFF1F6", alpha: 1.0)
        self.layer.cornerRadius = 2
        initView()
        updateConstraints()
    }
    
    
    
    
    func initView(){
        contentLabel = UILabel()
        contentLabel.text = "冰徕(上海)"
        contentLabel.font = UIFont.systemFont(ofSize: 13)
        contentLabel.textColor = UIColor(hex: "#2A2B37", alpha: 1.0)
        contentLabel.textAlignment = .center
        contentLabel.numberOfLines = 0
        self.contentView.addSubview(contentLabel)
        
        
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        contentLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left)
            make.right.equalTo(self.snp.right)
            make.centerY.equalTo(self)
        }
     
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
