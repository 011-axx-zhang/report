//
//  PlayBackBarChartDataSet.swift
//  NewGCB
//
//  Created by YTKJ on 2020/1/2.
//  Copyright © 2020 YTKJ. All rights reserved.
//

import UIKit
import Charts

class PlayBackBarChartDataSet: BarChartDataSet {
    var progressIndex:Int = 0
}
