//
//  VehicleBottomView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/13.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class VehicleBottomView: UIView {

    var playBackBtn :UIButton!
    var vehicleTrackBtn:UIButton!
     @objc var playBackClick:(()->Void)?
     @objc var trackClick:(()->Void)?
   
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        self.createUI()
        updateConstraints()
    }
    
    private func createUI() {
        vehicleTrackBtn = UIButton()
        vehicleTrackBtn.setTitle("车辆定位", for: .normal)
        vehicleTrackBtn.setTitleColor(UIColor(hex: "#363847", alpha: 1.0), for: .normal)
        vehicleTrackBtn.layer.borderWidth = 1
        vehicleTrackBtn.layer.borderColor = UIColor(hex: "#E6E9EE", alpha: 1.0)?.cgColor
        vehicleTrackBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        vehicleTrackBtn.addTarget(self, action: #selector(self.trackEvent), for: .touchUpInside)
        self.addSubview(vehicleTrackBtn)
        
        playBackBtn = UIButton()
        playBackBtn.setTitle("历史轨迹", for: .normal)
        playBackBtn.setTitleColor(UIColor(hex: "#363847", alpha: 1.0), for: .normal)
        playBackBtn.backgroundColor = UIColor(hex: "#F1F2F6",alpha: 1.0)
        playBackBtn.layer.borderWidth = 1
        playBackBtn.layer.borderColor = UIColor(hex: "#E6E9EE", alpha: 1.0)?.cgColor
        playBackBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        playBackBtn.addTarget(self, action: #selector(self.playBackEvent), for: .touchUpInside)
        self.addSubview(playBackBtn)
    }
    
    
    
    @objc  func playBackEvent() {
        if self.playBackClick != nil {
            self.playBackClick?()
        }
        
    }
    
    @objc   func trackEvent()  {
        if self.trackClick != nil {
            self.trackClick?()
        }
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        vehicleTrackBtn.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.centerY.equalTo(self)
            make.size.equalTo(CGSize(width: (KW - 45)/2.0, height: 40))
        }
        playBackBtn .snp.makeConstraints { (make) in
            make.left.equalTo( vehicleTrackBtn.snp.right).offset(15)
            make.centerY.equalTo(self)
            make.size.equalTo(CGSize(width: (KW - 45)/2.0, height: 40))
        }
    
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }


}
