//
//  RateChooseView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/17.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class RateChooseView: UIView {
   
    var halfBtn:UIButton!
    var oneBtn:UIButton!
    var twoBtn:UIButton!
    var fourBtn:UIButton!
    var selectBtn:UIButton!
    var index:Int = 2

    @objc var playClick:(()->Void)?
    @objc var slideValueChange:((UISlider)->Void)?
    @objc var passRateValue:((Float,Int)->Void)?
    
   init(frame: CGRect, index: Int) {
       super.init(frame: frame)
        self.backgroundColor = UIColor.white
        self.index = index
        self.createUI()
        updateConstraints()
        updateConstraints()
    }
    
    
//    override init(frame: CGRect) {
//        super.init(frame: frame)
//        self.backgroundColor = UIColor.white
//        self.createUI()
//        updateConstraints()
//    }
    
    private func createUI() {
        halfBtn = UIButton()
        halfBtn.setTitle("0.5X", for: .normal)
        halfBtn.layer.cornerRadius = 11
        halfBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        halfBtn.setTitleColor(UIColor(hex: "#363847", alpha: 1.0), for: .normal)
        halfBtn.addTarget(self, action: #selector(self.btnEvent(btn:)), for: .touchUpInside)
        self.addSubview(halfBtn)
        
        oneBtn = UIButton()
        oneBtn.setTitle("1X", for: .normal)
        oneBtn.layer.cornerRadius = 11
        oneBtn.backgroundColor = UIColor(hex: "#D2E1FD", alpha: 1.0)
        oneBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        oneBtn.setTitleColor(UIColor(hex: "#363847", alpha: 1.0), for: .normal)
        oneBtn.addTarget(self, action: #selector(self.btnEvent(btn:)), for: .touchUpInside)
        self.addSubview(oneBtn)
        
        twoBtn = UIButton()
        twoBtn.setTitle("2X", for: .normal)
        twoBtn.layer.cornerRadius = 11
        twoBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        twoBtn.setTitleColor(UIColor(hex: "#363847", alpha: 1.0), for: .normal)
        twoBtn.addTarget(self, action: #selector(self.btnEvent(btn:)), for: .touchUpInside)
        self.addSubview(twoBtn)
        
        fourBtn = UIButton()
        fourBtn.setTitle("4X", for: .normal)
        fourBtn.layer.cornerRadius = 11
        fourBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        fourBtn.setTitleColor(UIColor(hex: "#363847", alpha: 1.0), for: .normal)
        fourBtn.addTarget(self, action: #selector(self.btnEvent(btn:)), for: .touchUpInside)
        self.addSubview(fourBtn)
        
        
        if index == 1 {
            selectBtn = halfBtn
            halfBtn.backgroundColor =  UIColor(hex: "#D2E1FD", alpha: 1.0)
            oneBtn.backgroundColor =  UIColor.white
            twoBtn.backgroundColor =  UIColor.white
            fourBtn.backgroundColor =  UIColor.white
        }else if index == 2 {
            selectBtn = oneBtn
            halfBtn.backgroundColor =  UIColor.white
            oneBtn.backgroundColor =  UIColor(hex: "#D2E1FD", alpha: 1.0)
            twoBtn.backgroundColor =  UIColor.white
            fourBtn.backgroundColor =  UIColor.white
        }else if index == 3 {
            selectBtn = twoBtn
            halfBtn.backgroundColor =  UIColor.white
            oneBtn.backgroundColor =  UIColor.white
            twoBtn.backgroundColor =  UIColor(hex: "#D2E1FD", alpha: 1.0)
            fourBtn.backgroundColor =  UIColor.white
        }else if index == 4 {
            selectBtn = fourBtn
            halfBtn.backgroundColor =  UIColor.white
            oneBtn.backgroundColor =  UIColor.white
            twoBtn.backgroundColor =  UIColor.white
            fourBtn.backgroundColor =  UIColor(hex: "#D2E1FD", alpha: 1.0)
        }
        
    }
    
    @objc  func btnEvent(btn:UIButton)  {
          selectBtn.backgroundColor = UIColor.white
          btn.backgroundColor = UIColor(hex: "#D2E1FD", alpha: 1.0)
          selectBtn = btn
          let str = btn.titleLabel?.text as! NSString
        
        if str == "0.5X" {
            index = 1
        }else if str == "1X" {
             index = 2
        }else if str == "2X" {
             index = 3
        }else if str == "4X" {
             index = 4
        }
  
          self.passRateValue?(str.floatValue,index)
      }
    
    
    
    
    override func updateConstraints() {
        super.updateConstraints()
        halfBtn.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.centerY.equalTo(self)
            make.size.equalTo(CGSize(width: 50, height: 22))
        }
        oneBtn.snp.makeConstraints { (make) in
            make.left.equalTo(halfBtn.snp.right).offset((KW - 260)/3.0)
            make.centerY.equalTo(self)
            make.size.equalTo(CGSize(width: 50, height: 22))
        }
        
        twoBtn.snp.makeConstraints { (make) in
            make.left.equalTo(oneBtn.snp.right).offset((KW - 260)/3.0)
            make.centerY.equalTo(self)
            make.size.equalTo(CGSize(width: 50, height: 22))
        }
        
        fourBtn.snp.makeConstraints { (make) in
            make.left.equalTo(twoBtn.snp.right).offset((KW - 260)/3.0)
             make.centerY.equalTo(self)
            make.size.equalTo(CGSize(width: 50, height: 22))
        }
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

}
