//
//  PlayBackDrawView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/25.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class PlayBackDrawView: UIView {
    
    var  axisLeftY:UILabel!
    var  axisRightY:UILabel!
    var  axisX:UILabel!
    var  leftLabels:[UILabel] = []
    var  rightLabels:[UILabel] = []
    var leftArr:Array<String> = ["-30","-15","0","15","30"]
    var rightArr:Array<String> = ["0","90","160"]
    var speedDataArr:Array<Float> = []
    var speedLessColor=UIColor.black
    var speedLessForty = UIColor(hex: "#1D69F5", alpha: 1.0)!
    var speedMiddleColor=UIColor(hex:"#84CF6A",alpha: 1.0)!
    var speedMoreColor=UIColor(hex:"#F23E3E",alpha: 1.0)!
    var speedZeroColor=UIColor.clear
    var tempraArr:Array<Float> = []
    var leftBgView:UIView!
    var rightBgView:UIView!
    var speedLabel:UILabel!
    var tempLabel:UILabel!
    

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        //self.layer.shouldRasterize = true
        self.createUI()
        updateConstraints()
        
    }
    
    func createUI()  {
        for i in 0...4{
            let label=UILabel()
            label.font=UIFont.systemFont(ofSize: 10)
            label.textColor = UIColor(hex: "#9395AC", alpha: 1.0)
            label.textAlignment = .right
            label.text = leftArr[i]
            leftLabels.append(label)
            self.addSubview(label)
        }
        
        for i in 0...2{
            let label = UILabel()
            label.font = UIFont.systemFont(ofSize: 10)
            label.textColor = UIColor(hex: "#9395AC", alpha: 1.0)
            label.text = rightArr[i]
            label.textAlignment = .left
            rightLabels.append(label)
            self.addSubview(label)
        }
        //轴线
        axisLeftY = UILabel()
        axisLeftY.backgroundColor = UIColor(hex: "#E6E9EE", alpha: 1.0)
        self.addSubview(axisLeftY)
        axisRightY = UILabel()
        axisRightY.backgroundColor = UIColor(hex: "#E6E9EE", alpha: 1.0)
        self.addSubview(axisRightY)
        axisX = UILabel()
        axisX.backgroundColor = UIColor(hex: "#E6E9EE", alpha: 1.0)
        self.addSubview(axisX)
        
        leftBgView = UIView()
        self.addSubview(leftBgView)
        
        rightBgView = UIView()
        self.addSubview(rightBgView)
        
        
        speedLabel = UILabel()
        speedLabel.text = "时速变化表(km/h)"
        speedLabel.font = UIFont.systemFont(ofSize: 11)
        speedLabel.textColor = UIColor(hex: "", alpha: 1.0)
        self.addSubview(speedLabel)
        
        tempLabel = UILabel()
        tempLabel.text = "车厢温度表(℃)"
        tempLabel.font = UIFont.systemFont(ofSize: 11)
        tempLabel.textColor = UIColor(hex: "", alpha: 1.0)
        self.addSubview(tempLabel)
        
        
    }
      
      override func updateConstraints() {
          super.updateConstraints()
        speedLabel.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp.right).offset(-15)
            make.top.equalTo(self.snp.top).offset(10)
        }
        
        tempLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self.snp.top).offset(10)
        }
        
        
        axisLeftY.snp.makeConstraints { (make) in
            make.left.equalTo(58)
            make.top.equalTo(self.snp.top).offset(40)
            make.size.equalTo(CGSize(width: 1, height: 80))
        }
        
        axisRightY.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp.right).offset(-58)
            make.top.equalTo(self.snp.top).offset(40)
            make.size.equalTo(CGSize(width: 1, height: 40))
        }
        
        axisX.snp.makeConstraints { (make) in
            make.left.equalTo(axisLeftY)
            make.right.equalTo(axisRightY)
            make.top.equalTo(self.snp.top).offset(80)
            make.height.equalTo(1)
        }
        
        
        leftBgView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(10)
            make.top.equalTo(self.snp.top).offset(40)
            make.size.equalTo(CGSize(width: 40, height: 80))
        }
        
        rightBgView.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp.right).offset(-10)
            make.top.equalTo(self.snp.top).offset(40)
            make.size.equalTo(CGSize(width: 40, height: 40))
        }
        
        if leftLabels.count>0 {
            for i in 0..<leftLabels.count{
                let label=leftLabels[i]
                label.textAlignment = .right
                label.snp.makeConstraints({ (make) in
                    make.left.equalTo(self.leftBgView.snp.left).offset(20)
                    make.right.equalTo(axisLeftY.snp.right).offset(-2)
                    make.bottom.equalTo(i==0 ? self.leftBgView.snp.bottom : leftLabels[i-1].snp.top).priority(750)
                    make.top.equalTo(i==leftLabels.count-1 ? self.leftBgView.snp.top : leftLabels[i+1].snp.bottom).priority(500)
                    if i != 0{
                        make.height.equalTo(leftLabels[i-1].snp.height)
                    }
                })
            }
        }
        
        
        if rightArr.count>0 {
            for i in 0..<rightArr.count{
                let label=rightLabels[i]
                label.textAlignment = .left
                label.snp.makeConstraints({ (make) in
                    make.left.equalTo(self.rightBgView.snp.left).offset(10)
                    // make.right.equalTo(axisLeftY.snp.right).offset(-2)
                    make.bottom.equalTo(i==0 ? self.rightBgView.snp.bottom : rightLabels[i-1].snp.top).priority(750)
                    make.top.equalTo(i==rightLabels.count-1 ? self.rightBgView.snp.top : rightLabels[i+1].snp.bottom).priority(500)
                    if i != 0{
                        make.height.equalTo(rightLabels[i-1].snp.height)
                    }
                })
            }
        }
        
      }
    
    
    private func drawHor(){
        guard let ctx  = UIGraphicsGetCurrentContext() else { return }
        let xBegin = axisX.frame.origin.x
        let xOver  = axisX.frame.origin.x+axisX.frame.size.width
        let yBegin = axisRightY.frame.origin.y
        let yOver  = axisRightY.frame.origin.y + axisRightY.frame.size.height
        let xLength = xOver-xBegin
        let yLength = yOver-yBegin
         let num = speedDataArr.count
         let xPartLength = xLength/CGFloat(num)
        //一天的分钟数
        for j in 0..<speedDataArr.count{
            let speed = speedDataArr[j]
            let height = speed/160 * 40
            var color:UIColor = speedZeroColor
            switch speed {
            case 0:
                color = speedZeroColor
            case 0..<5:
                 color = speedLessColor
            case 5..<40:
                color = speedLessForty
            case 40..<90:
                color = speedMiddleColor
            case 90...1000:
                color = speedMoreColor
            default:
                color=speedZeroColor
            }
            ctx.addRect(CGRect(x: xBegin+xPartLength*CGFloat(j), y: yOver, width: xPartLength, height: -CGFloat(height)))
            ctx.setFillColor(color.cgColor)
            ctx.fillPath()
        }
    }
    
    func drawCourbe()  {

        let  context = UIGraphicsGetCurrentContext()
        context?.setShouldAntialias(false)

        let xBegin = axisX.frame.origin.x
        let xOver  = axisX.frame.origin.x+axisX.frame.size.width
        let xLength = xOver-xBegin
        let num = tempraArr.count
        let xPartLength = xLength/CGFloat(num)
        let path = UIBezierPath.init()
        var startPoint:CGPoint = CGPoint(x: 58, y:80)
        path.move(to: startPoint)
        for i in 0..<tempraArr.count{
            let temp = tempraArr[i]
            var height:Float = 0.0
            if temp > 0 {
                height =   80 + temp/30 * 40
            }else {
                height =   80 - temp/30 * 40
            }
            let endPoint = CGPoint(x: CGFloat(i+1)*xPartLength + 58, y: CGFloat(height))


            let centerX = (startPoint.x + endPoint.x)/2.0
            let centerY = (startPoint.y + endPoint.y)/2.0
            let p1 = CGPoint(x: centerX, y: startPoint.y)
            let p2 = CGPoint(x: centerX, y: endPoint.y)
            let p3 = CGPoint(x: centerX, y: centerY)
            path.addCurve(to: endPoint, controlPoint1: p1, controlPoint2: p2)
            startPoint = endPoint
        }
        let pathLayer = CAShapeLayer()
        pathLayer.strokeColor = UIColor(hex: "#1D69F5", alpha: 1.0)?.cgColor
        pathLayer.fillColor = nil
        pathLayer.lineWidth = 1.5
        pathLayer.lineCap = .round
        pathLayer.lineJoin = .round
        self.layer.addSublayer(pathLayer)
        pathLayer.path = path.cgPath
        pathLayer.frame = self.bounds

    }
    
    

    
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
         drawHor()
         self.drawCourbe()
    }
      
      required init?(coder aDecoder: NSCoder) {
          fatalError("init(coder:) has not been implemented")
      }

}
