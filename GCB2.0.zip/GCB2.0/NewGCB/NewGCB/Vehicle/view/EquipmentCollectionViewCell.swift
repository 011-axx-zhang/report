//
//  EquipmentCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/12.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class EquipmentCollectionViewCell: UICollectionViewCell {
    var equipmentLabel:UILabel!
    var dateLabel:UILabel!
    var statusLabel:UILabel!
    var lineView:UIView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        initView()
        updateConstraints()
    }
    
    
    func initView(){
        equipmentLabel = UILabel()
        equipmentLabel.text = "TBOX"
        equipmentLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        equipmentLabel.font = UIFont.systemFont(ofSize: 14)
        equipmentLabel.numberOfLines = 0
        self.contentView.addSubview(equipmentLabel)
        
        dateLabel = UILabel()
        dateLabel.text = "激活时间："
        dateLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        dateLabel.font = UIFont.systemFont(ofSize: 14)
        dateLabel.textAlignment = .left
        self.contentView.addSubview(dateLabel)
        
        statusLabel = UILabel()
        statusLabel.text = "在线"
        statusLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        statusLabel.font = UIFont.systemFont(ofSize: 14)
        self.contentView.addSubview(statusLabel)
        
        lineView = UIView()
        lineView.backgroundColor = UIColor(hex: "#E6E9EE", alpha: 1.0)
        self.contentView.addSubview(lineView)
      
        
    }
    
    
    func configData(model:DevicesModel)  {
        equipmentLabel.text = model.name ?? ""
        dateLabel.text = String(format: "激活时间:%@", model.activeTime ?? "")  
        statusLabel.text = model.status ?? ""
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        equipmentLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self.snp.top).offset(8)
            make.width.lessThanOrEqualTo(90)
        }

        dateLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(105)
            make.top.equalTo(self.snp.top).offset(8)
        }
        
       statusLabel.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp.right).offset(-15)
            make.top.equalTo(self.snp.top).offset(8)
        }
        
       
        
        lineView.snp.makeConstraints { (make) in
            make.bottom.equalTo(self.contentView.snp.bottom).offset(0)
            make.left.equalTo(self.snp.left).offset(15)
            make.size.equalTo(CGSize(width: KW - 30, height: 1))
        }
      
    }
    
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
