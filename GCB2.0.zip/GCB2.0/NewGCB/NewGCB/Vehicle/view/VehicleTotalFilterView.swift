//
//  VehicleTotalFilterView.swift
//  NewGCB
//
//  Created by YTKJ on 2020/1/16.
//  Copyright © 2020 YTKJ. All rights reserved.
//

import UIKit

class VehicleTotalFilterView: UIView,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {

    var collectView :UICollectionView!
    var shadowView:UIView!
    @objc var passValue:((Int,Int64)->Void)?
    var dataArr:Array<String> = []
      

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor =  UIColor(red: 51.0/255.0, green: 51.0/255.0, blue: 51.0/255.0, alpha: 0.5)
        dataArr = ["综合排序","今日行驶里程从高到低","今日行驶里程从低到高"]
        self.createCollectionView()
        updateConstraints()
    }
    
    
    func createCollectionView()  {
        let layout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 5, left: 5,bottom: 5, right: 5)
        layout.minimumInteritemSpacing = 10
        layout.minimumLineSpacing  = 10
        collectView = UICollectionView(frame:CGRect(x: 0, y: 0, width: KW, height: KH*4/7 - 48), collectionViewLayout: layout)
        collectView.backgroundColor = UIColor.white
        collectView.register(TotalVehicleFilterCollectionViewCell.self, forCellWithReuseIdentifier:"vehicleChooseCollectionViewCell")
        collectView.delegate = self
        collectView.dataSource = self
        self.addSubview(collectView)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "totalVehicleFilterCollectionViewCell", for: indexPath) as! TotalVehicleFilterCollectionViewCell
        cell.contentLabel.text = self.dataArr[indexPath.row]
        return cell
    }
    
    
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return self.dataArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 1
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: KW , height: 40)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: KW, height: 0.01)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        return CGSize(width: KW, height: 0.01)
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        
    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
