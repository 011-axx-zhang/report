//
//  TrackBottomView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/13.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class TrackBottomView: UIView {
    var bgView:UIView!
     var iconImageView:UIImageView!
     var vehicleNameLabel:UILabel!
     var orgNameLabel:UILabel!
     var driverLabel:UILabel!
     var locationLabel:UILabel!
    
     var reportImageView:UIImageView!
     var reportLabel:UILabel!
     var telImageView:UIImageView!
     var telLabel:UILabel!
     var videoView:UIView!
     var videoImageView:UIImageView!
     var videoLabel:UILabel!
     var chatView:UIView!
     var chatImageView:UIImageView!
     var chatLabel:UILabel!
     var lineView:UIView!
     var modelName:UILabel!
     var reportBtn:UIButton!
        var telBtn:UIButton!

       @objc var notiClick:(()->Void)?
       @objc var guanCheClick:(()->Void)?
       @objc var baoBiaoClick:(()->Void)?
    
       @objc var reportClick:(()->Void)?
        @objc var telClick:(()->Void)?
       
       override init(frame: CGRect) {
           super.init(frame: frame)
           self.backgroundColor = UIColor.white
           self.createUI()
           updateConstraints()
       }
       
       private func createUI() {
         bgView = UIView()
         bgView.backgroundColor = UIColor.white
         self.addSubview(bgView)
       
         iconImageView = UIImageView()
         iconImageView.image = UIImage(named: "vehicle_driverIcon")
         self.addSubview(iconImageView)
         vehicleNameLabel = UILabel()
         vehicleNameLabel.text = "浙DF789"
         vehicleNameLabel.font = UIFont.boldSystemFont(ofSize: 17)
         self.addSubview(vehicleNameLabel)
         orgNameLabel = UILabel()
         orgNameLabel.text = "【冰徕(杭州)科技有限公司】"
         orgNameLabel.font = UIFont.systemFont(ofSize: 10)
         orgNameLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
         self.addSubview(orgNameLabel)
         driverLabel = UILabel()
         driverLabel.text = "驾驶员:李刚"
         driverLabel.font = UIFont.systemFont(ofSize: 13)
         driverLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
         self.addSubview(driverLabel)
        
         locationLabel = UILabel()
         locationLabel.font = UIFont.systemFont(ofSize: 12)
         locationLabel.text = "当前位置：江苏省太仓市姑苏镇三香路58号"
         locationLabel.numberOfLines = 0
         locationLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
         self.addSubview(locationLabel)

         reportBtn = UIButton()
         self.addSubview(reportBtn)
         reportImageView = UIImageView()
         reportImageView.image = UIImage(named: "home_mark_baobiao")
         reportImageView.isUserInteractionEnabled = false
         reportBtn.addSubview(reportImageView)
         reportLabel = UILabel()
         reportLabel.text = "车辆报表"
         reportLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
         reportLabel.font = UIFont.systemFont(ofSize: 12)
         reportBtn.addSubview(reportLabel)

         telBtn = UIButton()
         telBtn.backgroundColor = UIColor.clear
         self.addSubview(telBtn )
         telImageView = UIImageView()
         telImageView.image = UIImage(named: "home_mark_tel")
         telBtn.addSubview(telImageView)
         telLabel = UILabel()
         telLabel.text = "拨打电话"
         telLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
         telLabel.font = UIFont.systemFont(ofSize: 12)
         telBtn.addSubview(telLabel)



         videoView = UIView()
         videoView.backgroundColor = UIColor.clear
         self.addSubview(videoView)
         videoImageView = UIImageView()
         videoImageView.image = UIImage(named: "home_mark_video")
         videoView.addSubview(videoImageView)
         videoLabel = UILabel()
         videoLabel.text = "实时视频"
         videoLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
         videoLabel.font = UIFont.systemFont(ofSize: 12)
         videoView.addSubview(videoLabel)


         chatView = UIView()
         chatView .backgroundColor = UIColor.clear
         self.addSubview(chatView)
         chatImageView = UIImageView()
         chatImageView .image = UIImage(named: "home_mark_chat")
         chatView.addSubview(chatImageView)
         chatLabel = UILabel()
         chatLabel.text = "远程对话"
         chatLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
         chatLabel.font = UIFont.systemFont(ofSize: 12)
         chatView.addSubview(chatLabel)

         lineView = UIView()
         lineView.backgroundColor = UIColor(hex: "#E6E9EE", alpha: 1.0)
         self.addSubview(lineView)
        
        
        modelName = UILabel()
        modelName.text = ""
        modelName.isHidden = true
        modelName.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        modelName.font = UIFont.systemFont(ofSize: 10)
        modelName.layer.borderWidth = 1
        modelName.layer.borderColor = UIColor(hex: "#E6E9EE", alpha: 1.0)?.cgColor
        modelName.textAlignment = .center
        self.addSubview(modelName)
        reportBtn.addTarget(self, action: #selector(self.reportEvent), for: .touchUpInside)
        telBtn.addTarget(self, action: #selector(self.telEvent), for: .touchUpInside)
        
    }
    
    @objc   func telEvent() {
        self.telClick?()
    }
    
    @objc  func reportEvent() {
        self.reportClick?()
    }
    
    func configData(model:VehConditionModel)  {
        vehicleNameLabel.text = model.plateLicenseNo ?? ""
      
        orgNameLabel.text = model.orgName ?? ""
        driverLabel.text = String(format: "驾驶员:%@", model.driver ?? "未知驾驶员")
        locationLabel.text = String(format: "当前位置:%@", model.address ?? "")
        if model.driverUrl != nil && model.driverUrl != "" {
            let url = URL.init(string: model.driverUrl ?? "")
            iconImageView.sd_setImage(with: url, completed: nil)
        }
        
        if model.modelName != nil {
             modelName.isHidden = false
              modelName.text = model.modelName ?? ""
        }else {
             modelName.isHidden = true
             modelName.text = ""
        }
        
    }
    
   
      
    
    func configRectCorner(view: UIView, corner: UIRectCorner, radii: CGSize) -> CALayer {
        let maskPath = UIBezierPath.init(roundedRect: view.bounds, byRoundingCorners: corner, cornerRadii: radii)
        let maskLayer = CAShapeLayer.init()
        maskLayer.frame = view.bounds
        maskLayer.path = maskPath.cgPath
        return maskLayer
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        iconImageView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self.snp.top).offset(20)
            make.size.equalTo(CGSize(width: 80, height: 100))
        }
        vehicleNameLabel.snp.makeConstraints { (make) in
            make.left.equalTo(iconImageView.snp.right).offset(8)
            make.top.equalTo(self.snp.top).offset(30)
        }
        
        modelName.snp.makeConstraints { (make) in
            make.left.equalTo(vehicleNameLabel.snp.right).offset(5)
            make.centerY.equalTo(vehicleNameLabel)
              make.width.greaterThanOrEqualTo(50)
            make.height.equalTo(16)
        }
        orgNameLabel.snp.makeConstraints { (make) in
            make.left.equalTo(modelName.snp.right).offset(5)
            make.centerY.equalTo(vehicleNameLabel)
        }
        
        driverLabel.snp.makeConstraints { (make) in
            make.left.equalTo(iconImageView.snp.right).offset(8)
            make.top.equalTo(vehicleNameLabel.snp.bottom).offset(4)
        }

        locationLabel.snp.makeConstraints { (make) in
            make.top.equalTo(driverLabel.snp.bottom).offset(16)
            make.left.equalTo(iconImageView.snp.right).offset(8)
            make.right.equalTo(self.snp.right).offset(-16)
        }
        
        
        lineView.snp.makeConstraints { (make) in
            make.top.equalTo(iconImageView.snp.bottom).offset(10)
            make.left.equalTo(self.snp.left).offset(18)
            make.size.equalTo(CGSize(width: KW - 36, height: 1))
        }
        
        reportBtn.snp.makeConstraints { (make) in
            make.top.equalTo(lineView.snp.bottom).offset(14)
            make.left.equalTo(self.snp.left).offset(0)
            make.size.equalTo(CGSize(width: KW/4.0, height: 65))
            
        }
        
        
        reportImageView.snp.makeConstraints { (make) in
            make.top.equalTo(reportBtn.snp.top).offset(0)
            make.centerX.equalTo(reportBtn)
        }
        
        reportLabel.snp.makeConstraints { (make) in
            make.top.equalTo(reportImageView.snp.bottom).offset(5)
            make.centerX.equalTo(reportBtn)
        }
        
        
        telBtn.snp.makeConstraints { (make) in
            make.top.equalTo(lineView.snp.bottom).offset(14)
            make.left.equalTo(reportBtn.snp.right).offset(0)
            make.size.equalTo(CGSize(width: KW/4.0, height: 65))
            
        }
        
        telImageView.snp.makeConstraints { (make) in
            make.top.equalTo(reportBtn.snp.top).offset(0)
            make.centerX.equalTo(telBtn)
        }
        
        telLabel.snp.makeConstraints { (make) in
            make.top.equalTo(telImageView.snp.bottom).offset(5)
            make.centerX.equalTo(telBtn)
        }
        
        videoView.snp.makeConstraints { (make) in
            make.top.equalTo(lineView.snp.bottom).offset(14)
            make.left.equalTo(telBtn.snp.right).offset(0)
            make.size.equalTo(CGSize(width: KW/4.0, height: 65))
            
        }
        
        videoImageView.snp.makeConstraints { (make) in
            make.top.equalTo(videoView.snp.top).offset(0)
            make.centerX.equalTo(videoView)
        }
        
        videoLabel.snp.makeConstraints { (make) in
            make.top.equalTo(videoImageView.snp.bottom).offset(5)
            make.centerX.equalTo(videoView)
        }
        
        chatView.snp.makeConstraints { (make) in
            make.top.equalTo(lineView.snp.bottom).offset(14)
            make.left.equalTo(videoView.snp.right).offset(0)
            make.size.equalTo(CGSize(width: KW/4.0, height: 65))
            
        }
        
        
        chatImageView.snp.makeConstraints { (make) in
            make.top.equalTo(chatView.snp.top).offset(0)
            make.centerX.equalTo(chatView)
        }
        
        chatLabel.snp.makeConstraints { (make) in
            make.top.equalTo(chatImageView.snp.bottom).offset(5)
            make.centerX.equalTo(chatView)
        }
 
    }
       
       required init?(coder aDecoder: NSCoder) {
           fatalError("init(coder:) has not been implemented")
       }

}
