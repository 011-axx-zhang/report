//
//  VehicleOptionView.swift
//  NewGCB
//
//  Created by YTKJ on 2020/2/22.
//  Copyright © 2020 YTKJ. All rights reserved.
//

import UIKit

class VehicleOptionView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
