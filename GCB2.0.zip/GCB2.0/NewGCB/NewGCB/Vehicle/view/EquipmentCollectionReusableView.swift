//
//  EquipmentCollectionReusableView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/12.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class EquipmentCollectionReusableView: UICollectionReusableView {
    var label:UILabel!
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.createUI()
        self.updateConstraints()
    }
    
    private func createUI() {
        label = UILabel()
        label .font = UIFont.boldSystemFont(ofSize: 15)
        label.textAlignment = .left
        self.addSubview(label)
    }
    override func updateConstraints() {
        super.updateConstraints()
        label .snp.makeConstraints {[unowned self] (make) in
            make.left.equalTo(self.snp.left).offset(12)
            make.centerY.equalToSuperview()
        }
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
