//
//  VehicelReportBottomCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2020/2/12.
//  Copyright © 2020 YTKJ. All rights reserved.
//

import UIKit

class VehicelReportBottomCollectionViewCell: UICollectionViewCell {
    var titleLabel:UILabel!
    var firstView:UIView!
    var seconView:UIView!
    var thirdView:UIView!
    var fourView:UIView!
    var mileageValueLabel:UILabel!
    var mileageLabel:UILabel!
    var riskLabel:UILabel!
    var riskValueLabel:UILabel!
    var rijianIcon:UIImageView!
    var rijianTimeLabel:UILabel!
    var rijianMileLabel:UILabel!
    var rijianMileValueLabel:UILabel!
    var yejianIcon:UIImageView!
    var yejiianTimeLabel:UILabel!
    var yejiianMileLabel:UILabel!
    var yejiianMileValueLabel:UILabel!
    var mileBottomBgView:UIView!
    
    var yunYingtitleLabel:UILabel!
    var yunYingfirstView:UIView!
    var yunYingseconView:UIView!
    var yunyingDaysLabel:UILabel!
    var yunyingDayValueLabel:UILabel!
    var yunyinglvLabel:UILabel!
    var yunyinglvValueLabel:UILabel!
    var rijunmileLabel:UILabel!
    var rijunmileValueLabel:UILabel!
    var rijuntimeLabel:UILabel!
    var rijuntimeValueLabel:UILabel!
    
    var yunyingBottomBgView:UIView!
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        initView()
        yunyingInitView()
        updateConstraints()
    }
    
    
    func initView(){
        titleLabel = UILabel()
        titleLabel.font = UIFont.boldSystemFont(ofSize: 17)
        titleLabel.text = "行驶里程"
        titleLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(titleLabel)
        
        firstView = UIView()
        firstView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        firstView.layer.cornerRadius = 4
        self.contentView.addSubview(firstView)
        
        seconView = UIView()
        seconView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        seconView.layer.cornerRadius = 4
        self.contentView.addSubview( seconView)
        
        
        thirdView = UIView()
        thirdView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        thirdView.layer.cornerRadius = 4
        self.contentView.addSubview(thirdView)
        
        fourView = UIView()
        fourView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        fourView.layer.cornerRadius = 4
        self.contentView.addSubview(fourView)
        
        mileageValueLabel = UILabel()
        mileageValueLabel.text = "23.32"
        mileageValueLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        mileageValueLabel.font = UIFont.systemFont(ofSize: 20)
        firstView.addSubview(mileageValueLabel)
        mileageLabel = UILabel()
        mileageLabel.text = "累计行驶公里"
        mileageLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        mileageLabel.font = UIFont.systemFont(ofSize: 13)
        firstView.addSubview(mileageLabel)
        
        
        riskValueLabel = UILabel()
        riskValueLabel.text = "1.4"
        riskValueLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        riskValueLabel.font = UIFont.systemFont(ofSize: 20)
        seconView.addSubview(riskValueLabel)
        riskLabel = UILabel()
        riskLabel.text = "百公里高/中风险数"
        riskLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        riskLabel.font = UIFont.systemFont(ofSize: 13)
        seconView.addSubview(riskLabel)
        
        rijianIcon = UIImageView()
        rijianIcon.image = UIImage(named: "baobiao_rijian")
        thirdView.addSubview(rijianIcon)
        rijianTimeLabel = UILabel()
        rijianTimeLabel.text = "(7:00～21:00)"
        rijianTimeLabel.font = UIFont.systemFont(ofSize: 10)
        rijianTimeLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        thirdView.addSubview(rijianTimeLabel)
        rijianMileValueLabel = UILabel()
        rijianMileValueLabel.text = "1.56"
        rijianMileValueLabel.font = UIFont.systemFont(ofSize: 20)
        rijianMileValueLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        thirdView.addSubview(rijianMileValueLabel)
        rijianMileLabel = UILabel()
        rijianMileLabel.text = "日间行驶公里数"
        rijianMileLabel.font = UIFont.systemFont(ofSize: 13)
        rijianMileLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        thirdView.addSubview(rijianMileLabel)
        
        yejianIcon = UIImageView()
        yejianIcon.image = UIImage(named: "baobiao_yejian")
        fourView.addSubview(yejianIcon)
        yejiianTimeLabel = UILabel()
        yejiianTimeLabel.text = "(7:00～21:00)"
        yejiianTimeLabel.font = UIFont.systemFont(ofSize: 10)
        yejiianTimeLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        fourView.addSubview(yejiianTimeLabel)
        yejiianMileValueLabel = UILabel()
        yejiianMileValueLabel.text = "1.56"
        yejiianMileValueLabel.font = UIFont.systemFont(ofSize: 20)
        yejiianMileValueLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        fourView.addSubview(yejiianMileValueLabel)
        yejiianMileLabel = UILabel()
        yejiianMileLabel.text = "日间行驶公里数"
        yejiianMileLabel.font = UIFont.systemFont(ofSize: 13)
        yejiianMileLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        fourView.addSubview(yejiianMileLabel)
        
        mileBottomBgView = UIView()
        mileBottomBgView.backgroundColor = UIColor(hex: "#F0F0F7", alpha: 1.0)
        self.addSubview(mileBottomBgView)
        
        
       
        
    }
    
    
    func configData(model:VehRunningReportModel)  {
        let model1 = model.mils
        mileageValueLabel.text = String(format: "%.2f", model1?.milsSum ?? 0)
        riskValueLabel.text = String(format: "%.2f", model1?.riskPerHundred ?? 0)
        rijianMileValueLabel.text = String(format: "%.2f", model1?.milsDay ?? 0)
        yejiianMileValueLabel.text = String(format: "%.2f", model1?.milsNight ?? 0)
        
        let model2 = model.runningInfo
        yunyingDayValueLabel.text = String(format: "%d", model2?.days ?? 0)
        yunyinglvValueLabel.text = String(format: "%.1f%@", (model2?.rate ?? 0) * 100 ,"%")
        rijunmileValueLabel.text = String(format: "%.2f", model2?.milsPerDay ?? 0)
        rijuntimeValueLabel.text = String(format: "%.2f", model2?.durationPerDay ?? 0)
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self.snp.top).offset(12)
        }
        
        firstView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(titleLabel.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 38)/2, height: 68))
        }
        seconView.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.right).offset(8)
            make.top.equalTo(titleLabel.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 38)/2, height: 68))
        }
        
        
        thirdView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(firstView.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 38)/2, height: 84))
        }
        
        fourView.snp.makeConstraints { (make) in
            make.left.equalTo( thirdView.snp.right).offset(8)
            make.top.equalTo(firstView.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 38)/2, height: 84))
        }
        
        
        mileageValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.left).offset(20)
            make.top.equalTo(firstView.snp.top).offset(13)
        }
        mileageLabel.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.left).offset(20)
            make.top.equalTo(mileageValueLabel.snp.bottom).offset(4)
        }
        
        
        riskValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(seconView.snp.left).offset(26)
            make.top.equalTo(seconView.snp.top).offset(13)
        }
        riskLabel.snp.makeConstraints { (make) in
            make.left.equalTo(seconView.snp.left).offset(26)
            make.top.equalTo(riskValueLabel.snp.bottom).offset(4)
        }
        
        rijianIcon.snp.makeConstraints { (make) in
            make.left.equalTo(thirdView.snp.left).offset(5)
            make.top.equalTo(thirdView.snp.top).offset(13)
            make.size.equalTo(CGSize(width: 20, height: 20))
        }
        rijianTimeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(rijianIcon.snp.right).offset(2)
            make.top.equalTo(thirdView.snp.top).offset(13)
        }
        rijianMileValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(thirdView.snp.left).offset(26)
            make.top.equalTo(rijianTimeLabel.snp.bottom).offset(4)
        }
        
        rijianMileLabel.snp.makeConstraints { (make) in
            make.left.equalTo(thirdView.snp.left).offset(26)
            make.top.equalTo(rijianMileValueLabel.snp.bottom).offset(4)
        }
        
        yejianIcon.snp.makeConstraints { (make) in
            make.left.equalTo(fourView.snp.left).offset(5)
            make.top.equalTo(fourView.snp.top).offset(13)
            make.size.equalTo(CGSize(width: 20, height: 20))
        }
        yejiianTimeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(yejianIcon.snp.right).offset(2)
            make.top.equalTo(fourView.snp.top).offset(13)
        }
        yejiianMileValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(fourView.snp.left).offset(26)
            make.top.equalTo(yejiianTimeLabel.snp.bottom).offset(4)
        }
        
        yejiianMileLabel.snp.makeConstraints { (make) in
            make.left.equalTo(fourView.snp.left).offset(26)
            make.top.equalTo(yejiianMileValueLabel.snp.bottom).offset(4)
        }
        
        mileBottomBgView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(0)
            make.top.equalTo(thirdView.snp.bottom).offset(30)
            make.size.equalTo(CGSize(width: KW, height: 20))
        }
        
        
        yunYingtitleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(mileBottomBgView.snp.bottom).offset(10)
        }
        
        yunYingfirstView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(yunYingtitleLabel.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 30), height: 68))
        }
        yunYingseconView.snp.makeConstraints { (make) in
            make.left.equalTo(yunYingfirstView.snp.left).offset(0)
            make.top.equalTo(yunYingfirstView.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 30), height: 68))
        }
        
        yunyingDayValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(yunYingfirstView.snp.left).offset(30)
            make.top.equalTo(yunYingfirstView.snp.top).offset(14)
        }
        yunyingDaysLabel.snp.makeConstraints { (make) in
            make.left.equalTo(yunYingfirstView.snp.left).offset(30)
            make.top.equalTo(yunyingDayValueLabel.snp.bottom).offset(4)
        }

        yunyinglvValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(yunYingfirstView.snp.centerX).offset(20)
            make.top.equalTo(yunYingfirstView.snp.top).offset(14)
        }

        yunyinglvLabel.snp.makeConstraints { (make) in
            make.left.equalTo(yunyinglvValueLabel.snp.left).offset(0)
            make.top.equalTo(yunyinglvValueLabel.snp.bottom).offset(4)
        }

        rijunmileValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(yunYingseconView.snp.left).offset(30)
            make.top.equalTo(yunYingseconView.snp.top).offset(14)
        }
        rijunmileLabel.snp.makeConstraints { (make) in
            make.left.equalTo(yunYingseconView.snp.left).offset(30)
            make.top.equalTo(rijunmileValueLabel.snp.bottom).offset(4)
        }



        rijuntimeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(yunYingfirstView.snp.centerX).offset(20)
            make.top.equalTo(rijuntimeValueLabel.snp.bottom).offset(4)
        }

        rijuntimeValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(rijuntimeLabel.snp.left).offset(0)
            make.top.equalTo(yunYingseconView.snp.top).offset(14)
        }
        
        
        yunyingBottomBgView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(0)
            make.top.equalTo(yunYingseconView.snp.bottom).offset(30)
            make.size.equalTo(CGSize(width: KW, height: 20))
        }
        
    }
    
    
    
    func yunyingInitView(){
        yunYingtitleLabel = UILabel()
        yunYingtitleLabel.font = UIFont.boldSystemFont(ofSize: 17)
        yunYingtitleLabel.text = "运营情况"
        yunYingtitleLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(yunYingtitleLabel)
        
        yunYingfirstView = UIView()
        yunYingfirstView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        yunYingfirstView.layer.cornerRadius = 4
        self.contentView.addSubview(yunYingfirstView)
        
        yunYingseconView = UIView()
        yunYingseconView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        yunYingseconView.layer.cornerRadius = 4
        self.contentView.addSubview(yunYingseconView)
        
        yunyingDayValueLabel = UILabel()
        yunyingDayValueLabel.font = UIFont.systemFont(ofSize: 20)
        yunyingDayValueLabel.text = "30"
        yunyingDayValueLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        yunYingfirstView.addSubview(yunyingDayValueLabel)
        yunyingDaysLabel = UILabel()
        yunyingDaysLabel.font = UIFont.systemFont(ofSize: 13)
        yunyingDaysLabel.text = "运营天数(天)"
        yunyingDaysLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        yunYingfirstView.addSubview(yunyingDaysLabel)
        yunyinglvValueLabel = UILabel()
        yunyinglvValueLabel.font = UIFont.systemFont(ofSize: 20)
        yunyinglvValueLabel.text = "98.2%"
        yunyinglvValueLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        yunYingfirstView.addSubview(yunyinglvValueLabel)
        yunyinglvLabel = UILabel()
        yunyinglvLabel.font = UIFont.systemFont(ofSize: 13)
        yunyinglvLabel.text = "运营率"
        yunyinglvLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        yunYingfirstView.addSubview(yunyinglvLabel)
        
        
        rijunmileLabel = UILabel()
        rijunmileLabel.font = UIFont.systemFont(ofSize: 13)
        rijunmileLabel.text = "日均行驶公里"
        rijunmileLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        yunYingseconView.addSubview(rijunmileLabel)
        
        rijunmileValueLabel = UILabel()
        rijunmileValueLabel.font = UIFont.systemFont(ofSize: 20)
        rijunmileValueLabel.text = "348.2"
        rijunmileValueLabel.textColor = UIColor(hex: "#36384", alpha: 1.0)
        yunYingseconView.addSubview(rijunmileValueLabel)
        
        rijuntimeValueLabel = UILabel()
        rijuntimeValueLabel.font = UIFont.systemFont(ofSize:20)
        rijuntimeValueLabel.text = "3.2"
        rijuntimeValueLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        yunYingseconView.addSubview(rijuntimeValueLabel)
        
        rijuntimeLabel = UILabel()
        rijuntimeLabel.font = UIFont.systemFont(ofSize: 13)
        rijuntimeLabel.text = "日均行驶时长(小时)"
        rijuntimeLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        yunYingseconView.addSubview(rijuntimeLabel)
        
        
        yunyingBottomBgView = UIView()
        yunyingBottomBgView.backgroundColor = UIColor(hex: "#F0F0F7", alpha: 1.0)
        self.addSubview(yunyingBottomBgView)
     
    }
    
    
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
