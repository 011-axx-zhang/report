//
//  PlayBackAnnotationView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/16.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class PlayBackAnnotationView: MAAnnotationView {

     var bgImageV:UIImageView!
       var imageV:UIImageView!
       var timeLabel:UILabel!
       var odometerLabel:UILabel!
       var speedLabel:UILabel!
       var temperatureImageView:UIImageView!
       var temperatureLabel:UILabel!
       var humidityImageView:UIImageView!
       var humidityLabel:UILabel!
       var batteryVoltageImageView:UIImageView!
       var batteryVoltageLabel:UILabel!

       override init!(annotation: MAAnnotation!, reuseIdentifier: String!) {
           super.init(annotation: annotation, reuseIdentifier: reuseIdentifier)
           imageV=UIImageView()
           imageV.contentMode = .center
           imageV.image = UIImage(named: "green_level_vehicle")
           self.addSubview(imageV)
           
        
           bgImageV=UIImageView()
           bgImageV.contentMode = .scaleToFill
           bgImageV.image = UIImage(named: "palyback_Bg")
         //  bgImageV.image = UIImage(named: "guijihuifang")
           self.addSubview(bgImageV)
           
           timeLabel = UILabel()
           timeLabel.textAlignment = .left
           timeLabel.font = UIFont.systemFont(ofSize: 12)
           bgImageV.addSubview(timeLabel)
           
           odometerLabel = UILabel()
           odometerLabel.textAlignment = .left
           odometerLabel.font = UIFont.systemFont(ofSize: 12)
           bgImageV.addSubview(odometerLabel)
           
           speedLabel = UILabel()
           speedLabel.textAlignment = .left
           speedLabel.font = UIFont.systemFont(ofSize: 12)
           bgImageV.addSubview(speedLabel)
           
           temperatureImageView = UIImageView()
           temperatureImageView.image = UIImage(named: "track_temp")
           temperatureImageView.contentMode = .center
           bgImageV.addSubview(temperatureImageView)
           
           temperatureLabel = UILabel()
           temperatureLabel.font = UIFont.systemFont(ofSize: 12)
           bgImageV.addSubview(temperatureLabel)
           
           humidityImageView = UIImageView()
           humidityImageView.image = UIImage(named: "track_shidu")
           humidityImageView.contentMode = .center
           bgImageV.addSubview(humidityImageView)
           
           humidityLabel = UILabel()
           humidityLabel.font = UIFont.systemFont(ofSize: 12)
           bgImageV.addSubview(humidityLabel)
           
           batteryVoltageImageView = UIImageView()
           batteryVoltageImageView.image = UIImage(named: "track_dianping")
           batteryVoltageImageView.contentMode = .center
           bgImageV.addSubview(batteryVoltageImageView)
           
           batteryVoltageLabel = UILabel()
           batteryVoltageLabel.font = UIFont.systemFont(ofSize: 12)
           bgImageV.addSubview(batteryVoltageLabel)
           

           
           let pad=20
           
           
           timeLabel.snp.makeConstraints { (make ) in
               make.left.equalTo(bgImageV.snp.left).offset(pad)
               make.top.equalTo(bgImageV).offset(20)
           }
           odometerLabel.snp.makeConstraints { (make ) in
               make.left.equalTo(bgImageV.snp.left).offset(pad)
               make.top.equalTo(timeLabel.snp.bottom).offset(20)
           }
           speedLabel.snp.makeConstraints { (make ) in
               make.left.equalTo(odometerLabel.snp.right).offset(10)
               make.top.equalTo(timeLabel.snp.bottom).offset(20)
           }
           
           temperatureImageView.snp.makeConstraints { (make ) in
               make.left.equalTo(bgImageV.snp.left).offset(pad)
               make.size.equalTo(CGSize(width: 7, height: 14))
               make.top.equalTo(odometerLabel.snp.bottom).offset(8)
           }
           
           temperatureLabel.snp.makeConstraints { (make ) in
               make.left.equalTo( temperatureImageView.snp.right).offset(4)
               make.centerY.equalTo(temperatureImageView)
           }
           humidityImageView.snp.makeConstraints { (make ) in
               make.left.equalTo(temperatureLabel.snp.right).offset(20)
               make.size.equalTo(CGSize(width: 12, height: 10))
               make.centerY.equalTo(temperatureImageView)
           }
           humidityLabel.snp.makeConstraints { (make ) in
               make.left.equalTo(humidityImageView.snp.right).offset(4)
               make.centerY.equalTo(temperatureImageView)
           }
           batteryVoltageImageView.snp.makeConstraints { (make ) in
               make.left.equalTo(humidityLabel.snp.right).offset(20)
               make.size.equalTo(CGSize(width: 12, height: 10))
               make.centerY.equalTo(temperatureImageView)
           }
           batteryVoltageLabel.snp.makeConstraints { (make ) in
               make.left.equalTo(batteryVoltageImageView.snp.right).offset(4)
               make.centerY.equalTo(temperatureImageView)
           }

           
        bgImageV.snp.makeConstraints { (make ) in
            make.top.equalTo(self.snp.top)
            make.leading.equalTo(self.snp.leading)
            make.trailing.equalTo(self.snp.trailing)
          // make.bottom.equalTo(temperatureLabel.snp.bottom).offset(30)
            make.height.equalTo(120)
        }
        
        
        self.snp.makeConstraints { (make ) in
            make.width.equalTo(255)
            make.height.equalTo(180)
        }

        imageV.snp.makeConstraints { (make ) in
            make.top.equalTo(bgImageV.snp.bottom).offset(0)
            make.centerX.equalTo(bgImageV.snp.centerX).offset(0)
            make.size.equalTo(CGSize(width: 38, height: 55))
        }
           
           imageV.isUserInteractionEnabled=false
           bgImageV.isUserInteractionEnabled=false
           timeLabel.isUserInteractionEnabled = false
           odometerLabel.isUserInteractionEnabled = false
           speedLabel.isUserInteractionEnabled = false
           temperatureImageView.isUserInteractionEnabled = false
           temperatureLabel.isUserInteractionEnabled = false
           humidityImageView.isUserInteractionEnabled = false
           humidityLabel.isUserInteractionEnabled = false
           batteryVoltageImageView.isUserInteractionEnabled = false
           batteryVoltageLabel.isUserInteractionEnabled = false
           
           
       }
       
       required init?(coder aDecoder: NSCoder) {
           fatalError("init(coder:) has not been implemented")
       }
       //设置信息,改变角度
    func setModel (tspe :VehHisTrackModel!)  {
       
      
        guard let tsp  = tspe else { return }
        timeLabel.text = tsp.time
        if tspe.milsToday == nil {
            odometerLabel.text = String(format: "今日里程:%@km", "--")
        }else {
            odometerLabel.text = String(format: "今日里程:%.2fkm", tspe?.milsToday ?? 0.0)
        }
        
        speedLabel.text = String(format: "时速:%.2fkm/h", tspe?.speed ?? 0.0)
        if tsp.temperature != nil  {
            temperatureLabel.text = String(format: "%.1f℃", tsp.temperature ?? 0.0)
        }else {
            temperatureLabel.text = String(format: "%@","--")
        }
        
        
        
        
        if tsp.humidity != nil  {
             humidityLabel.text = String(format: "%.1f%RH", tsp.humidity ?? 0.0)
        }else {
            humidityLabel.text = String(format: "%@", "--")
        }
        if tsp.voltage != nil {
           batteryVoltageLabel.text = String(format: "%.1fV", tsp.voltage ?? 0.0)
        }else {
             batteryVoltageLabel.text = String(format: "%@", "--")
        }
       
        
        
        
//        if tsp.temperatureDeviceStatus == 1{
//            bottomTemperaIcon.image = UIImage(named: "track_green_wenkong")
//            bottomTemperaIcon.isHidden = false
//            bottomTemperaLabel.isHidden = false
//        }else if tsp.temperatureDeviceStatus == 2 {
//            bottomTemperaIcon.image = UIImage(named: "track_red_wenkong")
//            bottomTemperaIcon.isHidden = false
//            bottomTemperaLabel.isHidden = false
//        }else if tsp.temperatureDeviceStatus == 0 {
//            bottomTemperaIcon.isHidden = true
//            bottomTemperaLabel.isHidden = true
//        }
//
//
//        if tsp.tboxStatus == 1{
//            bottomChekuangIcon.image = UIImage(named: "track_green_jiankong")
//            bottomChekuangIcon.isHidden = false
//            bottomChekuangLabel.isHidden = false
//        }else if tsp.tboxStatus == 2 {
//            bottomChekuangIcon.image = UIImage(named: "track_red_jiankong")
//            bottomChekuangIcon.isHidden = false
//            bottomChekuangLabel.isHidden = false
//        }else if tsp.tboxStatus == 3 {
//            bottomChekuangIcon.isHidden = true
//            bottomChekuangLabel.isHidden = true
//        }
//
//
//        if tsp.adasStatus == 1{
//            bottomFuzhuIcon.image = UIImage(named: "track_green_fuzhu")
//            bottomFuzhuIcon.isHidden = false
//            bottomFuzhuLabel.isHidden = false
//        }else if  tsp.adasStatus == 2{
//            bottomFuzhuIcon.image = UIImage(named: "track_red_fuzhu")
//            bottomFuzhuIcon.isHidden = false
//            bottomFuzhuLabel.isHidden = false
//        }else if  tsp.adasStatus == 0{
//            bottomFuzhuIcon.isHidden = true
//            bottomFuzhuLabel.isHidden = true
//        }
//
        
        
        
        
    }


}
