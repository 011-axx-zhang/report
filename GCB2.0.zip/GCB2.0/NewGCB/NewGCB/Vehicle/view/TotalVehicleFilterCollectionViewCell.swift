//
//  TotalVehicleFilterCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2020/1/16.
//  Copyright © 2020 YTKJ. All rights reserved.
//

import UIKit

class TotalVehicleFilterCollectionViewCell: UICollectionViewCell {
    var contentLabel :UILabel!
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initView()
        updateConstraints()
    }

    func initView(){
        contentLabel = UILabel()
        contentLabel.text = "冰徕(上海)"
        contentLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        contentLabel.font = UIFont.systemFont(ofSize: 13)
        self.contentView.addSubview(contentLabel)
        
        
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        contentLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.centerY.equalTo(self)
        }
        
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
