//
//  TrackAnnotationView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/13.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class TrackAnnotationView: MAAnnotationView {
    var bgImageV:UIImageView!
    var imageV:UIImageView!
    var timeLabel:UILabel!
    var odometerLabel:UILabel!
    var speedLabel:UILabel!
    var temperatureImageView:UIImageView!
    var temperatureLabel:UILabel!
    var humidityImageView:UIImageView!
    var humidityLabel:UILabel!
    var batteryVoltageImageView:UIImageView!
    var batteryVoltageLabel:UILabel!
    var lineview:UIView!
    var bottomTemperaIcon:UIImageView!
    var bottomTemperaLabel:UILabel!
    var bottomChekuangIcon:UIImageView!
    var bottomChekuangLabel:UILabel!
    var bottomFuzhuLabel:UILabel!
    var bottomFuzhuIcon:UIImageView!
    
     var totalH: CGFloat = 255
     var  bgH: CGFloat = 190
     var  lineTopH: CGFloat = 35
    
     var  temperatopH: CGFloat = 8
     var  humidityleftW: CGFloat = 20
     var  batteryleftW: CGFloat = 20
    
     var  chekuangleftW: CGFloat = 15
     var  fuzhuleftW: CGFloat = 15
     var  wenkongtopH: CGFloat = 10
    
   
    
    
    
    
    
    override init!(annotation: MAAnnotation!, reuseIdentifier: String!) {
        super.init(annotation: annotation, reuseIdentifier: reuseIdentifier)
        imageV=UIImageView()
        imageV.contentMode = .center
        imageV.image = UIImage(named: "green_level_vehicle")
        self.addSubview(imageV)
        
        bgImageV=UIImageView()
        bgImageV.contentMode = .scaleToFill
        bgImageV.image = UIImage(named: "palyback_Bg")
        self.addSubview(bgImageV)
        
        timeLabel = UILabel()
        timeLabel.textAlignment = .left
        timeLabel.font = UIFont.systemFont(ofSize: 12)
        bgImageV.addSubview(timeLabel)
        
        odometerLabel = UILabel()
        odometerLabel.textAlignment = .left
        odometerLabel.font = UIFont.systemFont(ofSize: 12)
        bgImageV.addSubview(odometerLabel)
        
        speedLabel = UILabel()
        speedLabel.textAlignment = .left
        speedLabel.font = UIFont.systemFont(ofSize: 12)
        bgImageV.addSubview(speedLabel)
        
        temperatureImageView = UIImageView()
        temperatureImageView.image = UIImage(named: "")
        temperatureImageView.contentMode = .center
        bgImageV.addSubview(temperatureImageView)
        
        temperatureLabel = UILabel()
        temperatureLabel.font = UIFont.systemFont(ofSize: 12)
        temperatureLabel.text = ""
        temperatureLabel.isHidden = true
        bgImageV.addSubview(temperatureLabel)
        
        humidityImageView = UIImageView()
        humidityImageView.image = UIImage(named: "")
        humidityImageView.contentMode = .center
        bgImageV.addSubview(humidityImageView)
        
     
        
        humidityLabel = UILabel()
        humidityLabel.font = UIFont.systemFont(ofSize: 12)
        humidityLabel.text = ""
        humidityLabel.isHidden = true
        bgImageV.addSubview(humidityLabel)
        
        batteryVoltageImageView = UIImageView()
        batteryVoltageImageView.image = UIImage(named: "")
        batteryVoltageImageView.contentMode = .center
        bgImageV.addSubview(batteryVoltageImageView)
        
        batteryVoltageLabel = UILabel()
        batteryVoltageLabel.font = UIFont.systemFont(ofSize: 12)
        batteryVoltageLabel.text = ""
        batteryVoltageLabel.isHidden = true
        bgImageV.addSubview(batteryVoltageLabel)
        
        
        bottomTemperaIcon = UIImageView()
        bottomTemperaIcon.image = UIImage(named: "track_wenkong")
        bottomTemperaIcon.contentMode = .center
        bgImageV.addSubview(bottomTemperaIcon)
        bottomTemperaLabel = UILabel()
        bottomTemperaLabel.text = ""
        bottomTemperaLabel.isHidden = true
        bottomTemperaLabel.font = UIFont.systemFont(ofSize: 12)
        bottomTemperaLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        bgImageV.addSubview(bottomTemperaLabel)
        
        bottomChekuangIcon = UIImageView()
        bottomChekuangIcon.image = UIImage(named: "track_jiankong")
        bottomChekuangIcon.contentMode = .center
        bgImageV.addSubview(bottomChekuangIcon)
        bottomChekuangLabel = UILabel()
        bottomChekuangLabel.text = ""
         bottomChekuangLabel.isHidden = true
        bottomChekuangLabel.font = UIFont.systemFont(ofSize: 12)
        bottomChekuangLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        bgImageV.addSubview(bottomChekuangLabel)
        
        
        bottomFuzhuIcon = UIImageView()
        bottomFuzhuIcon.image = UIImage(named: "track_fuzhu")
        bottomFuzhuIcon.contentMode = .center
        bgImageV.addSubview(bottomFuzhuIcon)
        bottomFuzhuLabel = UILabel()
        bottomFuzhuLabel.text = ""
        bottomFuzhuLabel.isHidden = true
        bottomFuzhuLabel.font = UIFont.systemFont(ofSize: 12)
        bottomFuzhuLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        bgImageV.addSubview(bottomFuzhuLabel)
        
        
        lineview = UIView()
        lineview.backgroundColor = UIColor(hex: "#E6E9EE", alpha: 1.0)
        bgImageV.addSubview(lineview)
        
        
     //   let pad=20
        
//
//        timeLabel.snp.makeConstraints { (make ) in
//            make.left.equalTo(bgImageV.snp.left).offset(pad)
//            make.top.equalTo(bgImageV).offset(20)
//        }
//        odometerLabel.snp.makeConstraints { (make ) in
//            make.left.equalTo(bgImageV.snp.left).offset(pad)
//            make.top.equalTo(timeLabel.snp.bottom).offset(24)
//        }
//        speedLabel.snp.makeConstraints { (make ) in
//            make.left.equalTo(odometerLabel.snp.right).offset(10)
//            make.top.equalTo(timeLabel.snp.bottom).offset(24)
//        }
//
//        temperatureImageView.snp.makeConstraints { (make ) in
//            make.left.equalTo(bgImageV.snp.left).offset(pad)
//            //make.size.equalTo(CGSize(width: 7, height: 14))
//            make.top.equalTo(odometerLabel.snp.bottom).offset(8)
//        }
//
//        temperatureLabel.snp.makeConstraints { (make ) in
//            make.left.equalTo( temperatureImageView.snp.right).offset(4)
//            make.centerY.equalTo(temperatureImageView)
//        }
//        humidityImageView.snp.makeConstraints { (make ) in
//            make.left.equalTo(temperatureLabel.snp.right).offset(20)
//            //make.size.equalTo(CGSize(width: 12, height: 10))
//            make.centerY.equalTo(temperatureImageView)
//        }
//        humidityLabel.snp.makeConstraints { (make ) in
//            make.left.equalTo(humidityImageView.snp.right).offset(4)
//            make.centerY.equalTo(temperatureImageView)
//        }
//        batteryVoltageImageView.snp.makeConstraints { (make ) in
//            make.left.equalTo(humidityLabel.snp.right).offset(20)
//           // make.size.equalTo(CGSize(width: 12, height: 10))
//            make.centerY.equalTo(temperatureImageView)
//        }
//        batteryVoltageLabel.snp.makeConstraints { (make ) in
//            make.left.equalTo(batteryVoltageImageView.snp.right).offset(4)
//            make.centerY.equalTo(temperatureImageView)
//        }
//        lineview.snp.makeConstraints { (make) in
//            make.left.equalTo(bgImageV.snp.left).offset(0)
//            make.right.equalTo(bgImageV.snp.right).offset(0)
//            make.top.equalTo(batteryVoltageImageView.snp.bottom).offset(10)
//            make.height.equalTo(1)
//        }
//
//
//        bottomTemperaIcon.snp.makeConstraints { (make) in
//            make.left.equalTo(bgImageV.snp.left).offset(16)
//            make.top.equalTo(lineview.snp.bottom).offset(10)
//            //make.size.equalTo(CGSize(width: 20, height: 20))
//        }
//        bottomTemperaLabel.snp.makeConstraints { (make) in
//            make.left.equalTo(bottomTemperaIcon.snp.right).offset(2)
//            make.centerY.equalTo(bottomTemperaIcon)
//        }
//
//        bottomChekuangIcon.snp.makeConstraints { (make) in
//            make.left.equalTo(bottomTemperaLabel.snp.right).offset(15)
//            make.top.equalTo(lineview.snp.bottom).offset(10)
//           // make.size.equalTo(CGSize(width: 20, height: 20))
//        }
//        bottomChekuangLabel.snp.makeConstraints { (make) in
//            make.left.equalTo(bottomChekuangIcon.snp.right).offset(2)
//            make.centerY.equalTo(bottomChekuangIcon)
//        }
//
//        bottomFuzhuIcon.snp.makeConstraints { (make) in
//            make.left.equalTo(bottomChekuangLabel.snp.right).offset(14)
//            make.top.equalTo(lineview.snp.bottom).offset(10)
//            //make.size.equalTo(CGSize(width: 20, height: 20))
//        }
//        bottomFuzhuLabel.snp.makeConstraints { (make) in
//            make.left.equalTo(bottomFuzhuIcon.snp.right).offset(2)
//            make.centerY.equalTo(bottomFuzhuIcon)
//        }
//
//
//        bgImageV.snp.makeConstraints { (make ) in
//            make.top.equalTo(self.snp.top)
//            make.leading.equalTo(self.snp.leading)
//            make.trailing.equalTo(self.snp.trailing)
//            make.width.equalTo(255)
//            make.bottom.equalTo(bottomChekuangIcon.snp.bottom).offset(25)
//        }
//
//
//        self.snp.makeConstraints { (make ) in
//            make.width.equalTo(255)
//            make.height.equalTo(240)
//        }
//
//        imageV.snp.makeConstraints { (make ) in
//            make.top.equalTo(bgImageV.snp.bottom).offset(0)
//            make.centerX.equalTo(bgImageV.snp.centerX).offset(0)
//            make.size.equalTo(CGSize(width: 38, height: 55))
//        }
        
        imageV.isUserInteractionEnabled=false
        bgImageV.isUserInteractionEnabled=false
        timeLabel.isUserInteractionEnabled = false
        odometerLabel.isUserInteractionEnabled = false
        speedLabel.isUserInteractionEnabled = false
        temperatureImageView.isUserInteractionEnabled = false
        temperatureLabel.isUserInteractionEnabled = false
        humidityImageView.isUserInteractionEnabled = false
        humidityLabel.isUserInteractionEnabled = false
        batteryVoltageImageView.isUserInteractionEnabled = false
        batteryVoltageLabel.isUserInteractionEnabled = false
        
        
    }
    
    
    override func updateConstraints() {
        super.updateConstraints()
        
         let pad=20

        timeLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(bgImageV.snp.left).offset(pad)
            make.top.equalTo(bgImageV).offset(20)
            make.height.equalTo(20)
        }
        odometerLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(bgImageV.snp.left).offset(pad)
            make.top.equalTo(timeLabel.snp.bottom).offset(20)
            make.height.equalTo(20)
        }
        speedLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(odometerLabel.snp.right).offset(10)
            make.centerY.equalTo(odometerLabel)
        }
        
        temperatureImageView.snp.makeConstraints { (make ) in
            make.left.equalTo(bgImageV.snp.left).offset(18)
            make.top.equalTo(odometerLabel.snp.bottom).offset(temperatopH)
        }
        
        temperatureLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(temperatureImageView.snp.right).offset(2)
            make.centerY.equalTo(temperatureImageView)
        }
        humidityImageView.snp.makeConstraints { (make ) in
            make.left.equalTo(temperatureLabel.snp.right).offset(humidityleftW)
             make.top.equalTo(odometerLabel.snp.bottom).offset(temperatopH + 2)
        }
        humidityLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(humidityImageView.snp.right).offset(2)
            make.centerY.equalTo(humidityImageView)
        }
        batteryVoltageImageView.snp.makeConstraints { (make ) in
            make.left.equalTo(humidityLabel.snp.right).offset(batteryleftW)
            make.top.equalTo(odometerLabel.snp.bottom).offset(temperatopH + 2)
        }
        batteryVoltageLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(batteryVoltageImageView.snp.right).offset(2)
            make.centerY.equalTo(batteryVoltageImageView)
        }
        
        lineview.snp.makeConstraints { (make) in
            make.left.equalTo(bgImageV.snp.left).offset(0)
            make.right.equalTo(bgImageV.snp.right).offset(0)
            make.top.equalTo(speedLabel.snp.bottom).offset(lineTopH)
            make.height.equalTo(1)
        }
        
        
        bottomTemperaIcon.snp.makeConstraints { (make) in
            make.left.equalTo(bgImageV.snp.left).offset(18)
            make.top.equalTo(lineview.snp.bottom).offset(wenkongtopH)
        }
        bottomTemperaLabel.snp.makeConstraints { (make) in
            make.left.equalTo(bottomTemperaIcon.snp.right).offset(2)
            make.centerY.equalTo(bottomTemperaIcon)
        }
        
        bottomChekuangIcon.snp.makeConstraints { (make) in
            make.left.equalTo(bottomTemperaLabel.snp.right).offset(chekuangleftW)
            make.top.equalTo(lineview.snp.bottom).offset(wenkongtopH)
        }
        bottomChekuangLabel.snp.makeConstraints { (make) in
            make.left.equalTo(bottomChekuangIcon.snp.right).offset(2)
            make.centerY.equalTo(bottomChekuangIcon)
        }
        
        bottomFuzhuIcon.snp.makeConstraints { (make) in
            make.left.equalTo(bottomChekuangLabel.snp.right).offset(fuzhuleftW)
            make.top.equalTo(lineview.snp.bottom).offset(wenkongtopH)
        }
        bottomFuzhuLabel.snp.makeConstraints { (make) in
            make.left.equalTo(bottomFuzhuIcon.snp.right).offset(2)
            make.centerY.equalTo(bottomFuzhuIcon)
        }
        
        
        bgImageV.snp.makeConstraints { (make ) in
            make.top.equalTo(self.snp.top)
            make.leading.equalTo(self.snp.leading)
            make.trailing.equalTo(self.snp.trailing)
            make.width.equalTo(255)
            make.height.equalTo(bgH)
        }
        
        
        self.snp.makeConstraints { (make ) in
            make.width.equalTo(255)
            make.height.equalTo(totalH)
        }
        
        imageV.snp.makeConstraints { (make ) in
            make.top.equalTo(bgImageV.snp.bottom).offset(0)
            make.centerX.equalTo(bgImageV.snp.centerX).offset(0)
            make.size.equalTo(CGSize(width: 38, height: 55))
        }
   
    }
    
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //设置信息,改变角度
    func setModel (tspe :VehConditionModel!)  {
        guard let tsp  = tspe else { return }
        if tsp.isRunning == true {
            imageV.image = UIImage(named: "green_level_vehicle")
        }else {
            imageV.image = UIImage(named: "gray_level_vehicle")
            
        }
        timeLabel.text = tsp.time
        if tspe.milsToday == nil {
            odometerLabel.text = String(format: "今日里程:%@km", "--")
        }else {
            odometerLabel.text = String(format: "今日里程:%.2fkm", tspe?.milsToday ?? 0.0)
        }
        
        speedLabel.text = String(format: "时速:%.2fkm/h", tspe?.speed ?? 0.0)
        
        

        self.setSep(tsp: tsp)
           
        if tsp.temperatureDeviceStatus != 0 {
            if tsp.temperature != nil  {
                temperatureLabel.text = String(format: "%.1f℃", tsp.temperature ?? 0.0)
            }else {
                temperatureLabel.text = String(format: "%@","--")
            }
            
            if tsp.humidity != nil  {
                humidityLabel.text = String(format: "%.1f%RH", tsp.humidity ?? 0.0)
            }else {
                humidityLabel.text = String(format: "%@", "--")
            }
            
            
            humidityImageView.image = UIImage(named: "track_shidu")
            temperatureImageView.image = UIImage(named: "track_temp")
            
            temperatureLabel.isHidden = false
            humidityLabel.isHidden = false
            
            temperatureImageView.isHidden = false
            humidityImageView.isHidden = false
            
            
        }else {
            humidityImageView.image = UIImage(named: "")
            temperatureImageView.image = UIImage(named: "")
            
            temperatureLabel.isHidden = true
            humidityLabel.isHidden = true
            temperatureImageView.isHidden = true
            humidityImageView.isHidden = true
        }
        
       
        if tsp.tboxStatus != 0 {
            if tsp.voltage != nil  {
                batteryVoltageLabel.text = String(format: "%.1fV", tsp.voltage ?? 0.0)
            }else {
                batteryVoltageLabel.text = String(format: "%@", "--")
            }
            batteryVoltageLabel.isHidden = false
            batteryVoltageImageView.isHidden = false
            batteryVoltageImageView.image = UIImage(named: "track_dianping")
        }else {
            batteryVoltageLabel.isHidden = true
            batteryVoltageImageView.isHidden = true
            batteryVoltageImageView.image = UIImage(named: "")
        }
        
        
        
        
        
     
        
        if tsp.temperatureDeviceStatus == 1{
             bottomTemperaIcon.image = UIImage(named: "track_green_wenkong")
             bottomTemperaIcon.isHidden = false
            bottomTemperaLabel.isHidden = false
            bottomTemperaLabel.text = "温控"
         }else if tsp.temperatureDeviceStatus == 2 {
             bottomTemperaIcon.image = UIImage(named: "track_gray_wenkong")
             bottomTemperaIcon.isHidden = false
            bottomTemperaLabel.isHidden = false
            bottomTemperaLabel.text = "温控"
          
         }else if tsp.temperatureDeviceStatus == 0 {
             bottomTemperaIcon.isHidden = true
            bottomTemperaLabel.isHidden = true
            bottomTemperaLabel.text = ""
             
         }else if tsp.temperatureDeviceStatus == 3{
             bottomTemperaIcon.image = UIImage(named: "track_red_wenkong")
             bottomTemperaIcon.isHidden = false
            bottomTemperaLabel.isHidden = false
            bottomTemperaLabel.text = "温控"
          
         }
         
         
         if tsp.tboxStatus == 1{
             bottomChekuangIcon.image = UIImage(named: "track_green_jiankong")
             bottomChekuangIcon.isHidden = false
            bottomChekuangLabel.isHidden = false
             bottomChekuangLabel.text = "车况监控"
         }else if tsp.tboxStatus == 2 {
             bottomChekuangIcon.image = UIImage(named: "track_gray_jiankong")
             bottomChekuangIcon.isHidden = false
            bottomChekuangLabel.isHidden = false
            bottomChekuangLabel.text = "车况监控"
         }else if tsp.tboxStatus == 0 {
             bottomChekuangIcon.isHidden = true
            bottomChekuangLabel.isHidden = true
            bottomChekuangLabel.text = ""
         }else if tsp.tboxStatus == 3 {
             bottomChekuangIcon.image = UIImage(named: "track_red_jiankong")
             bottomChekuangIcon.isHidden = false
            bottomChekuangLabel.isHidden = false
            bottomChekuangLabel.text = "车况监控"
         }
         
         
         if tsp.adasStatus == 1{
             bottomFuzhuIcon.image = UIImage(named: "track_green_fuzhu")
             bottomFuzhuIcon.isHidden = false
            bottomFuzhuLabel.isHidden = false
              bottomFuzhuLabel.text = "辅助驾驶"
         }else if  tsp.adasStatus == 2{
             bottomFuzhuIcon.image = UIImage(named: "track_gray_fuzhu")
             bottomFuzhuIcon.isHidden = false
            bottomFuzhuLabel.isHidden = false
             bottomFuzhuLabel.text = "辅助驾驶"
         }else if  tsp.adasStatus == 0{
             bottomFuzhuIcon.isHidden = true
             bottomFuzhuLabel.isHidden = true
             bottomFuzhuLabel.text = ""
         }else if  tsp.adasStatus == 3{
             bottomFuzhuIcon.image = UIImage(named: "track_red_fuzhu")
             bottomFuzhuIcon.isHidden = false
            bottomFuzhuLabel.isHidden = false
             bottomFuzhuLabel.text = "辅助驾驶"
         }
        
   
        updateConstraints()
    }
    
    //根据不通的情况设置间隔
    func setSep(tsp:VehConditionModel)  {
        if tsp.temperatureDeviceStatus == 0  && tsp.tboxStatus! == 0 && tsp.adasStatus == 0 {
            totalH = 180
            bgH = 110
            lineTopH = 0
            temperatopH = 0
            humidityleftW = 0
            batteryleftW  = 0
            lineview.isHidden = true
        } else  if tsp.temperatureDeviceStatus == 0 && tsp.tboxStatus!  == 0  && tsp.adasStatus != 0{
            totalH = 190
            bgH = 140
            lineTopH = 0
            temperatopH = 0
            chekuangleftW = 0
            fuzhuleftW = 0
            wenkongtopH = 15
            lineview.isHidden = true
        }else if tsp.temperatureDeviceStatus == 0  && tsp.tboxStatus! != 0 && tsp.adasStatus == 0 {
            totalH = 240
            bgH = 170
            lineTopH = 35
            temperatopH = 8
            chekuangleftW = 0
            fuzhuleftW = 0
            wenkongtopH = 10
            humidityleftW = 0
            batteryleftW = 0
            lineview.isHidden = false
        }else if tsp.temperatureDeviceStatus != 0  && tsp.tboxStatus! == 0 && tsp.adasStatus == 0 {
            totalH = 240
            bgH = 170
            lineTopH = 35
            temperatopH = 8
            chekuangleftW = 0
            fuzhuleftW = 0
            wenkongtopH = 10
            humidityleftW = 20
            batteryleftW = 0
            lineview.isHidden = false
        }else if tsp.temperatureDeviceStatus != 0  && tsp.tboxStatus! != 0 && tsp.adasStatus == 0 {
            totalH = 240
            bgH = 170
            lineTopH = 35
            temperatopH = 8
            chekuangleftW = 15
            fuzhuleftW = 0
            wenkongtopH = 10
            humidityleftW = 20
            batteryleftW = 20
            lineview.isHidden = false
        }else if tsp.temperatureDeviceStatus == 0  && tsp.tboxStatus! != 0 && tsp.adasStatus != 0 {
            totalH = 240
            bgH = 170
            lineTopH = 35
            temperatopH = 8
            chekuangleftW = 0
            fuzhuleftW = 15
            wenkongtopH = 10
            humidityleftW = 0
            batteryleftW = 0
            lineview.isHidden = false
        }else if tsp.temperatureDeviceStatus != 0  && tsp.tboxStatus! == 0 && tsp.adasStatus != 0{
            totalH = 240
            bgH = 170
            lineTopH = 35
            temperatopH = 8
            chekuangleftW = 15
            fuzhuleftW = 0
            wenkongtopH = 10
            humidityleftW = 20
            batteryleftW = 20
            lineview.isHidden = false
        }else if tsp.temperatureDeviceStatus != 0  && tsp.tboxStatus! != 0 && tsp.adasStatus != 0{
            totalH = 240
            bgH = 170
            lineTopH = 35
            temperatopH = 8
            chekuangleftW = 15
            fuzhuleftW = 15
            wenkongtopH = 10
            humidityleftW = 20
            batteryleftW = 20
            lineview.isHidden = false
        }else {
            totalH = 240
            bgH = 170
            lineTopH = 35
            temperatopH = 8
            chekuangleftW = 15
            fuzhuleftW = 15
            wenkongtopH = 10
            humidityleftW = 20
            batteryleftW = 20
            lineview.isHidden = false
        }
        

    }
    
    
}
