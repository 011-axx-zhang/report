//
//  YunYingCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/13.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class YunYingCollectionViewCell: UICollectionViewCell {
    var titleLabel:UILabel!
    var firstView:UIView!
    var seconView:UIView!
    var yunyingDaysLabel:UILabel!
    var yunyingDayValueLabel:UILabel!
    var yunyinglvLabel:UILabel!
    var yunyinglvValueLabel:UILabel!
    var rijunmileLabel:UILabel!
    var rijunmileValueLabel:UILabel!
    var rijuntimeLabel:UILabel!
    var rijuntimeValueLabel:UILabel!
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        initView()
        updateConstraints()
    }
    
    
    func initView(){
        titleLabel = UILabel()
        titleLabel.font = UIFont.boldSystemFont(ofSize: 17)
        titleLabel.text = "运营情况"
        titleLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(titleLabel)
        
        firstView = UIView()
        firstView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        firstView.layer.cornerRadius = 4
        self.contentView.addSubview(firstView)
        
        seconView = UIView()
        seconView.backgroundColor = UIColor(hex: "#F5F5FB", alpha: 1.0)
        seconView.layer.cornerRadius = 4
        self.contentView.addSubview( seconView)
        
        yunyingDayValueLabel = UILabel()
        yunyingDayValueLabel.font = UIFont.systemFont(ofSize: 20)
        yunyingDayValueLabel.text = "30"
        yunyingDayValueLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        firstView.addSubview(yunyingDayValueLabel)
        yunyingDaysLabel = UILabel()
        yunyingDaysLabel.font = UIFont.systemFont(ofSize: 13)
        yunyingDaysLabel.text = "运营天数(天)"
        yunyingDaysLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
       firstView.addSubview(yunyingDaysLabel)
        yunyinglvValueLabel = UILabel()
        yunyinglvValueLabel.font = UIFont.systemFont(ofSize: 20)
        yunyinglvValueLabel.text = "98.2%"
        yunyinglvValueLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        firstView.addSubview(yunyinglvValueLabel)
        yunyinglvLabel = UILabel()
        yunyinglvLabel.font = UIFont.systemFont(ofSize: 13)
        yunyinglvLabel.text = "运营率"
        yunyinglvLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        firstView.addSubview(yunyinglvLabel)
        
        
        rijunmileLabel = UILabel()
        rijunmileLabel.font = UIFont.systemFont(ofSize: 13)
        rijunmileLabel.text = "日均行驶公里"
        rijunmileLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        seconView.addSubview(rijunmileLabel)
        
        rijunmileValueLabel = UILabel()
        rijunmileValueLabel.font = UIFont.systemFont(ofSize: 20)
        rijunmileValueLabel.text = "348.2"
        rijunmileValueLabel.textColor = UIColor(hex: "#36384", alpha: 1.0)
        seconView.addSubview(rijunmileValueLabel)
        
        rijuntimeValueLabel = UILabel()
        rijuntimeValueLabel.font = UIFont.systemFont(ofSize:20)
        rijuntimeValueLabel.text = "3.2"
        rijuntimeValueLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        seconView.addSubview(rijuntimeValueLabel)
        
        rijuntimeLabel = UILabel()
        rijuntimeLabel.font = UIFont.systemFont(ofSize: 13)
        rijuntimeLabel.text = "日均行驶时长(小时)"
        rijuntimeLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        seconView.addSubview(rijuntimeLabel)
   
    }
    
   func configData(model:VehRunningReportModel)  {
        let model = model.runningInfo
        yunyingDayValueLabel.text = String(format: "%d", model?.days ?? 0)
    yunyinglvValueLabel.text = String(format: "%.1f%@", (model?.rate ?? 0) * 100 ,"%")
        rijunmileValueLabel.text = String(format: "%.2f", model?.milsPerDay ?? 0)
        rijuntimeValueLabel.text = String(format: "%.2f", model?.durationPerDay ?? 0)
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self.snp.top).offset(12)
        }
        
        firstView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(titleLabel.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 30), height: 68))
        }
        seconView.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.left).offset(0)
            make.top.equalTo(firstView.snp.bottom).offset(10)
            make.size.equalTo(CGSize(width: (KW - 30), height: 68))
        }
        
        yunyingDayValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.left).offset(30)
            make.top.equalTo(firstView.snp.top).offset(14)
        }
        yunyingDaysLabel.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.left).offset(30)
            make.top.equalTo(yunyingDayValueLabel.snp.bottom).offset(4)
        }
        
        yunyinglvValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.centerX).offset(20)
            make.top.equalTo(firstView.snp.top).offset(14)
        }
        
        yunyinglvLabel.snp.makeConstraints { (make) in
            make.left.equalTo(yunyinglvValueLabel.snp.left).offset(0)
            make.top.equalTo(yunyinglvValueLabel.snp.bottom).offset(4)
        }
        
        rijunmileValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(seconView.snp.left).offset(30)
            make.top.equalTo(seconView.snp.top).offset(14)
        }
        rijunmileLabel.snp.makeConstraints { (make) in
            make.left.equalTo(seconView.snp.left).offset(30)
            make.top.equalTo(rijunmileValueLabel.snp.bottom).offset(4)
        }
        
        

        rijuntimeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(firstView.snp.centerX).offset(20)
            make.top.equalTo(rijuntimeValueLabel.snp.bottom).offset(4)
        }
        
        rijuntimeValueLabel.snp.makeConstraints { (make) in
            make.left.equalTo(rijuntimeLabel.snp.left).offset(0)
            make.top.equalTo(seconView.snp.top).offset(14)
        }
        
    }
    
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
