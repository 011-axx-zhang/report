//
//  VehicleReportDriverImageCollectionViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/12.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class VehicleReportDriverImageCollectionViewCell: UICollectionViewCell {
      
    var driverImageView:UIImageView!
    var driverNameLabel:UILabel!
    
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        initView()
        updateConstraints()
    }
    
    
    
    
    func initView(){
        driverImageView = UIImageView()
       // driverImageView.backgroundColor = UIColor.white
        driverImageView.image = UIImage(named: "vehicle_driverIcon")
        self.contentView.addSubview(driverImageView)
        driverNameLabel = UILabel()
        driverNameLabel.text = "谭谭谭"
        driverNameLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        driverNameLabel.font = UIFont.systemFont(ofSize: 15)
        self.contentView.addSubview(driverNameLabel)
    }
    
    
    func configData(model:VehicleDriversModel)  {
        if model.licenseUrl != nil && model.licenseUrl != "" {
            let url = URL.init(string: model.licenseUrl ?? "")
            self.driverImageView?.sd_setImage(with: url, placeholderImage: UIImage(named: "vehicle_driverIcon"), options: .highPriority, completed: nil)
            
        }else {
            driverImageView.image = UIImage(named: "vehicle_driverIcon")
        }
        driverNameLabel.text = model.driverName ?? ""
    }
    
    
    override func updateConstraints() {
        super.updateConstraints()
        driverImageView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(5)
            make.top.equalTo(self.snp.top).offset(5)
            make.size.equalTo(CGSize(width: 88, height: 114))
        }

        driverNameLabel.snp.makeConstraints { (make) in
            make.top.equalTo(driverImageView.snp.bottom).offset(8)
            make.centerX.equalTo(driverImageView)
        }




    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
