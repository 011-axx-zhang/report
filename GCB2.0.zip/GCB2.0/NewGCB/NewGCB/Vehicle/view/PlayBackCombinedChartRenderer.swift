//
//  PlayBackCombinedChartRenderer.swift
//  NewGCB
//
//  Created by YTKJ on 2020/1/2.
//  Copyright © 2020 YTKJ. All rights reserved.
//

import UIKit
import Charts

class PlayBackCombinedChartRenderer: CombinedChartRenderer {
    
    override init(chart: CombinedChartView, animator: Animator, viewPortHandler: ViewPortHandler) {
        super.init(chart: chart, animator: animator, viewPortHandler: viewPortHandler)
        createRenderers()
        subRenderers=_renderers
    }
    
     internal var _renderers = [DataRenderer]()
    
     internal func createRenderers()
    {
        
        guard let chart = chart else { return }
        
        for order in drawOrder
        {
            switch (order)
            {
            case .bar:
                if chart.barData !== nil
                {
                    
                    _renderers.append(PlayBackBarChartRenderer(dataProvider: chart, animator: animator, viewPortHandler: viewPortHandler))
                }
                break
                
            case .line:
                if chart.lineData !== nil
                {
                    _renderers.append(PlayBackLineChartRenderer(dataProvider: chart, animator: animator, viewPortHandler: viewPortHandler))
                }
                break
                
            case .candle:
                if chart.candleData !== nil
                {
                    _renderers.append(CandleStickChartRenderer(dataProvider: chart, animator: animator, viewPortHandler: viewPortHandler))
                }
                break
                
            case .scatter:
                if chart.scatterData !== nil
                {
                    _renderers.append(ScatterChartRenderer(dataProvider: chart, animator: animator, viewPortHandler: viewPortHandler))
                }
                break
                
            case .bubble:
                if chart.bubbleData !== nil
                {
                    _renderers.append(BubbleChartRenderer(dataProvider: chart, animator: animator, viewPortHandler: viewPortHandler))
                }
                break
            }
        }
        
    }
}
