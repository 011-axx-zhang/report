//
//  VehPlaybackAnnotationView.swift
//  GCB
//
//  Created by YTKJ on 2018/7/13.
//  Copyright © 2018年 YTKJ. All rights reserved.
//  自定义地图标注，暂时没有用到

import UIKit

class VehPlaybackAnnotationView: MAAnnotationView {

    var annContent:UILabel!
    var normalType:UIImageView!     //  未选中
    var selectType:UIImageView!     //  选中
    var endType:UIImageView!        //  结束

    override init!(annotation: MAAnnotation!, reuseIdentifier: String!) {
        super.init(annotation: annotation, reuseIdentifier: reuseIdentifier)
        
        normalType = UIImageView()
        self.addSubview(normalType)
        
        selectType = UIImageView()
        selectType.isHidden = true  //  默认隐藏
        self.addSubview(selectType)
        
        endType = UIImageView()
        endType.isHidden = true //  默认隐藏
        self.addSubview(endType)
        
        annContent = UILabel()
        annContent.textColor = UIColor.white
        annContent.font = UIFont.boldSystemFont(ofSize: 15)
        self.addSubview(annContent)
        
        self.snp.makeConstraints { (make ) in
            make.width.equalTo(38)
            make.height.equalTo(55)
        }
        
        normalType.snp.makeConstraints { (make ) in
            make.centerX.equalTo(self.snp.centerX)
            make.centerY.equalTo(self.snp.centerY)
            make.width.equalTo(30)
            make.height.equalTo(26)
        }
        
        selectType.snp.makeConstraints { (make ) in
            make.centerX.equalTo(self.snp.centerX)
            make.centerY.equalTo(self.snp.centerY)
            make.width.equalTo(34)
            make.height.equalTo(34)
        }
        
        endType.snp.makeConstraints { (make ) in
            make.top.equalTo(self.snp.top)
            make.centerX.equalTo(self.snp.centerX)
            make.width.equalTo(self.snp.width)
            make.height.equalTo(self.snp.height)
        }
        
        annContent.snp.makeConstraints { (make ) in
            make.top.equalTo(self.snp.top)
            make.bottom.equalTo(self.snp.bottom)
            make.centerX.equalTo(self.snp.centerX)
        }
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        print("选中了？？？？")
        if selected {
            normalType.isHidden = true
            selectType.isHidden = false
        }else{
            normalType.isHidden = false
            selectType.isHidden = true
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    //设置信息,改变角度
    func setViewLevel(str : String) -> Void {
        if str == "中风险" {
            normalType.image = UIImage.init(named: "risk_details_medium_triangle_normal")
            selectType.image = UIImage.init(named: "risk_details_medium_triangle_selected")
        }else{
            normalType.image = UIImage.init(named: "risk_details_heigher_triangle_normal")
            selectType.image = UIImage.init(named: "risk_details_heigher_triangle_selected")
        }
    }
    func setViewContentText(str:String) -> Void {
        annContent.text = str
    }
    /*
    func setModel (tspe :PlayBackModel!)  {
        super.updateConstraints()
        guard let tsp  = tspe else { return }
        timeLabel.text = tsp.time
      
        if tspe.odometer == nil {
            odometerLabel.text = String(format: "里程:%@ / %.2fkm", "--" ,tsp.totalMile!)
        }else {
            odometerLabel.text = String(format: "里程:%.2f / %.2fkm", (tspe?.useMile)! ,tsp.totalMile!)
        }
        
       
       speedLabel.text = String(format: "时速:%.2fkm/h", tspe?.speed ?? 0.0)
        batteryVoltageLabel.text = String(format: "%.2fv", tspe?.batteryVoltage ?? 0.0)
        
        
    
        
        if tsp.temperature == nil {
             temperatureLabel.text="--"
        }else {
            if tsp.temperature?.count == 0 {
                temperatureLabel.text="--"
            }else {
                let  ssStr:Array<String> = tspe?.temperature! ?? []
                    //.map(String.init())
                let resultStr = ssStr.joined(separator: " / ")
                temperatureLabel.text = String(format: "%@ %@", resultStr,"℃")
            }
        }

        if tsp.humidity == nil  {
              humidityLabel.text=" --"
        }else {
            if tsp.humidity?.count == 0 {
                humidityLabel.text=" --"
            }else {
                let  ssStr = tspe?.humidity!.map(String.init)
                let resultStr = ssStr?.joined(separator: " / ")
                 humidityLabel.text = String(format: "%@ %@", resultStr!,"%RH")
            }
        }
       
 
        
    }*/

}
