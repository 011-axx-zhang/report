//
//  InsuranceTableViewCell.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/10.
//  Copyright © 2019 YTKJ. All rights reserved.
//  保险通知国旗列表

import UIKit

class InsuranceTableViewCell: UITableViewCell {
    let plate = UILabel.init()              //  车牌
    let time = UILabel.init()               //  时间
    let vehicleType = UILabel.init()        //  车型
    let orgName = UILabel.init()            //  组织名
    let insuranceNumber = UILabel.init()    //  保单号
    let insuranceType = UILabel.init()      //  保险类型
    let insuranceOrg = UILabel.init()       //  保险公司
    let insuranceTime = UILabel.init()      //  到期时间
    let line = UIView.init()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        createUI()
        self .updateConstraints()
        self.backgroundColor = UIColor.white
        self.contentView.backgroundColor = UIColor.white
    }
    
    
    private func createUI() {
        
        plate.textColor = UIColor(hex: "#363847", alpha: 1.0)
        plate.font = UIFont.boldSystemFont(ofSize: 15.0)
        self.contentView.addSubview(plate)
        
        
        time.font = UIFont.systemFont(ofSize: 12)
        time.textAlignment = .center
        self.contentView.addSubview(time)
        
        
        vehicleType.font = UIFont.systemFont(ofSize: 10)
        vehicleType.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        vehicleType.layer.borderColor = UIColor(hex: "#E6E9EE", alpha: 1.0)?.cgColor
        vehicleType.layer.borderWidth = 1
        vehicleType.textAlignment = NSTextAlignment.center
        self.contentView.addSubview(vehicleType)
        
        
        orgName.font = UIFont.systemFont(ofSize: 10)
        orgName.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.contentView.addSubview(orgName)
        
        insuranceNumber.font = UIFont.systemFont(ofSize: 12)
        self.contentView.addSubview(insuranceNumber)
        
        insuranceType.font = UIFont.systemFont(ofSize: 12)
        self.contentView.addSubview(insuranceType)
        
        insuranceOrg.font = UIFont.systemFont(ofSize: 12)
        self.contentView.addSubview(insuranceOrg)
        
        insuranceTime.font = UIFont.systemFont(ofSize: 12)
        self.contentView.addSubview(insuranceTime)
        
        
        line.backgroundColor = UIColor.init(hex: "#E6E9EE", alpha: 1.0)
        self.contentView.addSubview(line)
        
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        
        time.snp.makeConstraints { (make) in
            make.right.equalTo(self.contentView.snp.right).offset(-15)
            make.top.equalTo(self.contentView.snp.top).offset(10)
            make.height.equalTo(16)
        }
        
        plate.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.top.equalTo(self.contentView.snp.top).offset(10)
            make.height.equalTo(21)
        }
        
        vehicleType.snp.makeConstraints { (make) in
            make.left.equalTo(plate.snp.right).offset(4)
            make.centerY.equalTo(plate)
            make.height.equalTo(16)
            make.width.greaterThanOrEqualTo(50)
        }
        
        orgName.snp.makeConstraints { (make) in
            make.centerY.equalTo(vehicleType)
            make.left.equalTo(vehicleType.snp.right).offset(5)
            make.height.equalTo(14)
        }
        
        insuranceNumber.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.top.equalTo(plate.snp.bottom).offset(4)
            make.height.equalTo(17)
            make.width.lessThanOrEqualTo(150)
        }
        
        insuranceType.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.centerX)
            make.top.equalTo(insuranceNumber)
            make.height.equalTo(17)
        }
        
        insuranceOrg.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.top.equalTo(insuranceNumber.snp.bottom).offset(4)
            make.height.equalTo(17)
            make.width.lessThanOrEqualTo(150)
        }
        
        insuranceTime.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.centerX)
            make.top.equalTo(insuranceNumber.snp.bottom).offset(4)
            make.height.equalTo(17)
        }
        
        line.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.bottom.equalTo(self.contentView.snp.bottom).offset(0)
            make.width.equalTo(KW-30)
            make.height.equalTo(1)
        }
    }
    
    func configDataSource (riskData:InsuranceModel) {
        
        plate.text = riskData.plateNo
        vehicleType.text = riskData.model
        orgName.text = "【\(riskData.orgName ?? "")】"
        time.text = riskData.time?.sliceString(11..<16)
        insuranceNumber.text = "保单号:\(riskData.insuranceNo ?? " ")"
        insuranceType.text = "保险类型:\(riskData.type ?? " ")"
        insuranceOrg.text = "保险公司:\(riskData.insuranceCompany ?? " ")"
        insuranceTime.text = "到期时间:\(riskData.expiresDate ?? " ")"
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
