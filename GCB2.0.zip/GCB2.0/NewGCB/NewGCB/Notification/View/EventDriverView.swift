//
//  EventDriverView.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/12.
//  Copyright © 2019 YTKJ. All rights reserved.
//  司机详情页

import UIKit

class EventDriverView: UIView {
    var picker = UIImageView()
    var number = UILabel()
    var type = UILabel()
    var orgName = UILabel()
    var driver = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        setupView()
        updateConstraints()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
    }
    
    func setupView() -> Void {
        picker = UIImageView.init()
//        picker.image = UIImage.init(named: "default_header_portrait")
        self.addSubview(picker)
        
        number.font = UIFont.boldSystemFont(ofSize: 15)
        number.textColor = UIColor.black
        number.textAlignment = NSTextAlignment.left
        self.addSubview(number)
        
        type.font = UIFont.systemFont(ofSize: 10)
        type.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        type.layer.borderColor = UIColor(hex: "#E6E9EE", alpha: 1.0)?.cgColor
        type.layer.borderWidth = 1
        type.textAlignment = NSTextAlignment.center
        self.addSubview(type)
        
        orgName.font = UIFont.systemFont(ofSize: 10)
        orgName.textColor = UIColor.init(hex: "#5C5E74", alpha: 1.0)
        orgName.textAlignment = NSTextAlignment.left
        self.addSubview(orgName)
        
        driver.font = UIFont.boldSystemFont(ofSize: 11)
        driver.textAlignment = NSTextAlignment.left
        driver.text = ""
        self.addSubview(driver)
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        
        picker.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(self.snp.top).offset(16)
            make.width.equalTo(80)
            make.height.equalTo(80)
        }
        
        number.snp.makeConstraints { (make) in
            make.left.equalTo(picker.snp.right).offset(8)
            make.top.equalTo(picker.snp.top).offset(20)
            make.height.equalTo(20)
        }
        
        type.snp.makeConstraints { (make) in
            make.left.equalTo(number.snp.right).offset(4)
            make.top.equalTo(number.snp.top).offset(2)
            make.height.equalTo(16)
            make.width.greaterThanOrEqualTo(50)
        }
        
        orgName.snp.makeConstraints { (make) in
            make.left.equalTo(type.snp.right).offset(4)
            make.top.equalTo(number.snp.top).offset(2)
            make.height.equalTo(14)
        }
        
        driver.snp.makeConstraints { (make) in
            make.left.equalTo(picker.snp.right).offset(8)
            make.top.equalTo(number.snp.bottom).offset(8)
            make.height.equalTo(20)
        }
    }
    
    func setViewData(objc: EventDriverModel) -> Void {
        let url = URL.init(string: objc.image ?? "http://file.56matrix.com")
        picker.sd_setImage(with: url, placeholderImage: UIImage.init(named: "default_vehicle"), options: .delayPlaceholder, completed: nil)
        number.text = objc.number
        type.text = objc.type
        orgName.text = "【\(objc.orgName ?? "")】"
        driver.text = objc.driverName
        driver.font = objc.textFont
        driver.textColor = objc.textColor
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
