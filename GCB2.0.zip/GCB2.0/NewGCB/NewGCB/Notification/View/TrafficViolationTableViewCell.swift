//
//  TrafficViolationTableViewCell.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/10.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class TrafficViolationTableViewCell: UITableViewCell {
    let headPicker = UIImageView.init()     //  头像
    let plate = UILabel.init()              //  车牌
    let time = UILabel.init()               //  时间
    let vehicleType = UILabel.init()        //  车型
    let orgName = UILabel.init()            //  组织名
    let driver = UILabel.init()             //  驾驶员
    let eventTime = UILabel.init()          //  违章事件
    let disposeType = UILabel.init()        //  处理类型
    let eventCause = UILabel.init()         //  违章原因
    let line = UIView.init()
    
    
    
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        createUI()
        self .updateConstraints()
        self.backgroundColor = UIColor.white
        self.contentView.backgroundColor = UIColor.white
    }
    
    
    private func createUI() {
        
        self.contentView.addSubview(headPicker)
        
        
        plate.textColor = UIColor(hex: "#363847", alpha: 1.0)
        plate.font = UIFont.boldSystemFont(ofSize: 15.0)
        self.contentView.addSubview(plate)
        
        
        time.font = UIFont.systemFont(ofSize: 12)
        time.textAlignment = .center
        self.contentView.addSubview(time)
        
        
        vehicleType.font = UIFont.systemFont(ofSize: 10)
        vehicleType.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        vehicleType.layer.borderColor = UIColor(hex: "#E6E9EE", alpha: 1.0)?.cgColor
        vehicleType.layer.borderWidth = 1
        vehicleType.textAlignment = NSTextAlignment.center
        self.contentView.addSubview(vehicleType)
        
        
        orgName.font = UIFont.systemFont(ofSize: 10)
        orgName.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.contentView.addSubview(orgName)
        
        driver.font = UIFont.boldSystemFont(ofSize: 14)
        driver.numberOfLines = 0
        driver.lineBreakMode = .byCharWrapping
        driver.textColor =  UIColor(hex: "#3B3D4C", alpha: 1.0)
        self.contentView.addSubview(driver)
        
        eventTime.font = UIFont.systemFont(ofSize: 12)
        eventTime.numberOfLines = 0
        eventTime.lineBreakMode = .byCharWrapping
        eventTime.textColor =  UIColor(hex: "#5C5E74", alpha: 1.0)
        self.contentView.addSubview(eventTime)
        
        
        disposeType.font = UIFont.boldSystemFont(ofSize: 14)
        disposeType.textColor = UIColor(hex: "#3B3D4C", alpha: 1.0)
        self.contentView.addSubview(disposeType)
        
        eventCause.font = UIFont.systemFont(ofSize: 12)
        eventCause.textColor = UIColor.init(hex: "#5C5E74", alpha: 1.0)
        self.contentView.addSubview(eventCause)
        
        
        line.backgroundColor = UIColor.init(hex: "#E6E9EE", alpha: 1.0)
        self.contentView.addSubview(line)
        
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        
        headPicker.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.top.equalTo(self.contentView.snp.top).offset(10)
            make.width.equalTo(80)
            make.height.equalTo(100)
        }
        
        time.snp.makeConstraints { (make) in
            make.right.equalTo(self.contentView.snp.right).offset(-15)
            make.top.equalTo(self.contentView.snp.top).offset(10)
            make.height.equalTo(16)
        }
        
        plate.snp.makeConstraints { (make) in
            make.left.equalTo(headPicker.snp.right).offset(16)
            make.top.equalTo(self.contentView.snp.top).offset(23)
            make.height.equalTo(21)
        }
        
        vehicleType.snp.makeConstraints { (make) in
            make.left.equalTo(plate.snp.right).offset(4)
            make.centerY.equalTo(plate)
            make.height.equalTo(16)
            make.width.greaterThanOrEqualTo(50)
        }
        
        orgName.snp.makeConstraints { (make) in
            make.centerY.equalTo(vehicleType)
            make.left.equalTo(vehicleType.snp.right).offset(5)
            make.height.equalTo(14)
        }
        
        
        driver.snp.makeConstraints { (make) in
            make.left.equalTo(headPicker.snp.right).offset(16)
            make.top.equalTo(plate.snp.bottom).offset(4)
            make.height.equalTo(19)
        }
        
        eventTime.snp.makeConstraints { (make) in
            make.left.equalTo(headPicker.snp.right).offset(16)
            make.top.equalTo(driver.snp.bottom).offset(4)
            make.height.equalTo(19)
        }
        
        disposeType.snp.makeConstraints { (make) in
            make.top.equalTo(orgName.snp.bottom).offset(8)
            make.right.equalTo(self.contentView.snp.right).offset(-15)
            make.height.equalTo(19)
        }
        
        
        
        eventCause.snp.makeConstraints { (make) in
            make.left.equalTo(headPicker.snp.right).offset(16)
            make.top.equalTo(eventTime.snp.bottom).offset(4)
            make.height.equalTo(17)
            make.width.lessThanOrEqualTo(KW-135)
        }
        
        line.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.bottom.equalTo(self.contentView.snp.bottom).offset(0)
            make.width.equalTo(KW-30)
            make.height.equalTo(1)
        }
    }
    
    func configDataSource (riskData:TrafficViolationModel) {
        
        headPicker.sd_setImage(with: URL.init(string: riskData.driverurl ?? ""), placeholderImage: UIImage.init(named: "vehicle_driverIcon"), options: .highPriority, completed: nil)
        plate.text  = riskData.plateNo
        vehicleType.text = riskData.model
        orgName.text = "【\(riskData.orgName ?? "")】"
        time.text = riskData.time?.sliceString(5..<16)
        
        driver.text = "驾驶员:\(riskData.driverName ?? " ")"
        eventTime.text = "违章时间：\(riskData.time ?? " ")"
        if riskData.status!.contains("已处理已缴费") {
            disposeType.textColor = UIColor.init(hex: "#9395AC", alpha: 1.0)
        }else if riskData.status!.contains("已处理未缴费") {
            disposeType.textColor = UIColor.init(hex: "#1D69F5", alpha: 1.0)
        }else{  //  未处理未缴费
            disposeType.textColor = UIColor.init(hex: "#FB6610", alpha: 1.0)
        }
        disposeType.text = riskData.status
        
        eventCause.text = "违章原因: \(riskData.reason ?? " ")"
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
