//
//  EventTypeView.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/19.
//  Copyright © 2019 YTKJ. All rights reserved.
//  事件类型筛选框

import UIKit

class EventTypeView: UIView,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {

    var collectView :UICollectionView!
    var bottomView:UIView!
    var gestureView:UIView!
    var resetBtn:UIButton!
    var confirmBtn:UIButton!
    var shadowView:UIView!
    var firstArr:Array<String> = []
    var secArr:Array<String> = []
    var thirdArr:Array<String> = []
    @objc var resetClick:(()->Void)?
    @objc var confirmClick:((String, String, String)->Void)?
    @objc var closeClick:(()->Void)?
    var selectStr = ""
    var secondStr = ""
    var thirdStr = ""
    
    
    

    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor =  UIColor(red: 51.0/255.0, green: 51.0/255.0, blue: 51.0/255.0, alpha: 0.5)
        let defaults = UserDefaults.standard
        if defaults.value(forKey: "vehicleSelectStr") == nil {
            selectStr = ""
        }else {
            selectStr = defaults.value(forKey: "vehicleSelectStr") as! String
        }
        if defaults.value(forKey: "vehicleSelectStr_Second") == nil {
            secondStr = ""
        }else {
            secondStr = defaults.value(forKey: "vehicleSelectStr_Second") as! String
        }
        if defaults.value(forKey: "vehicleSelectStr_Third") == nil {
            thirdStr = ""
        }else {
            thirdStr = defaults.value(forKey: "vehicleSelectStr_Third") as! String
        }

        self.configData()
        self.createCollectionView()
        self.createUI()
        updateConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func createCollectionView()  {
        let layout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 5, left: 5,bottom: 5, right: 5)
        layout.minimumInteritemSpacing = 10
        layout.minimumLineSpacing  = 10
        collectView = UICollectionView(frame:CGRect(x: 0, y: 0, width: KW, height: KH*4/7 - 48), collectionViewLayout: layout)
        collectView.backgroundColor = UIColor.white
        collectView.register(VehicleChooseCollectionViewCell.self, forCellWithReuseIdentifier:"vehicleChooseCollectionViewCell")
        collectView!.register(VehicleFilterCollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionHeader, withReuseIdentifier: "vehicleFilterCollectionReusableView")
        collectView!.register(UICollectionReusableView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionFooter, withReuseIdentifier: "nofooterID")
        collectView.delegate = self
        collectView.dataSource = self
        self.addSubview(collectView)
    }
    
    func configData()  {
        firstArr = ["中风险","高风险"]
        thirdArr = ["已干预","未干预"]
    }
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "vehicleChooseCollectionViewCell", for: indexPath) as! VehicleChooseCollectionViewCell
        cell.contentLabel.numberOfLines = 0
        
        if indexPath.section == 0 {
            let str = self.firstArr[indexPath.row]
            if str == selectStr {
                cell.backgroundColor = UIColor(hex: "#D6DEFC", alpha: 1.0)
                cell.contentLabel.textColor = UIColor(hex: "#1D69F5", alpha: 1.0)
                
            }else {
                cell.backgroundColor = UIColor(hex: "#EFF1F6", alpha: 1.0)
                cell.contentLabel.textColor = UIColor(hex: "#2A2B37", alpha: 1.0)
            }
            cell.contentLabel.text = str
        }else if indexPath.section  == 1 {
            let str = self.secArr[indexPath.row]
            cell.contentLabel.text = str
            if str == secondStr {
                cell.backgroundColor = UIColor(hex: "#D6DEFC", alpha: 1.0)
                cell.contentLabel.textColor = UIColor(hex: "#1D69F5", alpha: 1.0)
                
            }else {
                cell.backgroundColor = UIColor(hex: "#EFF1F6", alpha: 1.0)
                cell.contentLabel.textColor = UIColor(hex: "#2A2B37", alpha: 1.0)
            }
        }else {
            let str = self.thirdArr[indexPath.row]
            cell.contentLabel.text = str
            if str == thirdStr {
                cell.backgroundColor = UIColor(hex: "#D6DEFC", alpha: 1.0)
                cell.contentLabel.textColor = UIColor(hex: "#1D69F5", alpha: 1.0)
                
            }else {
                cell.backgroundColor = UIColor(hex: "#EFF1F6", alpha: 1.0)
                cell.contentLabel.textColor = UIColor(hex: "#2A2B37", alpha: 1.0)
            }
        }
       
        return cell
    }
    
    
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 3
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0 {
            return self.firstArr.count
        }else if section == 1 {
            return self.secArr.count
        }else {
            return self.thirdArr.count
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 108 , height: 44)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: KW, height: 40)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        return CGSize(width: KW, height: 0.01)
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String,
                        at indexPath: IndexPath) -> UICollectionReusableView {
        var  filterReusableview:VehicleFilterCollectionReusableView!
        var noneReusableview:UICollectionReusableView!
        if kind == UICollectionView.elementKindSectionHeader{
            filterReusableview = (collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "vehicleFilterCollectionReusableView", for: indexPath) as! VehicleFilterCollectionReusableView)
            //  隐藏右侧 “展开” 选项
            filterReusableview.hiddenRightContent()
            if indexPath.section == 0 {
                filterReusableview.leftLabel.text = "风险等级"
            }else if indexPath.section == 1 {
                filterReusableview.leftLabel.text = "风险事件"
            }else {
                filterReusableview.leftLabel.text = "干预状态"
            }
            return  filterReusableview
            
        }else {
            noneReusableview = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "nofooterID", for: indexPath)
            noneReusableview.backgroundColor = UIColor.white
            return noneReusableview
        }
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if indexPath.section == 0 {
            selectStr =  self.firstArr[indexPath.row]
        }else if indexPath.section  == 1 {
            secondStr =  self.secArr[indexPath.row]
        }else {
           thirdStr =  self.thirdArr[indexPath.row]
        }
        self.collectView.reloadData()
    }
    
    
    func createUI()  {
        bottomView = UIView()
        bottomView.backgroundColor = UIColor.white
        bottomView.layer.shadowOpacity = 0.1
        bottomView.layer.shadowColor =  UIColor(hex: "#363847",alpha: 1.0)?.cgColor
        self.addSubview(bottomView)
        
        resetBtn = UIButton()
        resetBtn.setTitle("重置", for: .normal)
        resetBtn.backgroundColor = UIColor(hex: "#EFF1F6", alpha: 1.0)
        resetBtn.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        resetBtn.setTitleColor(UIColor(hex: "#2A2B37", alpha: 1.0), for: .normal)
        resetBtn.layer.cornerRadius = 5
        resetBtn.addTarget(self, action: #selector(self.resetEvent), for: .touchUpInside)
        bottomView.addSubview(resetBtn)
        confirmBtn = UIButton()
        confirmBtn.setTitle("确定", for: .normal)
        confirmBtn.setTitleColor(UIColor(hex: "#FFFFFF", alpha: 1.0), for: .normal)
        confirmBtn.backgroundColor = UIColor(hex: "#2B72F5", alpha: 1.0)
        confirmBtn.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        confirmBtn.layer.cornerRadius = 5
        confirmBtn.addTarget(self, action: #selector(self.confirmEvent), for: .touchUpInside)
        bottomView.addSubview(confirmBtn)
    
        gestureView = UIView()
        let tapGest = UITapGestureRecognizer.init(target: self, action: #selector(self.tapBackgroundView))
        gestureView.addGestureRecognizer(tapGest)
        self.addSubview(gestureView)
    }
    
    
    @objc  func resetEvent()  {
        let defaults = UserDefaults.standard
        defaults.setValue("", forKey: "vehicleSelectStr")
        defaults.setValue("", forKey: "vehicleSelectStr_Second")
        defaults.setValue("", forKey: "vehicleSelectStr_Third")
        
        selectStr = ""
        secondStr = ""
        thirdStr = ""
        
        self.collectView.reloadData()
        self.resetClick?()
    }
    
    @objc  func confirmEvent()  {
        let defaults = UserDefaults.standard
        defaults.setValue(selectStr, forKey: "vehicleSelectStr")
        defaults.setValue(secondStr, forKey: "vehicleSelectStr_Second")
        defaults.setValue(thirdStr, forKey: "vehicleSelectStr_Third")
        
//        print("选中的条件 \(selectStr) \(secondStr) \(thirdStr)")
        self.confirmClick?(selectStr,secondStr,thirdStr)
        
    }
    
    @objc func tapBackgroundView(){
        self.closeClick?()
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        bottomView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(0)
            make.top.equalTo(self.snp.top).offset(KH*4/7 - 48)
            make.size.equalTo(CGSize(width: KW, height: 48))
        }
        
        resetBtn.snp.makeConstraints { (make) in
            make.left.equalTo(bottomView.snp.left).offset(15)
            make.centerY.equalTo(bottomView)
            make.size.equalTo(CGSize(width: (KW - 38)/2, height: 35))
        }
        
        confirmBtn.snp.makeConstraints { (make) in
            make.right.equalTo(bottomView.snp.right).offset(-15)
            make.centerY.equalTo(bottomView)
            make.size.equalTo(CGSize(width: (KW - 38)/2, height: 35))
        }
        
        gestureView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left)
            make.top.equalTo(bottomView.snp.bottom)
            make.width.equalTo(KW)
            make.bottom.equalTo(self.snp.bottom)
        }
     
    }

}
