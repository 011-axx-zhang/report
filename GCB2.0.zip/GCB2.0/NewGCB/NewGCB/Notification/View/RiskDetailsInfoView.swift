//
//  RiskDetailsInfoView.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/16.
//  Copyright © 2019 YTKJ. All rights reserved.
//  事故详情面板，显示的是该事件的具体信息

import UIKit
import BMPlayer

protocol RiskDetailsInfoViewDelegate:NSObjectProtocol {
    func followDriver(status: Bool)     //  关注司机
    func followCar(status: Bool)        //  关注车辆
    func imageViewDidScroll(index:Int)  //  滑动图片事件
}

class RiskDetailsInfoView: UIView,UIScrollViewDelegate {
//    let dragBtn = UIButton()
    let dragImg = UIImageView()
//    var player : BMPlayer!
    let imageScroll = UIScrollView()
    let imageIndex = UILabel()
    let timeLabel = UILabel()
    let weather = UILabel()
    let plateNumber = UILabel()
    let vehicleType = UILabel()
    let orgName = UILabel()
    let driver = UILabel()
    let result = UILabel()
    let speed = UILabel()
    let location = UILabel()
    let line = UILabel()
    let followDriver = UIButton()
    let followCar = UIButton()
    let resultTitle = UILabel()
    let eventView = EventDetailsListView()
    weak var delegate: RiskDetailsInfoViewDelegate?
    
    var viewModel : RiskDetailsModel?
    var scrollPage = -1
    

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        self.isUserInteractionEnabled = true
        setupView()
        updateConstraints()
    }

    func setupView(){
        dragImg.image = UIImage.init(named: "drag_image")
        dragImg.isUserInteractionEnabled = true
        dragImg.contentMode = ContentMode.center
        self.addSubview(dragImg)
        
        imageScroll.showsVerticalScrollIndicator = false
        imageScroll.showsHorizontalScrollIndicator = false
        imageScroll.isPagingEnabled = true
        imageScroll.delegate = self
        imageScroll.layer.cornerRadius = 10
        imageScroll.clipsToBounds = true
        self.addSubview(imageScroll)
        
        print("生成播放器")
        BMPlayerConf.shouldAutoPlay = false
        BMPlayerConf.topBarShowInCase = .none
        BMPlayerConf.loaderType = .circleStrokeSpin
        BMPlayerConf.enableBrightnessGestures = false
        BMPlayerConf.enableVolumeGestures = false
        BMPlayerConf.enablePlaytimeGestures = false
        BMPlayerConf.enablePlayControlGestures = false
        //  视频播放
//        let controller = CustomPalyerControl()
//        player = BMPlayer()
//        player.isHidden = true
//        player = BMPlayer(customControlView: controller)
//        self.addSubview(player)
        
        imageIndex.backgroundColor = UIColor.init(white: 0.1, alpha: 0.6)
        imageIndex.textColor = UIColor.white
        imageIndex.textAlignment = NSTextAlignment.center
        imageIndex.layer.cornerRadius = 10.0
        imageIndex.clipsToBounds = true
        self.addSubview(imageIndex)
        
        timeLabel.font = UIFont.systemFont(ofSize: 12)
        timeLabel.textColor = UIColor.init(hex: "#5C5E74", alpha: 1.0)
        timeLabel.textAlignment = NSTextAlignment.left
        self.addSubview(timeLabel)
        
        weather.font = UIFont.systemFont(ofSize: 14)
        weather.textAlignment = NSTextAlignment.right
        self.addSubview(weather)
        
        plateNumber.font = UIFont.boldSystemFont(ofSize: 17)
        plateNumber.textAlignment = NSTextAlignment.left
        plateNumber.textColor = UIColor.init(hex: "#1D69F5", alpha: 1.0)
        self.addSubview(plateNumber)
        
        vehicleType.font = UIFont.systemFont(ofSize: 10)
        vehicleType.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        vehicleType.layer.borderColor = UIColor(hex: "#E6E9EE", alpha: 1.0)?.cgColor
        vehicleType.layer.borderWidth = 1
        vehicleType.textAlignment = NSTextAlignment.center
        self.addSubview(vehicleType)
        
        orgName.font = UIFont.systemFont(ofSize: 10)
        orgName.textAlignment = NSTextAlignment.left
        orgName.textColor = UIColor.init(hex: "#5C5E74", alpha: 1.0)
        self.addSubview(orgName)
        
        driver.font = UIFont.boldSystemFont(ofSize: 13)
        driver.textAlignment = NSTextAlignment.left
        self.addSubview(driver)
        
        result.font = UIFont.boldSystemFont(ofSize: 13)
        result.textAlignment = NSTextAlignment.left
        self.addSubview(result)
        
        speed.font = UIFont.systemFont(ofSize: 12)
        speed.textAlignment = NSTextAlignment.left
        speed.textColor = UIColor.init(hex: "#5C5E74", alpha: 1.0)
        self.addSubview(speed)
        
        location.font = UIFont.systemFont(ofSize: 12)
        location.textAlignment = NSTextAlignment.left
        location.textColor = UIColor.init(hex: "#5C5E74", alpha: 1.0)
        self.addSubview(location)
        
        line.backgroundColor = UIColor.init(hex: "#E6E9EE", alpha: 1.0)
        self.addSubview(line)
        
        followDriver.setTitle("关注驾驶员", for: .normal)
        followDriver.isSelected = false
        followDriver.setImage(UIImage.init(named: "follow_heart_normal"), for: .normal)
        followDriver.setImage(UIImage.init(named: "follow_heart_selected"), for: .selected)
        followDriver.setTitleColor(UIColor.init(hex: "#5C5E74", alpha: 1.0), for: .normal)
        followDriver.titleLabel?.font = UIFont.systemFont(ofSize: 10)
        followDriver.addTarget(self, action: #selector(self.clickFollowDriverBtn(target: )), for: .touchUpInside)
        self.addSubview(followDriver)
        
        followCar.setTitle("收藏车辆", for: .normal)
        followCar.isSelected = false
        followCar.setImage(UIImage.init(named: "follow_star_normal"), for: .normal)
        followCar.setImage(UIImage.init(named: "follow_star_selected"), for: .selected)
        followCar.setTitleColor(UIColor.init(hex: "#5C5E74", alpha: 1.0), for: .normal)
        followCar.titleLabel?.font = UIFont.systemFont(ofSize: 10)
        followCar.addTarget(self, action: #selector(self.clickFollowCarBtn(target: )), for: .touchUpInside)
        self.addSubview(followCar)
        
        resultTitle.font = UIFont.boldSystemFont(ofSize: 17)
        resultTitle.text = "已干预信息"
        resultTitle.isHidden = true
        self.addSubview(resultTitle)
        
        eventView.setupView(items: ["干预人","干预时间","干预手段"])
//        eventView.setContentViewData(contents: ["2019-11-07 12:25:16","12:25:35  下发语音","12:25:26  控车干预：鸣笛喇叭+闪灯\n12:25:24  电话干预  通话时长52s"])
        self.addSubview(eventView)
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        dragImg.snp.makeConstraints { (make) in
            make.top.equalTo(self.snp.top)
            make.centerX.equalTo(self.snp.centerX)
            make.height.equalTo(40)
            make.width.equalTo(88)
        }
        
        imageScroll.snp.makeConstraints { (make) in
            make.top.equalTo(self.snp.top).offset(42)
            make.left.equalTo(self.snp.left).offset(15)
            make.right.equalTo(self.snp.right).offset(-15)
            make.height.equalTo(160)
        }
        
//        player.snp.makeConstraints { (make) in
//            make.top.equalTo(self.snp.top).offset(42)
//            make.left.equalTo(self.snp.left).offset(15)
//            make.right.equalTo(self.snp.right).offset(-15)
//            // 注意此处，宽高比 16:9 优先级比 1000 低就行，在因为 iPhone 4S 宽高比不是 16：9
//            make.height.equalTo(160)
//        }
        
        imageIndex.snp.makeConstraints { (make) in
            make.right.equalTo(imageScroll.snp.right).offset(-8)
            make.bottom.equalTo(imageScroll.snp.bottom).offset(-9)
            make.height.equalTo(20)
            make.width.equalTo(50)
        }
        
        timeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(imageScroll.snp.bottom).offset(10)
            make.height.equalTo(17)
        }
        
        weather.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp.right).offset(-15)
            make.top.equalTo(imageScroll.snp.bottom).offset(8)
            make.height.equalTo(20)
        }
        
        plateNumber.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(timeLabel.snp.bottom).offset(4)
            make.height.equalTo(24)
        }
        
        vehicleType.snp.makeConstraints { (make) in
            make.left.equalTo(plateNumber.snp.right).offset(4)
            make.top.equalTo(plateNumber.snp.top).offset(5)
            make.height.equalTo(14)
        }
        
        orgName.snp.makeConstraints { (make) in
            make.left.equalTo(vehicleType.snp.right).offset(5)
            make.top.equalTo(plateNumber.snp.top).offset(4)
            make.height.equalTo(14)
        }
        
        driver.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(plateNumber.snp.bottom).offset(4)
            make.height.equalTo(20)
        }
        
        result.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(driver.snp.bottom)
            make.height.equalTo(18)
        }
        
        speed.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp.right).offset(-15)
            make.top.equalTo(result.snp.top)
            make.height.equalTo(17)
        }
        
        location.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(result.snp.bottom).offset(4)
            make.height.equalTo(17)
        }
        
        line.snp.makeConstraints { (make) in
            make.top.equalTo(location.snp.bottom).offset(10)
            make.left.equalTo(self.snp.left).offset(15)
            make.right.equalTo(self.snp.right).offset(-15)
            make.height.equalTo(1)
        }
        
        followCar.snp.makeConstraints { (make) in
            make.top.equalTo(line.snp.bottom).offset(2)
            make.right.equalTo(self.snp.right).offset(-15)
            make.height.equalTo(25)
        }
        
        followDriver.snp.makeConstraints { (make) in
            make.top.equalTo(line.snp.bottom).offset(2)
            make.right.equalTo(followCar.snp.left).offset(-20)
            make.height.equalTo(25)
        }
        
        resultTitle.snp.makeConstraints { (make) in
            make.top.equalTo(line.snp.bottom).offset(bottomHeight == 0 ? 20 : 30)
            make.left.equalTo(self.snp.left).offset(15)
            make.height.equalTo(24)
        }
        
        eventView.snp.makeConstraints { (make) in
            make.top.equalTo(resultTitle.snp.bottom).offset(8)
            make.left.equalTo(self.snp.left).offset(15)
            make.width.equalTo(KW)
        }
    }
    
    //  显示基本不变的数据
    func setViewData(model:RiskDetailsModel) -> Void {
        viewModel = model
        var X:CGFloat = 0.0
        //  添加详情图片
        for item in model.items! {
            //  媒体信息是否有值，没有值的话默认显示图片
            if item.picVideo != nil {
                
                let url = URL.init(string: item.picVideo!)
//                print("这个媒体资源的格式是什么  \(url!.pathExtension)")
                if url?.pathExtension == "mp4" {
                    //  视频
                    let controller = CustomPalyerControl()
                    let player = BMPlayer(customControlView: controller)
                    player.delegate = self
                    player.frame = CGRect.init(x: X, y: 0.0, width: imageScroll.width, height: imageScroll.height)
                    player.removeGestureRecognizer(player.panGesture)
                    imageScroll.addSubview(player)
                    let asset = BMPlayerResource(url: url!, name: "")
                    player.setVideo(resource: asset)
                    
                }else{
                    //  图片
                    let pic = UIImageView.init()
                    pic.frame = CGRect.init(x: X, y: 0.0, width: imageScroll.width, height: imageScroll.height)
                    imageScroll.addSubview(pic)
                    pic.sd_setImage(with: url, placeholderImage: UIImage.init(named: "default_risk_picker"), options: .delayPlaceholder, completed: nil)
                }
            }else{
                let placeholderImage = UIImageView()
                placeholderImage.image = UIImage.init(named: "default_risk_picker")
                placeholderImage.frame = CGRect.init(x: X, y: 0.0, width: imageScroll.width, height: imageScroll.height)
                imageScroll.addSubview(placeholderImage)
            }
            X += imageScroll.width
        }
        //  添加图片索引
        imageIndex.text = "1/\(model.items?.count ?? 1)"
        
        followDriver.isSelected = model.isDriverFocused!
        followCar.isSelected = model.isVehFocused!
        
        //  判断是否显示关注司机
        if model.driverId == nil {
            followDriver.isHidden = true
        }else{
            followDriver.isHidden = false
        }
        
        imageScroll.contentSize = CGSize.init(width: X, height: 0)
        plateNumber.text = model.plateNo
        vehicleType.text = model.model
        orgName.text = "【\(model.orgName ?? "")】"
        driver.text = "驾驶员：\(model.driverName ?? "未知驾驶员")"
        result.text = model.interContent!.count == 0 ? "\(model.level ?? ""):\(model.eventName ?? "")" : "已干预\(model.level ?? ""):\(model.eventName ?? "")"
        
        //  默认选中第一条风险数据
        setItemDataOf(objc: model.items![0])
    }
    
    //  根据选择路线中不同的事件，显示不同的数据
    func setItemDataOf(objc:InterveneContentModel) -> Void {
        timeLabel.text = objc.time
        weather.text = objc.weather
        speed.text = "速度：\(objc.speed ?? 0.0)km/h"
        location.text = "当前位置：\(objc.address ?? "")"
        
        var titleArr = [String]()
        titleArr.append(viewModel!.interName ?? " ")
        titleArr.append(viewModel!.interTime ?? " ")
        //  填充已干预数据
        for obj in viewModel!.interContent! {
            var sortTime = obj["time"] as! String
            sortTime = sortTime.sliceString(11..<16)
            titleArr.append("\(sortTime) \(obj["content"] ?? " ")\n")
        }
        var lastStr = titleArr.last
        if lastStr == nil || lastStr == " " {
            //  空字符不处理
        }else{
            lastStr = lastStr!.replacingOccurrences(of: "\n", with: "")
            titleArr[titleArr.count-1] = lastStr!
        }
        eventView.setContentViewData(contents: titleArr)
        
        //  如果没有已干预信息，禁止view拖动
        if viewModel?.interContent?.count == 0 {
            eventView.isHidden = true
            resultTitle.isHidden = true
            dragImg.isHidden = true
//            dragImg.isUserInteractionEnabled = false
        }else{
            dragImg.isHidden = false
            eventView.isHidden = false
            resultTitle.isHidden = false
        }
    }
    
    //  选中地图标注时，修改对应要展示的内容
    func changeDataForMapAnnotationID(index:Int) -> Void {
        setItemDataOf(objc: viewModel!.items![index])
        imageIndex.text = "\(index+1)/\(viewModel!.items?.count ?? 1)"
        imageScroll.setContentOffset(CGPoint.init(x: CGFloat(index)*imageScroll.width, y: 0.0), animated: true)
    }
    
    //  MARK:-- UIScrollViewDelegate
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let offset = scrollView.contentOffset.x/scrollView.width
        //  如果页数相同的话跳出
        if scrollPage == Int(offset) {
            return
        }
        scrollPage = Int(offset)
        
        imageIndex.text = "\(Int(offset)+1)/\(viewModel!.items?.count ?? 1)"
        
        self.delegate?.imageViewDidScroll(index: Int(offset))
    }
    
    
    @objc func clickFollowDriverBtn(target:UIButton) {
        self.delegate?.followDriver(status: target.isSelected)
    }
    
    @objc func clickFollowCarBtn(target:UIButton) {
        self.delegate?.followCar(status: target.isSelected)
    }
    
    func changeFollowDriverStatus() -> Void {
        followDriver.isSelected = !followDriver.isSelected
    }
    
    func changeFollowCarStatus() -> Void {
        followCar.isSelected = !followCar.isSelected
    }
    
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
}

//  视频播放代理
extension RiskDetailsInfoView : BMPlayerDelegate {
    
    
    func bmPlayer(player: BMPlayer, playerIsPlaying playing: Bool) {
        print("开始播放")
        player.panGesture.isEnabled = false
    }
    
    func bmPlayer(player: BMPlayer, playerOrientChanged isFullscreen: Bool) {
        //
    }
    
    func bmPlayer(player: BMPlayer, playerStateDidChange state: BMPlayerState) {
        //
    }
    
    func bmPlayer(player: BMPlayer, playTimeDidChange currentTime: TimeInterval, totalTime: TimeInterval) {
        //
    }
    
    func bmPlayer(player: BMPlayer, loadedTimeDidChange loadedDuration: TimeInterval, totalDuration: TimeInterval) {
        //
    }
}
