//
//  RiskListTableViewCell.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/5.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class RiskListTableViewCell: UITableViewCell {
    
    let headPicker = UIImageView.init()     //  头像
    let plate = UILabel.init()              //  车牌
    let time = UILabel.init()               //  时间
    let vehicleType = UILabel.init()        //  车型
    let orgName = UILabel.init()            //  组织名
    let driver = UILabel.init()             //  驾驶员
    let risk = UILabel.init()               //  风险
    let icon = UIImageView()
    let location = UILabel.init()           //  定位
    let line = UIView.init()
    
    
    
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        createUI()
        self .updateConstraints()
        self.backgroundColor = UIColor.white
        self.contentView.backgroundColor = UIColor.white
    }
    
    
    private func createUI() {
        
        self.contentView.addSubview(headPicker)
        
        
        plate.textColor = UIColor(hex: "#363847", alpha: 1.0)
        plate.font = UIFont.boldSystemFont(ofSize: 15.0)
        self.contentView.addSubview(plate)
        
        
        time.font = UIFont.systemFont(ofSize: 12)
        time.textAlignment = .center
        self.contentView.addSubview(time)
        
        
        vehicleType.font = UIFont.systemFont(ofSize: 10)
        vehicleType.textAlignment = NSTextAlignment.center
        vehicleType.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        vehicleType.layer.borderColor = UIColor(hex: "#E6E9EE", alpha: 1.0)?.cgColor
        vehicleType.layer.borderWidth = 1
        self.contentView.addSubview(vehicleType)
        
        
        orgName.font = UIFont.systemFont(ofSize: 10)
        orgName.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.contentView.addSubview(orgName)
        
        driver.font = UIFont.boldSystemFont(ofSize: 14)
        driver.numberOfLines = 0
        driver.lineBreakMode = .byCharWrapping
        //        driver.textColor =  UIColor(hex: "#3B3D4C", alpha: 1.0)
        self.contentView.addSubview(driver)
        
        
        risk.font = UIFont.boldSystemFont(ofSize: 14)
        //        risk.textColor = UIColor(hex: "#3B3D4C", alpha: 1.0)
        self.contentView.addSubview(risk)
        
        icon.image = UIImage.init(named: "location_annotation")
        self.contentView.addSubview(icon)
        
        location.font = UIFont.systemFont(ofSize: 12)
        location.textColor = UIColor.init(hex: "#5C5E74", alpha: 1.0)
        self.contentView.addSubview(location)
        
        
        line.backgroundColor = UIColor.init(hex: "#E6E9EE", alpha: 1.0)
        self.contentView.addSubview(line)
        
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        
        headPicker.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.top.equalTo(self.contentView.snp.top).offset(10)
            make.width.equalTo(80)
            make.height.equalTo(100)
        }
        
        time.snp.makeConstraints { (make) in
            make.right.equalTo(self.contentView.snp.right).offset(-15)
            make.top.equalTo(self.contentView.snp.top).offset(10)
            make.height.equalTo(16)
        }
        
        plate.snp.makeConstraints { (make) in
            make.left.equalTo(headPicker.snp.right).offset(16)
            make.top.equalTo(self.contentView.snp.top).offset(23)
            make.height.equalTo(21)
        }
        
        vehicleType.snp.makeConstraints { (make) in
            make.left.equalTo(plate.snp.right).offset(4)
            make.centerY.equalTo(plate)
            make.height.equalTo(16)
            make.width.greaterThanOrEqualTo(50)
        }
        
        orgName.snp.makeConstraints { (make) in
            make.centerY.equalTo(vehicleType)
            make.left.equalTo(vehicleType.snp.right).offset(5)
            make.height.equalTo(14)
        }
        
        
        driver.snp.makeConstraints { (make) in
            make.left.equalTo(headPicker.snp.right).offset(16)
            make.top.equalTo(plate.snp.bottom).offset(4)
            make.height.equalTo(19)
        }
        
        risk.snp.makeConstraints { (make) in
            make.top.equalTo(driver.snp.bottom).offset(2)
            make.left.equalTo(headPicker.snp.right).offset(16)
            make.height.equalTo(19)
        }
        
        icon.snp.makeConstraints { (make) in
            make.left.equalTo(headPicker.snp.right).offset(16)
            make.top.equalTo(risk.snp.bottom).offset(6)
            make.size.equalTo(CGSize.init(width: 10, height: 14))
        }
        
        location.snp.makeConstraints { (make) in
            make.left.equalTo(icon.snp.right).offset(5)
            make.top.equalTo(risk.snp.bottom).offset(4)
            make.width.lessThanOrEqualTo(KW-135)
            make.height.equalTo(17)
        }
        
        line.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.bottom.equalTo(self.contentView.snp.bottom).offset(0)
            make.width.equalTo(KW-30)
            make.height.equalTo(1)
        }
    }
    
    func configDataSource (riskData:RiskListModel) {
        
        headPicker.sd_setImage(with: URL.init(string: riskData.driverurl ?? ""), placeholderImage: UIImage.init(named: "vehicle_driverIcon"), options: .highPriority, completed: nil)
        plate.text = riskData.plateNo
        vehicleType.text = riskData.model
        orgName.text = "【\(riskData.orgName ?? "")】"
        
        time.text = riskData.time?.sliceString(11..<16)
        
        driver.text = "驾驶员:\(riskData.driverName ?? "未知驾驶员")"
        risk.text = "\(riskData.isInter! ? "已干预" : "未干预")\(riskData.eventLevel ?? ""):\(riskData.eventName ?? "")"
        
        location.text = riskData.address
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
