//
//  SearchInputView.swift
//  GCBDemo
//
//  Created by 亭子 on 2019/12/4.
//  Copyright © 2019 TimaNetwork. All rights reserved.
//  自定义搜索框，控制搜索框样式

import UIKit

class SearchInputView: UITextField {
    
    // 未输入时文本的位置，向右缩进10
    override func textRect(forBounds bounds: CGRect) -> CGRect {
        
        return bounds.insetBy(dx: 10, dy: 0)
    }
    
    // 输入后文本的位置，向右缩进10
    override func editingRect(forBounds bounds: CGRect) -> CGRect {
        return bounds.insetBy(dx: 10, dy: 0)
    }

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
