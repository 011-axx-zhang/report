//
//  EventDetailsListView.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/11.
//  Copyright © 2019 YTKJ. All rights reserved.
//  自定义页面，根据传入的数据创建内容

import UIKit

class EventDetailsListView: UIView {
    
    var itemsArr = [UILabel]()
    var contentsArr = [UILabel]()
    
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
    }
    
    //  有坐标值初始化
    convenience init(frame: CGRect,list: [String]) {
        self.init(frame: frame)
        setupView(items: list)
        updateConstraints()
    }
    
    func setupView(items:[String]) -> Void {
        for text in items {
            //  左侧标题
            let item = UILabel.init()
            item.textColor = UIColor.init(hex: "#5C5E74", alpha: 1.0)
            item.font = UIFont.systemFont(ofSize: 13)
            item.text = text
            self.addSubview(item)
            
            //  右侧内容
            let content = UILabel.init()
            content.textColor = UIColor.black
            content.font = UIFont.systemFont(ofSize: 13)
            content.text = "   "
            content.numberOfLines = 0
            self.addSubview(content)
            
            itemsArr.append(item)
            contentsArr.append(content)
        }
    }
    
    //  设置右侧label内容
    func setContentViewData(contents:[String]) -> Void {
        for index in 0..<contents.count {
            let contentLabel = contentsArr[index]
            if contents[index] != "" {
                contentLabel.text = contents[index]
            }
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        if itemsArr.count == 0 {
            return
        }
        var lastRight = UILabel()
        
        
        for index in 0..<itemsArr.count {
            let leftLabel = itemsArr[index]
            leftLabel.snp.makeConstraints { (make) in
                make.left.equalTo(self).offset(15)
                make.top.equalTo(index == 0 ? self.snp.top : lastRight.snp.bottom).offset(8)
                make.height.equalTo(20)
                make.width.equalTo(80)
            }
            
            let rightLabel = contentsArr[index]
            rightLabel.snp.makeConstraints { (make) in
                make.left.equalTo(leftLabel.snp.right).offset(29)
                make.top.equalTo(leftLabel.snp.top)
                make.right.equalTo(self.snp.right).offset(-15)
                make.height.equalTo(20)
                if index == itemsArr.count-1{
                    make.bottom.equalTo(-8)
                }
            }
            
            lastRight = rightLabel
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
