//
//  NotificationTypeView.swift
//  GCBDemo
//
//  Created by 亭子 on 2019/12/4.
//  Copyright © 2019 TimaNetwork. All rights reserved.
//

import UIKit

class NotificationTypeView: UIView {

    var label:UILabel!
    var line:UIView!
    var btn:UIButton!
    var isSelect = false
    @objc var clickTypeView:(()->Void)?
    
    
    
    override init(frame: CGRect) {
        //
        super.init(frame: frame)
        
        self.setupSubViews()
    }
    
    func setupSubViews() -> Void {
        label = UILabel.init()
        label?.textColor = isSelect ? UIColor.init(hex: "#1D69F5", alpha: 1.0) : UIColor.black
        label?.font = UIFont.systemFont(ofSize: 15)
        label.textAlignment = NSTextAlignment.center
        self.addSubview(label)
        
        line = UIView.init()
        line.backgroundColor = UIColor.init(hex: "#1D69F5", alpha: 1.0)
        self.addSubview(line)
        
        line.isHidden = !isSelect
        
        btn = UIButton.init(type: .custom)
        btn.addTarget(self, action: #selector(didSelectTypeView), for: .touchUpInside)
        self.addSubview(btn)
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        label.frame = CGRect.init(x: 0, y: 10, width: self.frame.width, height: 21)
        line.frame = CGRect.init(x: 0, y: label.frame.maxY+7, width: self.frame.width, height: 4)
        
        btn.frame = self.bounds
    }
    
    
    //  标签点击事件
    @objc func didSelectTypeView(){
        self.setTypeViewSelectStatus(selected: true)
        if (self.clickTypeView != nil) {
            self.clickTypeView?()
        }
    }
    
    //  控制底下的线显示还是隐藏
    func setTypeViewSelectStatus(selected:Bool) -> Void {
        isSelect = selected
        line.isHidden = !isSelect
        label?.textColor = isSelect ? UIColor.init(hex: "#1D69F5", alpha: 1.0) : UIColor.black
    }
    
    func setTypeViewText(text:String) -> Void {
        label.text = text
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
