//
//  MaintenanceDetailsModel.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/31.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class MaintenanceDetailsModel: NSObject,HandyJSON {
    var company : String?
    var content : String?
    var cost : Float?
    var driverId : Int?
    var driverName : String?
    var driverurl : String?
    var duration : String?
    var id : Int?
    var licenseUrl : String?
    var model : String?
    var orgName : String?
    var plateNo : String?
    var reason : String?
    var status : String?
    var time : String?
    var type : String?
    var vehId : Int?

    override required init() {
        super.init()
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.content<--"content"
        mapper<<<self.company<--"company"
        mapper<<<self.driverId<--"driverId"
        mapper<<<self.driverName<--"driverName"
        mapper<<<self.driverurl<--"driverurl"
        mapper<<<self.id<--"id"
        mapper<<<self.cost<--"cost"
        mapper<<<self.duration<--"duration"
        mapper<<<self.licenseUrl<--"licenseUrl"
        mapper<<<self.status<--"status"
        mapper<<<self.model<--"model"
        mapper<<<self.orgName<--"orgName"
        mapper<<<self.type<--"type"
        mapper<<<self.plateNo<--"plateNo"
        mapper<<<self.reason<--"reason"
        mapper<<<self.time<--"time"
        mapper<<<self.vehId<--"vehId"
    }
    
}
