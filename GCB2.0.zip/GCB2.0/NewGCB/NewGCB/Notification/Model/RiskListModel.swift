//
//  RiskListModel.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/5.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class RiskListModel: NSObject,HandyJSON {
    var eventId:Int?
    var id:Int?
    var vehId:Int?
    var plateNo:String?
    var model:String?
    var orgName:String?
    var company:String?
    var driverId:Int?
    var licenseUrl:String?
    var driverName:String?
    var driverurl:String?
    var eventLevel:String?
    var eventName:String?
    var address:String?
    var time:String?
    var isInter:Bool?
    
    
    override required init() {
//        super.init()
    }
    
//    func mapping(mapper: HelpingMapper) {
//        mapper<<<self.eventId<--"eventId"
//        mapper<<<self.vehId<--"vehId"
//        mapper<<<self.id<--"id"
//        mapper<<<self.plateNo<--"plateNo"
//        mapper<<<self.model<--"model"
//        mapper<<<self.orgName<--"orgName"
//        mapper<<<self.company<--"company"
//        mapper<<<self.driverId<--"driverId"
//        mapper<<<self.licenseUrl<--"licenseUrl"
//        mapper<<<self.driverName<--"driverName"
//        mapper<<<self.eventLevel<--"eventLevel"
//        mapper<<<self.eventName<--"eventName"
//        mapper<<<self.address<--"address"
//        mapper<<<self.time<--"time"
//        mapper<<<self.isInter<--"isInter"
//    }
    
}
