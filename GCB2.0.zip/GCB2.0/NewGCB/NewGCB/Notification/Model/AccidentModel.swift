//
//  AccidentModel.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/10.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class AccidentModel: NSObject,HandyJSON {
    
    var address : String?
    var company : String?
    var driverId : Int?
    var driverName : String?
    var driverurl : String?
    var id : Int?
    var licenseUrl : String?
    var model : String?
    var nature : String?
    var orgName : String?
    var plateNo : String?
    var time : String?
    var vehId : Int?
    
    
    override required init() {
        super.init()
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.address<--"address"
        mapper<<<self.company<--"company"
        mapper<<<self.driverId<--"driverId"
        mapper<<<self.driverName<--"driverName"
        mapper<<<self.driverurl<--"driverurl"
        mapper<<<self.id<--"id"
        mapper<<<self.licenseUrl<--"licenseUrl"
        mapper<<<self.model<--"model"
        mapper<<<self.nature<--"nature"
        mapper<<<self.orgName<--"orgName"
        mapper<<<self.plateNo<--"plateNo"
        mapper<<<self.time<--"time"
        mapper<<<self.vehId<--"vehId"
    }
}
