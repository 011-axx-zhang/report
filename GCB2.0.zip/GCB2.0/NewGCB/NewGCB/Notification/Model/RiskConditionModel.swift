//
//  RiskConditionModel.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/31.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class RiskConditionModel: NSObject,HandyJSON {
    var events:String!
//    var level:Array<String>?
    
    override required init() {
        super.init()
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.events<--"events"
//        mapper<<<self.level<--"level"
    }
}
