//
//  InsuranceModel.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/10.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class InsuranceModel: NSObject,HandyJSON {
    
    var company : String!
    var expiresDate : String!
    var id : Int!
    var insuranceCompany : String!
    var insuranceNo : String!
    var model : String!
    var orgName : String!
    var plateNo : String!
    var time : String!
    var type : String!
    var vehId : Int!
    
    
    override required init() {
        super.init()
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.id<--"id"
        mapper<<<self.vehId<--"vehId"
        mapper<<<self.plateNo<--"plateNo"
        mapper<<<self.model<--"model"
        mapper<<<self.orgName<--"orgName"
        mapper<<<self.company<--"company"
        mapper<<<self.expiresDate<--"expiresDate"
        mapper<<<self.insuranceCompany<--"insuranceCompany"
        mapper<<<self.insuranceNo<--"insuranceNo"
        mapper<<<self.type<--"type"
        mapper<<<self.time<--"time"
    }
}
