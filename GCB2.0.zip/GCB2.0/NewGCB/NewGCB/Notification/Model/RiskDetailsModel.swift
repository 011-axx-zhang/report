//
//  RiskDetailsModel.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/16.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON



class InterveneContentModel: NSObject,HandyJSON {
    var address : String!
    var lat : Float!
    var lng : Float!
    var picVideo : String!
    var speed : Float!
    var time : String!
    var weather : String!
    
    override required init() {
        super.init()
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.address<--"address"
        mapper<<<self.lat<--"lat"
        mapper<<<self.lng<--"lng"
        mapper<<<self.picVideo<--"picVideo"
        mapper<<<self.speed<--"speed"
        mapper<<<self.time<--"time"
        mapper<<<self.weather<--"weather"
    }
}

class RiskDetailsModel: NSObject,HandyJSON {
    
    var eventId:Int16?
    var eventName:String?
    var level:String?
    var vehId:Int?
    var isVehFocused:Bool?
    var plateNo:String?
    var model:String?
    var orgName:String?
    var driverId:Int?
    var isDriverFocused:Bool?
    var driverName:String?
    var interName:String?
    var interTime:String?
    var interContent:Array<[String:Any]>?
    var items:Array<InterveneContentModel>?
    
    override required init() {
        super.init()
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.eventId<--"eventId"
        mapper<<<self.eventName<--"eventName"
        mapper<<<self.level<--"level"
        mapper<<<self.vehId<--"vehId"
        mapper<<<self.isVehFocused<--"isVehFocused"
        mapper<<<self.plateNo<--"plateNo"
        mapper<<<self.model<--"model"
        mapper<<<self.orgName<--"orgName"
        mapper<<<self.driverId<--"driverId"
        mapper<<<self.isDriverFocused<--"isDriverFocused"
        mapper<<<self.driverName<--"driverName"
        mapper<<<self.interName<--"interName"
        mapper<<<self.interTime<--"interTime"
        mapper<<<self.interContent<--"interContent"
        mapper<<<self.items<--"items"
    }
    
}
