//
//  MaintenanceModel.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/10.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class MaintenanceModel: NSObject,HandyJSON {
    
    var company : String?
    var driverId : Int?
    var driverName : String?
    var driverurl : String?
    var duration : String?
    var id : Int?
    var licenseUrl : String?
    var model : String?
    var orgName : String?
    var plateNo : String?
    var reason : String?
    var status : String?
    var time : String?
    var vehId : Int?
    
    
    override required init() {
        super.init()
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.id<--"id"
        mapper<<<self.vehId<--"vehId"
        mapper<<<self.plateNo<--"plateNo"
        mapper<<<self.model<--"model"
        mapper<<<self.orgName<--"orgName"
        mapper<<<self.company<--"company"
        mapper<<<self.driverId<--"driverId"
        mapper<<<self.licenseUrl<--"licenseUrl"
        mapper<<<self.driverName<--"driverName"
        mapper<<<self.driverurl<--"driverurl"
        mapper<<<self.duration<--"duration"
        mapper<<<self.reason<--"reason"
        mapper<<<self.status<--"status"
        mapper<<<self.time<--"time"
        mapper<<<self.vehId<--"vehId"
    }
}

