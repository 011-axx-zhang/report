//
//  InsuranceDetailsModel.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/31.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class InsuranceDetailsModel: NSObject,HandyJSON {
    var buyTime : String!
    var company : String!
    var cost : Float!
    var effectiveTime : String!
    var expiresDate : String!
    var id : Int!
    var insuranceCompany : String!
    var insuranceNo : String!
    var model : String!
    var orgName : String!
    var plateNo : String!
    var status : String!
    var time : String!
    var type : String!
    var vehId : Int!
    
    
    override required init() {
        super.init()
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.buyTime<--"buyTime"
        mapper<<<self.company<--"company"
        mapper<<<self.effectiveTime<--"effectiveTime"
        mapper<<<self.expiresDate<--"expiresDate"
        mapper<<<self.id<--"id"
        mapper<<<self.cost<--"cost"
        mapper<<<self.insuranceCompany<--"insuranceCompany"
        mapper<<<self.insuranceNo<--"insuranceNo"
        mapper<<<self.status<--"status"
        mapper<<<self.model<--"model"
        mapper<<<self.orgName<--"orgName"
        mapper<<<self.type<--"type"
        mapper<<<self.plateNo<--"plateNo"
        mapper<<<self.time<--"time"
        mapper<<<self.vehId<--"vehId"
    }
}
