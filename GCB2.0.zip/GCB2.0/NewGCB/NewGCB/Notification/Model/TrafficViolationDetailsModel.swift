//
//  TrafficViolationDetailsModel.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/31.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class TrafficViolationDetailsModel: NSObject,HandyJSON {
    var address : String!
    var company : String!
    var driverId : Int!
    var driverName : String!
    var id : Int!
    var latePaymentFee : Float!
    var liabilityPerson : String!
    var licenseUrl : String!
    var minusScore : Int!
    var model : String!
    var orgName : String!
    var penalty : Float!
    var plateNo : String!
    var reason : String!
    var status : String!
    var time : String!
    var unit : String!
    var vehId : Int!
    
    override required init() {
        super.init()
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.address<--"address"
        mapper<<<self.company<--"company"
        mapper<<<self.driverId<--"driverId"
        mapper<<<self.driverName<--"driverName"
        mapper<<<self.id<--"id"
        mapper<<<self.latePaymentFee<--"latePaymentFee"
        mapper<<<self.liabilityPerson<--"liabilityPerson"
        mapper<<<self.licenseUrl<--"licenseUrl"
        mapper<<<self.minusScore<--"minusScore"
        mapper<<<self.model<--"model"
        mapper<<<self.orgName<--"orgName"
        mapper<<<self.penalty<--"penalty"
        mapper<<<self.plateNo<--"plateNo"
        mapper<<<self.reason<--"reason"
        mapper<<<self.status<--"status"
        mapper<<<self.time<--"time"
        mapper<<<self.unit<--"unit"
        mapper<<<self.vehId<--"vehId"
    }
    
}
