//
//  EventDriverModel.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/13.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class EventDriverModel: NSObject,HandyJSON {
    
    var image:String?
    var number:String?
    var type:String?
    var orgName:String?
    var driverName:String?
    var textFont:UIFont?
    var textColor:UIColor?
    
    override required init() {
        super.init()
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.image<--"image"
        mapper<<<self.number<--"number"
        mapper<<<self.type<--"type"
        mapper<<<self.orgName<--"orgName"
        mapper<<<self.driverName<--"driverName"
        mapper<<<self.textFont<--"textFont"
    }
}
