//
//  AccidentDetailsModel.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/31.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON

class AccidentDetailsModel: NSObject,HandyJSON {
    var accidentLiability : String?
    var address : String?
    var company : String?
    var driverId : Int? = 0
    var driverLiability : String?
    var driverName : String?
    var id : Int?
    var insuranceArrivalDate : String?
    var insuranceArrivalMoney : Float?
    var insuranceStatus : String?
    var liabilityPerson : String?
    var liabilityPhone : String?
    var licenseUrl : String?
    var loss : Float?
    var lossStatus : String?
    var model : String?
    var nature : String?
    var orgName : String?
    var plateNo : String?
    var process : String?
    var reason : String?
    var time : String?
    var vehId : Int?

    override required init() {
        super.init()
    }
    
    func mapping(mapper: HelpingMapper) {
        mapper<<<self.address<--"address"
        mapper<<<self.company<--"company"
        mapper<<<self.driverId<--"driverId"
        mapper<<<self.driverName<--"driverName"
        mapper<<<self.id<--"id"
        mapper<<<self.accidentLiability<--"accidentLiability"
        mapper<<<self.liabilityPerson<--"liabilityPerson"
        mapper<<<self.licenseUrl<--"licenseUrl"
        mapper<<<self.driverLiability<--"driverLiability"
        mapper<<<self.model<--"model"
        mapper<<<self.orgName<--"orgName"
        mapper<<<self.insuranceArrivalDate<--"insuranceArrivalDate"
        mapper<<<self.plateNo<--"plateNo"
        mapper<<<self.reason<--"reason"
        mapper<<<self.insuranceArrivalMoney<--"insuranceArrivalMoney"
        mapper<<<self.time<--"time"
        mapper<<<self.insuranceStatus<--"insuranceStatus"
        mapper<<<self.vehId<--"vehId"
        mapper<<<self.liabilityPhone<--"liabilityPhone"
        mapper<<<self.loss<--"loss"
        mapper<<<self.lossStatus<--"lossStatus"
        mapper<<<self.nature<--"nature"
        mapper<<<self.process<--"process"
    }
    
}
