//
//  NotificationViewController.swift
//  GCBDemo
//
//  Created by 亭子 on 2019/12/4.
//  Copyright © 2019 TimaNetwork. All rights reserved.
//  各种通知主控制器

import UIKit
import HandyJSON
import SwiftyJSON

class NotificationViewController: UIViewController {

    var topView : UIView!
    var scroll : UIScrollView!
    var types = [NotificationTypeView]()
    var childVCs = [String:UIViewController]()     //  子控制器数组
    let VCScroll = UIScrollView()   //  用来展示子控制器
    var filterView:VehicleChooseViewForNorification!   //  筛选
    var eventType : EventTypeView!      //  事件类型
    var eventArr:[String]! = []
    var orgArr:Array<OrgAndGroupContent> = []
    var vehicleGroupArr:Array<OrgAndGroupContent> = []
    let eventOption = UIButton()
    let siftedOption = UIButton()
    let timeOption = UIButton()
    var searchLabel:SearchInputView!
    var filterViewIsShow = false    //  筛选框是否显示
//    var timeViewIsShow = false      //  事件选择框是否显示
    var eventTypeViewIsShow = false     //  事件类型提示框是否显示
    
    
    var driverID:Int64 = 0      //  司机ID，从司机报表跳转时需要传
    var vehicleID:Int64 = 0   //  车辆ID，从车辆报表跳转时需要传
    var isOtherPage = false     //  是否从其他页面跳转进来
    
    
    var orgId:Int64? = 0        //  组织ID
    var vehGroupId:Int64? = 0   //  车队ID
    var focusDriver = 0
    var focusVeh = 0
    var keyword = ""    //  搜索的关键字
    var eventName = ""  //  事件名称
    var eventLevel = "" //  事件等级
    var isInter = 0 //  是否干预
    var beginTime = ""  //  开始时间
    var endTime = ""    //  结束时间
    

    let queryHeight:CGFloat = 42
    let items = ["风险事件","交通违章","事故通知","维保通知","保险即将到期"]
    let controllers = ["RiskListViewController","TrafficViolationViewController",
                       "AccidentViewController","MaintenanceViewController","InsuranceViewController"]
    
    var selectIndex = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        NotificationCenter.default.addObserver(self, selector: #selector(didSelectedTimeForPicker(notf:)), name: NSNotification.Name(rawValue: "DidSelectedTimeNotification"), object: nil)
        loadTopView()
        loadSubControllers()
    }
    
    func loadTopView() -> Void {
        topView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: KW, height: navigationBarHeight == 64 ? 140 : 165))
        topView.backgroundColor = UIColor.white
        self.view.addSubview(topView)
        
        //  返回
        let back = UIButton.init(type: .custom)
        back.frame = CGRect.init(x: 5, y: statusHeight, width: 44, height: 44)
        back.setImage(UIImage(named: "navigation_back"), for: .normal)
        back.addTarget(self, action: #selector(backOff), for: .touchUpInside)
        topView.addSubview(back)
        
        //  输入
        searchLabel = SearchInputView.init(frame: CGRect.init(x: KW/2-136, y: statusHeight+2, width: 272, height: 40))
        searchLabel.backgroundColor = UIColor.init(hex: "#DFDFF1", alpha: 1.0)
        searchLabel.placeholder = "搜索车牌号/驾驶员姓名"
        searchLabel.font = UIFont.systemFont(ofSize: 13)
        searchLabel.layer.cornerRadius = 4;
        searchLabel.backgroundColor = UIColor.init(hex: "#EFF1F6", alpha: 1.0)
        topView.addSubview(searchLabel)
        
        //  搜索
        let search = UIButton.init(type: .custom)
        search.frame = CGRect.init(x: KW-44-10, y: statusHeight, width: 44, height: 44)
        search.setTitle("搜索", for: .normal)
        search.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        search.setTitleColor(UIColor.init(hex: "#325AEF", alpha: 1.0), for: .normal)
        search.addTarget(self, action: #selector(searchSomething), for: .touchUpInside)
        topView.addSubview(search)
        
        
        scroll = UIScrollView.init(frame: CGRect.init(x: 0, y: searchLabel.frame.maxY+2, width: KW, height: 40))
        scroll.showsHorizontalScrollIndicator = false
        self.addScrollItem(scrollObj: scroll)
        topView.addSubview(scroll)
        
        
        //  筛选条件
        let queryView = UIView.init(frame: .init(x: 0, y: scroll.frame.maxY, width: KW, height: queryHeight))
        self.view.addSubview(queryView)
        
        let topLine = UIView.init(frame: .init(x: 0, y: 0, width: queryView.frame.width, height: 1))
        topLine.backgroundColor = UIColor.init(hex: "#DFDFF1", alpha: 1.0)
        queryView.addSubview(topLine)
        
        let bottomLine = UIView.init(frame: .init(x: 0, y: queryView.frame.height-1, width: queryView.frame.width, height: 1))
        bottomLine.backgroundColor = UIColor.init(hex: "#DFDFF1", alpha: 1.0)
        queryView.addSubview(bottomLine)
        
        
        //  事件类型
        eventOption.frame = CGRect.init(x: queryView.frame.width/4-35, y: 0, width: 70, height: queryHeight)
        eventOption.setTitle("事件类型", for: .normal)
        eventOption.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        eventOption.setTitleColor(.black, for: .normal)
        eventOption.setTitleColor(UIColor.init(hex: "#325AEF", alpha: 1.0), for: .selected)
        eventOption.isSelected = false
        eventOption.setImage(UIImage.init(named: "notification_pull_down"), for: .normal)
        eventOption.setImage(UIImage.init(named: "notification_pull_up"), for: .selected)
        eventOption.imageEdgeInsets = UIEdgeInsets.init(top: 0, left: 60, bottom: 0, right: -10)
        eventOption.titleEdgeInsets = UIEdgeInsets.init(top: 0, left: -10, bottom: 0, right: 10)
        eventOption.addTarget(self, action: #selector(eventClicked), for: .touchUpInside)
        queryView.addSubview(eventOption)
        
        //  筛选
//        siftedOption = UIButton.init(type: .custom)
        siftedOption.frame = CGRect.init(x: queryView.frame.width/2+50, y: 0, width: 70, height: queryHeight)
        siftedOption.setTitle("筛选", for: .normal)
        siftedOption.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        siftedOption.setTitleColor(.black, for: .normal)
        siftedOption.setTitleColor(UIColor.init(hex: "#325AEF", alpha: 1.0), for: .selected)
        siftedOption.isSelected = false
        siftedOption.setImage(UIImage.init(named: "notification_ sifted_normal"), for: .normal)
        siftedOption.setImage(UIImage.init(named: "notification_ sifted_normal"), for: .selected)
        siftedOption.imageEdgeInsets = UIEdgeInsets.init(top: 0, left: 40, bottom: 0, right: 10)
        siftedOption.titleEdgeInsets = UIEdgeInsets.init(top: 0, left: -30, bottom: 0, right: 10)
        siftedOption.imageView?.contentMode = UIView.ContentMode.scaleAspectFit
        siftedOption.addTarget(self, action: #selector(filtrateCondition), for: .touchUpInside)
        queryView.addSubview(siftedOption)
        
        
        //  选择时间
        timeOption.frame = CGRect.init(x: queryView.frame.width/4-35, y: 0, width: 70, height: queryHeight)
        timeOption.setTitle("选择时间", for: .normal)
        timeOption.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        timeOption.titleLabel?.numberOfLines = 0
        timeOption.setTitleColor(.black, for: .normal)
        timeOption.setTitleColor(UIColor.init(hex: "#325AEF", alpha: 1.0), for: .selected)
        timeOption.isSelected = false
        timeOption.isHidden = true
        timeOption.setImage(UIImage.init(named: "notification_pull_down"), for: .normal)
        timeOption.setImage(UIImage.init(named: "notification_pull_up"), for: .selected)
        timeOption.imageEdgeInsets = UIEdgeInsets.init(top: 0, left: 60, bottom: 0, right: -10)
        timeOption.titleEdgeInsets = UIEdgeInsets.init(top: 0, left: -10, bottom: 0, right: 10)
        timeOption.addTarget(self, action: #selector(timeOptionClicked), for: .touchUpInside)
        queryView.addSubview(timeOption)
        
        let viewLine = UIView.init(frame: .init(x: 0, y: topView.frame.height-1, width: topView.frame.width, height: 1))
        viewLine.backgroundColor = UIColor.init(hex: "#DFDFF1", alpha: 1.0)
        topView.addSubview(viewLine)
    }
    
    //  添加事件类型控制器，通过 scrollview 横向添加5个子控制器，点击对应标签时切换 scrollview 的 contentOffSet 偏移量
    func addScrollItem(scrollObj : UIScrollView) -> Void {
        var x : CGFloat = 0.0
        for i in 0..<5 {
            
            let labelWidth = items[i].textSize(font: .systemFont(ofSize: 16)).width
            
            let type = NotificationTypeView.init(frame: CGRect.init(x: 10+60*i+24*i, y: 0, width: Int(labelWidth), height: 42))
            type.setTypeViewText(text: items[i])
            type.tag = 100+i
            type.clickTypeView = {
                self.changeTypeSelectStatus(index: type.tag)
            }
            type.setTypeViewSelectStatus(selected: false)
            scrollObj.addSubview(type)
            
            types.append(type)
            
            x = type.frame.maxX+24
        }
        
        scrollObj.contentSize = CGSize.init(width: x, height: 0)
        
        //  默认选中状态
        let first = types[selectIndex]
        first.setTypeViewSelectStatus(selected: true)
        
    }
    
    //  点击底部标签时，通过判断点击的 index 来控制显示那个子控制器
    func changeTypeSelectStatus(index:Int) -> Void {
//        print("select index = \(selectIndex)   index = \(index)")
        //  如果点的是已经选中的，且是通过首页进入的
        if selectIndex == index-100 && isOtherPage == false{
            return
        }
        //  判断是否有下拉框弹出，有的话取消掉
        if filterViewIsShow {
            //  取消掉筛选框
            self.filterViewIsShow = false
            self.filterView.removeFromSuperview()
            self.transparentView.removeFromSuperview()
        }
        if eventTypeViewIsShow {
            //  取消掉事件选择框
            self.eventTypeViewIsShow = false
            self.eventType.removeFromSuperview()
            self.transparentView.removeFromSuperview()
        }
        let obj = types[selectIndex]                    //  得到对应的事件
        obj.setTypeViewSelectStatus(selected: false)    //  事件的选中状态
        selectIndex = index-100     //  记录选中的事件
        //  判断 Child Controller 中是否存在与事件对应的 Controller
        if childVCs.keys.contains(controllers[selectIndex]) {
            eventOption.isHidden = selectIndex == 0 ? false : true
            timeOption.isHidden = selectIndex == 0 ? true : false
            VCScroll.setContentOffset(CGPoint.init(x: CGFloat(selectIndex)*KW, y: 0), animated: true)
        }else{
            switch selectIndex {
            case 0:
                //  风险事件
//                print("风险事件,司机ID=\(self.driverID)")
                eventOption.isHidden = false
                timeOption.isHidden = true
                let riskVC = RiskListViewController.init(height: VCScroll.frame.height)
                riskVC.view.frame = CGRect.init(x: 0, y: 0, width: KW, height: VCScroll.frame.height)
                if driverID != 0 {
                    riskVC.driverID = self.driverID
                }
                if orgId != 0 {
                    riskVC.orgid = orgId!
                }
                if vehGroupId != 0 {
                    riskVC.vehGroupId = vehGroupId!
                }
                VCScroll.addSubview(riskVC.view)
                addChild(riskVC)
                childVCs["RiskListViewController"] = riskVC
            case 1:
                //  交通
//                print("交通---\(vehicleID)")
                eventOption.isHidden = true
                timeOption.isHidden = false
                let trafficVC = TrafficViolationViewController.init(height: VCScroll.frame.height)
                trafficVC.view.frame = CGRect.init(x: KW, y: 0, width: KW, height: VCScroll.frame.height)
                
                let vehid = "\(self.vehicleID)"
                let vehGroupIdStr = "\(self.vehGroupId ?? 0)"
                let orgIdStr = "\(self.orgId ?? 0)"
                trafficVC.vehID = NSString(string: vehid).integerValue
                trafficVC.vehGroupID = NSString(string: vehGroupIdStr).integerValue
                trafficVC.orgID = NSString(string: orgIdStr).integerValue
                VCScroll.addSubview(trafficVC.view)
                addChild(trafficVC)
                childVCs["TrafficViolationViewController"] = trafficVC
            case 2:
                //  事故
//                print("事故---\(vehicleID)")
                eventOption.isHidden = true
                timeOption.isHidden = false
                let accVC = AccidentViewController.init(height: VCScroll.frame.height)
                accVC.view.frame = CGRect.init(x: KW*2, y: 0, width: KW, height: VCScroll.frame.height)
                let vehid = "\(self.vehicleID)"
                let vehGroupIdStr = "\(self.vehGroupId ?? 0)"
                let orgIdStr = "\(self.orgId ?? 0)"
                accVC.vehID = NSString(string: vehid).integerValue
                accVC.vehGroupID = NSString(string: vehGroupIdStr).integerValue
                accVC.orgID = NSString(string: orgIdStr).integerValue
                VCScroll.addSubview(accVC.view)
                addChild(accVC)
                childVCs["AccidentViewController"] = accVC
            case 3:
                
                //  维保
//                print("维保")
                eventOption.isHidden = true
                timeOption.isHidden = false
                let maintenanceVC = MaintenanceViewController.init(height: VCScroll.frame.height)
                maintenanceVC.view.frame = CGRect.init(x: KW*3, y: 0, width: KW, height: VCScroll.frame.height)
                let vehid = "\(self.vehicleID)"
                let vehGroupIdStr = "\(self.vehGroupId ?? 0)"
                let orgIdStr = "\(self.orgId ?? 0)"
                maintenanceVC.vehID = NSString(string: vehid).integerValue
                maintenanceVC.vehGroupID = NSString(string: vehGroupIdStr).integerValue
                maintenanceVC.orgID = NSString(string: orgIdStr).integerValue
                VCScroll.addSubview(maintenanceVC.view)
                addChild(maintenanceVC)
                childVCs["MaintenanceViewController"] = maintenanceVC
                
            case 4:
                
                //  保险
//                print("保险")
                eventOption.isHidden = true
                timeOption.isHidden = false
                let insuranceVC = InsuranceViewController.init(height: VCScroll.frame.height)
                insuranceVC.view.frame = CGRect.init(x: KW*4, y: 0, width: KW, height: VCScroll.frame.height)
                let vehid = "\(self.vehicleID)"
                let vehGroupIdStr = "\(self.vehGroupId ?? 0)"
                let orgIdStr = "\(self.orgId ?? 0)"
                insuranceVC.vehID = NSString(string: vehid).integerValue
                insuranceVC.vehGroupID = NSString(string: vehGroupIdStr).integerValue
                insuranceVC.orgID = NSString(string: orgIdStr).integerValue
                VCScroll.addSubview(insuranceVC.view)
                addChild(insuranceVC)
                childVCs["InsuranceViewController"] = insuranceVC
            default: break
                //
            }
            
            VCScroll.setContentOffset(CGPoint.init(x: CGFloat(selectIndex)*KW, y: 0), animated: true)
        }
    }
    
    
    //  添加子控制器
    func loadSubControllers() -> Void {
        let scrollY = topView.frame.maxY
        
        VCScroll.frame = CGRect.init(x: 0, y: scrollY, width: KW, height: KH-scrollY-bottomHeight)
        VCScroll.contentSize = CGSize.init(width: KW*5, height: 0)
        VCScroll.isScrollEnabled = false
        VCScroll.showsVerticalScrollIndicator = false
        VCScroll.showsHorizontalScrollIndicator = false
        self.view.addSubview(VCScroll)
        
        //  如果从其他页面进入，跳过以下代码
        if selectIndex > 0 {
            return
        }
        //  风险事件
        let riskVC = RiskListViewController.init(height: VCScroll.frame.height)
        riskVC.driverID = Int64(self.driverID)
//        print("从这里添加司机ID\(self.driverID)")
        riskVC.orgid = self.orgId ?? 0
        riskVC.vehGroupId = self.vehGroupId ?? 0
        riskVC.view.frame = CGRect.init(x: 0, y: 0, width: KW, height: VCScroll.frame.height)
        VCScroll.addSubview(riskVC.view)
        addChild(riskVC)
        childVCs["RiskListViewController"] = riskVC
        
    }
    
    func handleFilterValue(index:Int,id:Int64)  {
        if index == 1 {
            //  组织下的index
            orgId = id
            vehGroupId = 0
            focusDriver = 2     //  选择了其他选项的话，必定没选择关注项
            focusVeh = 2
        }else if index == 2 {
            vehGroupId = id
            orgId = 0
            focusDriver = 2
            focusVeh = 2
        }else if index == 3 {
            //  点击关注的index
            orgId = 0
            vehGroupId = 0
            focusDriver = 1     //  不管当前在哪个页面，只能有一个关注项
            focusVeh = 1        //  所以暂时把两项都选中
//            if id==0 {
//                //  收藏车辆
//                focusVeh = 1
//            }else{
//                focusVeh = 2
//            }
        }else if index == 4{
            orgId = 0
            vehGroupId = 0
            focusDriver = 2
        }else {
            orgId = 0
            vehGroupId = 0
            focusDriver = 2
            focusVeh = 0
        }
        self.filterView.removeFromSuperview()
        self.transparentView.removeFromSuperview()
        sendRequestToChildController()
    }
    
    //  MARK: - 网络请求
    //  通知当前显示的控制器，根据筛选的各种条件请求数据
    func sendRequestToChildController() -> Void {
        //  拼接请求用的参数
        //  isInter ：是否选择干预状态，0=未选择干预，1=选择了已干预，2=选择了未干预
        //  focusVeh ：是否选择关注车辆，0=未选择，1=选择了关注车辆，2=选择了未关注
        let info = ["orgId" : orgId!,
                    "vehGroupId" : vehGroupId!,
                    "focusDriver" : focusDriver,
                    "focusVeh" : focusVeh,
                    "keyword" : keyword,
                    "eventName" : eventName,
                    "eventLevel" : eventLevel,
                    "beginTime" : beginTime,
                    "endTime" : endTime,
                    "isInter" : isInter] as [String : Any]
//        print("是否选了关注司机  \(focusVeh)")
        
        //  获取当前显示的是哪个控制器
        switch selectIndex {
        case 0:
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RiskListVCRequestNotf"), object: nil, userInfo: info)
        case 1:
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "TrafficViolationListVCRequestNotf"), object: nil, userInfo: info)
        case 2:
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "AccidentVCRequestNotf"), object: nil, userInfo: info)
        case 3:
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "MaintenanceVCRequestNotf"), object: nil, userInfo: info)
        case 4:
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "InsuranceVCRequestNotf"), object: nil, userInfo: info)
        default: break
            //
        }
        
    }
    
    
    //  获取事件类型
    func getEventListData() -> Void {
        HttpRequest.loadData(target: InterfaceAPI.getNotificationEventFilter, success: { (datas) in
            let json = JSON(datas)
            let data = JSONDeserializer<RiskConditionModel>.deserializeModelArrayFrom(json: json["data"].description)
            if data != nil {
                for model in data! {
                    self.eventArr.append(model!.events!)
                }
            }
        }) { (stateCode, message) in
            print("请求失败 \(message)")
        }
    }
    
    //  获取筛选条件
    func getOrgName() -> Void {
        HttpRequest.loadData(target: InterfaceAPI.getOrgsAndVehGroups, needCache: false, cache: nil, success: { (datas) in
            let json = JSON(datas)
            let data = JSONDeserializer<OrgAndVehGroupsModel>.deserializeFrom(json: json["data"].description)
            self.orgArr = data?.orgs ?? []
            self.vehicleGroupArr = data?.vehGroups ?? []
        }) { (stateCode, message) in
            
        }
    }
    
    
    //  MARK: - 点击事件
    //  点击搜索响应事件
    @objc func searchSomething() {
        print("点击搜索")
        searchLabel.resignFirstResponder()
        //  暂时先跳转到司机列表页面
        keyword = searchLabel.text ?? ""
        if keyword.count > 0 {
            print("有内容，并且是\(keyword)")
        }else{
            print("没有内容")
            return
        }
        sendRequestToChildController()
    }
    
    //  点击事件类型回调
    @objc func eventClicked() {
        //  先判断筛选框是否弹出
        if filterViewIsShow {
            //
            self.filterViewIsShow = false
            self.filterView.removeFromSuperview()
            self.transparentView.removeFromSuperview()
        }
        //  判断自己是否弹出
        if eventTypeViewIsShow {
            self.eventTypeViewIsShow = false
            self.eventType.removeFromSuperview()
            self.transparentView.removeFromSuperview()
            return
        }
        self.view.addSubview(transparentView)
        eventType = EventTypeView()
        eventType.secArr = self.eventArr
        eventType.frame = CGRect(x: 0, y: 0, width: KW, height: transparentView.height)
        self.eventTypeViewIsShow = true
        transparentView.addSubview(eventType)
        eventType.confirmClick = { selectStr, secondStr, thirdStr in
            self.eventTypeViewIsShow = false
            self.eventName = secondStr
            self.eventLevel = selectStr
            self.isInter = thirdStr == "已干预" ? 1 :((thirdStr == "") ? 0 : 2)
            
            self.eventType.removeFromSuperview()
            self.transparentView.removeFromSuperview()
            self.sendRequestToChildController()     //  发送请求通知
        }
        
        eventType.resetClick = {
            print("重置事件类型")
        }
        
        eventType.closeClick = {
            self.eventTypeViewIsShow = false
            self.eventType.removeFromSuperview()
            self.transparentView.removeFromSuperview()
        }
    }
    
    //  点击筛选条件回调
    @objc func filtrateCondition() {
        //  筛选条件
        if eventTypeViewIsShow {
            //
            self.eventTypeViewIsShow = false
            self.eventType.removeFromSuperview()
            self.transparentView.removeFromSuperview()
        }
        
        //  判断自己是否弹出
        if filterViewIsShow {
            self.filterViewIsShow = false
            self.filterView.removeFromSuperview()
            self.transparentView.removeFromSuperview()
            return
        }
        self.view.addSubview(transparentView)
        filterView = VehicleChooseViewForNorification.init(frame: CGRect(x: 0, y: 0, width: KW, height: transparentView.height),orgArr:self.orgArr,vehicleGroupArr:self.vehicleGroupArr,controllerIndex:selectIndex)
//        filterView.orgArr = self.orgArr
//        filterView.vehicleGroupArr = self.vehicleGroupArr
//        filterView.frame = CGRect(x: 0, y: scroll.frame.maxY+40, width: KW, height: KH - statusHeight - 100)
        transparentView.addSubview(filterView)
        filterViewIsShow = true
        filterView.passValue = { (index,id,isFocus) in
            self.filterViewIsShow = false
            if index == 0 && isFocus == true{
                //  未选择筛选条件
                self.handleFilterValue(index: 3, id: id)
            }else{
                self.handleFilterValue(index: index, id: id)
            }
        }
        
        filterView.resetClick = {
            self.handleFilterValue(index: 0, id: 0)
        }
        
        filterView.closeClick = {
            self.filterViewIsShow = false
            self.filterView.removeFromSuperview()
            self.transparentView.removeFromSuperview()
        }
    }
    
    @objc func timeOptionClicked () {
        print("选择时间")
        self.navigationController?.present(TimeSelectorViewController(), animated: true, completion: nil)
        
        /*
        return
        let bgView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: KW, height: navigationBarHeight))
        bgView.backgroundColor = UIColor.init(white: 1, alpha: 0.5)
        self.view.addSubview(bgView)

        let myCalendar = MyCalendarView(x:0,y:navigationBarHeight)
        myCalendar.tagFromStr = "playBack"
        self.view.addSubview(myCalendar)
        myCalendar.resultDate = { (startStr, endStr,startTimeStr1,endTimeStr2) in
            bgView.removeFromSuperview()
            
            if startStr != nil && endStr != nil {
                self.timeOption.titleLabel?.font = UIFont.systemFont(ofSize: 9)
                self.timeOption.setTitle("\(startStr!) \n\(endStr!)", for: .normal)
                
                self.beginTime = startStr!
                self.endTime = endStr!
                self.sendRequestToChildController()
            }else{
                self.timeOption.titleLabel?.font = UIFont.systemFont(ofSize: 12)
                self.timeOption.setTitle("选择时间", for: .normal)
            }
        }
 */
    }
    
    //  在时间选择控件里选择了时间的回调
    @objc func didSelectedTimeForPicker(notf:Notification) -> Void {
//        print("更新了？？？？？？")
        let objc = notf.userInfo
        let startStr = objc!["beginTime"]
        let endStr = objc!["endTime"]
        if startStr != nil && endStr != nil {
            self.timeOption.titleLabel?.font = UIFont.systemFont(ofSize: 9)
            self.timeOption.setTitle("\(startStr!) \n\(endStr!)", for: .normal)
            
            self.beginTime = startStr as! String
            self.endTime = endStr as! String
            self.sendRequestToChildController()
        }else{
            self.timeOption.titleLabel?.font = UIFont.systemFont(ofSize: 12)
            self.timeOption.setTitle("选择时间", for: .normal)
        }
    }
    
    //  点击导航栏左侧返回按钮时调用
    @objc func backOff() {
//        print("返回上一级页面")
        for (_,VC) in childVCs {
            NotificationCenter.default.removeObserver(VC)
        }
        NotificationCenter.default.removeObserver(self)
        self.navigationController?.popViewController(animated: true)
    }
    
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
        
        if selectIndex>0 {
            let type = types[selectIndex]
            self.changeTypeSelectStatus(index: type.tag)
            type.setTypeViewSelectStatus(selected: true)
        }
        
        //  获取事件列表
        if self.eventArr == nil || self.eventArr.count < 1 {
            getEventListData()
        }
        
        //  获取筛选数据
        if self.orgArr.count < 1 && self.vehicleGroupArr.count < 1{
            getOrgName()
        }
    }
    
    lazy var transparentView:UIView = {
        let transparentView = UIView()
        transparentView.backgroundColor = UIColor.clear
        transparentView.frame = CGRect(x: 0, y: topView.height, width: KW, height: KH-topView.height)
        transparentView.isUserInteractionEnabled = true
        return transparentView
    }()
    
    
    //  当页面消失时判断是否需要注销通知观察者
    override func viewDidDisappear(_ animated: Bool) {
        var canRemove = true
        //  如果导航栈中存在当前控制器
        let controllers = self.navigationController?.viewControllers ?? []
        for vc in controllers {
            if vc.isKind(of: NotificationViewController.self) {
                //  如果存在，则表示当前操作不属于出栈，不用移除通知消息监听者
                canRemove = false
            }
        }
        
        if canRemove {
            for (_,VC) in childVCs {
                NotificationCenter.default.removeObserver(VC)
            }
        }
    }
}
