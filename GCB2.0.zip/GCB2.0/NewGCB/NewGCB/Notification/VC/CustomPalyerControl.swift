//
//  CustomPalyerControl.swift
//  NewGCB
//
//  Created by 亭子 on 2020/2/19.
//  Copyright © 2020 YTKJ. All rights reserved.
//  自定义视频播放控制面板，可控制显示进度条、视频事件等控件

import UIKit
import BMPlayer

class CustomPalyerControl: BMPlayerControlView,BMPlayerControlViewDelegate {
    func controlView(controlView: BMPlayerControlView, didChooseDefinition index: Int) {
        //
    }
    
    func controlView(controlView: BMPlayerControlView, didPressButton button: UIButton) {
        //
    }
    
    func controlView(controlView: BMPlayerControlView, slider: UISlider, onSliderEvent event: UIControl.Event) {
        //
    }
    

//    var palyButton = UIButton()
    override func customizeUIComponents() {
//        playButton.isHidden = true
        replayButton.isHidden = true
        fullscreenButton.isHidden = true
        backButton.isHidden = true
        timeSlider.removeFromSuperview()
        progressView.removeFromSuperview()
        totalTimeLabel.removeFromSuperview()
        currentTimeLabel.removeFromSuperview()
        
//        palyButton.setImage(UIImage.init(named: "video_player_play"), for: .normal)
//        palyButton.setImage(UIImage.init(named: "video_player_pasue"), for: .selected)
//        palyButton.addTarget(self, action: #selector(playVideo), for: .touchUpInside)
//        mainMaskView.addSubview(palyButton)
//        palyButton.snp.makeConstraints { (make) in
//            make.center.equalTo(mainMaskView.snp.center)
//            make.size.equalTo(CGSize.init(width: 50, height: 50))
//        }
    }
    override func updateUI(_ isForFullScreen: Bool) {
        topMaskView.isHidden = true
        chooseDefinitionView.isHidden = true
    }
    
    func controlView(controlView: BMPlayerControlView, didChangeVideoPlaybackRate rate: Float) {
        print("从这里间听到拖动进度条")
    }
    
    @objc func playVideo() -> Void {
        guard let layer = player?.playerLayer else {
            return
        }
//        if palyButton.isSelected {
//            print("暂停")
//            layer.pause()
//            palyButton.isSelected = false
//        }else{
//            print("播放")
//            layer.play()
//            palyButton.isSelected = true
//        }
    }
    
    override func playTimeDidChange(currentTime: TimeInterval, totalTime: TimeInterval) {
//        playTimeUIProgressView.setProgress(Float(currentTime/totalTime), animated: true)
    }

    override func onTapGestureTapped(_ gesture: UITapGestureRecognizer) {
        // redirect tap action to play button action
        delegate?.controlView(controlView: self, didPressButton: playButton)
    }
    
    override func playStateDidChange(isPlaying: Bool) {
        super.playStateDidChange(isPlaying: isPlaying)
//        playingStateLabel.text = isPlaying ? "Playing" : "Paused"
    }
    
    override func controlViewAnimation(isShow: Bool) {
        
    }

}
