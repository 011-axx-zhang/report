//
//  RiskListViewController.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/5.
//  Copyright © 2019 YTKJ. All rights reserved.
//  风险事件

import UIKit
import HandyJSON
import SwiftyJSON

class RiskListViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    var dataSource : [RiskListModel] = []
    var eventList : UITableView!
    var pageOffset = 0  //  请求数据的条数，从0开始以10为值自增
    var isInter = false
    var requestValue : [String : Any] = [:]
    var isSelectInter = false   //  是否选择已干预
    var isSelectFocus = false   //  是否选择关注司机
    var driverID:Int64 = 0      //  司机ID
    var orgid:Int64 = 0         //  组织ID
    var vehGroupId:Int64 = 0    //  车队ID
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        
    }
    
    init(height: CGFloat) {
        super.init(nibName: nil, bundle: nil)
        self.loadTableView(tableHeight: height)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.removeObserver(self)
        NotificationCenter.default.addObserver(self, selector: #selector(requestNotification(notf:)), name: NSNotification.Name(rawValue: "RiskListVCRequestNotf"), object: nil)
    }
    
    func loadTableView(tableHeight : CGFloat) -> Void {
        eventList = UITableView.init(frame: .init(x: 0.0, y: 0.0, width: self.view.frame.width, height: tableHeight), style: .plain)
        eventList.delegate = self
        eventList.dataSource = self
        eventList.rowHeight = 120.0
        eventList.separatorStyle = .none
        eventList.backgroundColor = UIColor.white
        self.view.addSubview(eventList)
        eventList!.register(RiskListTableViewCell.self, forCellReuseIdentifier: "notiCellID")
        eventList.mj_header = MJRefreshNormalHeader.init(refreshingBlock: {
            self.dataSource.removeAll()
            self.getNewData()
        })
        eventList.mj_footer = MJRefreshBackNormalFooter.init(refreshingBlock: {
            self.getMoreData()
        })
    }
    
    //  MARK: - tableView 代理
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
        
    }
     
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "notiCellID", for: indexPath) as! RiskListTableViewCell
        cell.selectionStyle = .none
        if indexPath.row>=0&&indexPath.row<dataSource.count {
            cell.configDataSource(riskData: dataSource[indexPath.row])
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailVC = RiskDetailsViewController()
        detailVC.riskInfo = dataSource[indexPath.row]
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
    
    //  MARK: - 刷新
    func getNewData() -> Void {
        pageOffset = 0
        getRiskListData(orgID: requestValue["orgId"] as! Int, vehGroupID: requestValue["vehGroupId"] as! Int, key: requestValue["key"] as! String, event: requestValue["event"] as! String, level: requestValue["level"] as! String, focusDriver: requestValue["focusDriver"] as! Bool, isInter: isInter)
    }
    func getMoreData() -> Void {
        pageOffset += 10
        getRiskListData(orgID: requestValue["orgId"] as! Int, vehGroupID: requestValue["vehGroupId"] as! Int, key: requestValue["key"] as! String, event: requestValue["event"] as! String, level: requestValue["level"] as! String, focusDriver: requestValue["focusDriver"] as! Bool, isInter: isInter)
    }
    
//    MARK: - 请求
    func getRiskListData(orgID:Int, vehGroupID:Int, key:String, event:String, level:String, focusDriver:Bool, isInter:Bool) -> Void {
        var param = ["orgId":orgID,
                     "vehGroupId":vehGroupID,
                     "focusDriver":focusDriver,    //  是否关注司机
                     "driverId":Int(self.driverID),
                     "key":key,
                     "event":event,
                     "level":level,
                     "isInter":isInter,   //  是否干预
                     "limit":10,
                     "offset":pageOffset] as [String : Any]
        
        requestValue = param
        
        //  值为 0 或者没有的话就不传
        for (objcKey, objcValue) in param {
            if objcValue is Int && objcValue as! Int == 0 && objcKey != "offset"{
                param.removeValue(forKey: objcKey)
            }else if objcValue is String && objcValue as! String == "" {
                param.removeValue(forKey: objcKey)
            }
        }
        
        //  如果是首次进入，无需传以下参数
        if isSelectFocus == false {
            param.removeValue(forKey: "focusDriver")
        }
        if isSelectInter == false {
            param.removeValue(forKey: "isInter")
        }
//        print("请求风险事件里列表参数--\(param)")
        
        HttpRequest.loadData(target: InterfaceAPI.getNotificationEvents(param: param), success: { (datas) in
            if self.eventList.mj_footer.isRefreshing {
                self.eventList.mj_footer.endRefreshing()
            }else if self.eventList.mj_header.isRefreshing {
                self.eventList.mj_header.endRefreshing()
            }
            let json = JSON(datas)
            let data = JSONDeserializer<RiskListModel>.deserializeModelArrayFrom(json: json["data"].description)
            for model in data ?? [] {
                self.dataSource.append(model!)
            }
            if data?.count == 0 || data == nil{
                self.view.makeToastMid(message: "没有更多内容")
            }
            self.eventList.reloadData()
        }) { (stateCode, message) in
            print("请求失败 \(message)")
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        if dataSource.count<1 {
            self.getRiskListData(orgID: Int(self.orgid), vehGroupID: Int(self.vehGroupId), key: "", event: "", level: "", focusDriver: false, isInter: isInter)
        }
    }
    
    // MARK: - 通知
    //  选中筛选条件时，通过发送通知让控制器刷新数据
    @objc func requestNotification(notf: NSNotification) -> Void {
        
        /*["orgId" : orgId!,
        "vehGroupId" : vehGroupId!,
        "focusDriver" : focusDriver,
        "focusVeh" : focusVeh,
        "keyword" : keyword,
        "eventName" : eventName,
        "eventLevel" : eventLevel,
        "isInter" : isInter]*/
        guard let org = notf.userInfo!["orgId"] as? Int64 else {
            return
        }
        guard let vehID = notf.userInfo!["vehGroupId"] as? Int64 else {
            return
        }
        guard let keyword = notf.userInfo!["keyword"] as? String else {
            return
        }
        guard let eventName = notf.userInfo!["eventName"] as? String else {
            return
        }
        guard let level = notf.userInfo!["eventLevel"] as? String else {
            return
        }
        guard let focusVeh = notf.userInfo!["focusVeh"] as? Int else {
            return
        }
        guard let inter = notf.userInfo!["isInter"] as? Int else {
            return
        }
//        print("刷新风险事件列表通知 \(notf.userInfo)")
        //  选择了筛选条件以后修改
        if inter == 0 {
            isSelectInter = false
        }else{
            isSelectInter = true
        }
        
        if focusVeh == 1 {
            isSelectFocus = true
        }else{
            isSelectFocus = false
        }
        isInter = inter == 1 ? true : false
        let focus = focusVeh == 1 ? true : false
        pageOffset = 0
        dataSource.removeAll()
        getRiskListData(orgID: Int(org), vehGroupID: Int(vehID), key: keyword, event: eventName, level: level, focusDriver:focus, isInter: isInter)
        
    }

}
