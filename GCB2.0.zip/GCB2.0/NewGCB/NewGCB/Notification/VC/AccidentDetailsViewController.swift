//
//  AccidentDetailsViewController.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/11.
//  Copyright © 2019 YTKJ. All rights reserved.
//  事故详情

import HandyJSON
import SwiftyJSON

class AccidentDetailsViewController: RootController {
    var driverView = EventDriverView()
    var listView = EventDetailsListView()
    var listView2 = EventDetailsListView()
    let claimSettlement = UILabel()
    var listView3 = EventDetailsListView()
    var detailsModel:AccidentDetailsModel!
    let recordOne = UILabel.init()
    let recordResult = UILabel.init()
    var accidentID:Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.init(hex: "#F5F5F9", alpha: 1.0)
        self.setNavViewData(title: "事故通知详情", leftImage: nil, rightImage: nil)
        
        loadInfomationView()
    }
    
    func loadInfomationView() -> Void {
        
        driverView = EventDriverView.init()
        self.view.addSubview(driverView)
        
        let recordView = UIView.init()
        recordView.backgroundColor = UIColor.white
        self.view.addSubview(recordView)
        
        
        recordOne.backgroundColor = UIColor.init(hex: "#F23E3E", alpha: 0.2)
        recordOne.font = UIFont.systemFont(ofSize: 11)
        recordOne.textAlignment = NSTextAlignment.center
        recordOne.textColor = UIColor.init(hex: "#F23E3E", alpha: 1.0)
        recordView.addSubview(recordOne)
        
        recordResult.textColor = UIColor.init(hex: "#5C5E74", alpha: 1.0)
        recordResult.font = UIFont.systemFont(ofSize: 14)
        recordResult.textAlignment = NSTextAlignment.right
        recordResult.text = "公司已支付"
        recordView.addSubview(recordResult)
        
        let line = UIView.init()
        line.backgroundColor = UIColor.init(hex: "#F5F5F9", alpha: 1.0)
        recordView.addSubview(line)
        
        
        listView = EventDetailsListView.init(frame: CGRect.zero, list: ["驾驶员责任","事故性质","事故原因","事故责任","事故过程"])
        recordView.addSubview(listView)
        
        let line2 = UIView.init()
        line2.backgroundColor = UIColor.init(hex: "#F5F5F9", alpha: 1.0)
        recordView.addSubview(line2)
        
        listView2 = EventDetailsListView.init(frame: CGRect.zero, list: ["责任人","责任人电话","违章时间","违章地点"])
        recordView.addSubview(listView2)
        
        claimSettlement.text = "保险理赔"
        claimSettlement.textColor = UIColor.black
        claimSettlement.font = UIFont.systemFont(ofSize: 14)
        self.view.addSubview(claimSettlement)
        
        listView3 = EventDetailsListView.init(frame: CGRect.zero, list: ["保险理赔金额","保险到账日期"])
        self.view.addSubview(listView3)
        
        driverView.snp.makeConstraints { (make) in
            make.left.equalTo(self.view.snp.left)
            make.top.equalTo(self.view.snp.top).offset(navigationBarHeight)
            make.width.equalTo(KW)
            make.height.equalTo(112)
        }
        
        recordView.snp.makeConstraints { (make) in
            make.left.equalTo(self.view.snp.left)
            make.top.equalTo(driverView.snp.bottom).offset(10)
            make.width.equalTo(KW)
            make.height.equalTo(352)
        }
        
        recordOne.snp.makeConstraints { (make) in
            make.left.equalTo(recordView.snp.left).offset(15)
            make.top.equalTo(recordView.snp.top).offset(20)
            make.height.equalTo(22)
//            make.width.equalTo(100)
        }
        
        recordResult.snp.makeConstraints { (make) in
            make.right.equalTo(recordView.snp.right).offset(-15)
            make.top.equalTo(recordView.snp.top).offset(20)
            make.height.equalTo(20)
        }
        
        line.snp.makeConstraints { (make) in
            make.left.equalTo(recordView.snp.left).offset(15)
            make.right.equalTo(recordView.snp.right).offset(-15)
            make.top.equalTo(recordOne.snp.bottom).offset(16)
            make.height.equalTo(1)
        }
        
        listView.snp.makeConstraints { (make) in
            make.left.equalTo(self.view.snp.left)
            make.top.equalTo(line.snp.bottom).offset(6)
            make.width.equalTo(KW)
        }
        
        line2.snp.makeConstraints { (make) in
            make.left.equalTo(recordView.snp.left).offset(15)
            make.right.equalTo(recordView.snp.right).offset(-15)
            make.top.equalTo(listView.snp.bottom).offset(10)
            make.height.equalTo(1)
        }
        
        listView2.snp.makeConstraints { (make) in
            make.left.equalTo(self.view.snp.left)
            make.top.equalTo(line2.snp.bottom).offset(6)
            make.width.equalTo(KW)
        }
        
        claimSettlement.snp.makeConstraints { (make) in
            make.left.equalTo(self.view.snp.left).offset(15)
            make.top.equalTo(recordView.snp.bottom).offset(10)
            make.height.equalTo(20)
        }
        
        listView3.snp.makeConstraints { (make) in
            make.left.equalTo(self.view.snp.left)
            make.top.equalTo(claimSettlement.snp.bottom).offset(10)
            make.width.equalTo(KW)
        }
    }
    
    
    //  MARK:- 获取事故详情
    func getDetailsData() -> Void {
        let param = ["accidentId":accidentID!] as [String : Any]
        HttpRequest.loadData(target: InterfaceAPI.getNotificationAccidentDetail(param: param), success: { (datas) in
            let json = JSON(datas)
            let data = JSONDeserializer<AccidentDetailsModel>.deserializeFrom(json: json["data"].description)
            self.detailsModel = data
            
            self.resetViewData()
        }) { (stateCode, message) in
            print("请求失败  \(message)")
        }
    }
    
    //  重置页面数据
    func resetViewData() -> Void {
        let model = EventDriverModel.init()
        model.image = "default_header_portrait"
        model.number = detailsModel?.plateNo
        model.type = detailsModel?.model
        model.orgName = detailsModel?.orgName
        model.driverName = "驾驶员:"+(detailsModel?.driverName ?? "")
        model.textFont = UIFont.boldSystemFont(ofSize: 15)
        model.textColor = UIColor.black
        driverView.setViewData(objc: model)
        
        
        print("保险数据 \(String(describing: detailsModel.toJSON()))")
        recordOne.text = "  定损金额 \(detailsModel.loss ?? 0) 元  "
        
        listView.setContentViewData(contents: [(detailsModel.driverLiability ?? " "),(detailsModel.nature ?? " "),(detailsModel.reason ?? " "),(detailsModel.accidentLiability ?? " "),(detailsModel.process ?? " ")])
        listView2.setContentViewData(contents: [(detailsModel.liabilityPerson ?? " "),(detailsModel.liabilityPhone ?? " "),(detailsModel.time ?? " "),(detailsModel.address ?? " ")])
        listView3.setContentViewData(contents: ["\(detailsModel.insuranceArrivalMoney ?? 0)元",(detailsModel.insuranceArrivalDate ?? " ")])
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        if detailsModel == nil {
            getDetailsData()
        }
    }

}
