//
//  TimeSelectorViewController.swift
//  NewGCB
//
//  Created by 亭子 on 2020/2/20.
//  Copyright © 2020 YTKJ. All rights reserved.
//  时间选择控件

import UIKit

class TimeSelectorViewController: UIViewController,UITextFieldDelegate,UIPickerViewDelegate,UIPickerViewDataSource {
    let dayButton = UIButton.init(type: .custom)
    let monthButton = UIButton.init(type: .custom)
    let deleteButton = UIButton.init(type: .custom)
    let beginLabel = UITextField.init()
    let beginLine = UIView.init()
    let endLabel = UITextField.init()
    let endLine = UIView.init()
    let monthLabel = UILabel.init()
    let monthLine = UIView.init()
    let centerLabel = UILabel.init()
    let datePicker = UIDatePicker.init()
    let monthPicker = UIPickerView.init()
    var isBeginTime = true  //  当前编辑的是否是开始时间，默认是true
    var yearsArr : [Int] = []
    let monthsArr = ["1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"]
    var nowYear:Int?        //  系统当前年份
    var nowMonth:Int?       //  系统当前月份
    var selectYear:Int?     //  用户选择的年份
    var selectMonth:Int?    //  用户选择的月份
    
    //  选中的结果
    var selectedBeginTime = ""
    var selectedEndTime = ""
    var selectedMonth = ""
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white

        loadNavViewBar()
        loadTimeView()
    }
    
    func loadNavViewBar() -> Void {
        let statusHight = 20
        let navView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: KW, height: navigationBarHeight))
        navView.backgroundColor = UIColor.white
        self.view.addSubview(navView)
        
        let cancelBtn = UIButton.init(type: .custom)
        cancelBtn.frame = CGRect.init(x: 15, y: statusHight, width: 44, height: 44)
        cancelBtn.setTitle("取消", for: .normal)
        cancelBtn.setTitleColor(UIColor.hex(hex: "#1D69F5"), for: .normal)
        cancelBtn.addTarget(self, action: #selector(cancelTimeSelector), for: .touchUpInside)
        navView.addSubview(cancelBtn)
        
        let navTitle = UILabel.init(frame: CGRect.init(x: Int(KW/2-40), y: statusHight, width: 80, height: 44))
        navTitle.text = "选择时间"
        navTitle.textAlignment = NSTextAlignment.center
        navTitle.font = UIFont.boldSystemFont(ofSize: 17)
        navView.addSubview(navTitle)
        
        let done = UIButton.init(type: .custom)
        done.frame = CGRect.init(x: KW-15-44, y: 20, width: 44, height: 44)
        done.setTitle("完成", for: .normal)
        done.setTitleColor(UIColor.hex(hex: "#1D69F5"), for: .normal)
        done.addTarget(self, action: #selector(didEndSelectedTimePicker), for: .touchUpInside)
        navView.addSubview(done)
        
        let line = UIView.init(frame: .init(x: 0, y: cancelBtn.frame.maxY+11, width: KW, height: 1))
        line.backgroundColor = UIColor.hex(hex: "#DFDFF1")
        navView.addSubview(line)
    }
    
    func loadTimeView() -> Void {
        
        
        dayButton.isSelected = true     //  默认选中
        dayButton.layer.cornerRadius = 5
        dayButton.setTitle("按日选择", for: .normal)
        dayButton.setTitleColor(.white, for: .selected)
        dayButton.setTitleColor(.black, for: .normal)
        dayButton.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        dayButton.backgroundColor = UIColor.hex(hex: "#1D69F5")
        dayButton.addTarget(self, action: #selector(selectedDayButton), for: .touchUpInside)
        self.view.addSubview(dayButton)
        

        monthButton.layer.cornerRadius = 5
        monthButton.setTitle("按月选择", for: .normal)
        monthButton.setTitleColor(.white, for: .selected)
        monthButton.setTitleColor(.black, for: .normal)
        monthButton.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        monthButton.backgroundColor = UIColor.white
        monthButton.addTarget(self, action: #selector(selectedMonthButton), for: .touchUpInside)
        self.view.addSubview(monthButton)
        
        beginLabel.tag = 101
        beginLabel.delegate = self
        beginLabel.font = UIFont.systemFont(ofSize: 15)
        beginLabel.textColor = UIColor.hex(hex: "#9395AC")
        beginLabel.textAlignment = NSTextAlignment.center
        beginLabel.placeholder = "开始时间"
        self.view.addSubview(beginLabel)
        
        beginLine.backgroundColor = UIColor.hex(hex: "#1D69F5")
        self.view.addSubview(beginLine)
        
        centerLabel.font = UIFont.systemFont(ofSize: 15)
        centerLabel.textColor = UIColor.black
        centerLabel.textAlignment = NSTextAlignment.center
        centerLabel.text = "至"
        self.view.addSubview(centerLabel)
        
        endLabel.tag = 102
        endLabel.delegate = self
        endLabel.font = UIFont.systemFont(ofSize: 15)
        endLabel.textColor = UIColor.hex(hex: "#9395AC")
        endLabel.textAlignment = NSTextAlignment.center
        endLabel.placeholder = "结束时间"
        self.view.addSubview(endLabel)
        
        endLine.backgroundColor = UIColor.hex(hex: "#E6E9EE")
        self.view.addSubview(endLine)
        
        monthLabel.font = UIFont.systemFont(ofSize: 15)
        monthLabel.isHidden = true
        monthLabel.textColor = UIColor.hex(hex: "#9395AC")
        monthLabel.textAlignment = NSTextAlignment.center
        monthLabel.text = "选择月份"
        self.view.addSubview(monthLabel)
        
        monthLine.backgroundColor = UIColor.hex(hex: "#1D69F5")
        monthLine.isHidden = true
        self.view.addSubview(monthLine)
        
        deleteButton.setImage(UIImage.init(named: "date_picker_delete"), for: .normal)
        deleteButton.addTarget(self, action: #selector(deleteSeletedTime), for: .touchUpInside)
        self.view.addSubview(deleteButton)
        
        
        let format = DateFormatter()
        format.dateFormat = "yyyy-MM-dd"
//        format.setLocalizedDateFormatFromTemplate()
//        let date = format.date(from: "1900-01-01")
        datePicker.datePickerMode = .date
        datePicker.date = Date()
        datePicker.locale = Locale.init(identifier: "zh_CN")
        datePicker.minimumDate = Date.init(timeIntervalSince1970: 31536000*30)  //  最小时间范围从1970年往后30年，也就是2000年
        datePicker.maximumDate = Date()
        datePicker.addTarget(self, action: #selector(selectedTimePickerView(_:)), for: .valueChanged)
        self.view.addSubview(datePicker)
        
        
        monthPicker.dataSource = self
        monthPicker.delegate = self
        monthPicker.isHidden = true
        self.view.addSubview(monthPicker)
        
        dayButton.snp.makeConstraints { (make) in
            make.left.equalTo(self.view.snp.left).offset(112)
            make.top.equalTo(self.view.snp.top).offset(navigationBarHeight+40)
            make.size.equalTo(CGSize.init(width: 64, height: 24))
        }
        
        monthButton.snp.makeConstraints { (make) in
            make.right.equalTo(self.view.snp.right).offset(-112)
            make.top.equalTo(self.view.snp.top).offset(navigationBarHeight+40)
            make.size.equalTo(CGSize.init(width: 64, height: 24))
        }
        
        beginLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.view.snp.left).offset(15)
            make.top.equalTo(dayButton.snp.bottom).offset(32)
            make.size.equalTo(CGSize.init(width: 150, height: 20))
        }
        
        beginLine.snp.makeConstraints { (make) in
            make.left.equalTo(self.view.snp.left).offset(15)
            make.top.equalTo(beginLabel.snp.bottom).offset(4)
            make.size.equalTo(CGSize.init(width: 150, height: 1))
        }
        
        endLabel.snp.makeConstraints { (make) in
            make.right.equalTo(self.view.snp.right).offset(-15)
            make.top.equalTo(monthButton.snp.bottom).offset(32)
            make.size.equalTo(CGSize.init(width: 150, height: 20))
        }
        
        endLine.snp.makeConstraints { (make) in
            make.right.equalTo(self.view.snp.right).offset(-15)
            make.top.equalTo(endLabel.snp.bottom).offset(4)
            make.size.equalTo(CGSize.init(width: 150, height: 1))
        }
        
        monthLabel.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.view.snp.centerX)
            make.top.equalTo(monthButton.snp.bottom).offset(32)
            make.size.equalTo(CGSize.init(width: 300, height: 20))
        }
        
        monthLine.snp.makeConstraints { (make) in
            make.left.equalTo(self.view.snp.left).offset(15)
            make.right.equalTo(self.view.snp.right).offset(-15)
            make.top.equalTo(monthLabel.snp.bottom).offset(4)
            make.height.equalTo(1)
        }
        
        centerLabel.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.view.snp.centerX)
            make.top.equalTo(monthButton.snp.bottom).offset(32)
            make.size.equalTo(CGSize.init(width: 15, height: 20))
        }
        
        deleteButton.snp.makeConstraints { (make) in
            make.right.equalTo(self.view.snp.right).offset(-15)
            make.top.equalTo(monthLine.snp.bottom).offset(16)
            make.size.equalTo(CGSize.init(width: 30, height: 30))
        }
        
        datePicker.snp.makeConstraints { (make) in
            make.left.equalTo(self.view.snp.left)
            make.top.equalTo(deleteButton.snp.bottom).offset(8)
            make.right.equalTo(self.view.snp.right)
            make.height.equalTo(164)
        }
        
        monthPicker.snp.makeConstraints { (make) in
            make.left.equalTo(self.view.snp.left)
            make.top.equalTo(deleteButton.snp.bottom).offset(8)
            make.right.equalTo(self.view.snp.right)
            make.height.equalTo(164)
        }
    }
    
    //  修改时间
    func changeTimeLabelwithTimeStr(time:String) -> Void {
        if dayButton.isSelected {
            //  按日
            if isBeginTime {
                beginLabel.textColor = UIColor.hex(hex: "#1D69F5")
                beginLabel.text = time
            }else {
                endLabel.textColor = UIColor.hex(hex: "#1D69F5")
                endLabel.text = time
            }
        }
        if monthButton.isSelected {
            //  按月
            if monthLabel.text == "选择月份" {
                monthLabel.text = time
                monthLabel.textColor = UIColor.hex(hex: "#1D69F5")
            }
        }
    }
    
    //MARK:- UITextField代理
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.resignFirstResponder()
        if textField.tag == 101 {
            //  开始时间
            isBeginTime = true
            beginLine.backgroundColor = UIColor.hex(hex: "#1D69F5")
            endLine.backgroundColor = UIColor.hex(hex: "#E6E9EE")
        }else{
            //  结束时间
            isBeginTime = false
            beginLine.backgroundColor = UIColor.hex(hex: "#E6E9EE")
            endLine.backgroundColor = UIColor.hex(hex: "#1D69F5")
        }
    }
    
    //MARK:- UIPickerView 代理
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        return KW/2
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component == 0 {
            selectYear = row
            if selectYear == yearsArr.count-1 {
                //  得到选中的月份
                let m = monthPicker.selectedRow(inComponent: 1)
                let nowIndex = monthsArr.firstIndex(of: "\(nowMonth ?? 1)月")
                if nowIndex! < m {
                    // 超出范围
                    selectMonth = nowIndex!
                    monthPicker.selectRow(nowIndex!, inComponent: 1, animated: true)
                }
            }
        }else{
            if selectYear == yearsArr.count-1 {
                if row > nowMonth!-1 {
                    //  不能选超出当前时间的范围
                    selectMonth = nowMonth! - 1
                    monthPicker.selectRow(selectMonth!, inComponent: 1, animated: true)
                }else{
                    selectMonth = row
                }
            }else{
                selectMonth = row
            }
        }
        
        let yearStr = yearsArr[selectYear!]
        let month = monthsArr[selectMonth!]
        monthLabel.text = "\(yearStr)年-\(month)"
        monthLabel.textColor = UIColor.hex(hex: "#1D69F5")
    }
    
    //MARK:- UIPickerView 数据源
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == 0 {
            return yearsArr.count
        }else{
            return monthsArr.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {

        if component == 0 {
            return "\(yearsArr[row])年"
        }else{
            return monthsArr[row]
        }
    }
    
    
    func getYearMonthDate() -> String {
        let date = Date()
//        let timeFormatter = DateFormatter()
//        timeFormatter.dateFormat = "yyyy-MM-dd"
//        let strNowTime = timeFormatter.string(from: date)
        
        
        nowYear = date.year
        nowMonth = date.month
        //  向前取20年
        for year in 0...20 {
            let a = nowYear! - 20 + year     //  a = 19XX 年
            yearsArr.append(a)
        }
//        print("得到年份\(yearsArr)")
        let returnValue = "\(date.month)月"
//        return strNowTime
        return returnValue
    }
    
    
    //  选择按日选择
    @objc func selectedDayButton() -> Void {
        monthLabel.isHidden = true
        monthLine.isHidden = true
        monthPicker.isHidden = true
        datePicker.isHidden = false
        beginLabel.isHidden = false
        beginLine.isHidden = false
        endLabel.isHidden = false
        endLine.isHidden = false
        centerLabel.isHidden = false
        dayButton.isSelected = true
        monthButton.isSelected = false
        dayButton.backgroundColor = UIColor.hex(hex: "#1D69F5")
        monthButton.backgroundColor = UIColor.clear
    }
    
    
    //  选择按月选择
    @objc func selectedMonthButton() -> Void {
        monthLabel.isHidden = false
        monthLine.isHidden = false
        monthPicker.isHidden = false
        datePicker.isHidden = true
        beginLabel.isHidden = true
        beginLine.isHidden = true
        endLabel.isHidden = true
        endLine.isHidden = true
        centerLabel.isHidden = true
        dayButton.isSelected = false
        monthButton.isSelected = true
        dayButton.backgroundColor = UIColor.clear
        monthButton.backgroundColor = UIColor.hex(hex: "#1D69F5")
        
        let month = getYearMonthDate()
        let index = monthsArr.firstIndex(of: month)
        selectYear = yearsArr.count-1
        selectMonth = index
        monthPicker.reloadAllComponents()
        monthPicker.selectRow(yearsArr.count-1, inComponent: 0, animated: true)
        monthPicker.selectRow(index ?? 0, inComponent: 1, animated: true)
    }
    
    @objc func deleteSeletedTime() -> Void {
        if dayButton.isSelected {
            //  按日选择，删除所有
            isBeginTime = true  //  点击删除之后开始时间为默认
            selectedBeginTime = ""
            selectedEndTime = ""
            beginLabel.text = ""
            beginLabel.textColor = UIColor.hex(hex: "#9395AC")
            endLabel.text = ""
            endLabel.textColor = UIColor.hex(hex: "#9395AC")
        }
        
        if monthButton.isSelected {
            selectedMonth = ""
            monthLabel.text = "选择月份"
            monthLabel.textColor = UIColor.hex(hex: "#9395AC")
        }
    }
    
    @objc func selectedTimePickerView(_ datePicker:UIDatePicker) -> Void {
        let  chooseDate = datePicker.date
        let  dateFormater = DateFormatter.init()
        dateFormater.dateFormat = "YYYY-MM-dd"
//        print(dateFormater.string(from: chooseDate))
        changeTimeLabelwithTimeStr(time: dateFormater.string(from: chooseDate))
    }
    
    @objc func didEndSelectedTimePicker() -> Void {
        var beginTime = ""
        var endTime = ""
        if dayButton.isSelected {
            //  按日
            if beginLabel.text != "" && endLabel.text != "" {
                beginTime = beginLabel.text!
                endTime = endLabel.text!
            }
        }
        
        if monthButton.isSelected {
            //  按月
            if monthLabel.text != "选择月份" {
                let month = selectMonth!+1 < 10 ? "0\(selectMonth!+1)" : "\(selectMonth!+1)"
                
                beginTime = "\(yearsArr[selectYear!])-\(month)-1"
                var day = 30
                switch selectMonth {
                case 0,2,4,6,7,9,11:
                    day = 31
                    break
                case 1:
                    day = 28
                    break
                default:
                    day = 30
                }
                endTime = "\(yearsArr[selectYear!])-\(month)-\(day)"
            }
        }
        
//        print("选择的日期\(beginTime)   \(endTime)")
        if beginTime != "" && endTime != "" {
            let objc = ["beginTime":beginTime,"endTime":endTime]
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "DidSelectedTimeNotification"), object: nil, userInfo: objc)
        }

        self.dismiss(animated: true, completion: nil)
    }
    @objc func cancelTimeSelector() -> Void {
//        print("取消时间选择器")
        self.dismiss(animated: true, completion: nil)
    }
}
