//
//  TrafficViolationDetailsViewController.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/10.
//  Copyright © 2019 YTKJ. All rights reserved.
//  交通违章详情

import SwiftyJSON
import HandyJSON

class TrafficViolationDetailsViewController: RootController {
    let recordOne = UILabel()   //  违章记录1
    let recordTwo = UILabel()   //  违章记录2
    let processingResult = UILabel()    //  违章处理结果
    var driverInfo = EventDriverView()
    var event = EventDetailsListView()
    var otherEvent = EventDetailsListView()
    var detailsModel:TrafficViolationDetailsModel!
    var violate:Int = 0
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setNavViewData(title: "交通违章详情", leftImage: nil, rightImage: nil)
        loadInfomationView()
        
    }
    
    func loadInfomationView() -> Void {
        let contentView = UIView.init(frame: .init(x: 0, y: navigationBarHeight, width: KW, height: KH-navigationBarHeight))
        contentView.backgroundColor = UIColor.white
        self.view.addSubview(contentView)
        
        driverInfo = EventDriverView.init()
        contentView.addSubview(driverInfo)
        
        let line = UIView()
        line.backgroundColor = UIColor.init(hex: "#F5F5F9", alpha: 1.0)
        contentView.addSubview(line)
        
        recordOne.font = UIFont.systemFont(ofSize: 11)
        recordOne.backgroundColor = UIColor.init(hex: "#F23E3E", alpha: 0.2)
        recordOne.textColor = UIColor.init(hex: "#F23E3E", alpha: 1.0)
        contentView.addSubview(recordOne)
        
        recordTwo.backgroundColor = UIColor.init(hex: "#F23E3E", alpha: 0.2)
        recordTwo.textColor = UIColor.init(hex: "#F23E3E", alpha: 1.0)
        recordTwo.font = UIFont.systemFont(ofSize: 11)
        contentView.addSubview(recordTwo)
        
        processingResult.font = UIFont.boldSystemFont(ofSize: 14)
        processingResult.textColor = UIColor.init(hex: "#FB6610", alpha: 1.0)
        contentView.addSubview(processingResult)
        
        let line2 = UIView()
        line2.backgroundColor = UIColor.init(hex: "#F5F5F9", alpha: 1.0)
        contentView.addSubview(line2)
        
        event = EventDetailsListView.init(frame: CGRect.zero, list: ["违章原因"])
        contentView.addSubview(event)

        let line3 = UIView()
        line3.backgroundColor = UIColor.init(hex: "#F5F5F9", alpha: 1.0)
        contentView.addSubview(line3)
        
        otherEvent = EventDetailsListView.init(frame: CGRect.zero, list: ["责任人","违章时间","违章地点","违章采集单位"])
        contentView.addSubview(otherEvent)
        
        
        driverInfo.snp.makeConstraints { (make) in
            make.left.equalTo(contentView.snp.left)
            make.top.equalTo(contentView.snp.top)
            make.width.equalTo(contentView.snp.width)
            make.height.equalTo(112)
        }
        
        line.snp.makeConstraints { (make) in
            make.left.equalTo(contentView.snp.left)
            make.top.equalTo(driverInfo.snp.bottom).offset(16)
            make.height.equalTo(10)
            make.width.equalTo(KW)
        }
        
        recordOne.snp.makeConstraints { (make) in
            make.left.equalTo(contentView.snp.left).offset(15)
            make.top.equalTo(line.snp.bottom).offset(16)
            make.height.equalTo(22)
        }
        
        recordTwo.snp.makeConstraints { (make) in
            make.left.equalTo(recordOne.snp.right).offset(8)
            make.top.equalTo(line.snp.bottom).offset(16)
            make.height.equalTo(22)
        }
        
        processingResult.snp.makeConstraints { (make) in
            make.right.equalTo(contentView.snp.right).offset(-15)
            make.top.equalTo(line.snp.bottom).offset(16)
            make.height.equalTo(20)
        }
        
        line2.snp.makeConstraints { (make) in
            make.left.equalTo(contentView.snp.left).offset(15)
            make.right.equalTo(contentView.snp.right).offset(-15)
            make.top.equalTo(line.snp.bottom).offset(58)
            make.height.equalTo(1)
        }
        
        event.snp.makeConstraints { (make) in
            make.left.equalTo(contentView.snp.left)
            make.top.equalTo(line.snp.bottom).offset(58)
            make.right.equalTo(contentView.snp.right)
        }

        line3.snp.makeConstraints { (make) in
            make.left.equalTo(contentView.snp.left).offset(15)
            make.right.equalTo(contentView.snp.right).offset(-15)
            make.top.equalTo(event.snp.bottomMargin).offset(16)
            make.height.equalTo(1)
        }
        
        otherEvent.snp.makeConstraints { (make) in
            make.left.equalTo(contentView.snp.left)
            make.top.equalTo(line3.snp.bottom).offset(10)
            make.right.equalTo(contentView.snp.right)
        }
        
    }
    //  MARK : -    获取交通违章详情数据
    func getDetailsData() -> Void {
        let param = ["violateRuleId":violate] as [String : Any]
        HttpRequest.loadData(target: InterfaceAPI.getNotificationViolateRuleDetail(param: param), success: { (datas) in
            let json = JSON(datas)
            let data = JSONDeserializer<TrafficViolationDetailsModel>.deserializeFrom(json: json["data"].description)
            
            print("交通违章详情 \(json)")
            self.detailsModel = data
            self.resetViewData()
        }) { (stateCode, message) in
            
        }
    }
    
    func resetViewData() -> Void {
        let model = EventDriverModel.init()
        model.image = "default_header_portrait"
        model.number = detailsModel.plateNo
        model.type = detailsModel.model
        model.orgName = detailsModel.orgName
        model.driverName = "驾驶员:"+(detailsModel.driverName ?? "")
        model.textFont = UIFont.boldSystemFont(ofSize: 15)
        model.textColor = UIColor.black
        
        driverInfo.setViewData(objc: model)
        recordOne.text = "  罚款\(detailsModel.penalty ?? 0.0)元  滞纳金\(detailsModel.latePaymentFee ?? 0.0)元  "
        recordTwo.text = "  记\(detailsModel.minusScore ?? 0)分  "
        processingResult.text = detailsModel.status
        event.setContentViewData(contents: [detailsModel.reason])
        otherEvent.setContentViewData(contents: [(detailsModel.liabilityPerson ?? "未知"),(detailsModel.time ?? " "),(detailsModel.address ?? " "),(detailsModel.unit ?? " ")])
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        getDetailsData()
    }

}
