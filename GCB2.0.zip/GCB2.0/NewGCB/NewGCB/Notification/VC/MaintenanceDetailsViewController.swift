//
//  MaintenanceDetailsViewController.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/13.
//  Copyright © 2019 YTKJ. All rights reserved.
//  维保详情

import UIKit
import HandyJSON
import SwiftyJSON

class MaintenanceDetailsViewController: RootController {
    var total:UILabel?
    var driverInfo = EventDriverView.init()
    var listView = EventDetailsListView()
    var maintenanceId = Int()
    var detailsModel : MaintenanceDetailsModel!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        setNavViewData(title: "维保通知详情", leftImage: nil, rightImage: nil)
        // Do any additional setup after loading the view.
    }
    
    override func addChildView() {
        self.view.addSubview(driverInfo)
        
        let line = UILabel.init()
        line.backgroundColor = UIColor.init(hex: "#F5F5F9", alpha: 1.0)
        self.view.addSubview(line)
        
        listView = EventDetailsListView.init(frame: .zero, list: ["维保类型","维保原因","维保内容"])
        self.view.addSubview(listView)
        
        let line2 = UILabel.init()
        line2.backgroundColor = UIColor.init(hex: "#F5F5F9", alpha: 1.0)
        self.view.addSubview(line2)
        
        total = UILabel.init()
        total!.font = UIFont.systemFont(ofSize: 13)
        total!.textColor = UIColor.init(hex: "#5C5E74", alpha: 1.0)
        total!.text = "合计费用："
        self.view.addSubview(total!)
        
        driverInfo.snp.makeConstraints { (make) in
            make.left.equalTo(self.view.snp.left)
            make.top.equalTo(self.view.snp.top).offset(navigationBarHeight)
            make.width.equalTo(KW)
            make.height.equalTo(112)
        }
        
        line.snp.makeConstraints { (make) in
            make.left.equalTo(self.view.snp.left)
            make.top.equalTo(driverInfo.snp.bottom)
            make.width.equalTo(KW)
            make.height.equalTo(10)
        }
        
        listView.snp.makeConstraints { (make) in
            make.left.equalTo(self.view.snp.left)
            make.top.equalTo(line.snp.bottom)
            make.width.equalTo(KW)
        }
        
        line2.snp.makeConstraints { (make) in
            make.left.equalTo(self.view.snp.left).offset(15)
            make.right.equalTo(self.view.snp.right).offset(-15)
            make.top.equalTo(listView.snp.bottom).offset(10)
            make.height.equalTo(1)
        }
        
        total!.snp.makeConstraints { (make) in
            make.right.equalTo(self.view.snp.right).offset(-15)
            make.top.equalTo(line2.snp.bottom).offset(9)
            make.height.equalTo(20)
        }
    }
    

    
    // MARK: - 维保详情
    func getDetailsData() -> Void {
        let param = ["maintenanceId":maintenanceId] as [String : Any]
        HttpRequest.loadData(target: InterfaceAPI.getNotificationMaintenance(param: param), success: { (datas) in
            let json = JSON(datas)
            let data = JSONDeserializer<MaintenanceDetailsModel>.deserializeFrom(json: json["data"].description)
            print("维保详情数据 \(json)")
            
            self.detailsModel = data
            self.resetViewData()
        }) { (stateCode, message) in
            print("错误 \(message)")
        }
    }
    
    //  重置页面数据
    func resetViewData() -> Void {
        let model = EventDriverModel.init()
        model.image = detailsModel.driverurl
        model.number = detailsModel.plateNo
        model.type = detailsModel.model
        model.orgName = detailsModel.orgName
        model.driverName = "送修人:"+(detailsModel.driverName ?? "")
        model.textFont = UIFont.boldSystemFont(ofSize: 15)
        model.textColor = UIColor.black
        driverInfo.setViewData(objc: model)
        
        
        print("保险数据 \(String(describing: detailsModel.toJSON()))")
        
        listView.setContentViewData(contents: [(detailsModel.type ?? ""),(detailsModel.reason ?? ""),(detailsModel.content ?? "")])
        
        let costStr = "合计费用:\(detailsModel.cost ?? 0)元"
        let attributedString = NSMutableAttributedString(string: costStr)
        let range = attributedString.string.range(of: String("\(detailsModel.cost ?? 0)元"))
        let nsrange = attributedString.string.nsRange(from: range!)
        attributedString.addAttribute(.foregroundColor, value: UIColor.init(hex: "#FB6610", alpha: 1.0) as Any, range: nsrange!)
        total!.attributedText = attributedString
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        getDetailsData()
    }

}
