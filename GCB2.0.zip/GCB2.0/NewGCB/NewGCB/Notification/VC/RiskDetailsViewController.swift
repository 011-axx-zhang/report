//
//  RiskDetailsViewController.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/16.
//  Copyright © 2019 YTKJ. All rights reserved.
//  风险事件详情页

import UIKit
import HandyJSON
import SwiftyJSON

class RiskDetailsViewController: RootController,MAMapViewDelegate,RiskDetailsInfoViewDelegate {
    
//    var topView:SecurityDriverDetailTopView!
    var vehLine:MAPolyline?     //  地图折线
    var mapview:MAMapView!
    var vehAnnoView:MAAnnotationView!       //  当前选中的地图标注
//    var vehAnnoView:VehPlaybackAnnotationView!
    var annotations: Array<MAPointAnnotation> = []      //  地图标注数组
    var imageArr:Array<String> = []
    var dataArr:Array<CLLocationCoordinate2D> = []
    var risk:String = ""
//    var eventId:Int64! = 24671
    let infoView = RiskDetailsInfoView.init()       //  事件详情面板
    let mapViewHeight:CGFloat = 350.0   //  地图高度
    var infoViewHeight:CGFloat = 362    //  详情面板高度
    var infoViewY:CGFloat = KH-362.0-bottomHeight    //  详情面板初始位置
    let infoViewMaxY:CGFloat = 538.0    //  向上拖拽详情面板最大的位置
    var detailsModel:RiskDetailsModel!
    var riskInfo:RiskListModel!
//    var isSelectForMap = true   //  地图选点或滑动事件图片的判断
    
    override func viewDidLoad() {
        self.view.backgroundColor = UIColor.white
        self.addChildView()
        self.addNavView()
    }
    
    override func addNavView() {
        let backBtn = UIButton.init(type: .custom)
        backBtn.frame = CGRect.init(x: 8, y: statusHeight, width: 44, height: 44)
        backBtn.setImage(UIImage.init(named: "nav_back_circle"), for: .normal)
        backBtn.addTarget(self, action: #selector(leftNavigationBarItemAction), for: .touchUpInside)
        self.view.addSubview(backBtn)
    }
    
    override func addChildView() {
        createMap()
        addInfoView()
    }
    
    func addInfoView() -> Void {
        let pan = UIPanGestureRecognizer.init(target: self, action: #selector(dragBtnAction(drag:)))
        infoView.frame = CGRect.init(x: 0.0, y: infoViewY, width: KW, height: infoViewHeight)
        infoView.dragImg.addGestureRecognizer(pan)
        infoView.delegate = self
        self.view.addSubview(infoView)
        
        let path = UIBezierPath()
        path.move(to: CGPoint(x: 0, y: 5))
        path.addLine(to: CGPoint(x: KW, y: 5))
        path.addLine(to: CGPoint(x: KW, y: 0))
        path.addLine(to: CGPoint(x:0, y: 0))
        path.close()
        
        let corner = UIBezierPath.init(roundedRect: infoView.bounds, byRoundingCorners: [.topLeft, .topRight], cornerRadii: CGSize.init(width: 10, height: 10))
        let maskLayer = CAShapeLayer.init()
        maskLayer.frame = CGRect.init(x: 0, y: 0, width: KW, height: 20)
        maskLayer.path = corner.cgPath
        
        
        infoView.layer.shadowOpacity = 0.3
        infoView.layer.shadowColor = UIColor.black.cgColor
        infoView.layer.shadowRadius = 5.0
        infoView.layer.shadowPath = path.cgPath
        infoView.layer.cornerRadius = 10.0
    }
    
    //  MARK: - 创建地图与地图代理
    //  创建地图
    func createMap(){
        mapview = MAMapView(frame:CGRect(x: 0, y: 0, width: KW, height: KH-mapViewHeight))
        mapview.isRotateEnabled = false
        mapview.isRotateCameraEnabled = false
        mapview.showsCompass = false
        mapview.showsScale = false
        mapview.delegate = self
        self.view.addSubview(mapview)
        
        
        //  对地图添加点击事件，覆盖系统自带的点击事件(默认点击地图会把地图标注取消选中)
        let gest = UITapGestureRecognizer.init(target: self, action: #selector(tapMapView))
        mapview.addGestureRecognizer(gest)
    }
    
    
    //  添加地图标注以及绘制地图折线
    func riskEventDetailRequest()  {
        for objc in detailsModel.items! {
            self.dataArr.append(CLLocationCoordinate2D(latitude: Double(objc.lat ?? 0.0), longitude: Double(objc.lng ?? 0.0)))
        }
        self.drawLine()
    }
    
    
    //  绘制地图折线
    func drawLine(){
        if vehLine != nil {
            self.mapview.remove(vehLine)
        }
        vehLine = MAPolyline(coordinates: &dataArr, count: UInt(detailsModel.items!.count))
        mapview.add(vehLine)
        mapview.showOverlays([vehLine!], animated: false)
        
        //  添加地图标注
        for (index, coor) in dataArr.enumerated() {
            let anno = MAPointAnnotation()
            anno.coordinate = coor
            anno.title = "\(index+1)"
            annotations.append(anno)
        }
        self.mapview.addAnnotations(annotations)
        self.mapview.showAnnotations(annotations, edgePadding: UIEdgeInsets(top: 80, left: 20, bottom: 60, right: 20), animated: true)
        self.mapview.selectAnnotation(annotations.first, animated: false)
    }
    
    
    //  地图绘制回调
    func mapView(_ mapView: MAMapView!, rendererFor overlay: MAOverlay!) -> MAOverlayRenderer! {
        if overlay.isKind(of: MAPolyline.self) {
            let renderer: MAPolylineRenderer = MAPolylineRenderer(overlay: overlay)
            renderer.lineWidth = 5.0
            renderer.strokeColor = UIColor(hex: "#0DB423",alpha: 1.0)
            
            return renderer
        }
        
        return nil
    }
    
    
    //  地图标注回调
    func mapView(_ mapView: MAMapView!, viewFor annotation: MAAnnotation!) -> MAAnnotationView! {
        if annotation.isKind(of: MAPointAnnotation.self) {
            let pointReuseIndetifier = "riskPointReuseIndetifier"
            var annoV = mapView.dequeueReusableAnnotationView(withIdentifier: pointReuseIndetifier)
            if annoV == nil {
                annoV = MAAnnotationView(annotation: annotation, reuseIdentifier: pointReuseIndetifier)
                vehAnnoView = annoV
            }
            annoV?.isDraggable=false
            annoV?.canShowCallout=false
            return annoV!
        }
        return nil
    }

    //  标注添加完成后调用
    func mapView(_ mapView: MAMapView!, didAddAnnotationViews views: [Any]!) {
        for index in 0..<views.count {
            let anno = views[index] as! MAAnnotationView
            //  对最后一个标注做单独处理
            if index == views.count-1 {
                if self.detailsModel.level == "高风险" {
                    anno.image = UIImage.init(named: "risk_details_heigher_vehicle")
                }else{
                    anno.image = UIImage.init(named: "risk_details_medium_vehicle")
                }
            }else{
                if anno.isSelected {
                    if self.detailsModel.level == "高风险" {
                        anno.image = UIImage.init(named: "risk_details_heigher_triangle_selected")
                    }else{
                        anno.image = UIImage.init(named: "risk_details_medium_triangle_selected")
                    }
                }else{
                    if self.detailsModel.level == "高风险" {
                        anno.image = UIImage.init(named: "risk_details_heigher_triangle_normal")
                    }else{
                        anno.image = UIImage.init(named: "risk_details_medium_triangle_normal")
                    }
                }
            }
            anno.tag = index+100
            let tapPoint = UITapGestureRecognizer.init(target: self, action: #selector(tapMapPoint(tap:)))
            anno.addGestureRecognizer(tapPoint)
        }
    }
    //  地图标注选中回调
    func mapView(_ mapView: MAMapView!, didSelect view: MAAnnotationView!) {
        if view != vehAnnoView {
            mapView.deselectAnnotation(vehAnnoView.annotation, animated: true)
        }
         
        let idx = annotations.firstIndex(of: view.annotation as! MAPointAnnotation)!
        let anno = view!
        if detailsModel.level == "高风险" {
            if idx != annotations.count-1 {
                anno.image = UIImage.init(named: "risk_details_heigher_triangle_selected")
            }else{
                anno.image = UIImage.init(named: "risk_details_heigher_vehicle")
            }
        }else{
            if idx != annotations.count-1 {
                anno.image = UIImage.init(named: "risk_details_medium_triangle_selected")
            }else{
                anno.image = UIImage.init(named: "risk_details_medium_vehicle")
            }
        }
        
        mapView.selectAnnotation(anno.annotation, animated: true)
        vehAnnoView = anno
        
        //  修改对应的事件图片
        self.infoView.changeDataForMapAnnotationID(index:idx)
    }
       
    //  取消选中
    func mapView(_ mapView: MAMapView!, didDeselect view: MAAnnotationView!) {
        let idx = annotations.firstIndex(of: view.annotation as! MAPointAnnotation)!
        if detailsModel.level == "高风险" {
            //  高风险下最后一个点的图片
            if idx == annotations.count-1 {
                view?.image = UIImage.init(named: "risk_details_heigher_vehicle")
            }else{
                //  其他点的图片
                view?.image = UIImage.init(named: "risk_details_heigher_triangle_normal")
            }
        }else{
            if idx == annotations.count-1 {
                //  最后一个点的图片
                view?.image = UIImage.init(named: "risk_details_medium_vehicle")
            }else{
                //  其他点的图片
                view?.image = UIImage.init(named: "risk_details_medium_triangle_normal")
            }
        }
    }
    //  拖动事件
    @objc func dragBtnAction(drag:UIPanGestureRecognizer) -> Void {
        let point = drag.translation(in: infoView.dragImg)
        if drag.state == UIGestureRecognizer.State.began {
        }else if drag.state == UIGestureRecognizer.State.changed{
            if infoViewY + point.y <= KH-infoViewMaxY{
                //  向上拖动超过最大限度
                return
            }else if infoViewY + point.y >= KH-mapViewHeight-bottomHeight {
                //  向下拖动
                return
            }
            infoView.frame.origin.y = infoViewY + point.y
        }else if drag.state == UIGestureRecognizer.State.ended{
            //
            infoViewY = infoView.frame.origin.y
            if point.y > 0 {
                UIView.animate(withDuration: 0.3) {
                    self.infoView.frame.origin.y = KH - self.infoViewHeight - bottomHeight
                    self.infoViewY = self.infoView.frame.origin.y
                }
            }else{
                UIView.animate(withDuration: 0.3) {
                    self.infoView.frame.origin.y = KH - self.infoViewMaxY
                    self.infoViewY = self.infoView.frame.origin.y
                }
            }
        }
    }
    
    //  MARK: - 获取通知详情
    func getEventDetails() -> Void {
        let param = ["eventId":riskInfo.id!] as [String : Any] //riskInfo.id!  43815    44364
        HttpRequest.loadData(target: InterfaceAPI.getNotificationEventDetail(param: param), success: { (datas) in
            let json = JSON(datas)
            let data = JSONDeserializer<RiskDetailsModel>.deserializeFrom(json: json["data"].description)
            self.detailsModel = data
            /// 以下注释为测试数据，可以用来调试风险事件详情
            /// 如果接口返回的数据没有事件列表，或者内容较少，可以放开以下注释
//            let imageArr = ["http://img1.mydrivers.com/img/20160303/b3a568712da244628132c0a12a6455cf.jpg",
//        "http://attachment-uat.c3.timanetwork.net/attachment/test/2020-01-19/02_65_6504_03_f25eda7c20b64c709df9d76f6fae3b42.mp4",
//                            "http://img1.mydrivers.com/img/20160303/ca9f82e7368b4abfb663664700ebeb1c.jpg",
//                            "http://www.boyuesm.com/UploadFiles/FCK/2014-04/2014042868DT88V8H4.jpg",
//                            "http://www.boyuesm.com/UploadFiles/FCK/2014-04/201404280HP2BXBLJ8.jpg",
//                            "http://cdimg.good.cc/images/UploadImage/0/394/394979.jpg",
//                            "http://n1.itc.cn/img8/wb/smccloud/recom/2015/09/15/144230395222494144.PNG",
//                            "http://n1.itc.cn/img8/wb/smccloud/recom/2015/09/15/144230395144462072.PNG",
//                            "http://img1.mydrivers.com/img/20160303/55c4262047664ed688593f98c011d04f.jpg",
//                            "http://n1.itc.cn/img8/wb/smccloud/recom/2015/09/15/144230395110545610.PNG"] as [String]
//            for index in 0..<self.detailsModel.items!.count {
//                let obj = self.detailsModel.items![index]
//                if obj.picVideo == nil{
//                    obj.picVideo = imageArr[index]
//                }
//            }
            if data != nil {
                //  如果当前事件没有干预，则改变事件详情面板的 Y 坐标
                self.infoView.setViewData(model: self.detailsModel)
                //  添加地图标注
                self.riskEventDetailRequest()
            }
        }) { (stateCode, message) in
            
        }
    }
    
    //  MARK: - 点击事件
    @objc func tapMapView(tap : UITapGestureRecognizer) -> Void {
        //  空处理
    }
    
    //  对地图标注单独添加点击事件，用来覆盖系统自带的点击事件
    @objc func tapMapPoint(tap:UITapGestureRecognizer) -> Void {
        let annoIndex = tap.view!.tag-100
        self.mapview.deselectAnnotation(vehAnnoView.annotation, animated: true)
        self.mapview.selectAnnotation(annotations[annoIndex], animated: true)
        
    }
    
    //  MARK: - 代理方法
    //  关注或取消关注司机
    func followDriver(status :Bool) {
        if detailsModel.driverId == nil || detailsModel.driverId == 0 {
            return
        }
        let param = ["driverId":detailsModel.driverId!,
                     "isFocused":!status] as [String : Any]
        HttpRequest.loadData(target: InterfaceAPI.focusDriver(param: param), success: { (datas) in
            let json = JSON(datas)
            if json["code"] == 0 {
                if status {
                    self.view.makeToast("已取消关注该司机")
                }else{
                    self.view.makeToast("已关注该司机")
                }
                self.infoView.changeFollowDriverStatus()
            }
        }) { (stateCode, message) in
            print("关注司机失败---\(message)")
        }
    }
    //  收藏或取消车辆
    func followCar(status :Bool) {
        let param = ["vehId":detailsModel.vehId!,
                     "isFocused":!status] as [String : Any]
        HttpRequest.loadData(target: InterfaceAPI.focusVeh(param: param), success: { (datas) in
            let json = JSON(datas)
            if json["code"] == 0 {
                if status {
                    self.view.makeToast("已取消关注该车辆")
                }else{
                    self.view.makeToast("已关注该车辆")
                }
                self.infoView.changeFollowCarStatus()
            }
        }) { (stateCode, message) in
            print("收藏车辆失败---\(message)")
        }
    }
    
    //  滑动事件图片代理
    func imageViewDidScroll(index: Int) {
//        isSelectForMap = false
        self.mapview.deselectAnnotation(vehAnnoView.annotation, animated: true)
        self.mapview.selectAnnotation(annotations[index], animated: false)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        getEventDetails()
    }
    
}
