//
//  InsuranceDetailsViewController.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/13.
//  Copyright © 2019 YTKJ. All rights reserved.
//  保险详情

import UIKit
import HandyJSON
import SwiftyJSON

class InsuranceDetailsViewController: RootController {
    var carInfo = EventDriverView.init()
    var listView1 = EventDetailsListView()
    var listView2 = EventDetailsListView()
    var detailModel = InsuranceDetailsModel()
    var cost:UILabel! = nil
    var expirationTime:UILabel! = nil
    var status:UILabel! = nil
    var insuranceID : Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.init(hex: "#F5F5F9", alpha: 1.0)
        setNavViewData(title: "保险即将到期详情", leftImage: nil, rightImage: nil)
        
    }
    
    override func addChildView() {
        self.view.addSubview(carInfo)
        
        let contentView = UIView.init()
        contentView.backgroundColor = UIColor.white
        self.view.addSubview(contentView)
        
        cost = UILabel.init()
        cost.backgroundColor = UIColor.init(hex: "#F23E3E", alpha: 0.2)
        cost.textColor = UIColor.init(hex: "#F23E3E", alpha: 1.0)
        cost.font = UIFont.systemFont(ofSize: 11)
        cost.textAlignment = NSTextAlignment.center
        contentView.addSubview(cost)
        
        expirationTime = UILabel.init()
        expirationTime.textColor = UIColor.init(hex: "#5C5E74", alpha: 1.0)
        expirationTime.font = UIFont.systemFont(ofSize: 13)
//        expirationTime.textAlignment = NSTextAlignment.center
        contentView.addSubview(expirationTime)
        
        status = UILabel.init()
        status.textColor = UIColor.init(hex: "#FB6610", alpha: 1.0)
        status.font = UIFont.boldSystemFont(ofSize: 14)
        status.textAlignment = NSTextAlignment.right
        contentView.addSubview(status)
        
        let line = UILabel.init()
        line.backgroundColor = UIColor.init(hex: "#F5F5F9", alpha: 1.0)
        contentView.addSubview(line)
        
        listView1 = EventDetailsListView.init(frame: .zero, list: ["保单号","保险公司","保险类型"])
        contentView.addSubview(listView1)
        
        let line2 = UILabel.init()
        line2.backgroundColor = UIColor.init(hex: "#F5F5F9", alpha: 1.0)
        contentView.addSubview(line2)
        
        listView2 = EventDetailsListView.init(frame: .zero, list: ["购买时间","开始时间"])
        contentView.addSubview(listView2)
        
        carInfo.snp.makeConstraints { (make) in
            make.left.equalTo(self.view.snp.left)
            make.top.equalTo(self.view.snp.top).offset(navigationBarHeight)
            make.height.equalTo(112)
            make.width.equalTo(KW)
        }
        
        contentView.snp.makeConstraints { (make) in
            make.left.equalTo(self.view.snp.left)
            make.top.equalTo(carInfo.snp.bottom).offset(10)
            make.width.equalTo(KW)
            make.height.equalTo(KH-112-navigationBarHeight)
        }
        
        cost.snp.makeConstraints { (make) in
            make.left.equalTo(contentView.snp.left).offset(15)
            make.top.equalTo(contentView.snp.top).offset(20)
            make.height.equalTo(22)
//            make.width.equalTo(88)
        }
        
        expirationTime.snp.makeConstraints { (make) in
            make.left.equalTo(cost.snp.right).offset(8)
            make.top.equalTo(contentView.snp.top).offset(22)
            make.height.equalTo(19)
        }
        
        status.snp.makeConstraints { (make) in
            make.right.equalTo(contentView.snp.right).offset(-15)
            make.top.equalTo(contentView.snp.top).offset(21)
            make.height.equalTo(20)
        }
        
        line.snp.makeConstraints { (make) in
            make.left.equalTo(contentView.snp.left).offset(15)
            make.top.equalTo(cost.snp.bottom).offset(16)
            make.right.equalTo(contentView.snp.right).offset(-15)
            make.height.equalTo(1)
        }
        
        listView1.snp.makeConstraints { (make) in
            make.left.equalTo(contentView.snp.left)
            make.top.equalTo(line.snp.bottom).offset(10)
            make.width.equalTo(KW)
        }
        
        line2.snp.makeConstraints { (make) in
            make.left.equalTo(contentView.snp.left).offset(15)
            make.top.equalTo(listView1.snp.bottom).offset(10)
            make.right.equalTo(contentView.snp.right).offset(-15)
            make.height.equalTo(1)
        }
        
        listView2.snp.makeConstraints { (make) in
            make.left.equalTo(contentView.snp.left)
            make.top.equalTo(line2.snp.bottom).offset(10)
            make.width.equalTo(KW)
        }
        
        
    }
    
    //  MARK: - 获取保险详情
    func getDetailsData() -> Void {
        let param = ["insuranceId":insuranceID] as [String : Any]
        HttpRequest.loadData(target: InterfaceAPI.getNotificationInsuranceWarn(param: param), success: { (datas) in
            let json = JSON(datas)
            let data = JSONDeserializer<InsuranceDetailsModel>.deserializeFrom(json: json["data"].description)
            print("保险过期详情数据 \(json)")
            
            self.detailModel = data!
            self.resetViewData()
            
        }) { (stateCode, message) in
            print("请求失败----\(message)")
        }
    }

    func resetViewData() -> Void {
        
        let model = EventDriverModel.init()
        model.image = "default_header_portrait"
        model.number = detailModel.plateNo
        model.type = detailModel.model
        model.orgName = detailModel.orgName
        model.driverName = detailModel.company
        model.textFont = UIFont.systemFont(ofSize: 11)
        model.textColor = UIColor.init(hex: "#5C5E74", alpha: 1.0)
        carInfo.setViewData(objc: model)
        
        cost.text = " 保险费用\(detailModel.cost ?? 0.0)     "
        var timeStr = detailModel.expiresDate
        timeStr = timeStr!.sliceString(0..<10)
        expirationTime.text = "保险到期时间：\(timeStr ?? "")"
        status.text = detailModel.status
        listView1.setContentViewData(contents: [detailModel.insuranceNo,detailModel.insuranceCompany,detailModel.type])
        listView2.setContentViewData(contents: [detailModel.buyTime,detailModel.effectiveTime])
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        getDetailsData()
    }
}
