//
//  AccidentViewController.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/6.
//  Copyright © 2019 YTKJ. All rights reserved.
//  事故通知

import UIKit
import HandyJSON
import SwiftyJSON

class AccidentViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    var dataSource : Array<AccidentModel> = []
    var eventList : UITableView!
    var pageOffset = 0   //  请求数据的条数，从1开始以10为值自增
    var isInter = false
    var requestValue : [String : Any] = [:]
    var isSelectFocus = false   //  是否选择关注车辆
    var vehID:Int = 0   //  车辆ID
    var orgID:Int?=0      //  组织ID
    var vehGroupID:Int?=0
    
    init(height: CGFloat) {
        super.init(nibName: nil, bundle: nil)
        self.loadTableView(tableHeight: height)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(requestNotification(notf:)), name: NSNotification.Name(rawValue: "AccidentVCRequestNotf"), object: nil)
    }
    
    func loadTableView(tableHeight : CGFloat) -> Void {
        eventList = UITableView.init(frame: .init(x: 0.0, y: 0.0, width: self.view.frame.width, height: tableHeight), style: .plain)
        eventList.delegate = self
        eventList.dataSource = self
        eventList.rowHeight = 120.0
        eventList.separatorStyle = .none
        eventList.backgroundColor = UIColor.white
        self.view.addSubview(eventList)
        eventList!.register(AccidentTableViewCell.self, forCellReuseIdentifier: "notiCellID")
        eventList.mj_header = MJRefreshNormalHeader.init(refreshingBlock: {
            self.dataSource.removeAll()
            self.getNewData()
        })
        eventList.mj_footer = MJRefreshBackNormalFooter.init(refreshingBlock: {
            self.getMoreData()
        })
    }
    
    //  MARK: - tableView 代理
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "notiCellID", for: indexPath) as! AccidentTableViewCell
        cell.selectionStyle = .none
        if indexPath.row>=0&&indexPath.row<dataSource.count {
            cell.configDataSource(riskData: dataSource[indexPath.row])
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let model = dataSource[indexPath.row]
        let detailVC = AccidentDetailsViewController()
        detailVC.accidentID = model.id
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
    
    //  MARK: - 刷新
    func getNewData() -> Void {
        pageOffset = 0
        getRiskData(orgID: requestValue["orgId"] as! Int,
                    vehGroupID: requestValue["vehGroupId"] as! Int,
                    key: requestValue["key"] as! String,
                    begin: requestValue["beginDate"] as! String,
                    end: requestValue["endDate"] as! String,
                    isInter: isInter)
    }
    func getMoreData() -> Void {
        pageOffset += 10
        getRiskData(orgID: requestValue["orgId"] as! Int, vehGroupID: requestValue["vehGroupId"] as! Int, key: requestValue["key"] as! String, begin: requestValue["beginDate"] as! String, end: requestValue["endDate"] as! String, isInter: isInter)
    }
    
    //    MARK: - 请求
    func getRiskData(orgID:Int, vehGroupID:Int, key:String, begin:String, end:String, isInter:Bool) -> Void {
        var param = ["orgId":orgID,
                     "vehGroupId":vehGroupID,
                     "focusVeh":isInter,
                     "beginDate":begin,
                     "endDate":end,
                     "key":key,
                     "vehId":vehID,
                     "limit":10,
                     "offset":pageOffset] as [String : Any]
        requestValue = param
        
        //  值为 0 或者没有的话就不传
        for (objcKey, objcValue) in param {
            if objcValue is Int && objcValue as! Int == 0 && objcKey != "offset"{
                param.removeValue(forKey: objcKey)
            }else if objcValue is String && objcValue as! String == "" {
                param.removeValue(forKey: objcKey)
            }
        }
        
        //  未选择关注车辆时，不用传参
        if isSelectFocus == false {
            param.removeValue(forKey: "focusVeh")
        }
        
        print("事故通知页请求数据\(param)")
        HttpRequest.loadData(target: InterfaceAPI.getNotificationAccidents(param: param), success: { (datas) in
            if self.eventList.mj_footer.isRefreshing {
                self.eventList.mj_footer.endRefreshing()
            }else if self.eventList.mj_header.isRefreshing {
                self.eventList.mj_header.endRefreshing()
            }
            let json = JSON(datas)
            let data = JSONDeserializer<AccidentModel>.deserializeModelArrayFrom(json: json["data"].description)
//            print("事故列表数据 \(data)")
            for model in data ?? [] {
                self.dataSource.append(model!)
            }
            if data?.count == 0{
                self.view.makeToastMid(message: "没有更多内容")
            }
            self.eventList.reloadData()
            
        }) { (stateCode, message) in
            
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        if dataSource.count<1 {
            self.getRiskData(orgID: self.orgID ?? 0, vehGroupID: self.vehGroupID ?? 0, key: "", begin: "", end: "", isInter: isInter)
        }
    }

    // MARK: - 通知
    //  选中筛选条件时，通过发送通知让控制器刷新数据
    @objc func requestNotification(notf: NSNotification) -> Void {
        guard let org = notf.userInfo!["orgId"] as? Int64 else {
            return
        }
        guard let vehID = notf.userInfo!["vehGroupId"] as? Int64 else {
            return
        }
        guard let keyword = notf.userInfo!["keyword"] as? String else {
            return
        }
        guard let eventName = notf.userInfo!["beginTime"] as? String else {
            return
        }
        guard let level = notf.userInfo!["endTime"] as? String else {
            return
        }
        guard let inter = notf.userInfo!["focusVeh"] as? Int else {
            return
        }
//        print("刷新事故列表通知")
        if inter == 1 {
            isSelectFocus = true
        }else{
            isSelectFocus = false
        }
        pageOffset = 0
        dataSource.removeAll()
        isInter = inter == 1 ? true : false
        getRiskData(orgID: Int(org), vehGroupID: Int(vehID), key: keyword, begin: eventName, end: level, isInter: isInter)
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

}
