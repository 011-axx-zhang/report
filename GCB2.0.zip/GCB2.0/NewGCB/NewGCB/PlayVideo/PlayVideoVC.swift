//
//  PlayVideoVC.swift
//  NewGCB
//
//  Created by YTKJ on 2020/1/7.
//  Copyright © 2020 YTKJ. All rights reserved.
//

import UIKit
import WebKit

class PlayVideoVC: UIViewController {
    var webView:WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        self.title = "视频播放"
        self.createWebView()
        let image = UIImage(named: "nav_back")
        let backBtn = UIBarButtonItem.init(image: image! .withRenderingMode(.alwaysOriginal), style: .plain, target: self, action: #selector(self.backEvent))
        self.navigationItem.leftBarButtonItem = backBtn
      
    }
    
    @objc  func backEvent()  {
        self.navigationController?.popViewController(animated: true)
    }
    
    func createWebView()  {
        webView = WKWebView(frame:  CGRect(x: 0, y: 100, width: KW, height: KH - navigationBarHeight - tabBarHeight))
       
        let fileURL  = Bundle.main.url(forResource: "index", withExtension: "html")
        webView.loadFileURL(fileURL!, allowingReadAccessTo: Bundle.main.bundleURL)
         self.view.addSubview(webView)
    }
    

   


    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = false
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
