//
//  AppDelegate.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/4.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift
import UserNotificationsUI
import SwiftyJSON
import HandyJSON

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate ,JPUSHRegisterDelegate{
   
    
    
    
var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        IQKeyboardManager.shared.enable = true
        IQKeyboardManager.shared.shouldResignOnTouchOutside = true
        AMapServices.shared().apiKey="97750fcfe046cecd6adf37c915c20189"
        AMapServices.shared().enableHTTPS = true
        
        let entity = JPUSHRegisterEntity();
        entity.types = Int(JPAuthorizationOptions.alert.rawValue) |  Int(JPAuthorizationOptions.sound.rawValue) |  Int(JPAuthorizationOptions.badge.rawValue);
        JPUSHService.register(forRemoteNotificationConfig: entity, delegate: self as JPUSHRegisterDelegate);
        JPUSHService.setup(withOption: launchOptions, appKey: "107c971e50962b7179d8cddb", channel:"" , apsForProduction: true);
        
        if isLogin() {
            let navi = BaseNavigationController.init(rootViewController: HomeVC())
            self.window?.rootViewController =  navi
        }else {
            let navi = BaseNavigationController.init(rootViewController: LoginVC())
           // let navi = UINavigationController(rootViewController:LoginVC())
            self.window?.rootViewController =  navi
        }
        self.requestVersion()
        self.window?.makeKeyAndVisible()
        
        return true
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
         JPUSHService.registerDeviceToken(deviceToken)
//        let deviceTokenData = NSData.init(data: deviceToken)
//        let datastr = deviceTokenData.description.replacingOccurrences(of: "<", with: "").replacingOccurrences(of: ">", with: "").replacingOccurrences(of: " ", with: "")
////        print(datastr)
//        let deviceTokenStr = String(format: "%@", datastr)
//        let userDefaults = UserDefaults.standard
//        userDefaults.set(deviceTokenStr , forKey: "appDeviceToken")
//        userDefaults.synchronize()
     //  self.requestDevice(deviceToken: deviceTokenStr)
       
     }
    
    func requestDevice(deviceToken:String) {
        let phone = getPhone()
        let deviceId =  getUUID()
        if phone != nil  &&  phone != "" {
            let param = ["phone":phone!,"pushToken":deviceToken,"deviceType":5,"deviceId":deviceId] as [String : Any]
            NSLog("%@", param)
            HttpRequest.loadData(target: InterfaceAPI.pushTokenBind(param: param), needCache: false, cache: nil, success: { (datas) in
               
                
            }) { (stateCode, message) in
                
            }
        }
     
    }
    
    
    
    func requestVersion(){
         let paramDic = ["str":"com.ytsk.NewGCB"] as [String : String]
        
        HttpRequest.loadData(target: DMAPI.getVersion(param: paramDic), needCache: false, cache: nil, success: { (datas) in
            let json = JSON(datas)
            let model = JSONDeserializer<VersionModel>.deserializeFrom(json:json["data"].description)
            UserDefaults.standard.set(model?.isForce, forKey: keyisForce)
            UserDefaults.standard.set(model?.version, forKey: keyVersion)
            NotificationCenter.default.post(name: NSNotification.Name.init(rawValue: "version"), object: nil)
         
            
        }) { (stateCode, msg) in
            UserDefaults.standard.set(nil, forKey: keyVersion)
            UserDefaults.standard.set(nil, forKey: keyisForce)
        }
     
    }
    
    
   //App在前台获取通知
   @available(iOS 10.0, *)
    func jpushNotificationCenter(_ center: UNUserNotificationCenter!, willPresent notification: UNNotification!, withCompletionHandler completionHandler: ((Int) -> Void)!) {
    let userInfo:(Dictionary) = notification.request.content.userInfo
    if notification.request.trigger is UNPushNotificationTrigger {
        JPUSHService.handleRemoteNotification(userInfo);
    }
  completionHandler(Int(UNNotificationPresentationOptions.alert.rawValue)|Int(UNNotificationPresentationOptions.sound.rawValue))
    // 需要执行这个方法，选择是否提醒用户，有 Badge、Sound、Alert 三种类型可以选择设置
    }
    
    //点击通知进入App
    @available(iOS 10.0, *)
    func jpushNotificationCenter(_ center: UNUserNotificationCenter!, didReceive response: UNNotificationResponse!, withCompletionHandler completionHandler: (() -> Void)!) {
        
        let userInfo = response.notification.request.content.userInfo
        print(userInfo)
        if response.notification.request.trigger is UNPushNotificationTrigger {
            JPUSHService.handleRemoteNotification(userInfo);
        }
        completionHandler();
    }
    
    // Required, iOS 7 Support
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        
        JPUSHService.handleRemoteNotification(userInfo)
        completionHandler(UIBackgroundFetchResult.newData)
        
    }
    
    @available(iOS 10.0, *)
    func jpushNotificationCenter(_ center: UNUserNotificationCenter!, openSettingsFor notification: UNNotification?) {
        
    }
    
   
    
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
        self.requestVersion()
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


}

