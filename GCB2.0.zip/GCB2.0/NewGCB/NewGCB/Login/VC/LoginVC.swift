//
//  LoginVC.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/4.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import SwiftyJSON

class LoginVC: UIViewController,UITextFieldDelegate {
    
    @IBOutlet var getCodeBtn: UICountDownButton!
    @IBOutlet var codeTf: UITextField!
    @IBOutlet var phoneTf: UITextField!
    @IBOutlet var loginBtn: UIButton!
    var phoneStr:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.loginBtn.layer.cornerRadius = 8
        self.phoneTf.delegate = self
        self.codeTf.delegate = self
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func getCodeEvent(_ sender: UIButton) {
        self.phoneStr = self.phoneTf.text ?? ""
        if self.phoneStr.count == 0 {
            self.view.makeToastMid(message: "请填写手机号")
        }else if !isMobileNumber(phone: self.phoneStr)  {
            self.view.makeToastMid(message: "手机号格式不正确")
        }else {
            // 获取验证码h网络请求
//            self.requestGetCode()
            
        }
        
    }
    
    @IBAction func loginEvent(_ sender: UIButton) {
//        let app = UIApplication.shared.delegate as!AppDelegate
//                  app.window?.rootViewController = UINavigationController(rootViewController: HomeVC())
       self.loginHandle()
    }
    
    
    
    
    
    func loginHandle() {
        self.phoneStr = self.phoneTf.text ?? ""
        if self.phoneStr.count == 0 {
            self.view.makeToastMid(message: "请填写手机号")
            return
        }else if !isMobileNumber(phone: self.phoneStr)  {
            self.view.makeToastMid(message: "手机号格式不正确")
            return
        }
        
        if self.codeTf.text?.count != 4 {
            self.view.makeToastMid(message: "验证码长度不对")
            return
        }
        self.requestLogin()
    }
    
    func requestGetCode()  {
        let param = ["phone":self.phoneStr]
        HttpRequest.loadData(target: InterfaceAPI.getVerCode(param: param), needCache: false, cache: nil, success: { (datas) in
            self.getCodeBtn.isCounting=true
            
        }) { (stateCode, message) in
              self.view.makeToastMid(message: message)
        }
    }
    
    
    func requestLogin() {
        
        let param = ["phone":self.phoneStr,"verCode":self.codeTf.text!]
        NSLog("%@", param)
        HttpRequest.loadData(target: InterfaceAPI.login(param: param), needCache: false, cache: nil, success: { (datas) in
            let json = JSON(datas)
            let token = json["data"].description
            setToken(token:token)
            setIsLogin(isLogin: true)
            setPhone(phone: self.phoneStr)
            JPUSHService.setAlias(self.phoneStr, completion: { (iResCode, iAlias, seq) in
                print(iResCode)
                print(iAlias!)
            }, seq: 1)
            
            let app = UIApplication.shared.delegate as!AppDelegate
            let navi = BaseNavigationController.init(rootViewController: HomeVC())
            app.window?.rootViewController = navi
            
           
           
            
        }) { (stateCode, message) in
            self.view.makeToastMid(message: message)
        }
    }
    
    func requestDevice(deviceToken:String) {
        let phone = getPhone()
        let deviceId =  getUUID()
        if phone != nil  &&  phone != "" {
            let param = ["phone":phone!,"pushToken":deviceToken,"deviceType":5,"deviceId":deviceId] as [String : Any]
            NSLog("%@", param)
            HttpRequest.loadData(target: InterfaceAPI.pushTokenBind(param: param), needCache: false, cache: nil, success: { (datas) in
                let app = UIApplication.shared.delegate as!AppDelegate
                app.window?.rootViewController = UINavigationController(rootViewController: HomeVC())

            }) { (stateCode, message) in
                let app = UIApplication.shared.delegate as!AppDelegate
                app.window?.rootViewController = UINavigationController(rootViewController: HomeVC())
            }
        }
        
    }

    
    //手机号验证
    func isMobileNumber(phone:String) -> Bool {
        if self.phoneStr.count != 11 {
            return false
        }else {
            let regexStr = "^1\\d{10}$"
            let regextesMobile = NSPredicate.init(format: "SELF MATCHES %@", regexStr)
            return regextesMobile.evaluate(with:phone)
        }
    }
    
    
    
    
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == self.phoneTf {
            let phone = self.phoneTf.text
            if range.location > 10{
                let index1 = phone?.index((phone?.startIndex)!, offsetBy: 11)
                self.phoneTf.text = self.phoneTf.text?.substring(to: index1!)
                return false
            }
        }else if textField == self.codeTf {
            let codeStr = self.codeTf.text
            if range.location > 3{
                let index1 = codeStr?.index((codeStr?.startIndex)!, offsetBy: 4)
                self.codeTf.text = self.codeTf.text?.substring(to: index1!)
                return false
            }
        }
        
        return true
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
