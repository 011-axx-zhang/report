//
//  UICountDownButton.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/5.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class UICountDownButton: UIButton {
    
    var remainSeconds=0{
        willSet{
            self.setTitle("重新发送(\(newValue)s)", for: .normal)
            if newValue<=0 {
                self.setTitle("重新获取验证码", for: .normal)
                isCounting=false
            }
        }
    }
    var isCounting=false{
        willSet{
            if newValue{
                remainSeconds=60
                countDownTimer=Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.updateTimer(timer:)), userInfo: nil, repeats: true)
            }else{
                countDownTimer?.invalidate()
                countDownTimer=nil
            }
            self.isEnabled = !newValue
        }
    }
    
    var countDownTimer:Timer?
    
    @objc private func updateTimer(timer:Timer){
        remainSeconds -= 1
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setTitleColor(UIColor(hex: "#1D69F5", alpha: 1.0), for: .disabled)
    }
    
    convenience init() {
        self.init(frame: CGRect.zero)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setTitleColor(UIColor(hex: "#1D69F5", alpha: 1.0), for: .disabled)
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
}
