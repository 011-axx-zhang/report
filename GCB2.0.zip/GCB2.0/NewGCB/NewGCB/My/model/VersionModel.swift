//
//  VersionModel.swift
//  goods
//
//  Created by YTKJ on 2018/11/9.
//  Copyright © 2018年 ytsk. All rights reserved.
//

import UIKit
import HandyJSON

class VersionModel: NSObject,HandyJSON  {
    
    var isForce:Int = 0
    var version:Int = 0
    var updateInfo:String?

    override required init() {
        super.init()
    }
    
    //MARK - 版本号。相关信息
   
}
