//
//  AboutVC.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/9.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class AboutVC: BaseVC,UITableViewDelegate,UITableViewDataSource {
    var tableView :UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.createTableView()
        if #available(iOS 11.0, *) {
            tableView.contentInsetAdjustmentBehavior = .never
        }
        view.insertSubview(navBar, aboveSubview: tableView)
        navBar.title = "关于"
        self.view.backgroundColor = UIColor.white
       // self.setBackBtn()
        
    }
    func setBackBtn() {
        let leftBarBtn = UIBarButtonItem(title: "", style: .plain, target: self,
                                         action: #selector(backToPrevious))
        leftBarBtn.image = UIImage(named: "nav_back")!.withRenderingMode(.alwaysOriginal)
        self.navigationItem.leftBarButtonItem = leftBarBtn
    }
    @objc func backToPrevious()  {
        self.navigationController?.popViewController(animated: true)
    }
    func createTableView() {
        tableView = UITableView()
        tableView?.backgroundColor = UIColor.white
        tableView?.frame = CGRect(x: 0, y: kNavBarBottom, width: KW, height:KH)
        tableView!.dataSource = self
        tableView!.delegate = self
        tableView!.isScrollEnabled = false
        tableView.separatorStyle = .none
        self.view .addSubview(tableView!)
        tableView!.register(AboutFirstTableViewCell.self, forCellReuseIdentifier: "aboutFirstTableViewCellID")
        tableView!.register(AboutSecondTableViewCell.self, forCellReuseIdentifier: "aboutSecondTableViewCellID")
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 2
        }else {
            return 1
        }
        
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "aboutFirstTableViewCellID", for: indexPath) as! AboutFirstTableViewCell
            cell.selectionStyle = .none
            if indexPath.row == 0 {
                cell.leftLabel.text = "管车宝APP"
                let infoDictionary = Bundle.main.infoDictionary!
                let majorVersion = infoDictionary["CFBundleShortVersionString"]
                cell.rightLabel.text = majorVersion as! String
                 cell.lineLabel.isHidden = false
            }else {
                cell.leftLabel.text = "所属公司"
                cell.rightLabel.text = "一钛数科"
                cell.lineLabel.isHidden = true
            }
            return cell
        }else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "aboutSecondTableViewCellID", for: indexPath) as! AboutSecondTableViewCell
            cell.selectionStyle = .none
            return cell
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
       // self.navigationController?.navigationBar.isHidden = false
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
