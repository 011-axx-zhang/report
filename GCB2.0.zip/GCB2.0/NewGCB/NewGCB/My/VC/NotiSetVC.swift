//
//  NotiSetVC.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/9.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import SwiftyJSON
import HandyJSON

class NotiSetVC:BaseVC, UITableViewDelegate,UITableViewDataSource {

    var tableView :UITableView!
    var leftArrData:Array<String> = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(hex: "#EEEFF5", alpha: 1.0)
        //self.title = "通知设置"
        self.createTableView()
        if #available(iOS 11.0, *) {
            tableView.contentInsetAdjustmentBehavior = .never
        }
        view.insertSubview(navBar, aboveSubview: tableView)
        navBar.title = "通知设置"
        self.loadData()
      
    }
    
    
   
    
    func createTableView() {
        tableView = UITableView.init(frame: CGRect(x: 0, y: kNavBarBottom , width: KW, height: KH), style: .grouped)
        tableView?.backgroundColor = UIColor(hex: "#F5F5F9", alpha: 1.0)
        tableView!.dataSource = self
        tableView!.delegate = self
        tableView!.separatorStyle = .none
        tableView!.isScrollEnabled = false
        self.view .addSubview(tableView!)
        tableView!.register(NotiSetTableViewCell.self, forCellReuseIdentifier: "notiSetTableViewCellID")
    }
    
    func loadData()  {
        leftArrData = ["风险事件通知", "交通违章通知","事故通知","维保记录通知","保险提醒通知"]
        self.tableView.reloadData()
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
        
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 52
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "notiSetTableViewCellID", for: indexPath) as! NotiSetTableViewCell
        cell.selectionStyle = .none
        cell.leftLabel.text = leftArrData[indexPath.row]
        cell.switchClick = { sender in
            self.dealSwitch(sender: sender, indexPath: indexPath)
        }
        let defaults = UserDefaults.standard
        if indexPath.row == 0 {
            if defaults.bool(forKey: "fengxianNotiSet")  == true {
                cell.switchBtn.isOn = true
            }else {
                cell.switchBtn.isOn = false
            }
            
        }else if indexPath.row == 1 {
            if defaults.bool(forKey: "jiaotongNotiSet")  == true {
                cell.switchBtn.isOn = true
            }else {
                cell.switchBtn.isOn = false
            }
        }else if indexPath.row == 2 {
            if defaults.bool(forKey: "shiguNotiSet") == true {
                cell.switchBtn.isOn = true
            }else {
                cell.switchBtn.isOn = false
            }
        }else if indexPath.row == 3 {
            if defaults.bool(forKey: "weibaoNotiSet")  == true {
                cell.switchBtn.isOn = true
            }else {
                cell.switchBtn.isOn = false
            }
        }else if indexPath.row == 4 {
            if defaults.bool(forKey: "baoxianNotiSet")  == true {
                cell.switchBtn.isOn = true
            }else {
                cell.switchBtn.isOn = false
            }
        }
        
        return cell
    }
    
    
    
 
    
    
    
    func dealSwitch(sender:UISwitch,indexPath:IndexPath) {
        let defaults = UserDefaults.standard
        if indexPath.row == 0 {
            defaults.set(sender.isOn, forKey: "fengxianNotiSet")
            self.notificationSetRequest(type: 1, isOpen: sender.isOn)
        }else if indexPath.row == 1 {
            defaults.set(sender.isOn, forKey: "jiaotongNotiSet")
             self.notificationSetRequest(type: 2, isOpen: sender.isOn)
        }else if indexPath.row == 2 {
            defaults.set(sender.isOn, forKey: "shiguNotiSet")
             self.notificationSetRequest(type: 3, isOpen: sender.isOn)
        }else if indexPath.row == 3 {
            defaults.set(sender.isOn, forKey: "weibaoNotiSet")
             self.notificationSetRequest(type: 4, isOpen: sender.isOn)
        }else if indexPath.row == 4 {
            defaults.set(sender.isOn, forKey: "baoxianNotiSet")
             self.notificationSetRequest(type: 5, isOpen: sender.isOn)
        }
        
    }
    
    func notificationSetRequest(type:Int,isOpen:Bool){
         let param = ["type":1,"isopen":1]
         HttpRequest.loadData(target: InterfaceAPI.notiSet(param: param), needCache: false, cache: nil, success: { (datas) in
            
             
         }) { (stateCode, message) in
             
         }
     }
    
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0.1
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return UIView()
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.1
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
     //   self.navigationController?.navigationBar.isHidden = false
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
