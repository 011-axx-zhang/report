//
//  MyVC.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/9.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import HandyJSON
import SwiftyJSON

class MyVC: UIViewController ,UITableViewDelegate,UITableViewDataSource{

    var tableView :UITableView!
    var logOffBtn :UIButton!
    var topView:MyTopView!
    var dataArr:Array<Dictionary<String,String>> = []
    var model:MyInfoModel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(hex: "#F5F5F9",alpha: 1.0)
        self.createTableView()
        self.createBtn()
       self.getUserInfoRequest()
        self.loadData()
    }
    
    func createBtn(){
        logOffBtn = UIButton()
        logOffBtn.backgroundColor = UIColor.white
        logOffBtn.layer.cornerRadius = 5
        logOffBtn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 17.0)
        logOffBtn.setTitleColor(UIColor(hex: "#1D69F5",alpha: 1.0)!, for: .normal)
        logOffBtn.addTarget(self, action: #selector(self.logOffBtnClick), for: .touchUpInside)
        logOffBtn.setTitle("安全退出", for: .normal)
        self.view.addSubview(logOffBtn)
        logOffBtn.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.view)
            make.bottom.equalTo(self.view.snp.bottom).offset(-31 - bottomHeight)
            make.width.equalTo(KW-30)
            make.height.equalTo(44)
        }
    }
    
    func getUserInfoRequest(){
        HttpRequest.loadData(target: InterfaceAPI.getUserInfo, needCache: false, cache: nil, success: { (datas) in
            let json = JSON(datas)
            let model = JSONDeserializer<MyInfoModel>.deserializeFrom(json:json["data"].description)
            self.model = model
            self.topView.configData(model:self.model)
        }) { (stateCode, message) in
          
        }
    }
    
   
    
    
    @objc func logOffBtnClick()  {
        self.showCommonAlert(msg: "您确定要退出登录吗?")
    }
    
    
    func showCommonAlert(msg:String)  {
        let alertController = UIAlertController(title: "",
                                                message:msg, preferredStyle: .alert)
        let messageFont = UIFont.systemFont(ofSize: 15)
        let messageAttribute = NSMutableAttributedString.init(string:alertController.message!)
        messageAttribute.addAttributes([NSAttributedString.Key.font:messageFont],
                                       range:NSMakeRange(0, (alertController.message?.count)!))
        alertController.setValue(messageAttribute, forKey: "attributedMessage")
        alertController.view.tintColor = UIColor(hex: "#1D69F5", alpha: 1.0)
        
        let cancelAction = UIAlertAction(title: "取消", style: .cancel, handler: nil)
        let okAction = UIAlertAction(title: "确认", style: .default, handler: {
            action in
           // 退出登录之后清除各种设置
//            let userDefaults = UserDefaults.standard
//            let   deviceTokenStr   = userDefaults.string(forKey: "appDeviceToken")
//            if deviceTokenStr  != nil && deviceTokenStr  != "" {
//                self.requestDelPushToken(deviceToken: deviceTokenStr!)
//            }
             self.clearAllSet()
        })
        alertController.addAction(cancelAction)
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    func requestDelPushToken(deviceToken:String) {
          let phone = getPhone()
          let deviceId =  getUUID()
          if phone != nil  &&  phone != "" {
              let param = ["phone":phone!,"pushToken":deviceToken,"deviceType":5,"deviceId":deviceId] as [String : Any]
              NSLog("%@", param)
              HttpRequest.loadData(target: InterfaceAPI.pushTokenUnbind(param: param), needCache: false, cache: nil, success: { (datas) in
                  
                  self.clearAllSet()
              }) { (stateCode, message) in
                    self.clearAllSet()
              }
          }
          
      }
    
    
    
   
    
    func clearAllSet()  {
        setIsLogin(isLogin:false)
        setPhone(phone: "")
        setToken(token:"")
        let defaults = UserDefaults.standard
        defaults.set(nil, forKey: "orgId")
        defaults.set(nil, forKey: "groupId")
        defaults.set(nil, forKey: "focusDriver")
        defaults.set(nil, forKey: "focusVeh")
        defaults.set(nil, forKey: "filterValue")
        JPUSHService.deleteAlias({ (iResCode, iAlias, seq) in
            print(iResCode)
        }, seq: 1)
        let loginVC = LoginVC()
        self.present(loginVC , animated: true, completion: nil)
    }
    

    
    
    func loadData()  {
        let dic = ["image":"my_noti","title":"通知设置"]
        dataArr.append(dic)
        let dic2 = ["image":"my_clearCache","title":"清除缓存"]
        dataArr.append(dic2)
        let dic3 = ["image":"my_about","title":"关于"]
        dataArr.append(dic3)
        let dic4 = ["image":"my_check","title":"检查更新"]
        dataArr.append(dic4)
        self.tableView.reloadData()
    }
    
    

    
    func createTableView() {
        tableView = UITableView()
        tableView.backgroundColor = UIColor(hex: "#F5F5F9",alpha: 1.0)
        tableView.frame = CGRect(x: 0, y: 0, width: KW, height: KH - 100)
        tableView.dataSource = self
        tableView.delegate = self
        tableView.separatorStyle = .none
        tableView.isScrollEnabled = false
        tableView!.register(MyTableViewCell.self, forCellReuseIdentifier: "myTableViewCellID")
        topView = MyTopView.init(frame: CGRect(x: 0, y: 0, width: KW, height: 220))
        self.tableView.tableHeaderView = topView
        self.view.addSubview(tableView)
        if #available(iOS 11.0, *) {
            self.tableView.contentInsetAdjustmentBehavior = .never
        }else {
            self.automaticallyAdjustsScrollViewInsets = false
        }
        topView.backClick = {
            self.navigationController?.popViewController(animated: true)
        }
        
    }
    
    
    
    
  
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myTableViewCellID", for: indexPath) as! MyTableViewCell
        cell.selectionStyle = .none
        cell.setModel(dic: dataArr[indexPath.row])
        if indexPath.row == 1 {
            cell.rightImageView.isHidden = true
            cell.rightLabel.isHidden = false
            let  size:Float = Float(SDImageCache.shared().getSize())
            if size > 0 {
                cell.rightLabel.text = self.clearSize(size: size)
            }else {
                cell.rightLabel.text = "0M"
            }
        }else {
            cell.rightImageView.isHidden = false
            cell.rightLabel.isHidden = true
        }
        return cell
    }
    
    func clearSize (size:Float) -> String {
        var size = size
        let temp :String?
        if size < 1024 {
            temp = String(format: "%.2fdB", size)
        }else if size < (1024*1024) {
            size = size / (1024)
            temp = String(format: "%.2fKB", size)
        }else if size < (1024*1024*1024)  {
             size = size / (1024*1024)
            temp = String(format: "%.2fM", size)
        }else {
             size = size / (1024*1024*1024)
            temp = String(format: "%.2fG", size)
        }
        return temp!
    }
    
    
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 51
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            let vc = NotiSetVC()
            self.navigationController?.pushViewController(vc, animated: true)
            
        }else if indexPath.row == 1 {
            let  size:Float = Float(SDImageCache.shared().getSize())
            if size > 0 {
                self.showDeleteAlert(msg: self.clearSize(size: size))
            }
        }else if indexPath.row == 2 {
            let vc = AboutVC()
            self.navigationController?.pushViewController(vc, animated: true)
            
        }else if indexPath.row == 3 {
            self.updateApp()
        }
        
    }
    
    func showDeleteAlert(msg:String)  {
         
         let alertController = UIAlertController(title: "",
                                                 message:"你确定要清除缓存？", preferredStyle: .alert)
         let messageFont = UIFont.systemFont(ofSize: 15)
         let messageAttribute = NSMutableAttributedString.init(string:alertController.message!)
        messageAttribute.addAttributes([NSAttributedString.Key.font:messageFont],
                                        range:NSMakeRange(0, (alertController.message?.count)!))
         alertController.setValue(messageAttribute, forKey: "attributedMessage")
        alertController.view.tintColor = UIColor(hex: "#0FA59E",alpha: 1.0)
         
         let cancelAction = UIAlertAction(title: "取消", style: .cancel, handler: nil)
         let okAction = UIAlertAction(title: "确定", style: .default, handler: {
             action in
             let cache = SDImageCache.shared()
             cache.clearDisk(onCompletion: {
                 self.tableView.reloadData()
                 let str = String(format: "已清理缓存%@", msg)
                 self.view.makeToastMid(message: str)
             })
             
         })
         alertController.addAction(cancelAction)
         alertController.addAction(okAction)
         self.present(alertController, animated: true, completion: nil)
       
     }
    
  @objc  func updateApp()  {
      let userDefault = UserDefaults.standard
      var isForce:Int?
      var version:Int?

      if userDefault.value(forKey: keyisForce) != nil {
          isForce = userDefault.value(forKey: keyisForce) as! Int
      }else {
          self.view.makeToastMid(message: "暂无版本更新")
          return
      }

      if userDefault.value(forKey:keyVersion) != nil  {
          version = userDefault.value(forKey:keyVersion) as! Int
      }else {
          self.view.makeToastMid(message: "暂无版本更新")
          return
      }

      let infoDictionary = Bundle.main.infoDictionary
      let appBuild = infoDictionary?["CFBundleVersion"] as! String
      let build = Int(appBuild)

      if version! > build ?? 0{
          if isForce == 1 {
              showCallAlert(msg: "是否更新版本")
          }else {
            self.showAlert(msg: "是否更新版本")
          }
      }else {
          self.view.makeToastMid(message: "暂无版本更新")
      }
      
  }
  
  
     func showAlert(msg:String)  {
      
      let alertController = UIAlertController(title: "",
                                              message:msg, preferredStyle: .alert)
      let messageFont = UIFont.systemFont(ofSize: 15)
      let messageAttribute = NSMutableAttributedString.init(string:alertController.message!)
        messageAttribute.addAttributes([NSAttributedString.Key.font:messageFont],
                                     range:NSMakeRange(0, (alertController.message?.count)!))
      alertController.setValue(messageAttribute, forKey: "attributedMessage")
        alertController.view.tintColor = UIColor(hex: "#0FA59E", alpha: 1.0)!
      let cancelAction = UIAlertAction(title: "取消", style: .cancel, handler: nil)
      let okAction = UIAlertAction(title: "确定", style: .default, handler: {
          action in
           UIApplication.shared.openURL(NSURL.init(string: "https://itunes.apple.com/cn/app/id1495281943") as! URL)
          
      })
      alertController.addAction(cancelAction)
      alertController.addAction(okAction)
      self.present(alertController, animated: true, completion: nil)
  }
    
    
    func showCallAlert(msg:String)  {
        
        
        let alertController = UIAlertController(title: "",
                                                message:msg, preferredStyle: .alert)
        let messageFont = UIFont.systemFont(ofSize: 15)
        let messageAttribute = NSMutableAttributedString.init(string:alertController.message!)
        messageAttribute.addAttributes([NSAttributedString.Key.font:messageFont],
                                       range:NSMakeRange(0, (alertController.message?.count)!))
        alertController.setValue(messageAttribute, forKey: "attributedMessage")
        alertController.view.tintColor = UIColor(hex: "#0FA59E", alpha: 1.0)!
        
        
        let okAction = UIAlertAction(title: "确定", style: .default, handler: {
            action in
           UIApplication.shared.openURL(NSURL.init(string: "https://itunes.apple.com/cn/app/id1495281943") as! URL)
            
        })
        
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
  
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
