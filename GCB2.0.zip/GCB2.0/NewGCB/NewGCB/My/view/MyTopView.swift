//
//  MyTopView.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/9.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class MyTopView: UIView {
  
    var backBtn:UIButton!
    var titleLabel :UILabel!
    var iconImageVIew :UIImageView!
    var nameLabel :UILabel!
    var phoneLabel :UILabel!
    var bottomView:UIView!
    @objc var backClick:(()->Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor(hex: "#1D69F5", alpha: 1.0)
        self.createUI()
        updateConstraints()
    }
    
    private func createUI() {
        
   
        
        backBtn = UIButton()
        backBtn.setImage(UIImage(named: "my_back"), for: .normal)
        backBtn.addTarget(self, action: #selector(self.backEvent), for: .touchUpInside)
        self.addSubview(backBtn)
        titleLabel = UILabel()
        titleLabel.text = "我的"
        titleLabel.font = UIFont.systemFont(ofSize: 17)
        titleLabel.textColor = UIColor.white
        self.addSubview(titleLabel)
        iconImageVIew = UIImageView()
        iconImageVIew.image = UIImage(named: "my_icon")
        iconImageVIew.layer.cornerRadius = 40
        iconImageVIew.layer.masksToBounds = true
        iconImageVIew.contentMode = .scaleToFill
        self.addSubview(iconImageVIew)
        nameLabel = UILabel()
        nameLabel.textColor = UIColor.white
        nameLabel.font = UIFont.systemFont(ofSize: 17)
        nameLabel.text = "谭谭"
        nameLabel.numberOfLines = 0
        
        self.addSubview(nameLabel)
        phoneLabel = UILabel()
        phoneLabel.font = UIFont.systemFont(ofSize: 14)
        phoneLabel.textColor = UIColor.white
        phoneLabel.text = "18303898824"
        self.addSubview(phoneLabel)
        bottomView = UIView()
        bottomView.backgroundColor = UIColor(hex: "#E6E9EE", alpha: 1.0)
        self.addSubview(bottomView)
        
    }
    
    
    @objc func backEvent()  {
        if self.backClick != nil {
            self.backClick?()
        }
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        backBtn.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(0)
            make.top.equalTo(self.snp.top).offset(40)
            make.size.equalTo(CGSize(width: 44, height: 44))
        }

        titleLabel.snp.makeConstraints { (make) in
            make.centerX.equalTo(self)
            make.centerY.equalTo(backBtn)
        }

        iconImageVIew.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(15)
            make.top.equalTo(backBtn.snp.bottom).offset(22)
            make.size.equalTo(CGSize(width: 80, height: 80))
        }

        nameLabel.snp.makeConstraints { (make) in
            make.left.equalTo(iconImageVIew.snp.right).offset(18)
            make.right.equalTo(self.snp.right).offset(-15)
            make.top.equalTo(iconImageVIew.snp.top).offset(14)
        }

        phoneLabel.snp.makeConstraints { (make) in
            make.left.equalTo(nameLabel.snp.left).offset(0)
            make.top.equalTo(nameLabel.snp.bottom).offset(8)
        }

        bottomView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(0)
            make.bottom.equalTo(self)
            make.size.equalTo(CGSize(width: KW, height: 10))
        }
        
      
        
        
    }
    
    
    func configData(model:MyInfoModel)  {
        self.nameLabel.text = model.name ?? ""
        self.phoneLabel.text = model.phone ?? ""
        
        if model.phone != nil  && model.phone != "" {
            let str2 = model.phone?.substring(from: 7)
            let str1 = model.phone?.substring(to: 3)
            self.phoneLabel.text = str1! + "****" +  str2!
        }else {
            self.phoneLabel.text = ""
        }
        
        
        if model.avatarUrl != nil && model.avatarUrl != "" {
            let url = URL.init(string: model.avatarUrl ?? "")
            self.iconImageVIew?.sd_setImage(with: url, placeholderImage: UIImage(named: "my_icon"), options: .highPriority, completed: nil)
        }else {
            iconImageVIew.image = UIImage(named: "my_icon")
        }
       
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
