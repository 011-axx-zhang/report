//
//  AboutFirstTableViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/9.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class AboutFirstTableViewCell: UITableViewCell {
    var leftLabel :UILabel!
    var rightLabel :UILabel!
    var lineLabel :UILabel!

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.backgroundColor = UIColor.white
        createUI()
        self.contentView.backgroundColor=UIColor.white
        self .updateConstraints()
    }
    
    private func createUI() {
        leftLabel = UILabel()
        leftLabel.font = UIFont.systemFont(ofSize: 14.0)
        leftLabel.textAlignment = .left
        leftLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(leftLabel)
        
        rightLabel = UILabel()
        rightLabel.font = UIFont.systemFont(ofSize: 14.0)
        rightLabel.textAlignment = .right
        rightLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(rightLabel)
        
        lineLabel = UILabel()
        lineLabel.backgroundColor = UIColor(hex: "#E6E9EE", alpha: 1.0)
        self.contentView.addSubview(lineLabel)
        
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        leftLabel.snp.makeConstraints {[unowned self] (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.top.equalTo(self.contentView.snp.top).offset(15)
            
        }
        
        rightLabel.snp.makeConstraints {[unowned self] (make) in
            make.right.equalTo(self.contentView.snp.right).offset(-15)
            make.centerY.equalTo(self.contentView.snp.centerY)
        }
        
        lineLabel.snp.makeConstraints {[unowned self] (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.right.equalTo(self.contentView.snp.right).offset(-15)
            make.bottom.equalTo(self.contentView.snp.bottom).offset(0)
            make.height.equalTo(1)
        }
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }


}
