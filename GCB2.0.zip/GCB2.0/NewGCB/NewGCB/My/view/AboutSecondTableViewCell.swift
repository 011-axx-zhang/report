//
//  AboutSecondTableViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/9.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class AboutSecondTableViewCell: UITableViewCell {
    var topLineView:UIView!
    var titleLabel :UILabel!
    var lineLabel :UILabel!
    var descriptionLabel:UILabel!
    
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.contentView.backgroundColor = UIColor.white
        createUI()
        self .updateConstraints()
        
    }
    
    private func createUI() {
        topLineView = UIView()
        topLineView.backgroundColor = UIColor(hex: "#F5F5F9",alpha: 1.0)
        self.contentView.addSubview(topLineView)
        titleLabel = UILabel()
        titleLabel.font = UIFont.systemFont(ofSize: 15)
        titleLabel.text = "产品介绍"
        self.contentView.addSubview(titleLabel)
      
        descriptionLabel = UILabel()
        descriptionLabel.font = UIFont.systemFont(ofSize: 14)
        descriptionLabel.textAlignment = .left
        descriptionLabel.numberOfLines = 0
        let str = "一钛数科管车宝专注于数据服务物流，通过对运输过程中的车辆行程，司机的驾驶行为等数据的分析，达到帮助企业和车主有效降低运营成本，提升运输安全和效率的智能管车软件。"
        let style:NSMutableParagraphStyle  = NSMutableParagraphStyle()
        //将行间距设置为28
        style.lineSpacing = 5
        let attrStr = NSMutableAttributedString(string: str)
        attrStr.addAttribute(NSAttributedString.Key.paragraphStyle, value: style, range: NSRange(location: 0, length: (str.count)))
        descriptionLabel.attributedText = attrStr
        self.contentView.addSubview(descriptionLabel)
        
        
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        topLineView.snp.makeConstraints {[unowned self] (make) in
            make.leading.equalTo(self.contentView.snp.leading).offset(0)
            make.top.equalTo(self.contentView.snp.top).offset(0)
            make.right.equalTo(self.contentView.snp.right).offset(0)
            make.height.equalTo(20)
        }
        
        titleLabel.snp.makeConstraints {[unowned self] (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.top.equalTo(topLineView.snp.bottom).offset(16)
        }
       
        
        descriptionLabel.snp.makeConstraints {[unowned self] (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.right.equalTo(self.contentView.snp.right).offset(-15)
            make.top.equalTo(titleLabel.snp.bottom).offset(10)
            make.bottom.equalTo(self.contentView.snp.bottom).offset(-14)
        }
        
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }

}
