//
//  MyTableViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/9.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class MyTableViewCell: UITableViewCell {
    var leftLabel :UILabel!
    var leftImageView :UIImageView!
    var rightImageView :UIImageView!
    var rightLabel :UILabel!
    var dotView:UIView!
    var bottomView:UIView!
    private var contentEdges = UIEdgeInsets(top: 12, left: 23, bottom: 12, right: 16)
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        createUI()
        self .updateConstraints()
    }
    
    private func createUI() {
        leftImageView = UIImageView()
        self.contentView .addSubview(leftImageView)
        leftLabel = UILabel()
        leftLabel.font = UIFont.systemFont(ofSize: 15.0)
        leftLabel.textAlignment = .left
        leftLabel.textColor = UIColor(hex: "#363847", alpha: 1.0)
        self.contentView.addSubview(leftLabel)
        rightImageView = UIImageView()
        self.contentView .addSubview(rightImageView)
        rightLabel = UILabel()
        rightLabel.font = UIFont.systemFont(ofSize: 15.0)
        rightLabel.textAlignment = .right
        rightLabel.textColor = UIColor(hex: "#5C5E74", alpha: 1.0)
        self.contentView.addSubview(rightLabel)
        bottomView = UIView()
        bottomView.backgroundColor = UIColor(hex: "#E6E9EE", alpha: 1.0)
        self.contentView.addSubview(bottomView)
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        leftImageView.snp.makeConstraints {[unowned self] (make) in
            make.left.equalTo(self.snp.left).offset(contentEdges.left)
            make.centerY.equalTo(self)
        }
        
        leftLabel.snp.makeConstraints {[unowned self] (make) in
            make.centerY.equalTo(leftImageView)
            make.left.equalTo(leftImageView.snp.right).offset(9)
        }
        
        
        rightLabel.snp.makeConstraints {[unowned self] (make) in
            make.right.equalTo(self.contentView.snp.right).offset(-15)
            make.centerY.equalTo(self)
        }
        
        
        rightImageView.snp.makeConstraints {[unowned self] (make) in
            make.centerY.equalTo(self)
            make.right.equalTo(self.snp.right).offset(-15)
        }
        
        bottomView.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(60)
            make.right.equalTo(self.snp.right).offset(-15)
            make.bottom.equalTo(self)
            make.height.equalTo(1)
        }
        
      
        
    }
    func setModel(dic:Dictionary<String,String>) {
        rightImageView.image = UIImage(named: "my_rightJianTou")
        leftLabel.text = dic["title"]
        leftImageView.image = UIImage(named: dic["image"]!)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }

}
