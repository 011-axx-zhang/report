//
//  NotiSetTableViewCell.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/9.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class NotiSetTableViewCell: UITableViewCell {

    var leftLabel:UILabel!
    var switchBtn : UISwitch!
    var lineView :UIView!
    var switchClick:((UISwitch)->Void)?
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        createUI()
        self .updateConstraints()
    }
    
    private func createUI() {
        leftLabel = UILabel()
        leftLabel.font = UIFont.systemFont(ofSize: 15.0)
        leftLabel.textAlignment = .left
        leftLabel.textColor = UIColor(hex: "#363847",alpha: 1.0)
        self.contentView.addSubview(leftLabel)
        
        switchBtn = UISwitch()
        switchBtn.isOn = true
        switchBtn.onTintColor = UIColor(hex: "#1D69F5",alpha: 1.0)
        switchBtn.addTarget(self, action:#selector(self.switchDidChange(sender:)), for:  .valueChanged)
        self.contentView.addSubview(switchBtn)
        
        lineView = UIView()
        lineView.backgroundColor = UIColor(hex: "#E6E9EE",alpha: 1.0)!
        self.contentView.addSubview(lineView)
    }
    
    
    @objc  func switchDidChange(sender: UISwitch)  {
        self.switchClick?(sender)
    }
    
    override func updateConstraints() {
        super.updateConstraints()
        leftLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.top.equalTo(self.contentView.snp.top).offset(17)
        }
        
        
        switchBtn.snp.makeConstraints { (make) in
            make.right.equalTo(self.contentView.snp.right).offset(-12)
            make.centerY.equalTo(leftLabel)
            make.size.equalTo(CGSize(width: 51, height: 31))
        }
        
        
        lineView.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView.snp.left).offset(15)
            make.right.equalTo(self.contentView.snp.right).offset(-15)
            make.bottom.equalTo(self.contentView.snp.bottom).offset(0)
            make.height.equalTo(1)
        }
        
    }
    
    
    
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
       

}
