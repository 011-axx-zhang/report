//
//  MyCalendarView.swift
//  Calendar
//
//  Created by huobanbengkui on 2018/3/2.
//  Copyright © 2018年 huobanbengkui. All rights reserved.
//

import UIKit
import SnapKit

class MyCalendarView: UIView, MDTimePickerDialogDelegate {
 
   
    private let dateHeight = 270*IPHONE6SCALE;
    private let viewHeight = 470*IPHONE6SCALE;
    private var firstView:UIView!;
    private var secondView:UIView!;
    private var headLabel: UILabel!;
    private var leftButton: UIButton!;
    private var rightButton: UIButton!;
    private var startDateStr: String?;
    private var endDateStr: String?;
    private var useDate = Date();
    var resultDate:((String?, String?,String?,String?) -> Void)?;
    private let dateFormatter = DateFormatter();
    var cancleBtn:UIButton!
    var confirmBtn:UIButton!
    var cancleImageView:UIImageView!
    var confirmImageView:UIImageView!
    var startdateLabel:UILabel!
    var endDateLabel:UILabel!
    var endTimeLabel:UILabel!
    var beginTimeLabel:UILabel!
    var beginTimeImageView:UIImageView!
     var endTimeImageView:UIImageView!
    var timeStr1:String?
    var timeStr2:String?
    var selectIndex:Int?
    var benginBtn: UIButton!
     var endBtn: UIButton!
   // var upSevenShowView:(()->Void)?
    var index:Int!
     var tagFromStr:String!
    
     var height1 = 50*IPHONE6SCALE;

    init(x:CGFloat?, y:CGFloat?) {
        super.init(frame: CGRect.zero);
        self.backgroundColor = UIColor.white
        var left:CGFloat = 0
        var top:CGFloat = 0
        if x != nil {
            left = x!;
        }
        if y != nil {
            top = y!;
        }
        self.frame = CGRect.init(x: left, y: top, width: IPHONE_WIDTH, height: KH - 64);
        dateFormatter.dateFormat = "yyyy-MM-dd";
        createCalendarView(date: useDate);
    }
    //MARK:-- 创建视图
    private func createCalendarView(date: Date){
        self.backgroundColor = UIColor.white
        let titleView: UIView = UIView();
        titleView.frame = CGRect.init(x: 0, y: 0, width: IPHONE_WIDTH, height: 170);
        titleView.backgroundColor = CalendarHeader.RGBColor(r: 104, g: 114, b: 233, a: 1.0)
          //  UIColor.red
           //CalendarHeader.RGBColor(r: 104, g: 114, b: 233, a: 1.0)
        titleView.isUserInteractionEnabled = true
        self.addSubview(titleView);
    
        cancleBtn = UIButton()
       // cancleBtn.setImage(UIImage(named: "cuohao"), for: .normal)
        cancleBtn.addTarget(self, action: #selector(clickCancelButton), for: .touchUpInside);
        titleView.addSubview(cancleBtn)
        cancleBtn.snp.makeConstraints { (make) in
            make.left.equalTo( titleView.snp.left).offset(10)
            make.top.equalTo( titleView.snp.top).offset(5)
            make.size.equalTo(CGSize(width: 34, height: 34))
        }
        
        cancleImageView = UIImageView()
        cancleImageView.image = UIImage(named: "cuohao")
        cancleBtn.addSubview(cancleImageView)
        cancleImageView.snp.makeConstraints { (make) in
            make.center.equalTo(cancleBtn)
            make.size.equalTo(CGSize(width: 14, height: 14))
        }
       
        
        confirmBtn = UIButton()
       // confirmBtn.setImage(UIImage(named: "duihao"), for: .normal)
        confirmBtn.addTarget(self, action: #selector(clickSureButton), for: .touchUpInside);
        titleView.addSubview(confirmBtn)
        confirmBtn.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp.right).offset(-10)
            make.top.equalTo(self.snp.top).offset(5)
            make.size.equalTo(CGSize(width: 34, height: 34))
        }
        
        confirmImageView = UIImageView()
        confirmImageView .image = UIImage(named: "duihao")
        confirmBtn.addSubview(confirmImageView )
        confirmImageView .snp.makeConstraints { (make) in
            make.center.equalTo(confirmBtn)
            make.size.equalTo(CGSize(width: 14, height: 14))
        }
       
        
        let  startLabel = UILabel()
        startLabel.text = "开始"
        startLabel.font = UIFont.systemFont(ofSize: 15)
        startLabel.textColor = UIColor.white
        titleView.addSubview(startLabel)
        startLabel.snp.makeConstraints { (make) in
            make.left.equalTo(titleView.snp.left).offset(10)
            make.top.equalTo(cancleBtn.snp.bottom).offset(20)
        }
     
        
        let endLabel = UILabel()
        endLabel.text = "结束"
        endLabel.font = UIFont.systemFont(ofSize: 15)
        endLabel.textColor = UIColor.white
        titleView.addSubview(endLabel)
        endLabel.snp.makeConstraints { (make) in
            make.left.equalTo(titleView.snp.left).offset(IPHONE_WIDTH/2.0)
            make.top.equalTo(cancleBtn.snp.bottom).offset(20)
        }
        
        
        startdateLabel = UILabel()
        //startdateLabel.text = "2018/7/7"
        startdateLabel.font = UIFont.systemFont(ofSize: 12)
        startdateLabel.textColor = UIColor.white
        titleView.addSubview(startdateLabel)
        startdateLabel.snp.makeConstraints { (make) in
            make.left.equalTo(titleView.snp.left).offset(10)
            make.top.equalTo(startLabel.snp.bottom).offset(10)
           // make.size.equalTo(CGSize(width: 100, height: 15))
        }
        
        
        endDateLabel = UILabel()
        //endDateLabel.text = "2018/7/7"
        endDateLabel.font = UIFont.systemFont(ofSize: 12)
        endDateLabel.textColor = UIColor.white
        titleView.addSubview(endDateLabel)
        endDateLabel.snp.makeConstraints { (make) in
            make.left.equalTo(titleView.snp.left).offset(IPHONE_WIDTH/2.0)
            make.top.equalTo(endLabel.snp.bottom).offset(10)
            //make.size.equalTo(CGSize(width: 100, height: 15))
        }

        benginBtn = UIButton()
        benginBtn.addTarget(self, action: #selector(beginClickEvent), for: .touchUpInside);
        benginBtn.isEnabled = false
        titleView.addSubview(benginBtn)
        benginBtn.snp.makeConstraints { (make) in
            make.left.equalTo(titleView.snp.left).offset(10)
            make.top.equalTo(startdateLabel.snp.bottom).offset(15)
             make.size.equalTo(CGSize(width: 100, height: 30))
        }
        
        beginTimeLabel = UILabel()
       // beginTimeLabel.text = "8:00"
        beginTimeLabel.font = UIFont.systemFont(ofSize: 12)
        beginTimeLabel.textColor = UIColor.white
        benginBtn.addSubview(beginTimeLabel)
        beginTimeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(benginBtn.snp.left).offset(0)
          //  make.top.equalTo(benginBtn.snp.top).offset(5)
              make.centerY.equalTo(benginBtn)
            // make.size.equalTo(CGSize(width: 100, height: 15))
            
        }
        beginTimeImageView = UIImageView()
        beginTimeImageView.image = UIImage(named: "xiala")
        benginBtn.addSubview(beginTimeImageView)
        beginTimeImageView.snp.makeConstraints { (make) in
            make.left.equalTo(beginTimeLabel.snp.right).offset(10)
            make.centerY.equalTo(benginBtn)
        }
        beginTimeImageView.isHidden = true
        
       endBtn = UIButton()
        endBtn.isEnabled = false
        endBtn.addTarget(self, action: #selector(endClickEvent), for: .touchUpInside);
        titleView.addSubview(endBtn)
        endBtn.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(IPHONE_WIDTH/2.0)
            make.top.equalTo(endDateLabel.snp.bottom).offset(15)
            make.size.equalTo(CGSize(width: 100, height: 30))
        }
        
       endTimeLabel = UILabel()
      //  endTimeLabel.text = "12:00"
        endTimeLabel.font = UIFont.systemFont(ofSize: 12)
        endTimeLabel.textColor = UIColor.white
        endBtn.addSubview(endTimeLabel)
        endTimeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(endBtn.snp.left).offset(0)
            make.centerY.equalTo(endBtn)
           // make.top.equalTo(endBtn.snp.top).offset(5)
        }
        endTimeImageView = UIImageView()
        endTimeImageView.image = UIImage(named: "xiala")
        endBtn.addSubview(endTimeImageView)
        endTimeImageView.snp.makeConstraints { (make) in
            make.left.equalTo(endTimeLabel.snp.right).offset(10)
         //   make.top.equalTo(endBtn.snp.top).offset(5)
             make.centerY.equalTo(endBtn)
        }
         endTimeImageView.isHidden = true
        


        headLabel = UILabel();
        headLabel.frame = CGRect.init(x: 0, y: 138, width: IPHONE_WIDTH, height: height1);
        headLabel.font = UIFont.systemFont(ofSize: 14.0);
        headLabel.backgroundColor = CalendarHeader.RGBColor(r: 104, g: 114, b: 233, a: 1.0);
        headLabel.textAlignment = .center;
        headLabel.textColor = CalendarHeader.RGBColor(r: 255, g: 255, b: 255, a: 1.0);
        let dateM = getDayMonthAndYear(date: date);
        headLabel.text = "\(dateM.year)年\(dateM.month)月";
        titleView.addSubview(headLabel);

        leftButton = UIButton(type: UIButton.ButtonType.custom);
        leftButton.frame = CGRect.init(x: 5, y: headLabel.frame.minY, width: height1, height: height1);
        leftButton.setImage(UIImage.init(named: "triangleft"), for: .normal);
        leftButton.addTarget(self, action: #selector(clickLastMonth), for: UIControl.Event.touchUpInside);
        titleView.addSubview(leftButton);

        rightButton = UIButton(type: .custom);
        rightButton.frame = CGRect.init(x: IPHONE_WIDTH - height1, y: headLabel.frame.minY, width: height1, height: height1);
        rightButton.setImage(UIImage.init(named: "triangleright"), for: .normal);
        rightButton.addTarget(self, action: #selector(clickNextMonth), for: UIControl.Event.touchUpInside);
        titleView.addSubview(rightButton);


        let weekArray = ["日", "一", "二", "三", "四", "五", "六"];
        let weekBgView:UIView = UIView();
        weekBgView.frame = CGRect.init(x: 0, y: headLabel.frame.maxY, width: IPHONE_WIDTH, height: height1);
        weekBgView.backgroundColor = CalendarHeader.RGBColor(r: 255, g: 255, b: 255, a: 1.0);
        self.addSubview(weekBgView);
        for i in 0..<weekArray.count{
            let number = CGFloat.init(i);
            let label:UILabel = UILabel();
            label.frame = CGRect.init(x: 12.5*IPHONE6SCALE + 50*number*IPHONE6SCALE, y: 0, width: 50*IPHONE6SCALE, height: height1);
            label.text = weekArray[i];
            label.font = UIFont.systemFont(ofSize: 12.0);
            label.textColor = CalendarHeader.RGBColor(r: 0, g: 0, b: 0, a: 1.0);
            label.backgroundColor = UIColor.clear;
            label.textAlignment = .center;
            weekBgView.addSubview(label);
        }

        firstView = createDayView();
        firstView.frame = CGRect.init(x: 0, y: weekBgView.frame.maxY, width: IPHONE_WIDTH, height: viewHeight - weekBgView.frame.maxY);
        firstView.backgroundColor = CalendarHeader.RGBColor(r: 255, g: 255, b: 255, a: 1.0);
        self.addSubview(firstView);
        setMessageOnButton(date: date, view: firstView);

        secondView = createDayView();
        secondView.isHidden = true;
        secondView.frame = CGRect.init(x: 0, y: weekBgView.frame.maxY, width: IPHONE_WIDTH, height: viewHeight - weekBgView.frame.maxY);
        secondView.backgroundColor = CalendarHeader.RGBColor(r: 255, g: 255, b: 255, a: 1.0);
        self.addSubview(secondView);
        //添加手势
        addGestureOnView(view: firstView);
        addGestureOnView(view: secondView);
    }
    
    @objc func beginClickEvent() {
        let timePicker = MDTimePickerDialog()
        timePicker.delegate = self
        timePicker.theme = MDTimePickerTheme.light
        index = 1
        timePicker.show()
    }
    
    func timePickerDialog(_ timePickerDialog: MDTimePickerDialog, didSelectHour hour: Int, andMinute minute: Int) {
        let h  = String(format: "%ld", hour)
         let s = String(format: "%ld", minute)
        if index == 1 {
        timeStr1 =  h + ":"  + s
            if  timeStr2 != nil {
                if selectIndex == 1 {
                    let n1 = self.str2Date(dateStr: timeStr1)
                    let n2 = self.str2Date(dateStr: timeStr2)
                    let res = n1?.compare(n2!)
                 
                    if res == ComparisonResult.orderedDescending{
                        let midDateStr = timeStr1;
                        timeStr1 = timeStr2;
                        timeStr2 = midDateStr
                        
                    }
                }else {
                    if dateFormatter.date(from: startDateStr!)! == dateFormatter.date(from: endDateStr!)!{
                        let n1 = self.str2Date(dateStr: timeStr1)
                        let n2 = self.str2Date(dateStr: timeStr2)
                        let res = n1?.compare(n2!)
                        if res == ComparisonResult.orderedDescending{
                            let midDateStr = timeStr1;
                            timeStr1 = timeStr2;
                            timeStr2 = midDateStr
                            
                        }
                        
                    }
                }
                
                beginTimeLabel.text  = timeStr1
                endTimeLabel.text  = timeStr2
                
            
            }
            beginTimeLabel.text  = timeStr1
           
           
        }
        
        if index == 2 {
           timeStr2 =   h + ":"  + s
            if timeStr1 != nil {
                
                if selectIndex == 1 {
                    let n1 = self.str2Date(dateStr: timeStr1)
                    let n2 = self.str2Date(dateStr: timeStr2)
                    let res = n1?.compare(n2!)
                    if res == ComparisonResult.orderedDescending{
                        let midDateStr = timeStr1;
                        timeStr1 = timeStr2;
                        timeStr2 = midDateStr
                        
                    }
                }else {
                    if dateFormatter.date(from: startDateStr!)! == dateFormatter.date(from: endDateStr!)!{
                        let n1 = self.str2Date(dateStr: timeStr1)
                        let n2 = self.str2Date(dateStr: timeStr2)
                        let res = n1?.compare(n2!)
                        if res == ComparisonResult.orderedDescending{
                            let midDateStr = timeStr1;
                            timeStr1 = timeStr2;
                            timeStr2 = midDateStr
                            
                        }
                        
                    }
                }
             
              
                beginTimeLabel.text  = timeStr1
                endTimeLabel.text  = timeStr2
            }
            
            endTimeLabel.text  = timeStr2
        }
        
    }
    
    
    func strDate(dateStr:String?)->Date?{
        let formater=DateFormatter()
        formater.dateFormat="yyyy-MM-dd'T'HH:mm:ss"
        formater.timeZone=NSTimeZone.local
        return formater.date(from: dateStr ?? "")
    }
    
    
    func str2Date(dateStr:String?)->Date?{
        let formater=DateFormatter()
        formater.dateFormat="HH:mm"
        formater.timeZone=NSTimeZone.local
        return formater.date(from: dateStr ?? "")
    }
    
    @objc func endClickEvent() {
        let timePicker = MDTimePickerDialog()
        timePicker.delegate = self
        timePicker.theme = MDTimePickerTheme.light
        index = 2
        timePicker.show()
    }
    
    private func createDayView() -> UIView!{
        let baseView = UIView();
        baseView.backgroundColor = CalendarHeader.RGBColor(r: 255, g: 255, b: 255, a: 1.0);
        for i in 0..<42 {
            let x = CGFloat.init(i%7)*50*IPHONE6SCALE + 12.5*IPHONE6SCALE;
            let y = CGFloat.init(i/7)*45*IPHONE6SCALE + 5*IPHONE6SCALE;
//            为啥添加0.2 添加圆角以后，会导致产生部分空隙，原因未知：
            let button:UIButton = createPrivateButton(imageStr:"", font: 12.0, color: nil, frame: CGRect.init(x: x, y: y, width: 50*IPHONE6SCALE + 0.2, height: 35*IPHONE6SCALE));
            button.tag = 100 + i;
            button.addTarget(self, action: #selector(clickDayButton), for: UIControl.Event.touchUpInside);
            button.titleLabel?.textAlignment = .center;
            setRadius(button: button, isAll: true, radious: 2.0);
            baseView.addSubview(button);
        }
        return baseView;
    }
    
    //MARK:-- 添加滑动事件
    private func addGestureOnView(view: UIView){
        let swipeNext = UISwipeGestureRecognizer(target: self, action: #selector(clickNextMonth));
        swipeNext.direction = .left;
        view.addGestureRecognizer(swipeNext);
        
        let swipeLast = UISwipeGestureRecognizer(target: self, action: #selector(clickLastMonth));
        swipeLast.direction = .right;
        view.addGestureRecognizer(swipeLast);
    }
    
    @objc private func clickNextMonth(){
        rightButton.isEnabled = false;
        useDate = nextMonth(date: useDate);
        let dateM = getDayMonthAndYear(date: useDate);
        headLabel.text = "\(dateM.year)年\(dateM.month)月";
        if firstView.frame.origin.x == 0{
            var frame = secondView.frame;
            frame.origin.x = IPHONE_WIDTH;
            secondView.frame = frame;
            secondView.isHidden = false;
            setMessageOnButton(date: useDate, view: secondView);
            UIView.animate(withDuration: 0.5, animations: {[weak self]()->Void in
                if let strongSelf = self{
                    var frame = strongSelf.firstView.frame;
                    frame.origin.x = -IPHONE_WIDTH;
                    strongSelf.firstView.frame = frame;
                    
                    var frameNext = strongSelf.secondView.frame;
                    frameNext.origin.x = 0;
                    strongSelf.secondView.frame = frameNext;
                }
            }) { [weak self](finished) in
                if let strongSelf = self{
                    strongSelf.firstView.isHidden = true;
                    strongSelf.rightButton.isEnabled = true;
                }
            }
        }else{
            var frame = firstView.frame;
            frame.origin.x = IPHONE_WIDTH;
            firstView.frame = frame;
            firstView.isHidden = false;
            setMessageOnButton(date: useDate, view: firstView);
            UIView.animate(withDuration: 0.5, animations: {[weak self]()->Void in
                if let strongSelf = self{
                    var frame = strongSelf.secondView.frame;
                    frame.origin.x = -IPHONE_WIDTH;
                    strongSelf.secondView.frame = frame;
                    
                    var frameNext = strongSelf.firstView.frame;
                    frameNext.origin.x = 0;
                    strongSelf.firstView.frame = frameNext;
                }
            }) { [weak self](finished) in
                if let strongSelf = self{
                    strongSelf.secondView.isHidden = true;
                    strongSelf.rightButton.isEnabled = true;
                }
            }
        }
    }
    @objc private func clickLastMonth(){
        leftButton.isEnabled = false;
        useDate = lastMonth(date: useDate);
        let dateM = getDayMonthAndYear(date: useDate);
        headLabel.text = "\(dateM.year)年\(dateM.month)月";
        if firstView.frame.origin.x == 0{
            var frame = secondView.frame;
            frame.origin.x = -IPHONE_WIDTH;
            secondView.frame = frame;
            secondView.isHidden = false;
            setMessageOnButton(date: useDate, view: secondView);
            UIView.animate(withDuration: 0.5, animations: {[weak self]()->Void in
                if let strongSelf = self{
                    var frame = strongSelf.firstView.frame;
                    frame.origin.x = IPHONE_WIDTH;
                    strongSelf.firstView.frame = frame;
                    
                    var frameNext = strongSelf.secondView.frame;
                    frameNext.origin.x = 0;
                    strongSelf.secondView.frame = frameNext;
                }
            }) { [weak self](finished) in
                if let strongSelf = self{
                    strongSelf.firstView.isHidden = true;
                    strongSelf.leftButton.isEnabled = true;
                }
            }
        }else{
            var frame = firstView.frame;
            frame.origin.x = -IPHONE_WIDTH;
            firstView.frame = frame;
            firstView.isHidden = false;
            setMessageOnButton(date: useDate, view: firstView);
            UIView.animate(withDuration: 0.5, animations: {[weak self]()->Void in
                if let strongSelf = self{
                    var frame = strongSelf.secondView.frame;
                    frame.origin.x = IPHONE_WIDTH;
                    strongSelf.secondView.frame = frame;
                    
                    var frameNext = strongSelf.firstView.frame;
                    frameNext.origin.x = 0;
                    strongSelf.firstView.frame = frameNext;
                }
            }) { [weak self](finished) in
                if let strongSelf = self{
                    strongSelf.secondView.isHidden = true;
                    strongSelf.leftButton.isEnabled = true;
                }
            }
        }
    }
    
    //MARK:-- 设置数据
    private func setMessageOnButton(date:Date, view:UIView){
        let daysInThisMonth = totalDaysInMonth(date: date);
        let firstWeekday = firstWeekDayIntThisMonth(date: date);
        let useDateMessage = getDayMonthAndYear(date: date);
        let nowDate = getDayMonthAndYear(date: Date());
        let zoneNowDate = dateFormatter.date(from: "\(nowDate.year)-\(nowDate.month)-\(nowDate.day)")
        var day = 0;
        for i in 0..<42 {
            let button = view.viewWithTag(100 + i) as! UIButton;
            //复位
            button.setTitle(nil, for: .normal);
            button.setTitleColor(UIColor.clear, for: .normal);
            button.backgroundColor = UIColor.clear;
            //填写日期 不在本月的不显示
            if (i >= firstWeekday) && (i <= firstWeekday + daysInThisMonth - 1){
                day = i - firstWeekday + 1;
                button.setTitle("\(day)", for: .normal);
                
                //已经过去的日子可以点击
                let zoneDate = dateFormatter.date(from: "\(useDateMessage.year)-\(useDateMessage.month)-\(day)");
                if zoneDate! <= zoneNowDate!{
                    button.isEnabled = true;
                    button.setTitleColor(CalendarHeader.RGBColor(r: 0, g: 0, b: 0, a: 1.0), for: .normal);
                    if zoneDate! == zoneNowDate! {
                        button.backgroundColor = CalendarHeader.RGBColor(r: 232, g: 121, b: 124, a: 1.0)
                    }
                }else{
                    button.isEnabled = false;
                    button.setTitleColor(CalendarHeader.RGBColor(r: 125, g: 125, b: 125, a: 1.0), for: .normal);
                }
            }
        }
        setBackgroundColorOnButton(view: view);
    }
    
    //MARK:-- 获取年 月 日  元组
    private func getDayMonthAndYear(date: Date) -> (day: NSInteger, month: NSInteger, year: NSInteger){
        let components = NSCalendar.current.dateComponents([Calendar.Component.year, Calendar.Component.month, Calendar.Component.day], from: date as Date)
        return (day: components.day!, month: components.month!, year: components.year!);
    }
    //MARK:-- 获取本月的相关天数，星期
    private func firstWeekDayIntThisMonth(date: Date) -> NSInteger{
        var calendar = Calendar.current;
        //1:Sun 2.Mon  3.Thes 4.Wed 5.Thur 6.Fri 7.Sat
        calendar.firstWeekday = 1;
        var compents:DateComponents = calendar.dateComponents([.year, .month, .day], from: date as Date);
        compents.day = 1;
        let firstDayOfMonthDate: Date = calendar.date(from: compents)!;
        let firstWeekDay: NSInteger = calendar.ordinality(of: Calendar.Component.weekday, in: Calendar.Component.weekOfMonth, for: firstDayOfMonthDate)!;
        return firstWeekDay - 1;
    }
    private func totalDaysInMonth(date: Date) -> NSInteger{
        let daysInMonth:Range = Calendar.current.range(of: Calendar.Component.day, in: .month, for: date)!;
        return daysInMonth.count;
    }
    //MARK:-- 上一个月，下一个月的月份
    private func lastMonth(date: Date) -> Date{
        var dateCompoents:DateComponents = DateComponents();
        dateCompoents.month = -1;
        let lastDate = Calendar.current.date(byAdding: dateCompoents, to: date);
        return lastDate!;
    }
    private func nextMonth(date: Date) -> Date{
        var dateCompoents: DateComponents = DateComponents();
        dateCompoents.month = 1;
        let nextDate = Calendar.current.date(byAdding: dateCompoents, to: date);
        return nextDate!;
    }
    
    //MARK:-- 渲染选中的日期
    @objc private func clickDayButton(button: UIButton){
        if button.title(for: .normal) == nil {
            return;
        }
        let selectDay: String = button.title(for: .normal)!;
        let dateM = getDayMonthAndYear(date: useDate);
        if  startDateStr != nil && endDateStr != nil {
            //如果两个值都有，则清空所有的选择
            startDateStr = nil;
            endDateStr = nil;
            setBackgroundColorOnButton(view: nil);
           
        }else{
            if startDateStr == nil{
                selectIndex = 1
                startDateStr = "\(dateM.year)-\(dateM.month)-\(selectDay)";
                startdateLabel.text = startDateStr
                endDateLabel.text = startDateStr
                beginTimeLabel.text = "00:00"
                endTimeLabel.text = "00:00"
                beginTimeImageView.isHidden = false
                endTimeImageView.isHidden = false
                
                button.backgroundColor = CalendarHeader.RGBColor(r: 205, g: 209, b: 225, a: 1.0);
            }else{
                endDateStr = "\(dateM.year)-\(dateM.month)-\(selectDay)";
            }
            if startDateStr != nil && endDateStr != nil{
                //如果两个参数都有，先判断大小，然后刷新UI
                selectIndex = 2
                if dateFormatter.date(from: startDateStr!)! > dateFormatter.date(from: endDateStr!)!{
                    let midDateStr = startDateStr;
                    startDateStr = endDateStr;
                    endDateStr = midDateStr;
                  
                }
                startdateLabel.text = startDateStr
                endDateLabel.text = endDateStr
                beginTimeLabel.text = "00:00"
                endTimeLabel.text = "00:00"
                beginTimeImageView.isHidden = false
                endTimeImageView.isHidden = false
                setBackgroundColorOnButton(view: nil);
            }
        }
        
        benginBtn.isEnabled = true
        endBtn.isEnabled  = true
        
        
    }
    private func setBackgroundColorOnButton(view: UIView?){
        var useView: UIView!;
        if view == nil {
            useView = firstView.frame.origin.x == 0 ? firstView:secondView;
        }else{
            useView = view!;
        }
        let useDateMessage = getDayMonthAndYear(date: useDate);
        let nowDate = getDayMonthAndYear(date: Date());
        let zoneNowDate = dateFormatter.date(from: "\(nowDate.year)-\(nowDate.month)-\(nowDate.day)");
        var startDate: Date?;
        var endDate: Date?;
        var zoneDate: Date?;
        for i in 0..<42 {
            let button = useView.viewWithTag(100 + i) as! UIButton;
            if button.title(for: .normal) == nil {
                continue;
            }
            let selectDay: String = button.title(for: .normal)!;
            if startDateStr == nil || endDateStr == nil{
                setRadius(button: button, isAll: true, radious: 2.0);
                button.backgroundColor = CalendarHeader.RGBColor(r: 255, g: 255, b: 255, a: 1.0);
                zoneDate = dateFormatter.date(from: "\(useDateMessage.year)-\(useDateMessage.month)-\(selectDay)");
                if zoneDate! == zoneNowDate! {
                    button.backgroundColor = CalendarHeader.RGBColor(r: 232, g: 121, b: 124, a: 1.0)
                }
            }else{
                if startDate == nil || endDate == nil{
                    startDate = dateFormatter.date(from: startDateStr!);
                    endDate = dateFormatter.date(from: endDateStr!);
                }
                zoneDate = dateFormatter.date(from: "\(useDateMessage.year)-\(useDateMessage.month)-\(selectDay)");
                if zoneDate! > startDate! && zoneDate! < endDate!{
                    setRadius(button: button, isAll: true, radious: 0.0);
                    button.backgroundColor = CalendarHeader.RGBColor(r: 205, g: 209, b: 225, a: 1.0);
                }else if(zoneDate! == startDate!){
                    setRadius(button: button, isAll: nil, radious: 2.0);
                    button.backgroundColor = CalendarHeader.RGBColor(r: 205, g: 209, b: 225, a: 1.0);
                }else if(zoneDate! == endDate!){
                    setRadius(button: button, isAll: false, radious: 2.0);
                    button.backgroundColor = CalendarHeader.RGBColor(r: 205, g: 209, b: 225, a: 1.0);
                }
            }
        }
    }
    
    //MARK:--快捷方式创建Button
    private func createPrivateButton(imageStr: String?, font: CGFloat, color: UIColor?, frame: CGRect) -> UIButton{
        let button:UIButton = UIButton(type: .custom);
//        button.setTitle(title, for: .normal);
        button.titleLabel?.font = UIFont.systemFont(ofSize: font);
//        button.setImage(UIImage(named: imageStr!), for: .normal)
        button.setTitleColor(color, for: .normal);
        button.frame = frame;
        return button;
    }
    
    //MARK:-- 返回 、 确定
    @objc private func clickCancelButton(){
        if resultDate != nil{
            resultDate!(nil, nil,nil,nil);
        }
        self.removeFromSuperview();
    }
    @objc private func clickSureButton(){
        if startDateStr == nil {
            let alertView = UIAlertController(title: "请选择开始日期", message: nil, preferredStyle: .alert);
            let okAction = UIAlertAction(title: "好的", style: .default, handler: nil);
            alertView.addAction(okAction);
            (UIApplication.shared.keyWindow?.rootViewController)!.present(alertView, animated: true, completion: nil)
        }else if endDateStr == nil{
            endDateStr  = startDateStr
            if resultDate != nil{
                let formatter = DateFormatter()
                formatter.dateFormat = "YYYY-MM-dd"
        
                let startDate = formatter.date(from: startDateStr!)
                let endDate = formatter.date(from: endDateStr!)
                let days = startDate?.daysBetweenDate(toDate: endDate!)
                if days! > 7  && tagFromStr == "playBack"{
                    let alertView = UIAlertController(title: "日期选择不能超过7天", message: nil, preferredStyle: .alert);
                    let okAction = UIAlertAction(title: "好的", style: .default, handler: nil);
                    alertView.addAction(okAction);
                    (UIApplication.shared.keyWindow?.rootViewController)!.present(alertView, animated: true, completion: nil)
                }else {
                    resultDate!(startDateStr, endDateStr,timeStr1,timeStr2)
                    self.removeFromSuperview();
                }
               
            }
            
            
        }else{
            if resultDate != nil{
                let formatter = DateFormatter()
                formatter.dateFormat = "YYYY-MM-dd"
         
                let startDate = formatter.date(from: startDateStr!)
                let endDate = formatter.date(from: endDateStr!)
                let days = startDate?.daysBetweenDate(toDate: endDate!)
                if  days! > 7  && tagFromStr == "playBack"{
                    let alertView = UIAlertController(title: "日期选择不能超过7天", message: nil, preferredStyle: .alert);
                    let okAction = UIAlertAction(title: "好的", style: .default, handler: nil);
                    alertView.addAction(okAction);
                    (UIApplication.shared.keyWindow?.rootViewController)!.present(alertView, animated: true, completion: nil)
                }else {
                    resultDate!(startDateStr, endDateStr,timeStr1,timeStr2)
                     self.removeFromSuperview();
                }
            }
            
           
        }
    }
    //MARK:-- 设置圆角
    private func setRadius(button: UIButton!, isAll: Bool?, radious:CGFloat){
        var corners: UIRectCorner!;
        if isAll == nil {
            corners = [.topLeft, .bottomLeft];
        }else if isAll!{
            corners = .allCorners;
        }else{
            corners = [.topRight, .bottomRight];
        }
        let maskPath = UIBezierPath(roundedRect: button.bounds, byRoundingCorners: corners, cornerRadii: CGSize.init(width: radious, height: radious));
        let maskLayer = CAShapeLayer();
        maskLayer.frame = button.bounds;
        maskLayer.path = maskPath.cgPath;
        button.layer.mask = maskLayer;
    }
    
    //MARK:-- 获取最近时间
    @objc private func clickSelectDateButton(button: UIButton){
        let tag = button.tag - 1000;
        switch tag {
        case 0:
            //昨天
            getLastNumberDate(dateLength: 1);
        case 1:
            //过去7日
            getLastNumberDate(dateLength: 7);
        case 2:
            //过去30日
            getLastNumberDate(dateLength: 30);
        default:
            break;
        }
    }
    private func getLastNumberDate(dateLength: Int){
        let lastDate = Date(timeIntervalSinceNow: -24*60*60);
        let pastDate = Date(timeIntervalSinceNow: TimeInterval(-24*60*60*dateLength));
        startDateStr = dateFormatter.string(from: pastDate);
        endDateStr = dateFormatter.string(from: lastDate);
        if resultDate != nil{
            resultDate!(startDateStr, endDateStr,timeStr1,timeStr2);
        }
        self.removeFromSuperview();
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
//    deinit {
//        print("页面被释放");
//    }
    /*
    1，在 Swift 中, 类的初始化器有两种, 分别是Designated Initializer（指定初始化器）和Convenience Initializer（便利初始化器）
    2，如果子类没有定义任何的指定初始化器, 那么会默认继承所有来自父类的指定初始化器。
    3，如果子类提供了所有父类指定初始化器的实现, 那么自动继承父类的便利初始化器
    4，如果子类只实现部分父类初始化器，那么父类其他的指定初始化器和便利初始化器都不会继承。
    5，子类的指定初始化器必须要调用父类合适的指定初始化器。
     */
    
    /*2
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
