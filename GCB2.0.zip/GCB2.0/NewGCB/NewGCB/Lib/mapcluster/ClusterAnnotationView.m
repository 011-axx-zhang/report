//
//  ClusterAnnotationView.m
//  officialDemo2D
//
//  Created by yi chen on 14-5-15.
//  Copyright (c) 2014年 AutoNavi. All rights reserved.
//

#import "NewGCB-Swift.h"
#import "ClusterAnnotationView.h"
#import "ClusterAnnotation.h"




static CGFloat const ScaleFactorAlpha = 0.3;
static CGFloat const ScaleFactorBeta = 0.4;

/* 返回rect的中心. */
CGPoint RectCenter(CGRect rect)
{
    return CGPointMake(CGRectGetMidX(rect), CGRectGetMidY(rect));
}

/* 返回中心为center，尺寸为rect.size的rect. */
CGRect CenterRect(CGRect rect, CGPoint center)
{
    CGRect r = CGRectMake(center.x - rect.size.width/2.0,
                          center.y - rect.size.height/2.0,
                          rect.size.width,
                          rect.size.height);
    return r;
}

/* 根据count计算annotation的scale. */
CGFloat ScaledValueForValue(CGFloat value)
{
    return 1.0 / (1.0 + expf(-1 * ScaleFactorAlpha * powf(value, ScaleFactorBeta)));
}

#define FrameRect CGRectMake(0, 0, 50, 50)
#define CountRect CGRectMake(30, 0, 20, 20);


#pragma mark -

@interface ClusterAnnotationView ()

@property (nonatomic,strong) UIView *morePar;
@property (nonatomic, strong) UILabel *countLabel;
@property (nonatomic,strong) UIImageView * moreImg;

@property (nonatomic,strong) UIImageView * oneImg;

@end

@implementation ClusterAnnotationView

#pragma mark Initialization

- (id)initWithAnnotation:(id<MAAnnotation>)annotation reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithAnnotation:annotation reuseIdentifier:reuseIdentifier];
    if (self)
    {
        self.backgroundColor = [UIColor clearColor];
        [self setupLabel];
        [self setCount:1];        
    }
    
    return self;
}

#pragma mark Utility

- (void)setupLabel
{
    CGRect rect=FrameRect;
    self.frame=rect;
    //单车
    _oneImg=[[UIImageView alloc]initWithFrame:rect];
    _oneImg.contentMode=UIViewContentModeCenter;
    _oneImg.image=[UIImage imageNamed:@"lixian"];
    [self addSubview:_oneImg];
//    [_oneImg setHidden:YES];
    //多车
    _morePar=[[UIView alloc]initWithFrame:rect];
    [self addSubview:_morePar];
    
//#define FrameRect CGRectMake(0, 0, 50, 50)
//#define CountRect CGRectMake(30, 0, 20, 20);
    
    _countLabel = [[UILabel alloc] initWithFrame:FrameRect];
    _countLabel.textColor       = [UIColor whiteColor];
    _countLabel.textAlignment   = NSTextAlignmentCenter;
    _countLabel.numberOfLines = 1;
    _countLabel.font = [UIFont boldSystemFontOfSize:20];
    _countLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
    
    
    _moreImg=[[UIImageView alloc]initWithFrame:rect];
    _moreImg.contentMode=UIViewContentModeScaleAspectFit;
    _moreImg.image=[UIImage imageNamed:@"juhe"];
    
    [_morePar addSubview:_moreImg];
    [_morePar addSubview:_countLabel];
    
    [_morePar setUserInteractionEnabled:NO];
    [_countLabel setUserInteractionEnabled:NO];
    [_moreImg setUserInteractionEnabled:NO];
    [_oneImg setUserInteractionEnabled:NO];
}

- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
    NSArray *subViews = self.subviews;
    if ([subViews count] > 1)
    {
        for (UIView *aSubView in subViews)
        {
            if ([aSubView pointInside:[self convertPoint:point toView:aSubView] withEvent:event])
            {
                return YES;
            }
        }
    }
    if (point.x > 0 && point.x < self.frame.size.width && point.y > 0 && point.y < self.frame.size.height)
    {
        return YES;
    }
    return NO;
}

- (void)setCount:(NSUInteger)count
{
    _count = count;
    if (count==1) {
        [self.morePar setHidden:YES];
        [self.oneImg setHidden:NO];
        ClusterAnnotation *anno=(ClusterAnnotation*)self.annotation;
        if (anno.pois&&anno.pois.count==1) {
            VehicleModel *veh = anno.pois.firstObject;
            if (veh.isRunning) {
                if (veh.level >= 0 && veh.level < 1){
                    _oneImg.image=[UIImage imageNamed:@"green_level_vehicle"];
                }else  if (veh.level >2){
                    _oneImg.image=[UIImage imageNamed:@"red_level_vehicle"];
                }else {
                    _oneImg.image=[UIImage imageNamed:@"yellow_level_vehicle"];
                }
            }else {
                _oneImg.image=[UIImage imageNamed:@"gray_level_vehicle"];
            }
           
        }
    }else{
        [self.morePar setHidden:NO];
        [self.oneImg setHidden:YES];
        self.countLabel.text = [@(_count) stringValue];
    }
    [self setNeedsDisplay];
}

#pragma mark - annimation

- (void)willMoveToSuperview:(UIView *)newSuperview
{
    [super willMoveToSuperview:newSuperview];
    
    [self addBounceAnnimation];
}

- (void)addBounceAnnimation
{
    CAKeyframeAnimation *bounceAnimation = [CAKeyframeAnimation animationWithKeyPath:@"transform.scale"];
    
    bounceAnimation.values = @[@(0.05), @(1.1), @(0.9), @(1)];
    bounceAnimation.duration = 0.6;
    
    NSMutableArray *timingFunctions = [[NSMutableArray alloc] initWithCapacity:bounceAnimation.values.count];
    for (NSUInteger i = 0; i < bounceAnimation.values.count; i++)
    {
        [timingFunctions addObject:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
    }
    [bounceAnimation setTimingFunctions:timingFunctions.copy];
    
    bounceAnimation.removedOnCompletion = NO;
    
    [self.layer addAnimation:bounceAnimation forKey:@"bounce"];
}

#pragma mark draw rect



@end
