//
//  RootController.swift
//  NewGCB
//
//  Created by 亭子 on 2019/12/12.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit
import SwiftyJSON
import HandyJSON

class RootController: UIViewController {
    var leftBtn = UIButton()
    var rightBtn = UIButton()
    var navLabel = UILabel()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        
        addNavView()
        addChildView()
    }
    
    func addNavView() -> Void {
        //
        let navView = UIView.init(frame: .init(x: 0, y: 0, width: KW, height: navigationBarHeight))
        navView.backgroundColor = UIColor.white
        self.view.addSubview(navView)
        
        leftBtn = UIButton.init(type: .custom)
        leftBtn.frame = CGRect.init(x: 5, y: statusHeight, width: 44, height: 44)
        leftBtn.setImage(UIImage(named: "navigation_back"), for: .normal)
        leftBtn.addTarget(self, action: #selector(leftNavigationBarItemAction), for: .touchUpInside)
        navView.addSubview(leftBtn)
        
        navLabel = UILabel.init(frame: .init(x: KW/2-100, y: statusHeight, width: 200, height: 44))
        navLabel.font = UIFont.boldSystemFont(ofSize: 17)
        navLabel.textAlignment = NSTextAlignment.center
        navView.addSubview(navLabel)
        
        rightBtn = UIButton.init(type: .custom)
        rightBtn.frame = CGRect.init(x: navView.frame.width-5-44, y: statusHeight, width: 44, height: 44)
        rightBtn.isHidden = true;
        rightBtn.addTarget(self, action: #selector(rightNavigationBarItemAction), for: .touchUpInside)
        navView.addSubview(rightBtn)
        
        let line = UIView.init(frame: .init(x: 0, y: navView.frame.height-2, width: KW, height: 1.0))
        line.backgroundColor = UIColor.init(hex: "#F5F5F9", alpha: 1.0)
        navView.addSubview(line)
        
    }
    
    func addChildView() -> Void {
        //
    }
    
    func setNavViewData(title: String, leftImage: String?, rightImage: String?) -> Void {
        navLabel.text = title
        
        if leftImage == nil {
            leftBtn.setImage(UIImage(named: "navigation_back"), for: .normal)
        }else{
            leftBtn.setImage(UIImage.init(named: leftImage!), for: .normal)
        }
        
        if rightImage == nil {
            rightBtn.isHidden = true
        }else{
            rightBtn.isHidden = false
            rightBtn.setImage(UIImage(named: rightImage!), for: .normal)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.navigationBar.isHidden = true
    }
    
    
    @objc func leftNavigationBarItemAction() -> Void {
//        print("导航栏左侧按钮点击事件有需要的话可以重写！！")
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func rightNavigationBarItemAction() -> Void {
//        print("导航栏右侧按钮点击事件有需要的话可以重写！！")
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
