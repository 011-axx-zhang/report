//
//  BaseVC.swift
//  NewGCB
//
//  Created by YTKJ on 2020/1/30.
//  Copyright © 2020 YTKJ. All rights reserved.
//

import UIKit

class BaseVC: UIViewController {

   lazy var navBar = WRCustomNavigationBar.CustomNavigationBar()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        automaticallyAdjustsScrollViewInsets = false
        setupNavBar()
        
    }

    fileprivate func setupNavBar()
    {
        
        view.addSubview(navBar)
        
        // 设置自定义导航栏背景图片
       // navBar.barBackgroundImage = UIImage(named: "millcolorGrad")

        // 设置自定义导航栏背景颜色
        // navBar.backgroundColor = MainNavBarColor
        
        // 设置自定义导航栏标题颜色
        navBar.titleLabelColor = .black

        // 设置自定义导航栏左右按钮字体颜色
        navBar.wr_setTintColor(color: .black)
        
        navBar.titleLabelFont = UIFont.systemFont(ofSize: 17)
        
        
        
        if self.navigationController?.children.count != 0 {
            navBar.wr_setLeftButton(image: UIImage(named: "nav_back")!)
        }
    }
    
    @objc fileprivate func back()
    {
        _ = navigationController?.popViewController(animated: true)
    }
    
    @objc func onClickBack () {
         _ = navigationController?.popViewController(animated: true)
    }
    
    

}
