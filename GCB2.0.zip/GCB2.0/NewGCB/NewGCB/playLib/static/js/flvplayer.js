!
function(e) {
    var t = {};

    function n(i) {
        if (t[i]) return t[i].exports;
        var r = t[i] = {
            i: i,
            l: !1,
            exports: {}
        };
        return e[i].call(r.exports, r, r.exports, n),
        r.l = !0,
        r.exports
    }
    n.m = e,
    n.c = t,
    n.d = function(e, t, i) {
        n.o(e, t) || Object.defineProperty(e, t, {
            configurable: !1,
            enumerable: !0,
            get: i
        })
    },
    n.r = function(e) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        })
    },
    n.n = function(e) {
        var t = e && e.__esModule ?
        function() {
            return e.
        default
        }:
        function() {
            return e
        };
        return n.d(t, "a", t),
        t
    },
    n.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    },
    n.p = "",
    n(n.s = 7)
} ([function(e, t, n) {
    "use strict";
    var i, r, o;
    "function" == typeof Symbol && Symbol.iterator;
    r = [],
    void 0 === (o = "function" == typeof(i = function() {
        window.URL = window.URL || window.webkitURL,
        navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia;
        var e = function(e, t) { (t = t || {}).sampleBits = t.sampleBits || 16,
            t.sampleRate = t.sampleRate || 8e3,
            t.localRec = t.localRec || !1,
            t.onRecData = t.onRecData || null;
            var n = new(window.webkitAudioContext || window.AudioContext),
            i = n.createMediaStreamSource(e),
            r = n.createScriptProcessor || n.createJavaScriptNode,
            o = r.apply(n, [4096, 1, 1]),
            s = {
                size: 0,
                buffer: [],
                inputSampleRate: n.sampleRate,
                inputSampleBits: 16,
                outputSampleRate: t.sampleRate,
                outputSampleBits: t.sampleBits,
                input: function(e) {
                    this.buffer.push(new Float32Array(e)),
                    this.size += e.length
                },
                compress: function(e) {
                    for (var t = parseInt(this.inputSampleRate / this.outputSampleRate), n = parseInt(e.length / t), i = new Float32Array(n), r = 0, o = 0; r < n;) i[r] = e[o],
                    o += t,
                    r++;
                    return i
                },
                encodeWAV: function() {
                    for (var e = Math.min(this.inputSampleRate, this.outputSampleRate), t = Math.min(this.inputSampleBits, this.oututSampleBits), n = new Float32Array(this.size), i = 0, r = 0; r < this.buffer.length; r++) n.set(this.buffer[r], i),
                    i += this.buffer[r].length;
                    var o = this.compress(n),
                    s = o.length * (t / 8),
                    a = new ArrayBuffer(44 + s),
                    n = new DataView(a),
                    i = 0,
                    u = function(e) {
                        for (var t = 0; t < e.length; t++) n.setUint8(i + t, e.charCodeAt(t))
                    };
                    if (u("RIFF"), i += 4, n.setUint32(i, 36 + s, !0), i += 4, u("WAVE"), i += 4, u("fmt "), i += 4, n.setUint32(i, 16, !0), i += 4, n.setUint16(i, 1, !0), i += 2, n.setUint16(i, 1, !0), i += 2, n.setUint32(i, e, !0), i += 4, n.setUint32(i, 1 * e * (t / 8), !0), i += 4, n.setUint16(i, t / 8 * 1, !0), i += 2, n.setUint16(i, t, !0), i += 2, u("data"), i += 4, n.setUint32(i, s, !0), i += 4, 8 === t) for (var r = 0; r < o.length; r++, i++) {
                        var l = Math.max( - 1, Math.min(1, o[r])),
                        c = l < 0 ? 32768 * l: 32767 * l;
                        c = parseInt(255 / (65535 / (c + 32768))),
                        n.setInt8(i, c, !0)
                    } else for (var r = 0; r < o.length; r++, i += 2) {
                        var l = Math.max( - 1, Math.min(1, o[r]));
                        n.setInt16(i, l < 0 ? 32768 * l: 32767 * l, !0)
                    }
                    return new Blob([n], {
                        type: "audio/wav"
                    })
                }
            };
            this.start = function() {
                i.connect(o),
                o.connect(n.destination)
            },
            this.stop = function() {
                o.disconnect(),
                i.disconnect()
            },
            this.getBlob = function() {
                return this.stop(),
                s.encodeWAV()
            },
            this.play = function(e) {
                e.src = window.URL.createObjectURL(this.getBlob())
            },
            o.onaudioprocess = function(e) {
                if (t.localRec && s.input(e.inputBuffer.getChannelData(0)), "function" == typeof t.onRecData) {
                    for (var n = s.compress(new Float32Array(e.inputBuffer.getChannelData(0))), i = n.length * (t.sampleBits / 8), r = new ArrayBuffer(i), o = new DataView(r), a = 0, u = 0; u < n.length; u++, a += 2) {
                        var l = Math.max( - 1, Math.min(1, n[u]));
                        o.setInt16(a, l < 0 ? 32768 * l: 32767 * l, !0)
                    }
                    t.onRecData(o.buffer)
                }
            }
        };
        return e.throwError = function(e) {
            throw alert(e),
            new
            function() {
                this.toString = function() {
                    return e
                }
            }
        },
        e.canRecording = null != navigator.getUserMedia,
        e.get = function(t, n) {
            if (t) {
                if (!navigator.getUserMedia) return void e.throwErr('当前<a href="http://www.it165.net/edu/ewl/" target="_blank" class="keylink">浏览器</a>不支持录音功能。');
                navigator.getUserMedia({
                    audio: !0
                },
                function(i) {
                    var r = new e(i, n);
                    t(r)
                },
                function(t) {
                    switch (t.code || t.name) {
                    case "PERMISSION_DENIED":
                    case "PermissionDeniedError":
                        e.throwError("用户拒绝提供信息。");
                        break;
                    case "NOT_SUPPORTED_ERROR":
                    case "NotSupportedError":
                        e.throwError('<a href="http://www.it165.net/edu/ewl/" target="_blank" class="keylink">浏览器</a>不支持硬件设备。');
                        break;
                    case "MANDATORY_UNSATISFIED_ERROR":
                    case "MandatoryUnsatisfiedError":
                        e.throwError("无法发现指定的硬件设备。");
                        break;
                    default:
                        e.throwError("无法打开麦克风。异常信息:" + (t.code || t.name))
                    }
                })
            }
        },
        e
    }) ? i.apply(t, r) : i) || (e.exports = o)
},
function(e, t) { (function(t) {
        e.exports = t
    }).call(this, {})
},
function(e, t) {
    e.exports = function() {
        throw new Error("define cannot be used indirect")
    }
},
function(e, t, n) {
    "use strict";
    var i, r = r ||
    function(e) {
        if (! (void 0 === e || "undefined" != typeof navigator && /MSIE [1-9]\./.test(navigator.userAgent))) {
            var t = function() {
                return e.URL || e.webkitURL || e
            },
            n = e.document.createElementNS("http://www.w3.org/1999/xhtml", "a"),
            i = "download" in n,
            r = /constructor/i.test(e.HTMLElement) || e.safari,
            o = /CriOS\/[\d]+/.test(navigator.userAgent),
            s = function(t) { (e.setImmediate || e.setTimeout)(function() {
                    throw t
                },
                0)
            },
            a = function(e) {
                setTimeout(function() {
                    "string" == typeof e ? t().revokeObjectURL(e) : e.remove()
                },
                4e4)
            },
            u = function(e) {
                return /^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i.test(e.type) ? new Blob([String.fromCharCode(65279), e], {
                    type: e.type
                }) : e
            },
            l = function(l, c, d) {
                d || (l = u(l));
                var f, h = this,
                p = "application/octet-stream" === l.type,
                m = function() { !
                    function(e, t, n) {
                        for (var i = (t = [].concat(t)).length; i--;) {
                            var r = e["on" + t[i]];
                            if ("function" == typeof r) try {
                                r.call(e, n || e)
                            } catch(e) {
                                s(e)
                            }
                        }
                    } (h, "writestart progress write writeend".split(" "))
                };
                if (h.readyState = h.INIT, i) return f = t().createObjectURL(l),
                void setTimeout(function() {
                    var e, t;
                    n.href = f,
                    n.download = c,
                    e = n,
                    t = new MouseEvent("click"),
                    e.dispatchEvent(t),
                    m(),
                    a(f),
                    h.readyState = h.DONE
                }); !
                function() {
                    if ((o || p && r) && e.FileReader) {
                        var n = new FileReader;
                        return n.onloadend = function() {
                            var t = o ? n.result: n.result.replace(/^data:[^;]*;/, "data:attachment/file;");
                            e.open(t, "_blank") || (e.location.href = t),
                            t = void 0,
                            h.readyState = h.DONE,
                            m()
                        },
                        n.readAsDataURL(l),
                        void(h.readyState = h.INIT)
                    }
                    f || (f = t().createObjectURL(l)),
                    p ? e.location.href = f: e.open(f, "_blank") || (e.location.href = f);
                    h.readyState = h.DONE,
                    m(),
                    a(f)
                } ()
            },
            c = l.prototype;
            return "undefined" != typeof navigator && navigator.msSaveOrOpenBlob ?
            function(e, t, n) {
                return t = t || e.name || "download",
                n || (e = u(e)),
                navigator.msSaveOrOpenBlob(e, t)
            }: (c.abort = function() {},
            c.readyState = c.INIT = 0, c.WRITING = 1, c.DONE = 2, c.error = c.onwritestart = c.onprogress = c.onwrite = c.onabort = c.onerror = c.onwriteend = null,
            function(e, t, n) {
                return new l(e, t || e.name || "download", n)
            })
        }
    } ("undefined" != typeof self && self || "undefined" != typeof window && window || (void 0).content);
    /*! @source http://purl.eligrey.com/github/FileSaver.js/blob/master/FileSaver.js */
    void 0 !== e && e.exports ? e.exports.saveAs = r: null !== n(2) && null !== n(1) && (void 0 === (i = function() {
        return r
    }.call(t, n, t, e)) || (e.exports = i))
},
function(e, t, n) {
    var i;
    /*!
         * jQuery JavaScript Library v3.3.1
         * https://jquery.com/
         *
         * Includes Sizzle.js
         * https://sizzlejs.com/
         *
         * Copyright JS Foundation and other contributors
         * Released under the MIT license
         * https://jquery.org/license
         *
         * Date: 2018-01-20T17:24Z
         */
    /*!
         * jQuery JavaScript Library v3.3.1
         * https://jquery.com/
         *
         * Includes Sizzle.js
         * https://sizzlejs.com/
         *
         * Copyright JS Foundation and other contributors
         * Released under the MIT license
         * https://jquery.org/license
         *
         * Date: 2018-01-20T17:24Z
         */
    !
    function(t, n) {
        "use strict";
        "object" == typeof e && "object" == typeof e.exports ? e.exports = t.document ? n(t, !0) : function(e) {
            if (!e.document) throw new Error("jQuery requires a window with a document");
            return n(e)
        }: n(t)
    } ("undefined" != typeof window ? window: this,
    function(n, r) {
        "use strict";
        var o = [],
        s = n.document,
        a = Object.getPrototypeOf,
        u = o.slice,
        l = o.concat,
        c = o.push,
        d = o.indexOf,
        f = {},
        h = f.toString,
        p = f.hasOwnProperty,
        m = p.toString,
        _ = m.call(Object),
        v = {},
        g = function(e) {
            return "function" == typeof e && "number" != typeof e.nodeType
        },
        y = function(e) {
            return null != e && e === e.window
        },
        b = {
            type: !0,
            src: !0,
            noModule: !0
        };

        function w(e, t, n) {
            var i, r = (t = t || s).createElement("script");
            if (r.text = e, n) for (i in b) n[i] && (r[i] = n[i]);
            t.head.appendChild(r).parentNode.removeChild(r)
        }
        function E(e) {
            return null == e ? e + "": "object" == typeof e || "function" == typeof e ? f[h.call(e)] || "object": typeof e
        }
        var S = function(e, t) {
            return new S.fn.init(e, t)
        },
        k = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;

        function x(e) {
            var t = !!e && "length" in e && e.length,
            n = E(e);
            return ! g(e) && !y(e) && ("array" === n || 0 === t || "number" == typeof t && t > 0 && t - 1 in e)
        }
        S.fn = S.prototype = {
            jquery: "3.3.1",
            constructor: S,
            length: 0,
            toArray: function() {
                return u.call(this)
            },
            get: function(e) {
                return null == e ? u.call(this) : e < 0 ? this[e + this.length] : this[e]
            },
            pushStack: function(e) {
                var t = S.merge(this.constructor(), e);
                return t.prevObject = this,
                t
            },
            each: function(e) {
                return S.each(this, e)
            },
            map: function(e) {
                return this.pushStack(S.map(this,
                function(t, n) {
                    return e.call(t, n, t)
                }))
            },
            slice: function() {
                return this.pushStack(u.apply(this, arguments))
            },
            first: function() {
                return this.eq(0)
            },
            last: function() {
                return this.eq( - 1)
            },
            eq: function(e) {
                var t = this.length,
                n = +e + (e < 0 ? t: 0);
                return this.pushStack(n >= 0 && n < t ? [this[n]] : [])
            },
            end: function() {
                return this.prevObject || this.constructor()
            },
            push: c,
            sort: o.sort,
            splice: o.splice
        },
        S.extend = S.fn.extend = function() {
            var e, t, n, i, r, o, s = arguments[0] || {},
            a = 1,
            u = arguments.length,
            l = !1;
            for ("boolean" == typeof s && (l = s, s = arguments[a] || {},
            a++), "object" == typeof s || g(s) || (s = {}), a === u && (s = this, a--); a < u; a++) if (null != (e = arguments[a])) for (t in e) n = s[t],
            s !== (i = e[t]) && (l && i && (S.isPlainObject(i) || (r = Array.isArray(i))) ? (r ? (r = !1, o = n && Array.isArray(n) ? n: []) : o = n && S.isPlainObject(n) ? n: {},
            s[t] = S.extend(l, o, i)) : void 0 !== i && (s[t] = i));
            return s
        },
        S.extend({
            expando: "jQuery" + ("3.3.1" + Math.random()).replace(/\D/g, ""),
            isReady: !0,
            error: function(e) {
                throw new Error(e)
            },
            noop: function() {},
            isPlainObject: function(e) {
                var t, n;
                return ! (!e || "[object Object]" !== h.call(e)) && (!(t = a(e)) || "function" == typeof(n = p.call(t, "constructor") && t.constructor) && m.call(n) === _)
            },
            isEmptyObject: function(e) {
                var t;
                for (t in e) return ! 1;
                return ! 0
            },
            globalEval: function(e) {
                w(e)
            },
            each: function(e, t) {
                var n, i = 0;
                if (x(e)) for (n = e.length; i < n && !1 !== t.call(e[i], i, e[i]); i++);
                else for (i in e) if (!1 === t.call(e[i], i, e[i])) break;
                return e
            },
            trim: function(e) {
                return null == e ? "": (e + "").replace(k, "")
            },
            makeArray: function(e, t) {
                var n = t || [];
                return null != e && (x(Object(e)) ? S.merge(n, "string" == typeof e ? [e] : e) : c.call(n, e)),
                n
            },
            inArray: function(e, t, n) {
                return null == t ? -1 : d.call(t, e, n)
            },
            merge: function(e, t) {
                for (var n = +t.length,
                i = 0,
                r = e.length; i < n; i++) e[r++] = t[i];
                return e.length = r,
                e
            },
            grep: function(e, t, n) {
                for (var i = [], r = 0, o = e.length, s = !n; r < o; r++) ! t(e[r], r) !== s && i.push(e[r]);
                return i
            },
            map: function(e, t, n) {
                var i, r, o = 0,
                s = [];
                if (x(e)) for (i = e.length; o < i; o++) null != (r = t(e[o], o, n)) && s.push(r);
                else for (o in e) null != (r = t(e[o], o, n)) && s.push(r);
                return l.apply([], s)
            },
            guid: 1,
            support: v
        }),
        "function" == typeof Symbol && (S.fn[Symbol.iterator] = o[Symbol.iterator]),
        S.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "),
        function(e, t) {
            f["[object " + t + "]"] = t.toLowerCase()
        });
        var L =
        /*!
                     * Sizzle CSS Selector Engine v2.3.3
                     * https://sizzlejs.com/
                     *
                     * Copyright jQuery Foundation and other contributors
                     * Released under the MIT license
                     * http://jquery.org/license
                     *
                     * Date: 2016-08-08
                     */

        function(e) {
            var t, n, i, r, o, s, a, u, l, c, d, f, h, p, m, _, v, g, y, b = "sizzle" + 1 * new Date,
            w = e.document,
            E = 0,
            S = 0,
            k = se(),
            x = se(),
            L = se(),
            T = function(e, t) {
                return e === t && (d = !0),
                0
            },
            A = {}.hasOwnProperty,
            R = [],
            C = R.pop,
            O = R.push,
            D = R.push,
            I = R.slice,
            M = function(e, t) {
                for (var n = 0,
                i = e.length; n < i; n++) if (e[n] === t) return n;
                return - 1
            },
            j = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
            B = "[\\x20\\t\\r\\n\\f]",
            N = "(?:\\\\.|[\\w-]|[^\0-\\xa0])+",
            P = "\\[" + B + "*(" + N + ")(?:" + B + "*([*^$|!~]?=)" + B + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + N + "))|)" + B + "*\\]",
            U = ":(" + N + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + P + ")*)|.*)\\)|)",
            F = new RegExp(B + "+", "g"),
            W = new RegExp("^" + B + "+|((?:^|[^\\\\])(?:\\\\.)*)" + B + "+$", "g"),
            G = new RegExp("^" + B + "*," + B + "*"),
            H = new RegExp("^" + B + "*([>+~]|" + B + ")" + B + "*"),
            q = new RegExp("=" + B + "*([^\\]'\"]*?)" + B + "*\\]", "g"),
            z = new RegExp(U),
            V = new RegExp("^" + N + "$"),
            K = {
                ID: new RegExp("^#(" + N + ")"),
                CLASS: new RegExp("^\\.(" + N + ")"),
                TAG: new RegExp("^(" + N + "|[*])"),
                ATTR: new RegExp("^" + P),
                PSEUDO: new RegExp("^" + U),
                CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + B + "*(even|odd|(([+-]|)(\\d*)n|)" + B + "*(?:([+-]|)" + B + "*(\\d+)|))" + B + "*\\)|)", "i"),
                bool: new RegExp("^(?:" + j + ")$", "i"),
                needsContext: new RegExp("^" + B + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + B + "*((?:-\\d)?\\d*)" + B + "*\\)|)(?=[^-]|$)", "i")
            },
            X = /^(?:input|select|textarea|button)$/i,
            $ = /^h\d$/i,
            Y = /^[^{]+\{\s*\[native \w/,
            Q = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
            J = /[+~]/,
            Z = new RegExp("\\\\([\\da-f]{1,6}" + B + "?|(" + B + ")|.)", "ig"),
            ee = function(e, t, n) {
                var i = "0x" + t - 65536;
                return i != i || n ? t: i < 0 ? String.fromCharCode(i + 65536) : String.fromCharCode(i >> 10 | 55296, 1023 & i | 56320)
            },
            te = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\0-\x1f\x7f-\uFFFF\w-]/g,
            ne = function(e, t) {
                return t ? "\0" === e ? "�": e.slice(0, -1) + "\\" + e.charCodeAt(e.length - 1).toString(16) + " ": "\\" + e
            },
            ie = function() {
                f()
            },
            re = ge(function(e) {
                return ! 0 === e.disabled && ("form" in e || "label" in e)
            },
            {
                dir: "parentNode",
                next: "legend"
            });
            try {
                D.apply(R = I.call(w.childNodes), w.childNodes),
                R[w.childNodes.length].nodeType
            } catch(e) {
                D = {
                    apply: R.length ?
                    function(e, t) {
                        O.apply(e, I.call(t))
                    }: function(e, t) {
                        for (var n = e.length,
                        i = 0; e[n++] = t[i++];);
                        e.length = n - 1
                    }
                }
            }
            function oe(e, t, i, r) {
                var o, a, l, c, d, p, v, g = t && t.ownerDocument,
                E = t ? t.nodeType: 9;
                if (i = i || [], "string" != typeof e || !e || 1 !== E && 9 !== E && 11 !== E) return i;
                if (!r && ((t ? t.ownerDocument || t: w) !== h && f(t), t = t || h, m)) {
                    if (11 !== E && (d = Q.exec(e))) if (o = d[1]) {
                        if (9 === E) {
                            if (! (l = t.getElementById(o))) return i;
                            if (l.id === o) return i.push(l),
                            i
                        } else if (g && (l = g.getElementById(o)) && y(t, l) && l.id === o) return i.push(l),
                        i
                    } else {
                        if (d[2]) return D.apply(i, t.getElementsByTagName(e)),
                        i;
                        if ((o = d[3]) && n.getElementsByClassName && t.getElementsByClassName) return D.apply(i, t.getElementsByClassName(o)),
                        i
                    }
                    if (n.qsa && !L[e + " "] && (!_ || !_.test(e))) {
                        if (1 !== E) g = t,
                        v = e;
                        else if ("object" !== t.nodeName.toLowerCase()) {
                            for ((c = t.getAttribute("id")) ? c = c.replace(te, ne) : t.setAttribute("id", c = b), a = (p = s(e)).length; a--;) p[a] = "#" + c + " " + ve(p[a]);
                            v = p.join(","),
                            g = J.test(e) && me(t.parentNode) || t
                        }
                        if (v) try {
                            return D.apply(i, g.querySelectorAll(v)),
                            i
                        } catch(e) {} finally {
                            c === b && t.removeAttribute("id")
                        }
                    }
                }
                return u(e.replace(W, "$1"), t, i, r)
            }
            function se() {
                var e = [];
                return function t(n, r) {
                    return e.push(n + " ") > i.cacheLength && delete t[e.shift()],
                    t[n + " "] = r
                }
            }
            function ae(e) {
                return e[b] = !0,
                e
            }
            function ue(e) {
                var t = h.createElement("fieldset");
                try {
                    return !! e(t)
                } catch(e) {
                    return ! 1
                } finally {
                    t.parentNode && t.parentNode.removeChild(t),
                    t = null
                }
            }
            function le(e, t) {
                for (var n = e.split("|"), r = n.length; r--;) i.attrHandle[n[r]] = t
            }
            function ce(e, t) {
                var n = t && e,
                i = n && 1 === e.nodeType && 1 === t.nodeType && e.sourceIndex - t.sourceIndex;
                if (i) return i;
                if (n) for (; n = n.nextSibling;) if (n === t) return - 1;
                return e ? 1 : -1
            }
            function de(e) {
                return function(t) {
                    return "input" === t.nodeName.toLowerCase() && t.type === e
                }
            }
            function fe(e) {
                return function(t) {
                    var n = t.nodeName.toLowerCase();
                    return ("input" === n || "button" === n) && t.type === e
                }
            }
            function he(e) {
                return function(t) {
                    return "form" in t ? t.parentNode && !1 === t.disabled ? "label" in t ? "label" in t.parentNode ? t.parentNode.disabled === e: t.disabled === e: t.isDisabled === e || t.isDisabled !== !e && re(t) === e: t.disabled === e: "label" in t && t.disabled === e
                }
            }
            function pe(e) {
                return ae(function(t) {
                    return t = +t,
                    ae(function(n, i) {
                        for (var r, o = e([], n.length, t), s = o.length; s--;) n[r = o[s]] && (n[r] = !(i[r] = n[r]))
                    })
                })
            }
            function me(e) {
                return e && void 0 !== e.getElementsByTagName && e
            }
            for (t in n = oe.support = {},
            o = oe.isXML = function(e) {
                var t = e && (e.ownerDocument || e).documentElement;
                return !! t && "HTML" !== t.nodeName
            },
            f = oe.setDocument = function(e) {
                var t, r, s = e ? e.ownerDocument || e: w;
                return s !== h && 9 === s.nodeType && s.documentElement ? (p = (h = s).documentElement, m = !o(h), w !== h && (r = h.defaultView) && r.top !== r && (r.addEventListener ? r.addEventListener("unload", ie, !1) : r.attachEvent && r.attachEvent("onunload", ie)), n.attributes = ue(function(e) {
                    return e.className = "i",
                    !e.getAttribute("className")
                }), n.getElementsByTagName = ue(function(e) {
                    return e.appendChild(h.createComment("")),
                    !e.getElementsByTagName("*").length
                }), n.getElementsByClassName = Y.test(h.getElementsByClassName), n.getById = ue(function(e) {
                    return p.appendChild(e).id = b,
                    !h.getElementsByName || !h.getElementsByName(b).length
                }), n.getById ? (i.filter.ID = function(e) {
                    var t = e.replace(Z, ee);
                    return function(e) {
                        return e.getAttribute("id") === t
                    }
                },
                i.find.ID = function(e, t) {
                    if (void 0 !== t.getElementById && m) {
                        var n = t.getElementById(e);
                        return n ? [n] : []
                    }
                }) : (i.filter.ID = function(e) {
                    var t = e.replace(Z, ee);
                    return function(e) {
                        var n = void 0 !== e.getAttributeNode && e.getAttributeNode("id");
                        return n && n.value === t
                    }
                },
                i.find.ID = function(e, t) {
                    if (void 0 !== t.getElementById && m) {
                        var n, i, r, o = t.getElementById(e);
                        if (o) {
                            if ((n = o.getAttributeNode("id")) && n.value === e) return [o];
                            for (r = t.getElementsByName(e), i = 0; o = r[i++];) if ((n = o.getAttributeNode("id")) && n.value === e) return [o]
                        }
                        return []
                    }
                }), i.find.TAG = n.getElementsByTagName ?
                function(e, t) {
                    return void 0 !== t.getElementsByTagName ? t.getElementsByTagName(e) : n.qsa ? t.querySelectorAll(e) : void 0
                }: function(e, t) {
                    var n, i = [],
                    r = 0,
                    o = t.getElementsByTagName(e);
                    if ("*" === e) {
                        for (; n = o[r++];) 1 === n.nodeType && i.push(n);
                        return i
                    }
                    return o
                },
                i.find.CLASS = n.getElementsByClassName &&
                function(e, t) {
                    if (void 0 !== t.getElementsByClassName && m) return t.getElementsByClassName(e)
                },
                v = [], _ = [], (n.qsa = Y.test(h.querySelectorAll)) && (ue(function(e) {
                    p.appendChild(e).innerHTML = "<a id='" + b + "'></a><select id='" + b + "-\r\\' msallowcapture=''><option selected=''></option></select>",
                    e.querySelectorAll("[msallowcapture^='']").length && _.push("[*^$]=" + B + "*(?:''|\"\")"),
                    e.querySelectorAll("[selected]").length || _.push("\\[" + B + "*(?:value|" + j + ")"),
                    e.querySelectorAll("[id~=" + b + "-]").length || _.push("~="),
                    e.querySelectorAll(":checked").length || _.push(":checked"),
                    e.querySelectorAll("a#" + b + "+*").length || _.push(".#.+[+~]")
                }), ue(function(e) {
                    e.innerHTML = "<a href='' disabled='disabled'></a><select disabled='disabled'><option/></select>";
                    var t = h.createElement("input");
                    t.setAttribute("type", "hidden"),
                    e.appendChild(t).setAttribute("name", "D"),
                    e.querySelectorAll("[name=d]").length && _.push("name" + B + "*[*^$|!~]?="),
                    2 !== e.querySelectorAll(":enabled").length && _.push(":enabled", ":disabled"),
                    p.appendChild(e).disabled = !0,
                    2 !== e.querySelectorAll(":disabled").length && _.push(":enabled", ":disabled"),
                    e.querySelectorAll("*,:x"),
                    _.push(",.*:")
                })), (n.matchesSelector = Y.test(g = p.matches || p.webkitMatchesSelector || p.mozMatchesSelector || p.oMatchesSelector || p.msMatchesSelector)) && ue(function(e) {
                    n.disconnectedMatch = g.call(e, "*"),
                    g.call(e, "[s!='']:x"),
                    v.push("!=", U)
                }), _ = _.length && new RegExp(_.join("|")), v = v.length && new RegExp(v.join("|")), t = Y.test(p.compareDocumentPosition), y = t || Y.test(p.contains) ?
                function(e, t) {
                    var n = 9 === e.nodeType ? e.documentElement: e,
                    i = t && t.parentNode;
                    return e === i || !(!i || 1 !== i.nodeType || !(n.contains ? n.contains(i) : e.compareDocumentPosition && 16 & e.compareDocumentPosition(i)))
                }: function(e, t) {
                    if (t) for (; t = t.parentNode;) if (t === e) return ! 0;
                    return ! 1
                },
                T = t ?
                function(e, t) {
                    if (e === t) return d = !0,
                    0;
                    var i = !e.compareDocumentPosition - !t.compareDocumentPosition;
                    return i || (1 & (i = (e.ownerDocument || e) === (t.ownerDocument || t) ? e.compareDocumentPosition(t) : 1) || !n.sortDetached && t.compareDocumentPosition(e) === i ? e === h || e.ownerDocument === w && y(w, e) ? -1 : t === h || t.ownerDocument === w && y(w, t) ? 1 : c ? M(c, e) - M(c, t) : 0 : 4 & i ? -1 : 1)
                }: function(e, t) {
                    if (e === t) return d = !0,
                    0;
                    var n, i = 0,
                    r = e.parentNode,
                    o = t.parentNode,
                    s = [e],
                    a = [t];
                    if (!r || !o) return e === h ? -1 : t === h ? 1 : r ? -1 : o ? 1 : c ? M(c, e) - M(c, t) : 0;
                    if (r === o) return ce(e, t);
                    for (n = e; n = n.parentNode;) s.unshift(n);
                    for (n = t; n = n.parentNode;) a.unshift(n);
                    for (; s[i] === a[i];) i++;
                    return i ? ce(s[i], a[i]) : s[i] === w ? -1 : a[i] === w ? 1 : 0
                },
                h) : h
            },
            oe.matches = function(e, t) {
                return oe(e, null, null, t)
            },
            oe.matchesSelector = function(e, t) {
                if ((e.ownerDocument || e) !== h && f(e), t = t.replace(q, "='$1']"), n.matchesSelector && m && !L[t + " "] && (!v || !v.test(t)) && (!_ || !_.test(t))) try {
                    var i = g.call(e, t);
                    if (i || n.disconnectedMatch || e.document && 11 !== e.document.nodeType) return i
                } catch(e) {}
                return oe(t, h, null, [e]).length > 0
            },
            oe.contains = function(e, t) {
                return (e.ownerDocument || e) !== h && f(e),
                y(e, t)
            },
            oe.attr = function(e, t) { (e.ownerDocument || e) !== h && f(e);
                var r = i.attrHandle[t.toLowerCase()],
                o = r && A.call(i.attrHandle, t.toLowerCase()) ? r(e, t, !m) : void 0;
                return void 0 !== o ? o: n.attributes || !m ? e.getAttribute(t) : (o = e.getAttributeNode(t)) && o.specified ? o.value: null
            },
            oe.escape = function(e) {
                return (e + "").replace(te, ne)
            },
            oe.error = function(e) {
                throw new Error("Syntax error, unrecognized expression: " + e)
            },
            oe.uniqueSort = function(e) {
                var t, i = [],
                r = 0,
                o = 0;
                if (d = !n.detectDuplicates, c = !n.sortStable && e.slice(0), e.sort(T), d) {
                    for (; t = e[o++];) t === e[o] && (r = i.push(o));
                    for (; r--;) e.splice(i[r], 1)
                }
                return c = null,
                e
            },
            r = oe.getText = function(e) {
                var t, n = "",
                i = 0,
                o = e.nodeType;
                if (o) {
                    if (1 === o || 9 === o || 11 === o) {
                        if ("string" == typeof e.textContent) return e.textContent;
                        for (e = e.firstChild; e; e = e.nextSibling) n += r(e)
                    } else if (3 === o || 4 === o) return e.nodeValue
                } else for (; t = e[i++];) n += r(t);
                return n
            },
            (i = oe.selectors = {
                cacheLength: 50,
                createPseudo: ae,
                match: K,
                attrHandle: {},
                find: {},
                relative: {
                    ">": {
                        dir: "parentNode",
                        first: !0
                    },
                    " ": {
                        dir: "parentNode"
                    },
                    "+": {
                        dir: "previousSibling",
                        first: !0
                    },
                    "~": {
                        dir: "previousSibling"
                    }
                },
                preFilter: {
                    ATTR: function(e) {
                        return e[1] = e[1].replace(Z, ee),
                        e[3] = (e[3] || e[4] || e[5] || "").replace(Z, ee),
                        "~=" === e[2] && (e[3] = " " + e[3] + " "),
                        e.slice(0, 4)
                    },
                    CHILD: function(e) {
                        return e[1] = e[1].toLowerCase(),
                        "nth" === e[1].slice(0, 3) ? (e[3] || oe.error(e[0]), e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * ("even" === e[3] || "odd" === e[3])), e[5] = +(e[7] + e[8] || "odd" === e[3])) : e[3] && oe.error(e[0]),
                        e
                    },
                    PSEUDO: function(e) {
                        var t, n = !e[6] && e[2];
                        return K.CHILD.test(e[0]) ? null: (e[3] ? e[2] = e[4] || e[5] || "": n && z.test(n) && (t = s(n, !0)) && (t = n.indexOf(")", n.length - t) - n.length) && (e[0] = e[0].slice(0, t), e[2] = n.slice(0, t)), e.slice(0, 3))
                    }
                },
                filter: {
                    TAG: function(e) {
                        var t = e.replace(Z, ee).toLowerCase();
                        return "*" === e ?
                        function() {
                            return ! 0
                        }: function(e) {
                            return e.nodeName && e.nodeName.toLowerCase() === t
                        }
                    },
                    CLASS: function(e) {
                        var t = k[e + " "];
                        return t || (t = new RegExp("(^|" + B + ")" + e + "(" + B + "|$)")) && k(e,
                        function(e) {
                            return t.test("string" == typeof e.className && e.className || void 0 !== e.getAttribute && e.getAttribute("class") || "")
                        })
                    },
                    ATTR: function(e, t, n) {
                        return function(i) {
                            var r = oe.attr(i, e);
                            return null == r ? "!=" === t: !t || (r += "", "=" === t ? r === n: "!=" === t ? r !== n: "^=" === t ? n && 0 === r.indexOf(n) : "*=" === t ? n && r.indexOf(n) > -1 : "$=" === t ? n && r.slice( - n.length) === n: "~=" === t ? (" " + r.replace(F, " ") + " ").indexOf(n) > -1 : "|=" === t && (r === n || r.slice(0, n.length + 1) === n + "-"))
                        }
                    },
                    CHILD: function(e, t, n, i, r) {
                        var o = "nth" !== e.slice(0, 3),
                        s = "last" !== e.slice( - 4),
                        a = "of-type" === t;
                        return 1 === i && 0 === r ?
                        function(e) {
                            return !! e.parentNode
                        }: function(t, n, u) {
                            var l, c, d, f, h, p, m = o !== s ? "nextSibling": "previousSibling",
                            _ = t.parentNode,
                            v = a && t.nodeName.toLowerCase(),
                            g = !u && !a,
                            y = !1;
                            if (_) {
                                if (o) {
                                    for (; m;) {
                                        for (f = t; f = f[m];) if (a ? f.nodeName.toLowerCase() === v: 1 === f.nodeType) return ! 1;
                                        p = m = "only" === e && !p && "nextSibling"
                                    }
                                    return ! 0
                                }
                                if (p = [s ? _.firstChild: _.lastChild], s && g) {
                                    for (y = (h = (l = (c = (d = (f = _)[b] || (f[b] = {}))[f.uniqueID] || (d[f.uniqueID] = {}))[e] || [])[0] === E && l[1]) && l[2], f = h && _.childNodes[h]; f = ++h && f && f[m] || (y = h = 0) || p.pop();) if (1 === f.nodeType && ++y && f === t) {
                                        c[e] = [E, h, y];
                                        break
                                    }
                                } else if (g && (y = h = (l = (c = (d = (f = t)[b] || (f[b] = {}))[f.uniqueID] || (d[f.uniqueID] = {}))[e] || [])[0] === E && l[1]), !1 === y) for (; (f = ++h && f && f[m] || (y = h = 0) || p.pop()) && ((a ? f.nodeName.toLowerCase() !== v: 1 !== f.nodeType) || !++y || (g && ((c = (d = f[b] || (f[b] = {}))[f.uniqueID] || (d[f.uniqueID] = {}))[e] = [E, y]), f !== t)););
                                return (y -= r) === i || y % i == 0 && y / i >= 0
                            }
                        }
                    },
                    PSEUDO: function(e, t) {
                        var n, r = i.pseudos[e] || i.setFilters[e.toLowerCase()] || oe.error("unsupported pseudo: " + e);
                        return r[b] ? r(t) : r.length > 1 ? (n = [e, e, "", t], i.setFilters.hasOwnProperty(e.toLowerCase()) ? ae(function(e, n) {
                            for (var i, o = r(e, t), s = o.length; s--;) e[i = M(e, o[s])] = !(n[i] = o[s])
                        }) : function(e) {
                            return r(e, 0, n)
                        }) : r
                    }
                },
                pseudos: {
                    not: ae(function(e) {
                        var t = [],
                        n = [],
                        i = a(e.replace(W, "$1"));
                        return i[b] ? ae(function(e, t, n, r) {
                            for (var o, s = i(e, null, r, []), a = e.length; a--;)(o = s[a]) && (e[a] = !(t[a] = o))
                        }) : function(e, r, o) {
                            return t[0] = e,
                            i(t, null, o, n),
                            t[0] = null,
                            !n.pop()
                        }
                    }),
                    has: ae(function(e) {
                        return function(t) {
                            return oe(e, t).length > 0
                        }
                    }),
                    contains: ae(function(e) {
                        return e = e.replace(Z, ee),
                        function(t) {
                            return (t.textContent || t.innerText || r(t)).indexOf(e) > -1
                        }
                    }),
                    lang: ae(function(e) {
                        return V.test(e || "") || oe.error("unsupported lang: " + e),
                        e = e.replace(Z, ee).toLowerCase(),
                        function(t) {
                            var n;
                            do {
                                if (n = m ? t.lang: t.getAttribute("xml:lang") || t.getAttribute("lang")) return (n = n.toLowerCase()) === e || 0 === n.indexOf(e + "-")
                            } while (( t = t . parentNode ) && 1 === t.nodeType);
                            return ! 1
                        }
                    }),
                    target: function(t) {
                        var n = e.location && e.location.hash;
                        return n && n.slice(1) === t.id
                    },
                    root: function(e) {
                        return e === p
                    },
                    focus: function(e) {
                        return e === h.activeElement && (!h.hasFocus || h.hasFocus()) && !!(e.type || e.href || ~e.tabIndex)
                    },
                    enabled: he(!1),
                    disabled: he(!0),
                    checked: function(e) {
                        var t = e.nodeName.toLowerCase();
                        return "input" === t && !!e.checked || "option" === t && !!e.selected
                    },
                    selected: function(e) {
                        return e.parentNode && e.parentNode.selectedIndex,
                        !0 === e.selected
                    },
                    empty: function(e) {
                        for (e = e.firstChild; e; e = e.nextSibling) if (e.nodeType < 6) return ! 1;
                        return ! 0
                    },
                    parent: function(e) {
                        return ! i.pseudos.empty(e)
                    },
                    header: function(e) {
                        return $.test(e.nodeName)
                    },
                    input: function(e) {
                        return X.test(e.nodeName)
                    },
                    button: function(e) {
                        var t = e.nodeName.toLowerCase();
                        return "input" === t && "button" === e.type || "button" === t
                    },
                    text: function(e) {
                        var t;
                        return "input" === e.nodeName.toLowerCase() && "text" === e.type && (null == (t = e.getAttribute("type")) || "text" === t.toLowerCase())
                    },
                    first: pe(function() {
                        return [0]
                    }),
                    last: pe(function(e, t) {
                        return [t - 1]
                    }),
                    eq: pe(function(e, t, n) {
                        return [n < 0 ? n + t: n]
                    }),
                    even: pe(function(e, t) {
                        for (var n = 0; n < t; n += 2) e.push(n);
                        return e
                    }),
                    odd: pe(function(e, t) {
                        for (var n = 1; n < t; n += 2) e.push(n);
                        return e
                    }),
                    lt: pe(function(e, t, n) {
                        for (var i = n < 0 ? n + t: n; --i >= 0;) e.push(i);
                        return e
                    }),
                    gt: pe(function(e, t, n) {
                        for (var i = n < 0 ? n + t: n; ++i < t;) e.push(i);
                        return e
                    })
                }
            }).pseudos.nth = i.pseudos.eq, {
                radio: !0,
                checkbox: !0,
                file: !0,
                password: !0,
                image: !0
            }) i.pseudos[t] = de(t);
            for (t in {
                submit: !0,
                reset: !0
            }) i.pseudos[t] = fe(t);

            function _e() {}
            function ve(e) {
                for (var t = 0,
                n = e.length,
                i = ""; t < n; t++) i += e[t].value;
                return i
            }
            function ge(e, t, n) {
                var i = t.dir,
                r = t.next,
                o = r || i,
                s = n && "parentNode" === o,
                a = S++;
                return t.first ?
                function(t, n, r) {
                    for (; t = t[i];) if (1 === t.nodeType || s) return e(t, n, r);
                    return ! 1
                }: function(t, n, u) {
                    var l, c, d, f = [E, a];
                    if (u) {
                        for (; t = t[i];) if ((1 === t.nodeType || s) && e(t, n, u)) return ! 0
                    } else for (; t = t[i];) if (1 === t.nodeType || s) if (c = (d = t[b] || (t[b] = {}))[t.uniqueID] || (d[t.uniqueID] = {}), r && r === t.nodeName.toLowerCase()) t = t[i] || t;
                    else {
                        if ((l = c[o]) && l[0] === E && l[1] === a) return f[2] = l[2];
                        if (c[o] = f, f[2] = e(t, n, u)) return ! 0
                    }
                    return ! 1
                }
            }
            function ye(e) {
                return e.length > 1 ?
                function(t, n, i) {
                    for (var r = e.length; r--;) if (!e[r](t, n, i)) return ! 1;
                    return ! 0
                }: e[0]
            }
            function be(e, t, n, i, r) {
                for (var o, s = [], a = 0, u = e.length, l = null != t; a < u; a++)(o = e[a]) && (n && !n(o, i, r) || (s.push(o), l && t.push(a)));
                return s
            }
            function we(e, t, n, i, r, o) {
                return i && !i[b] && (i = we(i)),
                r && !r[b] && (r = we(r, o)),
                ae(function(o, s, a, u) {
                    var l, c, d, f = [],
                    h = [],
                    p = s.length,
                    m = o ||
                    function(e, t, n) {
                        for (var i = 0,
                        r = t.length; i < r; i++) oe(e, t[i], n);
                        return n
                    } (t || "*", a.nodeType ? [a] : a, []),
                    _ = !e || !o && t ? m: be(m, f, e, a, u),
                    v = n ? r || (o ? e: p || i) ? [] : s: _;
                    if (n && n(_, v, a, u), i) for (l = be(v, h), i(l, [], a, u), c = l.length; c--;)(d = l[c]) && (v[h[c]] = !(_[h[c]] = d));
                    if (o) {
                        if (r || e) {
                            if (r) {
                                for (l = [], c = v.length; c--;)(d = v[c]) && l.push(_[c] = d);
                                r(null, v = [], l, u)
                            }
                            for (c = v.length; c--;)(d = v[c]) && (l = r ? M(o, d) : f[c]) > -1 && (o[l] = !(s[l] = d))
                        }
                    } else v = be(v === s ? v.splice(p, v.length) : v),
                    r ? r(null, s, v, u) : D.apply(s, v)
                })
            }
            function Ee(e) {
                for (var t, n, r, o = e.length,
                s = i.relative[e[0].type], a = s || i.relative[" "], u = s ? 1 : 0, c = ge(function(e) {
                    return e === t
                },
                a, !0), d = ge(function(e) {
                    return M(t, e) > -1
                },
                a, !0), f = [function(e, n, i) {
                    var r = !s && (i || n !== l) || ((t = n).nodeType ? c(e, n, i) : d(e, n, i));
                    return t = null,
                    r
                }]; u < o; u++) if (n = i.relative[e[u].type]) f = [ge(ye(f), n)];
                else {
                    if ((n = i.filter[e[u].type].apply(null, e[u].matches))[b]) {
                        for (r = ++u; r < o && !i.relative[e[r].type]; r++);
                        return we(u > 1 && ye(f), u > 1 && ve(e.slice(0, u - 1).concat({
                            value: " " === e[u - 2].type ? "*": ""
                        })).replace(W, "$1"), n, u < r && Ee(e.slice(u, r)), r < o && Ee(e = e.slice(r)), r < o && ve(e))
                    }
                    f.push(n)
                }
                return ye(f)
            }
            return _e.prototype = i.filters = i.pseudos,
            i.setFilters = new _e,
            s = oe.tokenize = function(e, t) {
                var n, r, o, s, a, u, l, c = x[e + " "];
                if (c) return t ? 0 : c.slice(0);
                for (a = e, u = [], l = i.preFilter; a;) {
                    for (s in n && !(r = G.exec(a)) || (r && (a = a.slice(r[0].length) || a), u.push(o = [])), n = !1, (r = H.exec(a)) && (n = r.shift(), o.push({
                        value: n,
                        type: r[0].replace(W, " ")
                    }), a = a.slice(n.length)), i.filter) ! (r = K[s].exec(a)) || l[s] && !(r = l[s](r)) || (n = r.shift(), o.push({
                        value: n,
                        type: s,
                        matches: r
                    }), a = a.slice(n.length));
                    if (!n) break
                }
                return t ? a.length: a ? oe.error(e) : x(e, u).slice(0)
            },
            a = oe.compile = function(e, t) {
                var n, r = [],
                o = [],
                a = L[e + " "];
                if (!a) {
                    for (t || (t = s(e)), n = t.length; n--;)(a = Ee(t[n]))[b] ? r.push(a) : o.push(a); (a = L(e,
                    function(e, t) {
                        var n = t.length > 0,
                        r = e.length > 0,
                        o = function(o, s, a, u, c) {
                            var d, p, _, v = 0,
                            g = "0",
                            y = o && [],
                            b = [],
                            w = l,
                            S = o || r && i.find.TAG("*", c),
                            k = E += null == w ? 1 : Math.random() || .1,
                            x = S.length;
                            for (c && (l = s === h || s || c); g !== x && null != (d = S[g]); g++) {
                                if (r && d) {
                                    for (p = 0, s || d.ownerDocument === h || (f(d), a = !m); _ = e[p++];) if (_(d, s || h, a)) {
                                        u.push(d);
                                        break
                                    }
                                    c && (E = k)
                                }
                                n && ((d = !_ && d) && v--, o && y.push(d))
                            }
                            if (v += g, n && g !== v) {
                                for (p = 0; _ = t[p++];) _(y, b, s, a);
                                if (o) {
                                    if (v > 0) for (; g--;) y[g] || b[g] || (b[g] = C.call(u));
                                    b = be(b)
                                }
                                D.apply(u, b),
                                c && !o && b.length > 0 && v + t.length > 1 && oe.uniqueSort(u)
                            }
                            return c && (E = k, l = w),
                            y
                        };
                        return n ? ae(o) : o
                    } (o, r))).selector = e
                }
                return a
            },
            u = oe.select = function(e, t, n, r) {
                var o, u, l, c, d, f = "function" == typeof e && e,
                h = !r && s(e = f.selector || e);
                if (n = n || [], 1 === h.length) {
                    if ((u = h[0] = h[0].slice(0)).length > 2 && "ID" === (l = u[0]).type && 9 === t.nodeType && m && i.relative[u[1].type]) {
                        if (! (t = (i.find.ID(l.matches[0].replace(Z, ee), t) || [])[0])) return n;
                        f && (t = t.parentNode),
                        e = e.slice(u.shift().value.length)
                    }
                    for (o = K.needsContext.test(e) ? 0 : u.length; o--&&(l = u[o], !i.relative[c = l.type]);) if ((d = i.find[c]) && (r = d(l.matches[0].replace(Z, ee), J.test(u[0].type) && me(t.parentNode) || t))) {
                        if (u.splice(o, 1), !(e = r.length && ve(u))) return D.apply(n, r),
                        n;
                        break
                    }
                }
                return (f || a(e, h))(r, t, !m, n, !t || J.test(e) && me(t.parentNode) || t),
                n
            },
            n.sortStable = b.split("").sort(T).join("") === b,
            n.detectDuplicates = !!d,
            f(),
            n.sortDetached = ue(function(e) {
                return 1 & e.compareDocumentPosition(h.createElement("fieldset"))
            }),
            ue(function(e) {
                return e.innerHTML = "<a href='#'></a>",
                "#" === e.firstChild.getAttribute("href")
            }) || le("type|href|height|width",
            function(e, t, n) {
                if (!n) return e.getAttribute(t, "type" === t.toLowerCase() ? 1 : 2)
            }),
            n.attributes && ue(function(e) {
                return e.innerHTML = "<input/>",
                e.firstChild.setAttribute("value", ""),
                "" === e.firstChild.getAttribute("value")
            }) || le("value",
            function(e, t, n) {
                if (!n && "input" === e.nodeName.toLowerCase()) return e.defaultValue
            }),
            ue(function(e) {
                return null == e.getAttribute("disabled")
            }) || le(j,
            function(e, t, n) {
                var i;
                if (!n) return ! 0 === e[t] ? t.toLowerCase() : (i = e.getAttributeNode(t)) && i.specified ? i.value: null
            }),
            oe
        } (n);
        S.find = L,
        S.expr = L.selectors,
        S.expr[":"] = S.expr.pseudos,
        S.uniqueSort = S.unique = L.uniqueSort,
        S.text = L.getText,
        S.isXMLDoc = L.isXML,
        S.contains = L.contains,
        S.escapeSelector = L.escape;
        var T = function(e, t, n) {
            for (var i = [], r = void 0 !== n; (e = e[t]) && 9 !== e.nodeType;) if (1 === e.nodeType) {
                if (r && S(e).is(n)) break;
                i.push(e)
            }
            return i
        },
        A = function(e, t) {
            for (var n = []; e; e = e.nextSibling) 1 === e.nodeType && e !== t && n.push(e);
            return n
        },
        R = S.expr.match.needsContext;

        function C(e, t) {
            return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
        }
        var O = /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i;

        function D(e, t, n) {
            return g(t) ? S.grep(e,
            function(e, i) {
                return !! t.call(e, i, e) !== n
            }) : t.nodeType ? S.grep(e,
            function(e) {
                return e === t !== n
            }) : "string" != typeof t ? S.grep(e,
            function(e) {
                return d.call(t, e) > -1 !== n
            }) : S.filter(t, e, n)
        }
        S.filter = function(e, t, n) {
            var i = t[0];
            return n && (e = ":not(" + e + ")"),
            1 === t.length && 1 === i.nodeType ? S.find.matchesSelector(i, e) ? [i] : [] : S.find.matches(e, S.grep(t,
            function(e) {
                return 1 === e.nodeType
            }))
        },
        S.fn.extend({
            find: function(e) {
                var t, n, i = this.length,
                r = this;
                if ("string" != typeof e) return this.pushStack(S(e).filter(function() {
                    for (t = 0; t < i; t++) if (S.contains(r[t], this)) return ! 0
                }));
                for (n = this.pushStack([]), t = 0; t < i; t++) S.find(e, r[t], n);
                return i > 1 ? S.uniqueSort(n) : n
            },
            filter: function(e) {
                return this.pushStack(D(this, e || [], !1))
            },
            not: function(e) {
                return this.pushStack(D(this, e || [], !0))
            },
            is: function(e) {
                return !! D(this, "string" == typeof e && R.test(e) ? S(e) : e || [], !1).length
            }
        });
        var I, M = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/; (S.fn.init = function(e, t, n) {
            var i, r;
            if (!e) return this;
            if (n = n || I, "string" == typeof e) {
                if (! (i = "<" === e[0] && ">" === e[e.length - 1] && e.length >= 3 ? [null, e, null] : M.exec(e)) || !i[1] && t) return ! t || t.jquery ? (t || n).find(e) : this.constructor(t).find(e);
                if (i[1]) {
                    if (t = t instanceof S ? t[0] : t, S.merge(this, S.parseHTML(i[1], t && t.nodeType ? t.ownerDocument || t: s, !0)), O.test(i[1]) && S.isPlainObject(t)) for (i in t) g(this[i]) ? this[i](t[i]) : this.attr(i, t[i]);
                    return this
                }
                return (r = s.getElementById(i[2])) && (this[0] = r, this.length = 1),
                this
            }
            return e.nodeType ? (this[0] = e, this.length = 1, this) : g(e) ? void 0 !== n.ready ? n.ready(e) : e(S) : S.makeArray(e, this)
        }).prototype = S.fn,
        I = S(s);
        var j = /^(?:parents|prev(?:Until|All))/,
        B = {
            children: !0,
            contents: !0,
            next: !0,
            prev: !0
        };

        function N(e, t) {
            for (; (e = e[t]) && 1 !== e.nodeType;);
            return e
        }
        S.fn.extend({
            has: function(e) {
                var t = S(e, this),
                n = t.length;
                return this.filter(function() {
                    for (var e = 0; e < n; e++) if (S.contains(this, t[e])) return ! 0
                })
            },
            closest: function(e, t) {
                var n, i = 0,
                r = this.length,
                o = [],
                s = "string" != typeof e && S(e);
                if (!R.test(e)) for (; i < r; i++) for (n = this[i]; n && n !== t; n = n.parentNode) if (n.nodeType < 11 && (s ? s.index(n) > -1 : 1 === n.nodeType && S.find.matchesSelector(n, e))) {
                    o.push(n);
                    break
                }
                return this.pushStack(o.length > 1 ? S.uniqueSort(o) : o)
            },
            index: function(e) {
                return e ? "string" == typeof e ? d.call(S(e), this[0]) : d.call(this, e.jquery ? e[0] : e) : this[0] && this[0].parentNode ? this.first().prevAll().length: -1
            },
            add: function(e, t) {
                return this.pushStack(S.uniqueSort(S.merge(this.get(), S(e, t))))
            },
            addBack: function(e) {
                return this.add(null == e ? this.prevObject: this.prevObject.filter(e))
            }
        }),
        S.each({
            parent: function(e) {
                var t = e.parentNode;
                return t && 11 !== t.nodeType ? t: null
            },
            parents: function(e) {
                return T(e, "parentNode")
            },
            parentsUntil: function(e, t, n) {
                return T(e, "parentNode", n)
            },
            next: function(e) {
                return N(e, "nextSibling")
            },
            prev: function(e) {
                return N(e, "previousSibling")
            },
            nextAll: function(e) {
                return T(e, "nextSibling")
            },
            prevAll: function(e) {
                return T(e, "previousSibling")
            },
            nextUntil: function(e, t, n) {
                return T(e, "nextSibling", n)
            },
            prevUntil: function(e, t, n) {
                return T(e, "previousSibling", n)
            },
            siblings: function(e) {
                return A((e.parentNode || {}).firstChild, e)
            },
            children: function(e) {
                return A(e.firstChild)
            },
            contents: function(e) {
                return C(e, "iframe") ? e.contentDocument: (C(e, "template") && (e = e.content || e), S.merge([], e.childNodes))
            }
        },
        function(e, t) {
            S.fn[e] = function(n, i) {
                var r = S.map(this, t, n);
                return "Until" !== e.slice( - 5) && (i = n),
                i && "string" == typeof i && (r = S.filter(i, r)),
                this.length > 1 && (B[e] || S.uniqueSort(r), j.test(e) && r.reverse()),
                this.pushStack(r)
            }
        });
        var P = /[^\x20\t\r\n\f]+/g;

        function U(e) {
            return e
        }
        function F(e) {
            throw e
        }
        function W(e, t, n, i) {
            var r;
            try {
                e && g(r = e.promise) ? r.call(e).done(t).fail(n) : e && g(r = e.then) ? r.call(e, t, n) : t.apply(void 0, [e].slice(i))
            } catch(e) {
                n.apply(void 0, [e])
            }
        }
        S.Callbacks = function(e) {
            e = "string" == typeof e ?
            function(e) {
                var t = {};
                return S.each(e.match(P) || [],
                function(e, n) {
                    t[n] = !0
                }),
                t
            } (e) : S.extend({},
            e);
            var t, n, i, r, o = [],
            s = [],
            a = -1,
            u = function() {
                for (r = r || e.once, i = t = !0; s.length; a = -1) for (n = s.shift(); ++a < o.length;) ! 1 === o[a].apply(n[0], n[1]) && e.stopOnFalse && (a = o.length, n = !1);
                e.memory || (n = !1),
                t = !1,
                r && (o = n ? [] : "")
            },
            l = {
                add: function() {
                    return o && (n && !t && (a = o.length - 1, s.push(n)),
                    function t(n) {
                        S.each(n,
                        function(n, i) {
                            g(i) ? e.unique && l.has(i) || o.push(i) : i && i.length && "string" !== E(i) && t(i)
                        })
                    } (arguments), n && !t && u()),
                    this
                },
                remove: function() {
                    return S.each(arguments,
                    function(e, t) {
                        for (var n; (n = S.inArray(t, o, n)) > -1;) o.splice(n, 1),
                        n <= a && a--
                    }),
                    this
                },
                has: function(e) {
                    return e ? S.inArray(e, o) > -1 : o.length > 0
                },
                empty: function() {
                    return o && (o = []),
                    this
                },
                disable: function() {
                    return r = s = [],
                    o = n = "",
                    this
                },
                disabled: function() {
                    return ! o
                },
                lock: function() {
                    return r = s = [],
                    n || t || (o = n = ""),
                    this
                },
                locked: function() {
                    return !! r
                },
                fireWith: function(e, n) {
                    return r || (n = [e, (n = n || []).slice ? n.slice() : n], s.push(n), t || u()),
                    this
                },
                fire: function() {
                    return l.fireWith(this, arguments),
                    this
                },
                fired: function() {
                    return !! i
                }
            };
            return l
        },
        S.extend({
            Deferred: function(e) {
                var t = [["notify", "progress", S.Callbacks("memory"), S.Callbacks("memory"), 2], ["resolve", "done", S.Callbacks("once memory"), S.Callbacks("once memory"), 0, "resolved"], ["reject", "fail", S.Callbacks("once memory"), S.Callbacks("once memory"), 1, "rejected"]],
                i = "pending",
                r = {
                    state: function() {
                        return i
                    },
                    always: function() {
                        return o.done(arguments).fail(arguments),
                        this
                    },
                    catch: function(e) {
                        return r.then(null, e)
                    },
                    pipe: function() {
                        var e = arguments;
                        return S.Deferred(function(n) {
                            S.each(t,
                            function(t, i) {
                                var r = g(e[i[4]]) && e[i[4]];
                                o[i[1]](function() {
                                    var e = r && r.apply(this, arguments);
                                    e && g(e.promise) ? e.promise().progress(n.notify).done(n.resolve).fail(n.reject) : n[i[0] + "With"](this, r ? [e] : arguments)
                                })
                            }),
                            e = null
                        }).promise()
                    },
                    then: function(e, i, r) {
                        var o = 0;

                        function s(e, t, i, r) {
                            return function() {
                                var a = this,
                                u = arguments,
                                l = function() {
                                    var n, l;
                                    if (! (e < o)) {
                                        if ((n = i.apply(a, u)) === t.promise()) throw new TypeError("Thenable self-resolution");
                                        l = n && ("object" == typeof n || "function" == typeof n) && n.then,
                                        g(l) ? r ? l.call(n, s(o, t, U, r), s(o, t, F, r)) : (o++, l.call(n, s(o, t, U, r), s(o, t, F, r), s(o, t, U, t.notifyWith))) : (i !== U && (a = void 0, u = [n]), (r || t.resolveWith)(a, u))
                                    }
                                },
                                c = r ? l: function() {
                                    try {
                                        l()
                                    } catch(n) {
                                        S.Deferred.exceptionHook && S.Deferred.exceptionHook(n, c.stackTrace),
                                        e + 1 >= o && (i !== F && (a = void 0, u = [n]), t.rejectWith(a, u))
                                    }
                                };
                                e ? c() : (S.Deferred.getStackHook && (c.stackTrace = S.Deferred.getStackHook()), n.setTimeout(c))
                            }
                        }
                        return S.Deferred(function(n) {
                            t[0][3].add(s(0, n, g(r) ? r: U, n.notifyWith)),
                            t[1][3].add(s(0, n, g(e) ? e: U)),
                            t[2][3].add(s(0, n, g(i) ? i: F))
                        }).promise()
                    },
                    promise: function(e) {
                        return null != e ? S.extend(e, r) : r
                    }
                },
                o = {};
                return S.each(t,
                function(e, n) {
                    var s = n[2],
                    a = n[5];
                    r[n[1]] = s.add,
                    a && s.add(function() {
                        i = a
                    },
                    t[3 - e][2].disable, t[3 - e][3].disable, t[0][2].lock, t[0][3].lock),
                    s.add(n[3].fire),
                    o[n[0]] = function() {
                        return o[n[0] + "With"](this === o ? void 0 : this, arguments),
                        this
                    },
                    o[n[0] + "With"] = s.fireWith
                }),
                r.promise(o),
                e && e.call(o, o),
                o
            },
            when: function(e) {
                var t = arguments.length,
                n = t,
                i = Array(n),
                r = u.call(arguments),
                o = S.Deferred(),
                s = function(e) {
                    return function(n) {
                        i[e] = this,
                        r[e] = arguments.length > 1 ? u.call(arguments) : n,
                        --t || o.resolveWith(i, r)
                    }
                };
                if (t <= 1 && (W(e, o.done(s(n)).resolve, o.reject, !t), "pending" === o.state() || g(r[n] && r[n].then))) return o.then();
                for (; n--;) W(r[n], s(n), o.reject);
                return o.promise()
            }
        });
        var G = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;
        S.Deferred.exceptionHook = function(e, t) {
            n.console && n.console.warn && e && G.test(e.name) && n.console.warn("jQuery.Deferred exception: " + e.message, e.stack, t)
        },
        S.readyException = function(e) {
            n.setTimeout(function() {
                throw e
            })
        };
        var H = S.Deferred();

        function q() {
            s.removeEventListener("DOMContentLoaded", q),
            n.removeEventListener("load", q),
            S.ready()
        }
        S.fn.ready = function(e) {
            return H.then(e).
            catch(function(e) {
                S.readyException(e)
            }),
            this
        },
        S.extend({
            isReady: !1,
            readyWait: 1,
            ready: function(e) { (!0 === e ? --S.readyWait: S.isReady) || (S.isReady = !0, !0 !== e && --S.readyWait > 0 || H.resolveWith(s, [S]))
            }
        }),
        S.ready.then = H.then,
        "complete" === s.readyState || "loading" !== s.readyState && !s.documentElement.doScroll ? n.setTimeout(S.ready) : (s.addEventListener("DOMContentLoaded", q), n.addEventListener("load", q));
        var z = function(e, t, n, i, r, o, s) {
            var a = 0,
            u = e.length,
            l = null == n;
            if ("object" === E(n)) for (a in r = !0, n) z(e, t, a, n[a], !0, o, s);
            else if (void 0 !== i && (r = !0, g(i) || (s = !0), l && (s ? (t.call(e, i), t = null) : (l = t, t = function(e, t, n) {
                return l.call(S(e), n)
            })), t)) for (; a < u; a++) t(e[a], n, s ? i: i.call(e[a], a, t(e[a], n)));
            return r ? e: l ? t.call(e) : u ? t(e[0], n) : o
        },
        V = /^-ms-/,
        K = /-([a-z])/g;

        function X(e, t) {
            return t.toUpperCase()
        }
        function $(e) {
            return e.replace(V, "ms-").replace(K, X)
        }
        var Y = function(e) {
            return 1 === e.nodeType || 9 === e.nodeType || !+e.nodeType
        };

        function Q() {
            this.expando = S.expando + Q.uid++
        }
        Q.uid = 1,
        Q.prototype = {
            cache: function(e) {
                var t = e[this.expando];
                return t || (t = {},
                Y(e) && (e.nodeType ? e[this.expando] = t: Object.defineProperty(e, this.expando, {
                    value: t,
                    configurable: !0
                }))),
                t
            },
            set: function(e, t, n) {
                var i, r = this.cache(e);
                if ("string" == typeof t) r[$(t)] = n;
                else for (i in t) r[$(i)] = t[i];
                return r
            },
            get: function(e, t) {
                return void 0 === t ? this.cache(e) : e[this.expando] && e[this.expando][$(t)]
            },
            access: function(e, t, n) {
                return void 0 === t || t && "string" == typeof t && void 0 === n ? this.get(e, t) : (this.set(e, t, n), void 0 !== n ? n: t)
            },
            remove: function(e, t) {
                var n, i = e[this.expando];
                if (void 0 !== i) {
                    if (void 0 !== t) {
                        n = (t = Array.isArray(t) ? t.map($) : (t = $(t)) in i ? [t] : t.match(P) || []).length;
                        for (; n--;) delete i[t[n]]
                    } (void 0 === t || S.isEmptyObject(i)) && (e.nodeType ? e[this.expando] = void 0 : delete e[this.expando])
                }
            },
            hasData: function(e) {
                var t = e[this.expando];
                return void 0 !== t && !S.isEmptyObject(t)
            }
        };
        var J = new Q,
        Z = new Q,
        ee = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
        te = /[A-Z]/g;

        function ne(e, t, n) {
            var i;
            if (void 0 === n && 1 === e.nodeType) if (i = "data-" + t.replace(te, "-$&").toLowerCase(), "string" == typeof(n = e.getAttribute(i))) {
                try {
                    n = function(e) {
                        return "true" === e || "false" !== e && ("null" === e ? null: e === +e + "" ? +e: ee.test(e) ? JSON.parse(e) : e)
                    } (n)
                } catch(e) {}
                Z.set(e, t, n)
            } else n = void 0;
            return n
        }
        S.extend({
            hasData: function(e) {
                return Z.hasData(e) || J.hasData(e)
            },
            data: function(e, t, n) {
                return Z.access(e, t, n)
            },
            removeData: function(e, t) {
                Z.remove(e, t)
            },
            _data: function(e, t, n) {
                return J.access(e, t, n)
            },
            _removeData: function(e, t) {
                J.remove(e, t)
            }
        }),
        S.fn.extend({
            data: function(e, t) {
                var n, i, r, o = this[0],
                s = o && o.attributes;
                if (void 0 === e) {
                    if (this.length && (r = Z.get(o), 1 === o.nodeType && !J.get(o, "hasDataAttrs"))) {
                        for (n = s.length; n--;) s[n] && 0 === (i = s[n].name).indexOf("data-") && (i = $(i.slice(5)), ne(o, i, r[i]));
                        J.set(o, "hasDataAttrs", !0)
                    }
                    return r
                }
                return "object" == typeof e ? this.each(function() {
                    Z.set(this, e)
                }) : z(this,
                function(t) {
                    var n;
                    if (o && void 0 === t) return void 0 !== (n = Z.get(o, e)) ? n: void 0 !== (n = ne(o, e)) ? n: void 0;
                    this.each(function() {
                        Z.set(this, e, t)
                    })
                },
                null, t, arguments.length > 1, null, !0)
            },
            removeData: function(e) {
                return this.each(function() {
                    Z.remove(this, e)
                })
            }
        }),
        S.extend({
            queue: function(e, t, n) {
                var i;
                if (e) return t = (t || "fx") + "queue",
                i = J.get(e, t),
                n && (!i || Array.isArray(n) ? i = J.access(e, t, S.makeArray(n)) : i.push(n)),
                i || []
            },
            dequeue: function(e, t) {
                t = t || "fx";
                var n = S.queue(e, t),
                i = n.length,
                r = n.shift(),
                o = S._queueHooks(e, t);
                "inprogress" === r && (r = n.shift(), i--),
                r && ("fx" === t && n.unshift("inprogress"), delete o.stop, r.call(e,
                function() {
                    S.dequeue(e, t)
                },
                o)),
                !i && o && o.empty.fire()
            },
            _queueHooks: function(e, t) {
                var n = t + "queueHooks";
                return J.get(e, n) || J.access(e, n, {
                    empty: S.Callbacks("once memory").add(function() {
                        J.remove(e, [t + "queue", n])
                    })
                })
            }
        }),
        S.fn.extend({
            queue: function(e, t) {
                var n = 2;
                return "string" != typeof e && (t = e, e = "fx", n--),
                arguments.length < n ? S.queue(this[0], e) : void 0 === t ? this: this.each(function() {
                    var n = S.queue(this, e, t);
                    S._queueHooks(this, e),
                    "fx" === e && "inprogress" !== n[0] && S.dequeue(this, e)
                })
            },
            dequeue: function(e) {
                return this.each(function() {
                    S.dequeue(this, e)
                })
            },
            clearQueue: function(e) {
                return this.queue(e || "fx", [])
            },
            promise: function(e, t) {
                var n, i = 1,
                r = S.Deferred(),
                o = this,
                s = this.length,
                a = function() {--i || r.resolveWith(o, [o])
                };
                for ("string" != typeof e && (t = e, e = void 0), e = e || "fx"; s--;)(n = J.get(o[s], e + "queueHooks")) && n.empty && (i++, n.empty.add(a));
                return a(),
                r.promise(t)
            }
        });
        var ie = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
        re = new RegExp("^(?:([+-])=|)(" + ie + ")([a-z%]*)$", "i"),
        oe = ["Top", "Right", "Bottom", "Left"],
        se = function(e, t) {
            return "none" === (e = t || e).style.display || "" === e.style.display && S.contains(e.ownerDocument, e) && "none" === S.css(e, "display")
        },
        ae = function(e, t, n, i) {
            var r, o, s = {};
            for (o in t) s[o] = e.style[o],
            e.style[o] = t[o];
            for (o in r = n.apply(e, i || []), t) e.style[o] = s[o];
            return r
        };

        function ue(e, t, n, i) {
            var r, o, s = 20,
            a = i ?
            function() {
                return i.cur()
            }: function() {
                return S.css(e, t, "")
            },
            u = a(),
            l = n && n[3] || (S.cssNumber[t] ? "": "px"),
            c = (S.cssNumber[t] || "px" !== l && +u) && re.exec(S.css(e, t));
            if (c && c[3] !== l) {
                for (u /= 2, l = l || c[3], c = +u || 1; s--;) S.style(e, t, c + l),
                (1 - o) * (1 - (o = a() / u || .5)) <= 0 && (s = 0),
                c /= o;
                c *= 2,
                S.style(e, t, c + l),
                n = n || []
            }
            return n && (c = +c || +u || 0, r = n[1] ? c + (n[1] + 1) * n[2] : +n[2], i && (i.unit = l, i.start = c, i.end = r)),
            r
        }
        var le = {};

        function ce(e) {
            var t, n = e.ownerDocument,
            i = e.nodeName,
            r = le[i];
            return r || (t = n.body.appendChild(n.createElement(i)), r = S.css(t, "display"), t.parentNode.removeChild(t), "none" === r && (r = "block"), le[i] = r, r)
        }
        function de(e, t) {
            for (var n, i, r = [], o = 0, s = e.length; o < s; o++)(i = e[o]).style && (n = i.style.display, t ? ("none" === n && (r[o] = J.get(i, "display") || null, r[o] || (i.style.display = "")), "" === i.style.display && se(i) && (r[o] = ce(i))) : "none" !== n && (r[o] = "none", J.set(i, "display", n)));
            for (o = 0; o < s; o++) null != r[o] && (e[o].style.display = r[o]);
            return e
        }
        S.fn.extend({
            show: function() {
                return de(this, !0)
            },
            hide: function() {
                return de(this)
            },
            toggle: function(e) {
                return "boolean" == typeof e ? e ? this.show() : this.hide() : this.each(function() {
                    se(this) ? S(this).show() : S(this).hide()
                })
            }
        });
        var fe = /^(?:checkbox|radio)$/i,
        he = /<([a-z][^\/\0>\x20\t\r\n\f]+)/i,
        pe = /^$|^module$|\/(?:java|ecma)script/i,
        me = {
            option: [1, "<select multiple='multiple'>", "</select>"],
            thead: [1, "<table>", "</table>"],
            col: [2, "<table><colgroup>", "</colgroup></table>"],
            tr: [2, "<table><tbody>", "</tbody></table>"],
            td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
            _default: [0, "", ""]
        };

        function _e(e, t) {
            var n;
            return n = void 0 !== e.getElementsByTagName ? e.getElementsByTagName(t || "*") : void 0 !== e.querySelectorAll ? e.querySelectorAll(t || "*") : [],
            void 0 === t || t && C(e, t) ? S.merge([e], n) : n
        }
        function ve(e, t) {
            for (var n = 0,
            i = e.length; n < i; n++) J.set(e[n], "globalEval", !t || J.get(t[n], "globalEval"))
        }
        me.optgroup = me.option,
        me.tbody = me.tfoot = me.colgroup = me.caption = me.thead,
        me.th = me.td;
        var ge, ye, be = /<|&#?\w+;/;

        function we(e, t, n, i, r) {
            for (var o, s, a, u, l, c, d = t.createDocumentFragment(), f = [], h = 0, p = e.length; h < p; h++) if ((o = e[h]) || 0 === o) if ("object" === E(o)) S.merge(f, o.nodeType ? [o] : o);
            else if (be.test(o)) {
                for (s = s || d.appendChild(t.createElement("div")), a = (he.exec(o) || ["", ""])[1].toLowerCase(), u = me[a] || me._default, s.innerHTML = u[1] + S.htmlPrefilter(o) + u[2], c = u[0]; c--;) s = s.lastChild;
                S.merge(f, s.childNodes),
                (s = d.firstChild).textContent = ""
            } else f.push(t.createTextNode(o));
            for (d.textContent = "", h = 0; o = f[h++];) if (i && S.inArray(o, i) > -1) r && r.push(o);
            else if (l = S.contains(o.ownerDocument, o), s = _e(d.appendChild(o), "script"), l && ve(s), n) for (c = 0; o = s[c++];) pe.test(o.type || "") && n.push(o);
            return d
        }
        ge = s.createDocumentFragment().appendChild(s.createElement("div")),
        (ye = s.createElement("input")).setAttribute("type", "radio"),
        ye.setAttribute("checked", "checked"),
        ye.setAttribute("name", "t"),
        ge.appendChild(ye),
        v.checkClone = ge.cloneNode(!0).cloneNode(!0).lastChild.checked,
        ge.innerHTML = "<textarea>x</textarea>",
        v.noCloneChecked = !!ge.cloneNode(!0).lastChild.defaultValue;
        var Ee = s.documentElement,
        Se = /^key/,
        ke = /^(?:mouse|pointer|contextmenu|drag|drop)|click/,
        xe = /^([^.]*)(?:\.(.+)|)/;

        function Le() {
            return ! 0
        }
        function Te() {
            return ! 1
        }
        function Ae() {
            try {
                return s.activeElement
            } catch(e) {}
        }
        function Re(e, t, n, i, r, o) {
            var s, a;
            if ("object" == typeof t) {
                for (a in "string" != typeof n && (i = i || n, n = void 0), t) Re(e, a, n, i, t[a], o);
                return e
            }
            if (null == i && null == r ? (r = n, i = n = void 0) : null == r && ("string" == typeof n ? (r = i, i = void 0) : (r = i, i = n, n = void 0)), !1 === r) r = Te;
            else if (!r) return e;
            return 1 === o && (s = r, (r = function(e) {
                return S().off(e),
                s.apply(this, arguments)
            }).guid = s.guid || (s.guid = S.guid++)),
            e.each(function() {
                S.event.add(this, t, r, i, n)
            })
        }
        S.event = {
            global: {},
            add: function(e, t, n, i, r) {
                var o, s, a, u, l, c, d, f, h, p, m, _ = J.get(e);
                if (_) for (n.handler && (n = (o = n).handler, r = o.selector), r && S.find.matchesSelector(Ee, r), n.guid || (n.guid = S.guid++), (u = _.events) || (u = _.events = {}), (s = _.handle) || (s = _.handle = function(t) {
                    return void 0 !== S && S.event.triggered !== t.type ? S.event.dispatch.apply(e, arguments) : void 0
                }), l = (t = (t || "").match(P) || [""]).length; l--;) h = m = (a = xe.exec(t[l]) || [])[1],
                p = (a[2] || "").split(".").sort(),
                h && (d = S.event.special[h] || {},
                h = (r ? d.delegateType: d.bindType) || h, d = S.event.special[h] || {},
                c = S.extend({
                    type: h,
                    origType: m,
                    data: i,
                    handler: n,
                    guid: n.guid,
                    selector: r,
                    needsContext: r && S.expr.match.needsContext.test(r),
                    namespace: p.join(".")
                },
                o), (f = u[h]) || ((f = u[h] = []).delegateCount = 0, d.setup && !1 !== d.setup.call(e, i, p, s) || e.addEventListener && e.addEventListener(h, s)), d.add && (d.add.call(e, c), c.handler.guid || (c.handler.guid = n.guid)), r ? f.splice(f.delegateCount++, 0, c) : f.push(c), S.event.global[h] = !0)
            },
            remove: function(e, t, n, i, r) {
                var o, s, a, u, l, c, d, f, h, p, m, _ = J.hasData(e) && J.get(e);
                if (_ && (u = _.events)) {
                    for (l = (t = (t || "").match(P) || [""]).length; l--;) if (h = m = (a = xe.exec(t[l]) || [])[1], p = (a[2] || "").split(".").sort(), h) {
                        for (d = S.event.special[h] || {},
                        f = u[h = (i ? d.delegateType: d.bindType) || h] || [], a = a[2] && new RegExp("(^|\\.)" + p.join("\\.(?:.*\\.|)") + "(\\.|$)"), s = o = f.length; o--;) c = f[o],
                        !r && m !== c.origType || n && n.guid !== c.guid || a && !a.test(c.namespace) || i && i !== c.selector && ("**" !== i || !c.selector) || (f.splice(o, 1), c.selector && f.delegateCount--, d.remove && d.remove.call(e, c));
                        s && !f.length && (d.teardown && !1 !== d.teardown.call(e, p, _.handle) || S.removeEvent(e, h, _.handle), delete u[h])
                    } else for (h in u) S.event.remove(e, h + t[l], n, i, !0);
                    S.isEmptyObject(u) && J.remove(e, "handle events")
                }
            },
            dispatch: function(e) {
                var t, n, i, r, o, s, a = S.event.fix(e),
                u = new Array(arguments.length),
                l = (J.get(this, "events") || {})[a.type] || [],
                c = S.event.special[a.type] || {};
                for (u[0] = a, t = 1; t < arguments.length; t++) u[t] = arguments[t];
                if (a.delegateTarget = this, !c.preDispatch || !1 !== c.preDispatch.call(this, a)) {
                    for (s = S.event.handlers.call(this, a, l), t = 0; (r = s[t++]) && !a.isPropagationStopped();) for (a.currentTarget = r.elem, n = 0; (o = r.handlers[n++]) && !a.isImmediatePropagationStopped();) a.rnamespace && !a.rnamespace.test(o.namespace) || (a.handleObj = o, a.data = o.data, void 0 !== (i = ((S.event.special[o.origType] || {}).handle || o.handler).apply(r.elem, u)) && !1 === (a.result = i) && (a.preventDefault(), a.stopPropagation()));
                    return c.postDispatch && c.postDispatch.call(this, a),
                    a.result
                }
            },
            handlers: function(e, t) {
                var n, i, r, o, s, a = [],
                u = t.delegateCount,
                l = e.target;
                if (u && l.nodeType && !("click" === e.type && e.button >= 1)) for (; l !== this; l = l.parentNode || this) if (1 === l.nodeType && ("click" !== e.type || !0 !== l.disabled)) {
                    for (o = [], s = {},
                    n = 0; n < u; n++) void 0 === s[r = (i = t[n]).selector + " "] && (s[r] = i.needsContext ? S(r, this).index(l) > -1 : S.find(r, this, null, [l]).length),
                    s[r] && o.push(i);
                    o.length && a.push({
                        elem: l,
                        handlers: o
                    })
                }
                return l = this,
                u < t.length && a.push({
                    elem: l,
                    handlers: t.slice(u)
                }),
                a
            },
            addProp: function(e, t) {
                Object.defineProperty(S.Event.prototype, e, {
                    enumerable: !0,
                    configurable: !0,
                    get: g(t) ?
                    function() {
                        if (this.originalEvent) return t(this.originalEvent)
                    }: function() {
                        if (this.originalEvent) return this.originalEvent[e]
                    },
                    set: function(t) {
                        Object.defineProperty(this, e, {
                            enumerable: !0,
                            configurable: !0,
                            writable: !0,
                            value: t
                        })
                    }
                })
            },
            fix: function(e) {
                return e[S.expando] ? e: new S.Event(e)
            },
            special: {
                load: {
                    noBubble: !0
                },
                focus: {
                    trigger: function() {
                        if (this !== Ae() && this.focus) return this.focus(),
                        !1
                    },
                    delegateType: "focusin"
                },
                blur: {
                    trigger: function() {
                        if (this === Ae() && this.blur) return this.blur(),
                        !1
                    },
                    delegateType: "focusout"
                },
                click: {
                    trigger: function() {
                        if ("checkbox" === this.type && this.click && C(this, "input")) return this.click(),
                        !1
                    },
                    _default: function(e) {
                        return C(e.target, "a")
                    }
                },
                beforeunload: {
                    postDispatch: function(e) {
                        void 0 !== e.result && e.originalEvent && (e.originalEvent.returnValue = e.result)
                    }
                }
            }
        },
        S.removeEvent = function(e, t, n) {
            e.removeEventListener && e.removeEventListener(t, n)
        },
        S.Event = function(e, t) {
            if (! (this instanceof S.Event)) return new S.Event(e, t);
            e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || void 0 === e.defaultPrevented && !1 === e.returnValue ? Le: Te, this.target = e.target && 3 === e.target.nodeType ? e.target.parentNode: e.target, this.currentTarget = e.currentTarget, this.relatedTarget = e.relatedTarget) : this.type = e,
            t && S.extend(this, t),
            this.timeStamp = e && e.timeStamp || Date.now(),
            this[S.expando] = !0
        },
        S.Event.prototype = {
            constructor: S.Event,
            isDefaultPrevented: Te,
            isPropagationStopped: Te,
            isImmediatePropagationStopped: Te,
            isSimulated: !1,
            preventDefault: function() {
                var e = this.originalEvent;
                this.isDefaultPrevented = Le,
                e && !this.isSimulated && e.preventDefault()
            },
            stopPropagation: function() {
                var e = this.originalEvent;
                this.isPropagationStopped = Le,
                e && !this.isSimulated && e.stopPropagation()
            },
            stopImmediatePropagation: function() {
                var e = this.originalEvent;
                this.isImmediatePropagationStopped = Le,
                e && !this.isSimulated && e.stopImmediatePropagation(),
                this.stopPropagation()
            }
        },
        S.each({
            altKey: !0,
            bubbles: !0,
            cancelable: !0,
            changedTouches: !0,
            ctrlKey: !0,
            detail: !0,
            eventPhase: !0,
            metaKey: !0,
            pageX: !0,
            pageY: !0,
            shiftKey: !0,
            view: !0,
            char: !0,
            charCode: !0,
            key: !0,
            keyCode: !0,
            button: !0,
            buttons: !0,
            clientX: !0,
            clientY: !0,
            offsetX: !0,
            offsetY: !0,
            pointerId: !0,
            pointerType: !0,
            screenX: !0,
            screenY: !0,
            targetTouches: !0,
            toElement: !0,
            touches: !0,
            which: function(e) {
                var t = e.button;
                return null == e.which && Se.test(e.type) ? null != e.charCode ? e.charCode: e.keyCode: !e.which && void 0 !== t && ke.test(e.type) ? 1 & t ? 1 : 2 & t ? 3 : 4 & t ? 2 : 0 : e.which
            }
        },
        S.event.addProp),
        S.each({
            mouseenter: "mouseover",
            mouseleave: "mouseout",
            pointerenter: "pointerover",
            pointerleave: "pointerout"
        },
        function(e, t) {
            S.event.special[e] = {
                delegateType: t,
                bindType: t,
                handle: function(e) {
                    var n, i = e.relatedTarget,
                    r = e.handleObj;
                    return i && (i === this || S.contains(this, i)) || (e.type = r.origType, n = r.handler.apply(this, arguments), e.type = t),
                    n
                }
            }
        }),
        S.fn.extend({
            on: function(e, t, n, i) {
                return Re(this, e, t, n, i)
            },
            one: function(e, t, n, i) {
                return Re(this, e, t, n, i, 1)
            },
            off: function(e, t, n) {
                var i, r;
                if (e && e.preventDefault && e.handleObj) return i = e.handleObj,
                S(e.delegateTarget).off(i.namespace ? i.origType + "." + i.namespace: i.origType, i.selector, i.handler),
                this;
                if ("object" == typeof e) {
                    for (r in e) this.off(r, t, e[r]);
                    return this
                }
                return ! 1 !== t && "function" != typeof t || (n = t, t = void 0),
                !1 === n && (n = Te),
                this.each(function() {
                    S.event.remove(this, e, n, t)
                })
            }
        });
        var Ce = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([a-z][^\/\0>\x20\t\r\n\f]*)[^>]*)\/>/gi,
        Oe = /<script|<style|<link/i,
        De = /checked\s*(?:[^=]|=\s*.checked.)/i,
        Ie = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g;

        function Me(e, t) {
            return C(e, "table") && C(11 !== t.nodeType ? t: t.firstChild, "tr") && S(e).children("tbody")[0] || e
        }
        function je(e) {
            return e.type = (null !== e.getAttribute("type")) + "/" + e.type,
            e
        }
        function Be(e) {
            return "true/" === (e.type || "").slice(0, 5) ? e.type = e.type.slice(5) : e.removeAttribute("type"),
            e
        }
        function Ne(e, t) {
            var n, i, r, o, s, a, u, l;
            if (1 === t.nodeType) {
                if (J.hasData(e) && (o = J.access(e), s = J.set(t, o), l = o.events)) for (r in delete s.handle, s.events = {},
                l) for (n = 0, i = l[r].length; n < i; n++) S.event.add(t, r, l[r][n]);
                Z.hasData(e) && (a = Z.access(e), u = S.extend({},
                a), Z.set(t, u))
            }
        }
        function Pe(e, t, n, i) {
            t = l.apply([], t);
            var r, o, s, a, u, c, d = 0,
            f = e.length,
            h = f - 1,
            p = t[0],
            m = g(p);
            if (m || f > 1 && "string" == typeof p && !v.checkClone && De.test(p)) return e.each(function(r) {
                var o = e.eq(r);
                m && (t[0] = p.call(this, r, o.html())),
                Pe(o, t, n, i)
            });
            if (f && (o = (r = we(t, e[0].ownerDocument, !1, e, i)).firstChild, 1 === r.childNodes.length && (r = o), o || i)) {
                for (a = (s = S.map(_e(r, "script"), je)).length; d < f; d++) u = r,
                d !== h && (u = S.clone(u, !0, !0), a && S.merge(s, _e(u, "script"))),
                n.call(e[d], u, d);
                if (a) for (c = s[s.length - 1].ownerDocument, S.map(s, Be), d = 0; d < a; d++) u = s[d],
                pe.test(u.type || "") && !J.access(u, "globalEval") && S.contains(c, u) && (u.src && "module" !== (u.type || "").toLowerCase() ? S._evalUrl && S._evalUrl(u.src) : w(u.textContent.replace(Ie, ""), c, u))
            }
            return e
        }
        function Ue(e, t, n) {
            for (var i, r = t ? S.filter(t, e) : e, o = 0; null != (i = r[o]); o++) n || 1 !== i.nodeType || S.cleanData(_e(i)),
            i.parentNode && (n && S.contains(i.ownerDocument, i) && ve(_e(i, "script")), i.parentNode.removeChild(i));
            return e
        }
        S.extend({
            htmlPrefilter: function(e) {
                return e.replace(Ce, "<$1></$2>")
            },
            clone: function(e, t, n) {
                var i, r, o, s, a, u, l, c = e.cloneNode(!0),
                d = S.contains(e.ownerDocument, e);
                if (! (v.noCloneChecked || 1 !== e.nodeType && 11 !== e.nodeType || S.isXMLDoc(e))) for (s = _e(c), i = 0, r = (o = _e(e)).length; i < r; i++) a = o[i],
                u = s[i],
                void 0,
                "input" === (l = u.nodeName.toLowerCase()) && fe.test(a.type) ? u.checked = a.checked: "input" !== l && "textarea" !== l || (u.defaultValue = a.defaultValue);
                if (t) if (n) for (o = o || _e(e), s = s || _e(c), i = 0, r = o.length; i < r; i++) Ne(o[i], s[i]);
                else Ne(e, c);
                return (s = _e(c, "script")).length > 0 && ve(s, !d && _e(e, "script")),
                c
            },
            cleanData: function(e) {
                for (var t, n, i, r = S.event.special,
                o = 0; void 0 !== (n = e[o]); o++) if (Y(n)) {
                    if (t = n[J.expando]) {
                        if (t.events) for (i in t.events) r[i] ? S.event.remove(n, i) : S.removeEvent(n, i, t.handle);
                        n[J.expando] = void 0
                    }
                    n[Z.expando] && (n[Z.expando] = void 0)
                }
            }
        }),
        S.fn.extend({
            detach: function(e) {
                return Ue(this, e, !0)
            },
            remove: function(e) {
                return Ue(this, e)
            },
            text: function(e) {
                return z(this,
                function(e) {
                    return void 0 === e ? S.text(this) : this.empty().each(function() {
                        1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || (this.textContent = e)
                    })
                },
                null, e, arguments.length)
            },
            append: function() {
                return Pe(this, arguments,
                function(e) {
                    1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || Me(this, e).appendChild(e)
                })
            },
            prepend: function() {
                return Pe(this, arguments,
                function(e) {
                    if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                        var t = Me(this, e);
                        t.insertBefore(e, t.firstChild)
                    }
                })
            },
            before: function() {
                return Pe(this, arguments,
                function(e) {
                    this.parentNode && this.parentNode.insertBefore(e, this)
                })
            },
            after: function() {
                return Pe(this, arguments,
                function(e) {
                    this.parentNode && this.parentNode.insertBefore(e, this.nextSibling)
                })
            },
            empty: function() {
                for (var e, t = 0; null != (e = this[t]); t++) 1 === e.nodeType && (S.cleanData(_e(e, !1)), e.textContent = "");
                return this
            },
            clone: function(e, t) {
                return e = null != e && e,
                t = null == t ? e: t,
                this.map(function() {
                    return S.clone(this, e, t)
                })
            },
            html: function(e) {
                return z(this,
                function(e) {
                    var t = this[0] || {},
                    n = 0,
                    i = this.length;
                    if (void 0 === e && 1 === t.nodeType) return t.innerHTML;
                    if ("string" == typeof e && !Oe.test(e) && !me[(he.exec(e) || ["", ""])[1].toLowerCase()]) {
                        e = S.htmlPrefilter(e);
                        try {
                            for (; n < i; n++) 1 === (t = this[n] || {}).nodeType && (S.cleanData(_e(t, !1)), t.innerHTML = e);
                            t = 0
                        } catch(e) {}
                    }
                    t && this.empty().append(e)
                },
                null, e, arguments.length)
            },
            replaceWith: function() {
                var e = [];
                return Pe(this, arguments,
                function(t) {
                    var n = this.parentNode;
                    S.inArray(this, e) < 0 && (S.cleanData(_e(this)), n && n.replaceChild(t, this))
                },
                e)
            }
        }),
        S.each({
            appendTo: "append",
            prependTo: "prepend",
            insertBefore: "before",
            insertAfter: "after",
            replaceAll: "replaceWith"
        },
        function(e, t) {
            S.fn[e] = function(e) {
                for (var n, i = [], r = S(e), o = r.length - 1, s = 0; s <= o; s++) n = s === o ? this: this.clone(!0),
                S(r[s])[t](n),
                c.apply(i, n.get());
                return this.pushStack(i)
            }
        });
        var Fe = new RegExp("^(" + ie + ")(?!px)[a-z%]+$", "i"),
        We = function(e) {
            var t = e.ownerDocument.defaultView;
            return t && t.opener || (t = n),
            t.getComputedStyle(e)
        },
        Ge = new RegExp(oe.join("|"), "i");

        function He(e, t, n) {
            var i, r, o, s, a = e.style;
            return (n = n || We(e)) && ("" !== (s = n.getPropertyValue(t) || n[t]) || S.contains(e.ownerDocument, e) || (s = S.style(e, t)), !v.pixelBoxStyles() && Fe.test(s) && Ge.test(t) && (i = a.width, r = a.minWidth, o = a.maxWidth, a.minWidth = a.maxWidth = a.width = s, s = n.width, a.width = i, a.minWidth = r, a.maxWidth = o)),
            void 0 !== s ? s + "": s
        }
        function qe(e, t) {
            return {
                get: function() {
                    if (!e()) return (this.get = t).apply(this, arguments);
                    delete this.get
                }
            }
        } !
        function() {
            function e() {
                if (c) {
                    l.style.cssText = "position:absolute;left:-11111px;width:60px;margin-top:1px;padding:0;border:0",
                    c.style.cssText = "position:relative;display:block;box-sizing:border-box;overflow:scroll;margin:auto;border:1px;padding:1px;width:60%;top:1%",
                    Ee.appendChild(l).appendChild(c);
                    var e = n.getComputedStyle(c);
                    i = "1%" !== e.top,
                    u = 12 === t(e.marginLeft),
                    c.style.right = "60%",
                    a = 36 === t(e.right),
                    r = 36 === t(e.width),
                    c.style.position = "absolute",
                    o = 36 === c.offsetWidth || "absolute",
                    Ee.removeChild(l),
                    c = null
                }
            }
            function t(e) {
                return Math.round(parseFloat(e))
            }
            var i, r, o, a, u, l = s.createElement("div"),
            c = s.createElement("div");
            c.style && (c.style.backgroundClip = "content-box", c.cloneNode(!0).style.backgroundClip = "", v.clearCloneStyle = "content-box" === c.style.backgroundClip, S.extend(v, {
                boxSizingReliable: function() {
                    return e(),
                    r
                },
                pixelBoxStyles: function() {
                    return e(),
                    a
                },
                pixelPosition: function() {
                    return e(),
                    i
                },
                reliableMarginLeft: function() {
                    return e(),
                    u
                },
                scrollboxSize: function() {
                    return e(),
                    o
                }
            }))
        } ();
        var ze = /^(none|table(?!-c[ea]).+)/,
        Ve = /^--/,
        Ke = {
            position: "absolute",
            visibility: "hidden",
            display: "block"
        },
        Xe = {
            letterSpacing: "0",
            fontWeight: "400"
        },
        $e = ["Webkit", "Moz", "ms"],
        Ye = s.createElement("div").style;

        function Qe(e) {
            var t = S.cssProps[e];
            return t || (t = S.cssProps[e] = function(e) {
                if (e in Ye) return e;
                for (var t = e[0].toUpperCase() + e.slice(1), n = $e.length; n--;) if ((e = $e[n] + t) in Ye) return e
            } (e) || e),
            t
        }
        function Je(e, t, n) {
            var i = re.exec(t);
            return i ? Math.max(0, i[2] - (n || 0)) + (i[3] || "px") : t
        }
        function Ze(e, t, n, i, r, o) {
            var s = "width" === t ? 1 : 0,
            a = 0,
            u = 0;
            if (n === (i ? "border": "content")) return 0;
            for (; s < 4; s += 2)"margin" === n && (u += S.css(e, n + oe[s], !0, r)),
            i ? ("content" === n && (u -= S.css(e, "padding" + oe[s], !0, r)), "margin" !== n && (u -= S.css(e, "border" + oe[s] + "Width", !0, r))) : (u += S.css(e, "padding" + oe[s], !0, r), "padding" !== n ? u += S.css(e, "border" + oe[s] + "Width", !0, r) : a += S.css(e, "border" + oe[s] + "Width", !0, r));
            return ! i && o >= 0 && (u += Math.max(0, Math.ceil(e["offset" + t[0].toUpperCase() + t.slice(1)] - o - u - a - .5))),
            u
        }
        function et(e, t, n) {
            var i = We(e),
            r = He(e, t, i),
            o = "border-box" === S.css(e, "boxSizing", !1, i),
            s = o;
            if (Fe.test(r)) {
                if (!n) return r;
                r = "auto"
            }
            return s = s && (v.boxSizingReliable() || r === e.style[t]),
            ("auto" === r || !parseFloat(r) && "inline" === S.css(e, "display", !1, i)) && (r = e["offset" + t[0].toUpperCase() + t.slice(1)], s = !0),
            (r = parseFloat(r) || 0) + Ze(e, t, n || (o ? "border": "content"), s, i, r) + "px"
        }
        function tt(e, t, n, i, r) {
            return new tt.prototype.init(e, t, n, i, r)
        }
        S.extend({
            cssHooks: {
                opacity: {
                    get: function(e, t) {
                        if (t) {
                            var n = He(e, "opacity");
                            return "" === n ? "1": n
                        }
                    }
                }
            },
            cssNumber: {
                animationIterationCount: !0,
                columnCount: !0,
                fillOpacity: !0,
                flexGrow: !0,
                flexShrink: !0,
                fontWeight: !0,
                lineHeight: !0,
                opacity: !0,
                order: !0,
                orphans: !0,
                widows: !0,
                zIndex: !0,
                zoom: !0
            },
            cssProps: {},
            style: function(e, t, n, i) {
                if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
                    var r, o, s, a = $(t),
                    u = Ve.test(t),
                    l = e.style;
                    if (u || (t = Qe(a)), s = S.cssHooks[t] || S.cssHooks[a], void 0 === n) return s && "get" in s && void 0 !== (r = s.get(e, !1, i)) ? r: l[t];
                    "string" === (o = typeof n) && (r = re.exec(n)) && r[1] && (n = ue(e, t, r), o = "number"),
                    null != n && n == n && ("number" === o && (n += r && r[3] || (S.cssNumber[a] ? "": "px")), v.clearCloneStyle || "" !== n || 0 !== t.indexOf("background") || (l[t] = "inherit"), s && "set" in s && void 0 === (n = s.set(e, n, i)) || (u ? l.setProperty(t, n) : l[t] = n))
                }
            },
            css: function(e, t, n, i) {
                var r, o, s, a = $(t);
                return Ve.test(t) || (t = Qe(a)),
                (s = S.cssHooks[t] || S.cssHooks[a]) && "get" in s && (r = s.get(e, !0, n)),
                void 0 === r && (r = He(e, t, i)),
                "normal" === r && t in Xe && (r = Xe[t]),
                "" === n || n ? (o = parseFloat(r), !0 === n || isFinite(o) ? o || 0 : r) : r
            }
        }),
        S.each(["height", "width"],
        function(e, t) {
            S.cssHooks[t] = {
                get: function(e, n, i) {
                    if (n) return ! ze.test(S.css(e, "display")) || e.getClientRects().length && e.getBoundingClientRect().width ? et(e, t, i) : ae(e, Ke,
                    function() {
                        return et(e, t, i)
                    })
                },
                set: function(e, n, i) {
                    var r, o = We(e),
                    s = "border-box" === S.css(e, "boxSizing", !1, o),
                    a = i && Ze(e, t, i, s, o);
                    return s && v.scrollboxSize() === o.position && (a -= Math.ceil(e["offset" + t[0].toUpperCase() + t.slice(1)] - parseFloat(o[t]) - Ze(e, t, "border", !1, o) - .5)),
                    a && (r = re.exec(n)) && "px" !== (r[3] || "px") && (e.style[t] = n, n = S.css(e, t)),
                    Je(0, n, a)
                }
            }
        }),
        S.cssHooks.marginLeft = qe(v.reliableMarginLeft,
        function(e, t) {
            if (t) return (parseFloat(He(e, "marginLeft")) || e.getBoundingClientRect().left - ae(e, {
                marginLeft: 0
            },
            function() {
                return e.getBoundingClientRect().left
            })) + "px"
        }),
        S.each({
            margin: "",
            padding: "",
            border: "Width"
        },
        function(e, t) {
            S.cssHooks[e + t] = {
                expand: function(n) {
                    for (var i = 0,
                    r = {},
                    o = "string" == typeof n ? n.split(" ") : [n]; i < 4; i++) r[e + oe[i] + t] = o[i] || o[i - 2] || o[0];
                    return r
                }
            },
            "margin" !== e && (S.cssHooks[e + t].set = Je)
        }),
        S.fn.extend({
            css: function(e, t) {
                return z(this,
                function(e, t, n) {
                    var i, r, o = {},
                    s = 0;
                    if (Array.isArray(t)) {
                        for (i = We(e), r = t.length; s < r; s++) o[t[s]] = S.css(e, t[s], !1, i);
                        return o
                    }
                    return void 0 !== n ? S.style(e, t, n) : S.css(e, t)
                },
                e, t, arguments.length > 1)
            }
        }),
        S.Tween = tt,
        tt.prototype = {
            constructor: tt,
            init: function(e, t, n, i, r, o) {
                this.elem = e,
                this.prop = n,
                this.easing = r || S.easing._default,
                this.options = t,
                this.start = this.now = this.cur(),
                this.end = i,
                this.unit = o || (S.cssNumber[n] ? "": "px")
            },
            cur: function() {
                var e = tt.propHooks[this.prop];
                return e && e.get ? e.get(this) : tt.propHooks._default.get(this)
            },
            run: function(e) {
                var t, n = tt.propHooks[this.prop];
                return this.options.duration ? this.pos = t = S.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : this.pos = t = e,
                this.now = (this.end - this.start) * t + this.start,
                this.options.step && this.options.step.call(this.elem, this.now, this),
                n && n.set ? n.set(this) : tt.propHooks._default.set(this),
                this
            }
        },
        tt.prototype.init.prototype = tt.prototype,
        tt.propHooks = {
            _default: {
                get: function(e) {
                    var t;
                    return 1 !== e.elem.nodeType || null != e.elem[e.prop] && null == e.elem.style[e.prop] ? e.elem[e.prop] : (t = S.css(e.elem, e.prop, "")) && "auto" !== t ? t: 0
                },
                set: function(e) {
                    S.fx.step[e.prop] ? S.fx.step[e.prop](e) : 1 !== e.elem.nodeType || null == e.elem.style[S.cssProps[e.prop]] && !S.cssHooks[e.prop] ? e.elem[e.prop] = e.now: S.style(e.elem, e.prop, e.now + e.unit)
                }
            }
        },
        tt.propHooks.scrollTop = tt.propHooks.scrollLeft = {
            set: function(e) {
                e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
            }
        },
        S.easing = {
            linear: function(e) {
                return e
            },
            swing: function(e) {
                return.5 - Math.cos(e * Math.PI) / 2
            },
            _default: "swing"
        },
        S.fx = tt.prototype.init,
        S.fx.step = {};
        var nt, it, rt = /^(?:toggle|show|hide)$/,
        ot = /queueHooks$/;

        function st() {
            it && (!1 === s.hidden && n.requestAnimationFrame ? n.requestAnimationFrame(st) : n.setTimeout(st, S.fx.interval), S.fx.tick())
        }
        function at() {
            return n.setTimeout(function() {
                nt = void 0
            }),
            nt = Date.now()
        }
        function ut(e, t) {
            var n, i = 0,
            r = {
                height: e
            };
            for (t = t ? 1 : 0; i < 4; i += 2 - t) r["margin" + (n = oe[i])] = r["padding" + n] = e;
            return t && (r.opacity = r.width = e),
            r
        }
        function lt(e, t, n) {
            for (var i, r = (ct.tweeners[t] || []).concat(ct.tweeners["*"]), o = 0, s = r.length; o < s; o++) if (i = r[o].call(n, t, e)) return i
        }
        function ct(e, t, n) {
            var i, r, o = 0,
            s = ct.prefilters.length,
            a = S.Deferred().always(function() {
                delete u.elem
            }),
            u = function() {
                if (r) return ! 1;
                for (var t = nt || at(), n = Math.max(0, l.startTime + l.duration - t), i = 1 - (n / l.duration || 0), o = 0, s = l.tweens.length; o < s; o++) l.tweens[o].run(i);
                return a.notifyWith(e, [l, i, n]),
                i < 1 && s ? n: (s || a.notifyWith(e, [l, 1, 0]), a.resolveWith(e, [l]), !1)
            },
            l = a.promise({
                elem: e,
                props: S.extend({},
                t),
                opts: S.extend(!0, {
                    specialEasing: {},
                    easing: S.easing._default
                },
                n),
                originalProperties: t,
                originalOptions: n,
                startTime: nt || at(),
                duration: n.duration,
                tweens: [],
                createTween: function(t, n) {
                    var i = S.Tween(e, l.opts, t, n, l.opts.specialEasing[t] || l.opts.easing);
                    return l.tweens.push(i),
                    i
                },
                stop: function(t) {
                    var n = 0,
                    i = t ? l.tweens.length: 0;
                    if (r) return this;
                    for (r = !0; n < i; n++) l.tweens[n].run(1);
                    return t ? (a.notifyWith(e, [l, 1, 0]), a.resolveWith(e, [l, t])) : a.rejectWith(e, [l, t]),
                    this
                }
            }),
            c = l.props;
            for (!
            function(e, t) {
                var n, i, r, o, s;
                for (n in e) if (r = t[i = $(n)], o = e[n], Array.isArray(o) && (r = o[1], o = e[n] = o[0]), n !== i && (e[i] = o, delete e[n]), (s = S.cssHooks[i]) && "expand" in s) for (n in o = s.expand(o), delete e[i], o) n in e || (e[n] = o[n], t[n] = r);
                else t[i] = r
            } (c, l.opts.specialEasing); o < s; o++) if (i = ct.prefilters[o].call(l, e, c, l.opts)) return g(i.stop) && (S._queueHooks(l.elem, l.opts.queue).stop = i.stop.bind(i)),
            i;
            return S.map(c, lt, l),
            g(l.opts.start) && l.opts.start.call(e, l),
            l.progress(l.opts.progress).done(l.opts.done, l.opts.complete).fail(l.opts.fail).always(l.opts.always),
            S.fx.timer(S.extend(u, {
                elem: e,
                anim: l,
                queue: l.opts.queue
            })),
            l
        }
        S.Animation = S.extend(ct, {
            tweeners: {
                "*": [function(e, t) {
                    var n = this.createTween(e, t);
                    return ue(n.elem, e, re.exec(t), n),
                    n
                }]
            },
            tweener: function(e, t) {
                g(e) ? (t = e, e = ["*"]) : e = e.match(P);
                for (var n, i = 0,
                r = e.length; i < r; i++) n = e[i],
                ct.tweeners[n] = ct.tweeners[n] || [],
                ct.tweeners[n].unshift(t)
            },
            prefilters: [function(e, t, n) {
                var i, r, o, s, a, u, l, c, d = "width" in t || "height" in t,
                f = this,
                h = {},
                p = e.style,
                m = e.nodeType && se(e),
                _ = J.get(e, "fxshow");
                for (i in n.queue || (null == (s = S._queueHooks(e, "fx")).unqueued && (s.unqueued = 0, a = s.empty.fire, s.empty.fire = function() {
                    s.unqueued || a()
                }), s.unqueued++, f.always(function() {
                    f.always(function() {
                        s.unqueued--,
                        S.queue(e, "fx").length || s.empty.fire()
                    })
                })), t) if (r = t[i], rt.test(r)) {
                    if (delete t[i], o = o || "toggle" === r, r === (m ? "hide": "show")) {
                        if ("show" !== r || !_ || void 0 === _[i]) continue;
                        m = !0
                    }
                    h[i] = _ && _[i] || S.style(e, i)
                }
                if ((u = !S.isEmptyObject(t)) || !S.isEmptyObject(h)) for (i in d && 1 === e.nodeType && (n.overflow = [p.overflow, p.overflowX, p.overflowY], null == (l = _ && _.display) && (l = J.get(e, "display")), "none" === (c = S.css(e, "display")) && (l ? c = l: (de([e], !0), l = e.style.display || l, c = S.css(e, "display"), de([e]))), ("inline" === c || "inline-block" === c && null != l) && "none" === S.css(e, "float") && (u || (f.done(function() {
                    p.display = l
                }), null == l && (c = p.display, l = "none" === c ? "": c)), p.display = "inline-block")), n.overflow && (p.overflow = "hidden", f.always(function() {
                    p.overflow = n.overflow[0],
                    p.overflowX = n.overflow[1],
                    p.overflowY = n.overflow[2]
                })), u = !1, h) u || (_ ? "hidden" in _ && (m = _.hidden) : _ = J.access(e, "fxshow", {
                    display: l
                }), o && (_.hidden = !m), m && de([e], !0), f.done(function() {
                    for (i in m || de([e]), J.remove(e, "fxshow"), h) S.style(e, i, h[i])
                })),
                u = lt(m ? _[i] : 0, i, f),
                i in _ || (_[i] = u.start, m && (u.end = u.start, u.start = 0))
            }],
            prefilter: function(e, t) {
                t ? ct.prefilters.unshift(e) : ct.prefilters.push(e)
            }
        }),
        S.speed = function(e, t, n) {
            var i = e && "object" == typeof e ? S.extend({},
            e) : {
                complete: n || !n && t || g(e) && e,
                duration: e,
                easing: n && t || t && !g(t) && t
            };
            return S.fx.off ? i.duration = 0 : "number" != typeof i.duration && (i.duration in S.fx.speeds ? i.duration = S.fx.speeds[i.duration] : i.duration = S.fx.speeds._default),
            null != i.queue && !0 !== i.queue || (i.queue = "fx"),
            i.old = i.complete,
            i.complete = function() {
                g(i.old) && i.old.call(this),
                i.queue && S.dequeue(this, i.queue)
            },
            i
        },
        S.fn.extend({
            fadeTo: function(e, t, n, i) {
                return this.filter(se).css("opacity", 0).show().end().animate({
                    opacity: t
                },
                e, n, i)
            },
            animate: function(e, t, n, i) {
                var r = S.isEmptyObject(e),
                o = S.speed(t, n, i),
                s = function() {
                    var t = ct(this, S.extend({},
                    e), o); (r || J.get(this, "finish")) && t.stop(!0)
                };
                return s.finish = s,
                r || !1 === o.queue ? this.each(s) : this.queue(o.queue, s)
            },
            stop: function(e, t, n) {
                var i = function(e) {
                    var t = e.stop;
                    delete e.stop,
                    t(n)
                };
                return "string" != typeof e && (n = t, t = e, e = void 0),
                t && !1 !== e && this.queue(e || "fx", []),
                this.each(function() {
                    var t = !0,
                    r = null != e && e + "queueHooks",
                    o = S.timers,
                    s = J.get(this);
                    if (r) s[r] && s[r].stop && i(s[r]);
                    else for (r in s) s[r] && s[r].stop && ot.test(r) && i(s[r]);
                    for (r = o.length; r--;) o[r].elem !== this || null != e && o[r].queue !== e || (o[r].anim.stop(n), t = !1, o.splice(r, 1)); ! t && n || S.dequeue(this, e)
                })
            },
            finish: function(e) {
                return ! 1 !== e && (e = e || "fx"),
                this.each(function() {
                    var t, n = J.get(this),
                    i = n[e + "queue"],
                    r = n[e + "queueHooks"],
                    o = S.timers,
                    s = i ? i.length: 0;
                    for (n.finish = !0, S.queue(this, e, []), r && r.stop && r.stop.call(this, !0), t = o.length; t--;) o[t].elem === this && o[t].queue === e && (o[t].anim.stop(!0), o.splice(t, 1));
                    for (t = 0; t < s; t++) i[t] && i[t].finish && i[t].finish.call(this);
                    delete n.finish
                })
            }
        }),
        S.each(["toggle", "show", "hide"],
        function(e, t) {
            var n = S.fn[t];
            S.fn[t] = function(e, i, r) {
                return null == e || "boolean" == typeof e ? n.apply(this, arguments) : this.animate(ut(t, !0), e, i, r)
            }
        }),
        S.each({
            slideDown: ut("show"),
            slideUp: ut("hide"),
            slideToggle: ut("toggle"),
            fadeIn: {
                opacity: "show"
            },
            fadeOut: {
                opacity: "hide"
            },
            fadeToggle: {
                opacity: "toggle"
            }
        },
        function(e, t) {
            S.fn[e] = function(e, n, i) {
                return this.animate(t, e, n, i)
            }
        }),
        S.timers = [],
        S.fx.tick = function() {
            var e, t = 0,
            n = S.timers;
            for (nt = Date.now(); t < n.length; t++)(e = n[t])() || n[t] !== e || n.splice(t--, 1);
            n.length || S.fx.stop(),
            nt = void 0
        },
        S.fx.timer = function(e) {
            S.timers.push(e),
            S.fx.start()
        },
        S.fx.interval = 13,
        S.fx.start = function() {
            it || (it = !0, st())
        },
        S.fx.stop = function() {
            it = null
        },
        S.fx.speeds = {
            slow: 600,
            fast: 200,
            _default: 400
        },
        S.fn.delay = function(e, t) {
            return e = S.fx && S.fx.speeds[e] || e,
            t = t || "fx",
            this.queue(t,
            function(t, i) {
                var r = n.setTimeout(t, e);
                i.stop = function() {
                    n.clearTimeout(r)
                }
            })
        },
        function() {
            var e = s.createElement("input"),
            t = s.createElement("select").appendChild(s.createElement("option"));
            e.type = "checkbox",
            v.checkOn = "" !== e.value,
            v.optSelected = t.selected,
            (e = s.createElement("input")).value = "t",
            e.type = "radio",
            v.radioValue = "t" === e.value
        } ();
        var dt, ft = S.expr.attrHandle;
        S.fn.extend({
            attr: function(e, t) {
                return z(this, S.attr, e, t, arguments.length > 1)
            },
            removeAttr: function(e) {
                return this.each(function() {
                    S.removeAttr(this, e)
                })
            }
        }),
        S.extend({
            attr: function(e, t, n) {
                var i, r, o = e.nodeType;
                if (3 !== o && 8 !== o && 2 !== o) return void 0 === e.getAttribute ? S.prop(e, t, n) : (1 === o && S.isXMLDoc(e) || (r = S.attrHooks[t.toLowerCase()] || (S.expr.match.bool.test(t) ? dt: void 0)), void 0 !== n ? null === n ? void S.removeAttr(e, t) : r && "set" in r && void 0 !== (i = r.set(e, n, t)) ? i: (e.setAttribute(t, n + ""), n) : r && "get" in r && null !== (i = r.get(e, t)) ? i: null == (i = S.find.attr(e, t)) ? void 0 : i)
            },
            attrHooks: {
                type: {
                    set: function(e, t) {
                        if (!v.radioValue && "radio" === t && C(e, "input")) {
                            var n = e.value;
                            return e.setAttribute("type", t),
                            n && (e.value = n),
                            t
                        }
                    }
                }
            },
            removeAttr: function(e, t) {
                var n, i = 0,
                r = t && t.match(P);
                if (r && 1 === e.nodeType) for (; n = r[i++];) e.removeAttribute(n)
            }
        }),
        dt = {
            set: function(e, t, n) {
                return ! 1 === t ? S.removeAttr(e, n) : e.setAttribute(n, n),
                n
            }
        },
        S.each(S.expr.match.bool.source.match(/\w+/g),
        function(e, t) {
            var n = ft[t] || S.find.attr;
            ft[t] = function(e, t, i) {
                var r, o, s = t.toLowerCase();
                return i || (o = ft[s], ft[s] = r, r = null != n(e, t, i) ? s: null, ft[s] = o),
                r
            }
        });
        var ht = /^(?:input|select|textarea|button)$/i,
        pt = /^(?:a|area)$/i;

        function mt(e) {
            return (e.match(P) || []).join(" ")
        }
        function _t(e) {
            return e.getAttribute && e.getAttribute("class") || ""
        }
        function vt(e) {
            return Array.isArray(e) ? e: "string" == typeof e && e.match(P) || []
        }
        S.fn.extend({
            prop: function(e, t) {
                return z(this, S.prop, e, t, arguments.length > 1)
            },
            removeProp: function(e) {
                return this.each(function() {
                    delete this[S.propFix[e] || e]
                })
            }
        }),
        S.extend({
            prop: function(e, t, n) {
                var i, r, o = e.nodeType;
                if (3 !== o && 8 !== o && 2 !== o) return 1 === o && S.isXMLDoc(e) || (t = S.propFix[t] || t, r = S.propHooks[t]),
                void 0 !== n ? r && "set" in r && void 0 !== (i = r.set(e, n, t)) ? i: e[t] = n: r && "get" in r && null !== (i = r.get(e, t)) ? i: e[t]
            },
            propHooks: {
                tabIndex: {
                    get: function(e) {
                        var t = S.find.attr(e, "tabindex");
                        return t ? parseInt(t, 10) : ht.test(e.nodeName) || pt.test(e.nodeName) && e.href ? 0 : -1
                    }
                }
            },
            propFix: {
                for: "htmlFor",
                class: "className"
            }
        }),
        v.optSelected || (S.propHooks.selected = {
            get: function(e) {
                var t = e.parentNode;
                return t && t.parentNode && t.parentNode.selectedIndex,
                null
            },
            set: function(e) {
                var t = e.parentNode;
                t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex)
            }
        }),
        S.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"],
        function() {
            S.propFix[this.toLowerCase()] = this
        }),
        S.fn.extend({
            addClass: function(e) {
                var t, n, i, r, o, s, a, u = 0;
                if (g(e)) return this.each(function(t) {
                    S(this).addClass(e.call(this, t, _t(this)))
                });
                if ((t = vt(e)).length) for (; n = this[u++];) if (r = _t(n), i = 1 === n.nodeType && " " + mt(r) + " ") {
                    for (s = 0; o = t[s++];) i.indexOf(" " + o + " ") < 0 && (i += o + " ");
                    r !== (a = mt(i)) && n.setAttribute("class", a)
                }
                return this
            },
            removeClass: function(e) {
                var t, n, i, r, o, s, a, u = 0;
                if (g(e)) return this.each(function(t) {
                    S(this).removeClass(e.call(this, t, _t(this)))
                });
                if (!arguments.length) return this.attr("class", "");
                if ((t = vt(e)).length) for (; n = this[u++];) if (r = _t(n), i = 1 === n.nodeType && " " + mt(r) + " ") {
                    for (s = 0; o = t[s++];) for (; i.indexOf(" " + o + " ") > -1;) i = i.replace(" " + o + " ", " ");
                    r !== (a = mt(i)) && n.setAttribute("class", a)
                }
                return this
            },
            toggleClass: function(e, t) {
                var n = typeof e,
                i = "string" === n || Array.isArray(e);
                return "boolean" == typeof t && i ? t ? this.addClass(e) : this.removeClass(e) : g(e) ? this.each(function(n) {
                    S(this).toggleClass(e.call(this, n, _t(this), t), t)
                }) : this.each(function() {
                    var t, r, o, s;
                    if (i) for (r = 0, o = S(this), s = vt(e); t = s[r++];) o.hasClass(t) ? o.removeClass(t) : o.addClass(t);
                    else void 0 !== e && "boolean" !== n || ((t = _t(this)) && J.set(this, "__className__", t), this.setAttribute && this.setAttribute("class", t || !1 === e ? "": J.get(this, "__className__") || ""))
                })
            },
            hasClass: function(e) {
                var t, n, i = 0;
                for (t = " " + e + " "; n = this[i++];) if (1 === n.nodeType && (" " + mt(_t(n)) + " ").indexOf(t) > -1) return ! 0;
                return ! 1
            }
        });
        var gt = /\r/g;
        S.fn.extend({
            val: function(e) {
                var t, n, i, r = this[0];
                return arguments.length ? (i = g(e), this.each(function(n) {
                    var r;
                    1 === this.nodeType && (null == (r = i ? e.call(this, n, S(this).val()) : e) ? r = "": "number" == typeof r ? r += "": Array.isArray(r) && (r = S.map(r,
                    function(e) {
                        return null == e ? "": e + ""
                    })), (t = S.valHooks[this.type] || S.valHooks[this.nodeName.toLowerCase()]) && "set" in t && void 0 !== t.set(this, r, "value") || (this.value = r))
                })) : r ? (t = S.valHooks[r.type] || S.valHooks[r.nodeName.toLowerCase()]) && "get" in t && void 0 !== (n = t.get(r, "value")) ? n: "string" == typeof(n = r.value) ? n.replace(gt, "") : null == n ? "": n: void 0
            }
        }),
        S.extend({
            valHooks: {
                option: {
                    get: function(e) {
                        var t = S.find.attr(e, "value");
                        return null != t ? t: mt(S.text(e))
                    }
                },
                select: {
                    get: function(e) {
                        var t, n, i, r = e.options,
                        o = e.selectedIndex,
                        s = "select-one" === e.type,
                        a = s ? null: [],
                        u = s ? o + 1 : r.length;
                        for (i = o < 0 ? u: s ? o: 0; i < u; i++) if (((n = r[i]).selected || i === o) && !n.disabled && (!n.parentNode.disabled || !C(n.parentNode, "optgroup"))) {
                            if (t = S(n).val(), s) return t;
                            a.push(t)
                        }
                        return a
                    },
                    set: function(e, t) {
                        for (var n, i, r = e.options,
                        o = S.makeArray(t), s = r.length; s--;)((i = r[s]).selected = S.inArray(S.valHooks.option.get(i), o) > -1) && (n = !0);
                        return n || (e.selectedIndex = -1),
                        o
                    }
                }
            }
        }),
        S.each(["radio", "checkbox"],
        function() {
            S.valHooks[this] = {
                set: function(e, t) {
                    if (Array.isArray(t)) return e.checked = S.inArray(S(e).val(), t) > -1
                }
            },
            v.checkOn || (S.valHooks[this].get = function(e) {
                return null === e.getAttribute("value") ? "on": e.value
            })
        }),
        v.focusin = "onfocusin" in n;
        var yt = /^(?:focusinfocus|focusoutblur)$/,
        bt = function(e) {
            e.stopPropagation()
        };
        S.extend(S.event, {
            trigger: function(e, t, i, r) {
                var o, a, u, l, c, d, f, h, m = [i || s],
                _ = p.call(e, "type") ? e.type: e,
                v = p.call(e, "namespace") ? e.namespace.split(".") : [];
                if (a = h = u = i = i || s, 3 !== i.nodeType && 8 !== i.nodeType && !yt.test(_ + S.event.triggered) && (_.indexOf(".") > -1 && (_ = (v = _.split(".")).shift(), v.sort()), c = _.indexOf(":") < 0 && "on" + _, (e = e[S.expando] ? e: new S.Event(_, "object" == typeof e && e)).isTrigger = r ? 2 : 3, e.namespace = v.join("."), e.rnamespace = e.namespace ? new RegExp("(^|\\.)" + v.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, e.result = void 0, e.target || (e.target = i), t = null == t ? [e] : S.makeArray(t, [e]), f = S.event.special[_] || {},
                r || !f.trigger || !1 !== f.trigger.apply(i, t))) {
                    if (!r && !f.noBubble && !y(i)) {
                        for (l = f.delegateType || _, yt.test(l + _) || (a = a.parentNode); a; a = a.parentNode) m.push(a),
                        u = a;
                        u === (i.ownerDocument || s) && m.push(u.defaultView || u.parentWindow || n)
                    }
                    for (o = 0; (a = m[o++]) && !e.isPropagationStopped();) h = a,
                    e.type = o > 1 ? l: f.bindType || _,
                    (d = (J.get(a, "events") || {})[e.type] && J.get(a, "handle")) && d.apply(a, t),
                    (d = c && a[c]) && d.apply && Y(a) && (e.result = d.apply(a, t), !1 === e.result && e.preventDefault());
                    return e.type = _,
                    r || e.isDefaultPrevented() || f._default && !1 !== f._default.apply(m.pop(), t) || !Y(i) || c && g(i[_]) && !y(i) && ((u = i[c]) && (i[c] = null), S.event.triggered = _, e.isPropagationStopped() && h.addEventListener(_, bt), i[_](), e.isPropagationStopped() && h.removeEventListener(_, bt), S.event.triggered = void 0, u && (i[c] = u)),
                    e.result
                }
            },
            simulate: function(e, t, n) {
                var i = S.extend(new S.Event, n, {
                    type: e,
                    isSimulated: !0
                });
                S.event.trigger(i, null, t)
            }
        }),
        S.fn.extend({
            trigger: function(e, t) {
                return this.each(function() {
                    S.event.trigger(e, t, this)
                })
            },
            triggerHandler: function(e, t) {
                var n = this[0];
                if (n) return S.event.trigger(e, t, n, !0)
            }
        }),
        v.focusin || S.each({
            focus: "focusin",
            blur: "focusout"
        },
        function(e, t) {
            var n = function(e) {
                S.event.simulate(t, e.target, S.event.fix(e))
            };
            S.event.special[t] = {
                setup: function() {
                    var i = this.ownerDocument || this,
                    r = J.access(i, t);
                    r || i.addEventListener(e, n, !0),
                    J.access(i, t, (r || 0) + 1)
                },
                teardown: function() {
                    var i = this.ownerDocument || this,
                    r = J.access(i, t) - 1;
                    r ? J.access(i, t, r) : (i.removeEventListener(e, n, !0), J.remove(i, t))
                }
            }
        });
        var wt = n.location,
        Et = Date.now(),
        St = /\?/;
        S.parseXML = function(e) {
            var t;
            if (!e || "string" != typeof e) return null;
            try {
                t = (new n.DOMParser).parseFromString(e, "text/xml")
            } catch(e) {
                t = void 0
            }
            return t && !t.getElementsByTagName("parsererror").length || S.error("Invalid XML: " + e),
            t
        };
        var kt = /\[\]$/,
        xt = /\r?\n/g,
        Lt = /^(?:submit|button|image|reset|file)$/i,
        Tt = /^(?:input|select|textarea|keygen)/i;

        function At(e, t, n, i) {
            var r;
            if (Array.isArray(t)) S.each(t,
            function(t, r) {
                n || kt.test(e) ? i(e, r) : At(e + "[" + ("object" == typeof r && null != r ? t: "") + "]", r, n, i)
            });
            else if (n || "object" !== E(t)) i(e, t);
            else for (r in t) At(e + "[" + r + "]", t[r], n, i)
        }
        S.param = function(e, t) {
            var n, i = [],
            r = function(e, t) {
                var n = g(t) ? t() : t;
                i[i.length] = encodeURIComponent(e) + "=" + encodeURIComponent(null == n ? "": n)
            };
            if (Array.isArray(e) || e.jquery && !S.isPlainObject(e)) S.each(e,
            function() {
                r(this.name, this.value)
            });
            else for (n in e) At(n, e[n], t, r);
            return i.join("&")
        },
        S.fn.extend({
            serialize: function() {
                return S.param(this.serializeArray())
            },
            serializeArray: function() {
                return this.map(function() {
                    var e = S.prop(this, "elements");
                    return e ? S.makeArray(e) : this
                }).filter(function() {
                    var e = this.type;
                    return this.name && !S(this).is(":disabled") && Tt.test(this.nodeName) && !Lt.test(e) && (this.checked || !fe.test(e))
                }).map(function(e, t) {
                    var n = S(this).val();
                    return null == n ? null: Array.isArray(n) ? S.map(n,
                    function(e) {
                        return {
                            name: t.name,
                            value: e.replace(xt, "\r\n")
                        }
                    }) : {
                        name: t.name,
                        value: n.replace(xt, "\r\n")
                    }
                }).get()
            }
        });
        var Rt = /%20/g,
        Ct = /#.*$/,
        Ot = /([?&])_=[^&]*/,
        Dt = /^(.*?):[ \t]*([^\r\n]*)$/gm,
        It = /^(?:GET|HEAD)$/,
        Mt = /^\/\//,
        jt = {},
        Bt = {},
        Nt = "*/".concat("*"),
        Pt = s.createElement("a");

        function Ut(e) {
            return function(t, n) {
                "string" != typeof t && (n = t, t = "*");
                var i, r = 0,
                o = t.toLowerCase().match(P) || [];
                if (g(n)) for (; i = o[r++];)"+" === i[0] ? (i = i.slice(1) || "*", (e[i] = e[i] || []).unshift(n)) : (e[i] = e[i] || []).push(n)
            }
        }
        function Ft(e, t, n, i) {
            var r = {},
            o = e === Bt;

            function s(a) {
                var u;
                return r[a] = !0,
                S.each(e[a] || [],
                function(e, a) {
                    var l = a(t, n, i);
                    return "string" != typeof l || o || r[l] ? o ? !(u = l) : void 0 : (t.dataTypes.unshift(l), s(l), !1)
                }),
                u
            }
            return s(t.dataTypes[0]) || !r["*"] && s("*")
        }
        function Wt(e, t) {
            var n, i, r = S.ajaxSettings.flatOptions || {};
            for (n in t) void 0 !== t[n] && ((r[n] ? e: i || (i = {}))[n] = t[n]);
            return i && S.extend(!0, e, i),
            e
        }
        Pt.href = wt.href,
        S.extend({
            active: 0,
            lastModified: {},
            etag: {},
            ajaxSettings: {
                url: wt.href,
                type: "GET",
                isLocal: /^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(wt.protocol),
                global: !0,
                processData: !0,
                async: !0,
                contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                accepts: {
                    "*": Nt,
                    text: "text/plain",
                    html: "text/html",
                    xml: "application/xml, text/xml",
                    json: "application/json, text/javascript"
                },
                contents: {
                    xml: /\bxml\b/,
                    html: /\bhtml/,
                    json: /\bjson\b/
                },
                responseFields: {
                    xml: "responseXML",
                    text: "responseText",
                    json: "responseJSON"
                },
                converters: {
                    "* text": String,
                    "text html": !0,
                    "text json": JSON.parse,
                    "text xml": S.parseXML
                },
                flatOptions: {
                    url: !0,
                    context: !0
                }
            },
            ajaxSetup: function(e, t) {
                return t ? Wt(Wt(e, S.ajaxSettings), t) : Wt(S.ajaxSettings, e)
            },
            ajaxPrefilter: Ut(jt),
            ajaxTransport: Ut(Bt),
            ajax: function(e, t) {
                "object" == typeof e && (t = e, e = void 0),
                t = t || {};
                var i, r, o, a, u, l, c, d, f, h, p = S.ajaxSetup({},
                t),
                m = p.context || p,
                _ = p.context && (m.nodeType || m.jquery) ? S(m) : S.event,
                v = S.Deferred(),
                g = S.Callbacks("once memory"),
                y = p.statusCode || {},
                b = {},
                w = {},
                E = "canceled",
                k = {
                    readyState: 0,
                    getResponseHeader: function(e) {
                        var t;
                        if (c) {
                            if (!a) for (a = {}; t = Dt.exec(o);) a[t[1].toLowerCase()] = t[2];
                            t = a[e.toLowerCase()]
                        }
                        return null == t ? null: t
                    },
                    getAllResponseHeaders: function() {
                        return c ? o: null
                    },
                    setRequestHeader: function(e, t) {
                        return null == c && (e = w[e.toLowerCase()] = w[e.toLowerCase()] || e, b[e] = t),
                        this
                    },
                    overrideMimeType: function(e) {
                        return null == c && (p.mimeType = e),
                        this
                    },
                    statusCode: function(e) {
                        var t;
                        if (e) if (c) k.always(e[k.status]);
                        else for (t in e) y[t] = [y[t], e[t]];
                        return this
                    },
                    abort: function(e) {
                        var t = e || E;
                        return i && i.abort(t),
                        x(0, t),
                        this
                    }
                };
                if (v.promise(k), p.url = ((e || p.url || wt.href) + "").replace(Mt, wt.protocol + "//"), p.type = t.method || t.type || p.method || p.type, p.dataTypes = (p.dataType || "*").toLowerCase().match(P) || [""], null == p.crossDomain) {
                    l = s.createElement("a");
                    try {
                        l.href = p.url,
                        l.href = l.href,
                        p.crossDomain = Pt.protocol + "//" + Pt.host != l.protocol + "//" + l.host
                    } catch(e) {
                        p.crossDomain = !0
                    }
                }
                if (p.data && p.processData && "string" != typeof p.data && (p.data = S.param(p.data, p.traditional)), Ft(jt, p, t, k), c) return k;
                for (f in (d = S.event && p.global) && 0 == S.active++&&S.event.trigger("ajaxStart"), p.type = p.type.toUpperCase(), p.hasContent = !It.test(p.type), r = p.url.replace(Ct, ""), p.hasContent ? p.data && p.processData && 0 === (p.contentType || "").indexOf("application/x-www-form-urlencoded") && (p.data = p.data.replace(Rt, "+")) : (h = p.url.slice(r.length), p.data && (p.processData || "string" == typeof p.data) && (r += (St.test(r) ? "&": "?") + p.data, delete p.data), !1 === p.cache && (r = r.replace(Ot, "$1"), h = (St.test(r) ? "&": "?") + "_=" + Et+++h), p.url = r + h), p.ifModified && (S.lastModified[r] && k.setRequestHeader("If-Modified-Since", S.lastModified[r]), S.etag[r] && k.setRequestHeader("If-None-Match", S.etag[r])), (p.data && p.hasContent && !1 !== p.contentType || t.contentType) && k.setRequestHeader("Content-Type", p.contentType), k.setRequestHeader("Accept", p.dataTypes[0] && p.accepts[p.dataTypes[0]] ? p.accepts[p.dataTypes[0]] + ("*" !== p.dataTypes[0] ? ", " + Nt + "; q=0.01": "") : p.accepts["*"]), p.headers) k.setRequestHeader(f, p.headers[f]);
                if (p.beforeSend && (!1 === p.beforeSend.call(m, k, p) || c)) return k.abort();
                if (E = "abort", g.add(p.complete), k.done(p.success), k.fail(p.error), i = Ft(Bt, p, t, k)) {
                    if (k.readyState = 1, d && _.trigger("ajaxSend", [k, p]), c) return k;
                    p.async && p.timeout > 0 && (u = n.setTimeout(function() {
                        k.abort("timeout")
                    },
                    p.timeout));
                    try {
                        c = !1,
                        i.send(b, x)
                    } catch(e) {
                        if (c) throw e;
                        x( - 1, e)
                    }
                } else x( - 1, "No Transport");

                function x(e, t, s, a) {
                    var l, f, h, b, w, E = t;
                    c || (c = !0, u && n.clearTimeout(u), i = void 0, o = a || "", k.readyState = e > 0 ? 4 : 0, l = e >= 200 && e < 300 || 304 === e, s && (b = function(e, t, n) {
                        for (var i, r, o, s, a = e.contents,
                        u = e.dataTypes;
                        "*" === u[0];) u.shift(),
                        void 0 === i && (i = e.mimeType || t.getResponseHeader("Content-Type"));
                        if (i) for (r in a) if (a[r] && a[r].test(i)) {
                            u.unshift(r);
                            break
                        }
                        if (u[0] in n) o = u[0];
                        else {
                            for (r in n) {
                                if (!u[0] || e.converters[r + " " + u[0]]) {
                                    o = r;
                                    break
                                }
                                s || (s = r)
                            }
                            o = o || s
                        }
                        if (o) return o !== u[0] && u.unshift(o),
                        n[o]
                    } (p, k, s)), b = function(e, t, n, i) {
                        var r, o, s, a, u, l = {},
                        c = e.dataTypes.slice();
                        if (c[1]) for (s in e.converters) l[s.toLowerCase()] = e.converters[s];
                        for (o = c.shift(); o;) if (e.responseFields[o] && (n[e.responseFields[o]] = t), !u && i && e.dataFilter && (t = e.dataFilter(t, e.dataType)), u = o, o = c.shift()) if ("*" === o) o = u;
                        else if ("*" !== u && u !== o) {
                            if (! (s = l[u + " " + o] || l["* " + o])) for (r in l) if ((a = r.split(" "))[1] === o && (s = l[u + " " + a[0]] || l["* " + a[0]])) { ! 0 === s ? s = l[r] : !0 !== l[r] && (o = a[0], c.unshift(a[1]));
                                break
                            }
                            if (!0 !== s) if (s && e.throws) t = s(t);
                            else try {
                                t = s(t)
                            } catch(e) {
                                return {
                                    state: "parsererror",
                                    error: s ? e: "No conversion from " + u + " to " + o
                                }
                            }
                        }
                        return {
                            state: "success",
                            data: t
                        }
                    } (p, b, k, l), l ? (p.ifModified && ((w = k.getResponseHeader("Last-Modified")) && (S.lastModified[r] = w), (w = k.getResponseHeader("etag")) && (S.etag[r] = w)), 204 === e || "HEAD" === p.type ? E = "nocontent": 304 === e ? E = "notmodified": (E = b.state, f = b.data, l = !(h = b.error))) : (h = E, !e && E || (E = "error", e < 0 && (e = 0))), k.status = e, k.statusText = (t || E) + "", l ? v.resolveWith(m, [f, E, k]) : v.rejectWith(m, [k, E, h]), k.statusCode(y), y = void 0, d && _.trigger(l ? "ajaxSuccess": "ajaxError", [k, p, l ? f: h]), g.fireWith(m, [k, E]), d && (_.trigger("ajaxComplete", [k, p]), --S.active || S.event.trigger("ajaxStop")))
                }
                return k
            },
            getJSON: function(e, t, n) {
                return S.get(e, t, n, "json")
            },
            getScript: function(e, t) {
                return S.get(e, void 0, t, "script")
            }
        }),
        S.each(["get", "post"],
        function(e, t) {
            S[t] = function(e, n, i, r) {
                return g(n) && (r = r || i, i = n, n = void 0),
                S.ajax(S.extend({
                    url: e,
                    type: t,
                    dataType: r,
                    data: n,
                    success: i
                },
                S.isPlainObject(e) && e))
            }
        }),
        S._evalUrl = function(e) {
            return S.ajax({
                url: e,
                type: "GET",
                dataType: "script",
                cache: !0,
                async: !1,
                global: !1,
                throws: !0
            })
        },
        S.fn.extend({
            wrapAll: function(e) {
                var t;
                return this[0] && (g(e) && (e = e.call(this[0])), t = S(e, this[0].ownerDocument).eq(0).clone(!0), this[0].parentNode && t.insertBefore(this[0]), t.map(function() {
                    for (var e = this; e.firstElementChild;) e = e.firstElementChild;
                    return e
                }).append(this)),
                this
            },
            wrapInner: function(e) {
                return g(e) ? this.each(function(t) {
                    S(this).wrapInner(e.call(this, t))
                }) : this.each(function() {
                    var t = S(this),
                    n = t.contents();
                    n.length ? n.wrapAll(e) : t.append(e)
                })
            },
            wrap: function(e) {
                var t = g(e);
                return this.each(function(n) {
                    S(this).wrapAll(t ? e.call(this, n) : e)
                })
            },
            unwrap: function(e) {
                return this.parent(e).not("body").each(function() {
                    S(this).replaceWith(this.childNodes)
                }),
                this
            }
        }),
        S.expr.pseudos.hidden = function(e) {
            return ! S.expr.pseudos.visible(e)
        },
        S.expr.pseudos.visible = function(e) {
            return !! (e.offsetWidth || e.offsetHeight || e.getClientRects().length)
        },
        S.ajaxSettings.xhr = function() {
            try {
                return new n.XMLHttpRequest
            } catch(e) {}
        };
        var Gt = {
            0 : 200,
            1223 : 204
        },
        Ht = S.ajaxSettings.xhr();
        v.cors = !!Ht && "withCredentials" in Ht,
        v.ajax = Ht = !!Ht,
        S.ajaxTransport(function(e) {
            var t, i;
            if (v.cors || Ht && !e.crossDomain) return {
                send: function(r, o) {
                    var s, a = e.xhr();
                    if (a.open(e.type, e.url, e.async, e.username, e.password), e.xhrFields) for (s in e.xhrFields) a[s] = e.xhrFields[s];
                    for (s in e.mimeType && a.overrideMimeType && a.overrideMimeType(e.mimeType), e.crossDomain || r["X-Requested-With"] || (r["X-Requested-With"] = "XMLHttpRequest"), r) a.setRequestHeader(s, r[s]);
                    t = function(e) {
                        return function() {
                            t && (t = i = a.onload = a.onerror = a.onabort = a.ontimeout = a.onreadystatechange = null, "abort" === e ? a.abort() : "error" === e ? "number" != typeof a.status ? o(0, "error") : o(a.status, a.statusText) : o(Gt[a.status] || a.status, a.statusText, "text" !== (a.responseType || "text") || "string" != typeof a.responseText ? {
                                binary: a.response
                            }: {
                                text: a.responseText
                            },
                            a.getAllResponseHeaders()))
                        }
                    },
                    a.onload = t(),
                    i = a.onerror = a.ontimeout = t("error"),
                    void 0 !== a.onabort ? a.onabort = i: a.onreadystatechange = function() {
                        4 === a.readyState && n.setTimeout(function() {
                            t && i()
                        })
                    },
                    t = t("abort");
                    try {
                        a.send(e.hasContent && e.data || null)
                    } catch(e) {
                        if (t) throw e
                    }
                },
                abort: function() {
                    t && t()
                }
            }
        }),
        S.ajaxPrefilter(function(e) {
            e.crossDomain && (e.contents.script = !1)
        }),
        S.ajaxSetup({
            accepts: {
                script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
            },
            contents: {
                script: /\b(?:java|ecma)script\b/
            },
            converters: {
                "text script": function(e) {
                    return S.globalEval(e),
                    e
                }
            }
        }),
        S.ajaxPrefilter("script",
        function(e) {
            void 0 === e.cache && (e.cache = !1),
            e.crossDomain && (e.type = "GET")
        }),
        S.ajaxTransport("script",
        function(e) {
            var t, n;
            if (e.crossDomain) return {
                send: function(i, r) {
                    t = S("<script>").prop({
                        charset: e.scriptCharset,
                        src: e.url
                    }).on("load error", n = function(e) {
                        t.remove(),
                        n = null,
                        e && r("error" === e.type ? 404 : 200, e.type)
                    }),
                    s.head.appendChild(t[0])
                },
                abort: function() {
                    n && n()
                }
            }
        });
        var qt, zt = [],
        Vt = /(=)\?(?=&|$)|\?\?/;
        S.ajaxSetup({
            jsonp: "callback",
            jsonpCallback: function() {
                var e = zt.pop() || S.expando + "_" + Et++;
                return this[e] = !0,
                e
            }
        }),
        S.ajaxPrefilter("json jsonp",
        function(e, t, i) {
            var r, o, s, a = !1 !== e.jsonp && (Vt.test(e.url) ? "url": "string" == typeof e.data && 0 === (e.contentType || "").indexOf("application/x-www-form-urlencoded") && Vt.test(e.data) && "data");
            if (a || "jsonp" === e.dataTypes[0]) return r = e.jsonpCallback = g(e.jsonpCallback) ? e.jsonpCallback() : e.jsonpCallback,
            a ? e[a] = e[a].replace(Vt, "$1" + r) : !1 !== e.jsonp && (e.url += (St.test(e.url) ? "&": "?") + e.jsonp + "=" + r),
            e.converters["script json"] = function() {
                return s || S.error(r + " was not called"),
                s[0]
            },
            e.dataTypes[0] = "json",
            o = n[r],
            n[r] = function() {
                s = arguments
            },
            i.always(function() {
                void 0 === o ? S(n).removeProp(r) : n[r] = o,
                e[r] && (e.jsonpCallback = t.jsonpCallback, zt.push(r)),
                s && g(o) && o(s[0]),
                s = o = void 0
            }),
            "script"
        }),
        v.createHTMLDocument = ((qt = s.implementation.createHTMLDocument("").body).innerHTML = "<form></form><form></form>", 2 === qt.childNodes.length),
        S.parseHTML = function(e, t, n) {
            return "string" != typeof e ? [] : ("boolean" == typeof t && (n = t, t = !1), t || (v.createHTMLDocument ? ((i = (t = s.implementation.createHTMLDocument("")).createElement("base")).href = s.location.href, t.head.appendChild(i)) : t = s), r = O.exec(e), o = !n && [], r ? [t.createElement(r[1])] : (r = we([e], t, o), o && o.length && S(o).remove(), S.merge([], r.childNodes)));
            var i, r, o
        }, S.fn.load = function(e, t, n) {
            var i, r, o, s = this,
            a = e.indexOf(" ");
            return a > -1 && (i = mt(e.slice(a)), e = e.slice(0, a)),
            g(t) ? (n = t, t = void 0) : t && "object" == typeof t && (r = "POST"),
            s.length > 0 && S.ajax({
                url: e,
                type: r || "GET",
                dataType: "html",
                data: t
            }).done(function(e) {
                o = arguments,
                s.html(i ? S("<div>").append(S.parseHTML(e)).find(i) : e)
            }).always(n &&
            function(e, t) {
                s.each(function() {
                    n.apply(this, o || [e.responseText, t, e])
                })
            }),
            this
        },
        S.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"],
        function(e, t) {
            S.fn[t] = function(e) {
                return this.on(t, e)
            }
        }),
        S.expr.pseudos.animated = function(e) {
            return S.grep(S.timers,
            function(t) {
                return e === t.elem
            }).length
        },
        S.offset = {
            setOffset: function(e, t, n) {
                var i, r, o, s, a, u, l = S.css(e, "position"),
                c = S(e),
                d = {};
                "static" === l && (e.style.position = "relative"),
                a = c.offset(),
                o = S.css(e, "top"),
                u = S.css(e, "left"),
                ("absolute" === l || "fixed" === l) && (o + u).indexOf("auto") > -1 ? (s = (i = c.position()).top, r = i.left) : (s = parseFloat(o) || 0, r = parseFloat(u) || 0),
                g(t) && (t = t.call(e, n, S.extend({},
                a))),
                null != t.top && (d.top = t.top - a.top + s),
                null != t.left && (d.left = t.left - a.left + r),
                "using" in t ? t.using.call(e, d) : c.css(d)
            }
        },
        S.fn.extend({
            offset: function(e) {
                if (arguments.length) return void 0 === e ? this: this.each(function(t) {
                    S.offset.setOffset(this, e, t)
                });
                var t, n, i = this[0];
                return i ? i.getClientRects().length ? (t = i.getBoundingClientRect(), n = i.ownerDocument.defaultView, {
                    top: t.top + n.pageYOffset,
                    left: t.left + n.pageXOffset
                }) : {
                    top: 0,
                    left: 0
                }: void 0
            },
            position: function() {
                if (this[0]) {
                    var e, t, n, i = this[0],
                    r = {
                        top: 0,
                        left: 0
                    };
                    if ("fixed" === S.css(i, "position")) t = i.getBoundingClientRect();
                    else {
                        for (t = this.offset(), n = i.ownerDocument, e = i.offsetParent || n.documentElement; e && (e === n.body || e === n.documentElement) && "static" === S.css(e, "position");) e = e.parentNode;
                        e && e !== i && 1 === e.nodeType && ((r = S(e).offset()).top += S.css(e, "borderTopWidth", !0), r.left += S.css(e, "borderLeftWidth", !0))
                    }
                    return {
                        top: t.top - r.top - S.css(i, "marginTop", !0),
                        left: t.left - r.left - S.css(i, "marginLeft", !0)
                    }
                }
            },
            offsetParent: function() {
                return this.map(function() {
                    for (var e = this.offsetParent; e && "static" === S.css(e, "position");) e = e.offsetParent;
                    return e || Ee
                })
            }
        }),
        S.each({
            scrollLeft: "pageXOffset",
            scrollTop: "pageYOffset"
        },
        function(e, t) {
            var n = "pageYOffset" === t;
            S.fn[e] = function(i) {
                return z(this,
                function(e, i, r) {
                    var o;
                    if (y(e) ? o = e: 9 === e.nodeType && (o = e.defaultView), void 0 === r) return o ? o[t] : e[i];
                    o ? o.scrollTo(n ? o.pageXOffset: r, n ? r: o.pageYOffset) : e[i] = r
                },
                e, i, arguments.length)
            }
        }),
        S.each(["top", "left"],
        function(e, t) {
            S.cssHooks[t] = qe(v.pixelPosition,
            function(e, n) {
                if (n) return n = He(e, t),
                Fe.test(n) ? S(e).position()[t] + "px": n
            })
        }),
        S.each({
            Height: "height",
            Width: "width"
        },
        function(e, t) {
            S.each({
                padding: "inner" + e,
                content: t,
                "": "outer" + e
            },
            function(n, i) {
                S.fn[i] = function(r, o) {
                    var s = arguments.length && (n || "boolean" != typeof r),
                    a = n || (!0 === r || !0 === o ? "margin": "border");
                    return z(this,
                    function(t, n, r) {
                        var o;
                        return y(t) ? 0 === i.indexOf("outer") ? t["inner" + e] : t.document.documentElement["client" + e] : 9 === t.nodeType ? (o = t.documentElement, Math.max(t.body["scroll" + e], o["scroll" + e], t.body["offset" + e], o["offset" + e], o["client" + e])) : void 0 === r ? S.css(t, n, a) : S.style(t, n, r, a)
                    },
                    t, s ? r: void 0, s)
                }
            })
        }),
        S.each("blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(" "),
        function(e, t) {
            S.fn[t] = function(e, n) {
                return arguments.length > 0 ? this.on(t, null, e, n) : this.trigger(t)
            }
        }),
        S.fn.extend({
            hover: function(e, t) {
                return this.mouseenter(e).mouseleave(t || e)
            }
        }),
        S.fn.extend({
            bind: function(e, t, n) {
                return this.on(e, null, t, n)
            },
            unbind: function(e, t) {
                return this.off(e, null, t)
            },
            delegate: function(e, t, n, i) {
                return this.on(t, e, n, i)
            },
            undelegate: function(e, t, n) {
                return 1 === arguments.length ? this.off(e, "**") : this.off(t, e || "**", n)
            }
        }),
        S.proxy = function(e, t) {
            var n, i, r;
            if ("string" == typeof t && (n = e[t], t = e, e = n), g(e)) return i = u.call(arguments, 2),
            (r = function() {
                return e.apply(t || this, i.concat(u.call(arguments)))
            }).guid = e.guid = e.guid || S.guid++,
            r
        },
        S.holdReady = function(e) {
            e ? S.readyWait++:S.ready(!0)
        },
        S.isArray = Array.isArray,
        S.parseJSON = JSON.parse,
        S.nodeName = C,
        S.isFunction = g,
        S.isWindow = y,
        S.camelCase = $,
        S.type = E,
        S.now = Date.now,
        S.isNumeric = function(e) {
            var t = S.type(e);
            return ("number" === t || "string" === t) && !isNaN(e - parseFloat(e))
        },
        void 0 === (i = function() {
            return S
        }.apply(t, [])) || (e.exports = i);
        var Kt = n.jQuery,
        Xt = n.$;
        return S.noConflict = function(e) {
            return n.$ === S && (n.$ = Xt),
            e && n.jQuery === S && (n.jQuery = Kt),
            S
        },
        r || (n.jQuery = n.$ = S),
        S
    })
},
function(e, t) {
    var n;
    n = function() {
        return this
    } ();
    try {
        n = n || Function("return this")() || (0, eval)("this")
    } catch(e) {
        "object" == typeof window && (n = window)
    }
    e.exports = n
},
function(e, t, n) { (function(t) {
        var n;
        e.exports = function e(t, i, r) {
            function o(a, u) {
                if (!i[a]) {
                    if (!t[a]) {
                        var l = "function" == typeof n && n;
                        if (!u && l) return n(a, !0);
                        if (s) return s(a, !0);
                        var c = new Error("Cannot find module '" + a + "'");
                        throw c.code = "MODULE_NOT_FOUND",
                        c
                    }
                    var d = i[a] = {
                        exports: {}
                    };
                    t[a][0].call(d.exports,
                    function(e) {
                        var n = t[a][1][e];
                        return o(n || e)
                    },
                    d, d.exports, e, t, i, r)
                }
                return i[a].exports
            }
            for (var s = "function" == typeof n && n,
            a = 0; a < r.length; a++) o(r[a]);
            return o
        } ({
            1 : [function(e, n, i) { (function(t, r) {
                    /*!
                         * @overview es6-promise - a tiny implementation of Promises/A+.
                         * @copyright Copyright (c) 2014 Yehuda Katz, Tom Dale, Stefan Penner and contributors (Conversion to ES6 API by Jake Archibald)
                         * @license   Licensed under MIT license
                         *            See https://raw.githubusercontent.com/stefanpenner/es6-promise/master/LICENSE
                         * @version   4.1.0
                         */
                    !
                    function(e, t) {
                        "object" == typeof i && void 0 !== n ? n.exports = t() : e.ES6Promise = t()
                    } (this,
                    function() {
                        "use strict";

                        function n(e) {
                            return "function" == typeof e
                        }
                        var i = Array.isArray ? Array.isArray: function(e) {
                            return "[object Array]" === Object.prototype.toString.call(e)
                        },
                        o = 0,
                        s = void 0,
                        a = void 0,
                        u = function(e, t) {
                            m[o] = e,
                            m[o + 1] = t,
                            2 === (o += 2) && (a ? a(_) : w())
                        },
                        l = "undefined" != typeof window ? window: void 0,
                        c = l || {},
                        d = c.MutationObserver || c.WebKitMutationObserver,
                        f = "undefined" == typeof self && void 0 !== t && "[object process]" === {}.toString.call(t),
                        h = "undefined" != typeof Uint8ClampedArray && "undefined" != typeof importScripts && "undefined" != typeof MessageChannel;

                        function p() {
                            var e = setTimeout;
                            return function() {
                                return e(_, 1)
                            }
                        }
                        var m = new Array(1e3);

                        function _() {
                            for (var e = 0; e < o; e += 2) {
                                var t = m[e],
                                n = m[e + 1];
                                t(n),
                                m[e] = void 0,
                                m[e + 1] = void 0
                            }
                            o = 0
                        }
                        var v, g, y, b, w = void 0;

                        function E(e, t) {
                            var n = arguments,
                            i = this,
                            r = new this.constructor(x);
                            void 0 === r[k] && G(r);
                            var o, s = i._state;
                            return s ? (o = n[s - 1], u(function() {
                                return F(s, r, o, i._result)
                            })) : B(i, r, e, t),
                            r
                        }
                        function S(e) {
                            if (e && "object" == typeof e && e.constructor === this) return e;
                            var t = new this(x);
                            return D(t, e),
                            t
                        }
                        f ? w = function() {
                            return t.nextTick(_)
                        }: d ? (g = 0, y = new d(_), b = document.createTextNode(""), y.observe(b, {
                            characterData: !0
                        }), w = function() {
                            b.data = g = ++g % 2
                        }) : h ? ((v = new MessageChannel).port1.onmessage = _, w = function() {
                            return v.port2.postMessage(0)
                        }) : w = void 0 === l && "function" == typeof e ?
                        function() {
                            try {
                                var t = e,
                                n = t("vertx");
                                return void 0 !== (s = n.runOnLoop || n.runOnContext) ?
                                function() {
                                    s(_)
                                }: p()
                            } catch(e) {
                                return p()
                            }
                        } () : p();
                        var k = Math.random().toString(36).substring(16);

                        function x() {}
                        var L = void 0,
                        T = 1,
                        A = 2,
                        R = new P;

                        function C(e) {
                            try {
                                return e.then
                            } catch(e) {
                                return R.error = e,
                                R
                            }
                        }
                        function O(e, t, i) {
                            t.constructor === e.constructor && i === E && t.constructor.resolve === S ?
                            function(e, t) {
                                t._state === T ? M(e, t._result) : t._state === A ? j(e, t._result) : B(t, void 0,
                                function(t) {
                                    return D(e, t)
                                },
                                function(t) {
                                    return j(e, t)
                                })
                            } (e, t) : i === R ? (j(e, R.error), R.error = null) : void 0 === i ? M(e, t) : n(i) ?
                            function(e, t, n) {
                                u(function(e) {
                                    var i = !1,
                                    r = function(e, t, n, i) {
                                        try {
                                            e.call(t, n, i)
                                        } catch(e) {
                                            return e
                                        }
                                    } (n, t,
                                    function(n) {
                                        i || (i = !0, t !== n ? D(e, n) : M(e, n))
                                    },
                                    function(t) {
                                        i || (i = !0, j(e, t))
                                    },
                                    e._label); ! i && r && (i = !0, j(e, r))
                                },
                                e)
                            } (e, t, i) : M(e, t)
                        }
                        function D(e, t) {
                            var n;
                            e === t ? j(e, new TypeError("You cannot resolve a promise with itself")) : "function" == typeof(n = t) || "object" == typeof n && null !== n ? O(e, t, C(t)) : M(e, t)
                        }
                        function I(e) {
                            e._onerror && e._onerror(e._result),
                            N(e)
                        }
                        function M(e, t) {
                            e._state === L && (e._result = t, e._state = T, 0 !== e._subscribers.length && u(N, e))
                        }
                        function j(e, t) {
                            e._state === L && (e._state = A, e._result = t, u(I, e))
                        }
                        function B(e, t, n, i) {
                            var r = e._subscribers,
                            o = r.length;
                            e._onerror = null,
                            r[o] = t,
                            r[o + T] = n,
                            r[o + A] = i,
                            0 === o && e._state && u(N, e)
                        }
                        function N(e) {
                            var t = e._subscribers,
                            n = e._state;
                            if (0 !== t.length) {
                                for (var i = void 0,
                                r = void 0,
                                o = e._result,
                                s = 0; s < t.length; s += 3) i = t[s],
                                r = t[s + n],
                                i ? F(n, i, r, o) : r(o);
                                e._subscribers.length = 0
                            }
                        }
                        function P() {
                            this.error = null
                        }
                        var U = new P;

                        function F(e, t, i, r) {
                            var o = n(i),
                            s = void 0,
                            a = void 0,
                            u = void 0,
                            l = void 0;
                            if (o) {
                                if ((s = function(e, t) {
                                    try {
                                        return e(t)
                                    } catch(e) {
                                        return U.error = e,
                                        U
                                    }
                                } (i, r)) === U ? (l = !0, a = s.error, s.error = null) : u = !0, t === s) return void j(t, new TypeError("A promises callback cannot return that same promise."))
                            } else s = r,
                            u = !0;
                            t._state !== L || (o && u ? D(t, s) : l ? j(t, a) : e === T ? M(t, s) : e === A && j(t, s))
                        }
                        var W = 0;

                        function G(e) {
                            e[k] = W++,
                            e._state = void 0,
                            e._result = void 0,
                            e._subscribers = []
                        }
                        function H(e, t) {
                            this._instanceConstructor = e,
                            this.promise = new e(x),
                            this.promise[k] || G(this.promise),
                            i(t) ? (this._input = t, this.length = t.length, this._remaining = t.length, this._result = new Array(this.length), 0 === this.length ? M(this.promise, this._result) : (this.length = this.length || 0, this._enumerate(), 0 === this._remaining && M(this.promise, this._result))) : j(this.promise, new Error("Array Methods must be provided an Array"))
                        }
                        function q(e) {
                            this[k] = W++,
                            this._result = this._state = void 0,
                            this._subscribers = [],
                            x !== e && ("function" != typeof e &&
                            function() {
                                throw new TypeError("You must pass a resolver function as the first argument to the promise constructor")
                            } (), this instanceof q ?
                            function(e, t) {
                                try {
                                    t(function(t) {
                                        D(e, t)
                                    },
                                    function(t) {
                                        j(e, t)
                                    })
                                } catch(t) {
                                    j(e, t)
                                }
                            } (this, e) : function() {
                                throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.")
                            } ())
                        }
                        return H.prototype._enumerate = function() {
                            for (var e = this.length,
                            t = this._input,
                            n = 0; this._state === L && n < e; n++) this._eachEntry(t[n], n)
                        },
                        H.prototype._eachEntry = function(e, t) {
                            var n = this._instanceConstructor,
                            i = n.resolve;
                            if (i === S) {
                                var r = C(e);
                                if (r === E && e._state !== L) this._settledAt(e._state, t, e._result);
                                else if ("function" != typeof r) this._remaining--,
                                this._result[t] = e;
                                else if (n === q) {
                                    var o = new n(x);
                                    O(o, e, r),
                                    this._willSettleAt(o, t)
                                } else this._willSettleAt(new n(function(t) {
                                    return t(e)
                                }), t)
                            } else this._willSettleAt(i(e), t)
                        },
                        H.prototype._settledAt = function(e, t, n) {
                            var i = this.promise;
                            i._state === L && (this._remaining--, e === A ? j(i, n) : this._result[t] = n),
                            0 === this._remaining && M(i, this._result)
                        },
                        H.prototype._willSettleAt = function(e, t) {
                            var n = this;
                            B(e, void 0,
                            function(e) {
                                return n._settledAt(T, t, e)
                            },
                            function(e) {
                                return n._settledAt(A, t, e)
                            })
                        },
                        q.all = function(e) {
                            return new H(this, e).promise
                        },
                        q.race = function(e) {
                            var t = this;
                            return i(e) ? new t(function(n, i) {
                                for (var r = e.length,
                                o = 0; o < r; o++) t.resolve(e[o]).then(n, i)
                            }) : new t(function(e, t) {
                                return t(new TypeError("You must pass an array to race."))
                            })
                        },
                        q.resolve = S,
                        q.reject = function(e) {
                            var t = new this(x);
                            return j(t, e),
                            t
                        },
                        q._setScheduler = function(e) {
                            a = e
                        },
                        q._setAsap = function(e) {
                            u = e
                        },
                        q._asap = u,
                        q.prototype = {
                            constructor: q,
                            then: E,
                            catch: function(e) {
                                return this.then(null, e)
                            }
                        },
                        q.polyfill = function() {
                            var e = void 0;
                            if (void 0 !== r) e = r;
                            else if ("undefined" != typeof self) e = self;
                            else try {
                                e = Function("return this")()
                            } catch(e) {
                                throw new Error("polyfill failed because global object is unavailable in this environment")
                            }
                            var t = e.Promise;
                            if (t) {
                                var n = null;
                                try {
                                    n = Object.prototype.toString.call(t.resolve())
                                } catch(e) {}
                                if ("[object Promise]" === n && !t.cast) return
                            }
                            e.Promise = q
                        },
                        q.Promise = q,
                        q
                    })
                }).call(this, e("_process"), void 0 !== t ? t: "undefined" != typeof self ? self: "undefined" != typeof window ? window: {})
            },
            {
                _process: 3
            }],
            2 : [function(e, t, n) {
                function i() {
                    this._events = this._events || {},
                    this._maxListeners = this._maxListeners || void 0
                }
                function r(e) {
                    return "function" == typeof e
                }
                function o(e) {
                    return "object" == typeof e && null !== e
                }
                function s(e) {
                    return void 0 === e
                }
                t.exports = i,
                i.EventEmitter = i,
                i.prototype._events = void 0,
                i.prototype._maxListeners = void 0,
                i.defaultMaxListeners = 10,
                i.prototype.setMaxListeners = function(e) {
                    if ("number" != typeof e || e < 0 || isNaN(e)) throw TypeError("n must be a positive number");
                    return this._maxListeners = e,
                    this
                },
                i.prototype.emit = function(e) {
                    var t, n, i, a, u, l;
                    if (this._events || (this._events = {}), "error" === e && (!this._events.error || o(this._events.error) && !this._events.error.length)) {
                        if ((t = arguments[1]) instanceof Error) throw t;
                        var c = new Error('Uncaught, unspecified "error" event. (' + t + ")");
                        throw c.context = t,
                        c
                    }
                    if (s(n = this._events[e])) return ! 1;
                    if (r(n)) switch (arguments.length) {
                    case 1:
                        n.call(this);
                        break;
                    case 2:
                        n.call(this, arguments[1]);
                        break;
                    case 3:
                        n.call(this, arguments[1], arguments[2]);
                        break;
                    default:
                        a = Array.prototype.slice.call(arguments, 1),
                        n.apply(this, a)
                    } else if (o(n)) for (a = Array.prototype.slice.call(arguments, 1), l = n.slice(), i = l.length, u = 0; u < i; u++) l[u].apply(this, a);
                    return ! 0
                },
                i.prototype.addListener = function(e, t) {
                    var n;
                    if (!r(t)) throw TypeError("listener must be a function");
                    return this._events || (this._events = {}),
                    this._events.newListener && this.emit("newListener", e, r(t.listener) ? t.listener: t),
                    this._events[e] ? o(this._events[e]) ? this._events[e].push(t) : this._events[e] = [this._events[e], t] : this._events[e] = t,
                    o(this._events[e]) && !this._events[e].warned && (n = s(this._maxListeners) ? i.defaultMaxListeners: this._maxListeners) && n > 0 && this._events[e].length > n && (this._events[e].warned = !0, console.error("(node) warning: possible EventEmitter memory leak detected. %d listeners added. Use emitter.setMaxListeners() to increase limit.", this._events[e].length), "function" == typeof console.trace && console.trace()),
                    this
                },
                i.prototype.on = i.prototype.addListener,
                i.prototype.once = function(e, t) {
                    if (!r(t)) throw TypeError("listener must be a function");
                    var n = !1;

                    function i() {
                        this.removeListener(e, i),
                        n || (n = !0, t.apply(this, arguments))
                    }
                    return i.listener = t,
                    this.on(e, i),
                    this
                },
                i.prototype.removeListener = function(e, t) {
                    var n, i, s, a;
                    if (!r(t)) throw TypeError("listener must be a function");
                    if (!this._events || !this._events[e]) return this;
                    if (n = this._events[e], s = n.length, i = -1, n === t || r(n.listener) && n.listener === t) delete this._events[e],
                    this._events.removeListener && this.emit("removeListener", e, t);
                    else if (o(n)) {
                        for (a = s; a-->0;) if (n[a] === t || n[a].listener && n[a].listener === t) {
                            i = a;
                            break
                        }
                        if (i < 0) return this;
                        1 === n.length ? (n.length = 0, delete this._events[e]) : n.splice(i, 1),
                        this._events.removeListener && this.emit("removeListener", e, t)
                    }
                    return this
                },
                i.prototype.removeAllListeners = function(e) {
                    var t, n;
                    if (!this._events) return this;
                    if (!this._events.removeListener) return 0 === arguments.length ? this._events = {}: this._events[e] && delete this._events[e],
                    this;
                    if (0 === arguments.length) {
                        for (t in this._events)"removeListener" !== t && this.removeAllListeners(t);
                        return this.removeAllListeners("removeListener"),
                        this._events = {},
                        this
                    }
                    if (r(n = this._events[e])) this.removeListener(e, n);
                    else if (n) for (; n.length;) this.removeListener(e, n[n.length - 1]);
                    return delete this._events[e],
                    this
                },
                i.prototype.listeners = function(e) {
                    return this._events && this._events[e] ? r(this._events[e]) ? [this._events[e]] : this._events[e].slice() : []
                },
                i.prototype.listenerCount = function(e) {
                    if (this._events) {
                        var t = this._events[e];
                        if (r(t)) return 1;
                        if (t) return t.length
                    }
                    return 0
                },
                i.listenerCount = function(e, t) {
                    return e.listenerCount(t)
                }
            },
            {}],
            3 : [function(e, t, n) {
                var i, r, o = t.exports = {};

                function s() {
                    throw new Error("setTimeout has not been defined")
                }
                function a() {
                    throw new Error("clearTimeout has not been defined")
                }
                function u(e) {
                    if (i === setTimeout) return setTimeout(e, 0);
                    if ((i === s || !i) && setTimeout) return i = setTimeout,
                    setTimeout(e, 0);
                    try {
                        return i(e, 0)
                    } catch(t) {
                        try {
                            return i.call(null, e, 0)
                        } catch(t) {
                            return i.call(this, e, 0)
                        }
                    }
                } !
                function() {
                    try {
                        i = "function" == typeof setTimeout ? setTimeout: s
                    } catch(e) {
                        i = s
                    }
                    try {
                        r = "function" == typeof clearTimeout ? clearTimeout: a
                    } catch(e) {
                        r = a
                    }
                } ();
                var l, c = [],
                d = !1,
                f = -1;

                function h() {
                    d && l && (d = !1, l.length ? c = l.concat(c) : f = -1, c.length && p())
                }
                function p() {
                    if (!d) {
                        var e = u(h);
                        d = !0;
                        for (var t = c.length; t;) {
                            for (l = c, c = []; ++f < t;) l && l[f].run();
                            f = -1,
                            t = c.length
                        }
                        l = null,
                        d = !1,
                        function(e) {
                            if (r === clearTimeout) return clearTimeout(e);
                            if ((r === a || !r) && clearTimeout) return r = clearTimeout,
                            clearTimeout(e);
                            try {
                                r(e)
                            } catch(t) {
                                try {
                                    return r.call(null, e)
                                } catch(t) {
                                    return r.call(this, e)
                                }
                            }
                        } (e)
                    }
                }
                function m(e, t) {
                    this.fun = e,
                    this.array = t
                }
                function _() {}
                o.nextTick = function(e) {
                    var t = new Array(arguments.length - 1);
                    if (arguments.length > 1) for (var n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
                    c.push(new m(e, t)),
                    1 !== c.length || d || u(p)
                },
                m.prototype.run = function() {
                    this.fun.apply(null, this.array)
                },
                o.title = "browser",
                o.browser = !0,
                o.env = {},
                o.argv = [],
                o.version = "",
                o.versions = {},
                o.on = _,
                o.addListener = _,
                o.once = _,
                o.off = _,
                o.removeListener = _,
                o.removeAllListeners = _,
                o.emit = _,
                o.prependListener = _,
                o.prependOnceListener = _,
                o.listeners = function(e) {
                    return []
                },
                o.binding = function(e) {
                    throw new Error("process.binding is not supported")
                },
                o.cwd = function() {
                    return "/"
                },
                o.chdir = function(e) {
                    throw new Error("process.chdir is not supported")
                },
                o.umask = function() {
                    return 0
                }
            },
            {}],
            4 : [function(e, t, n) {
                var i = arguments[3],
                r = arguments[4],
                o = arguments[5],
                s = JSON.stringify;
                t.exports = function(e, t) {
                    for (var n, a = Object.keys(o), u = 0, l = a.length; u < l; u++) {
                        var c = a[u],
                        d = o[c].exports;
                        if (d === e || d && d.
                    default === e) {
                            n = c;
                            break
                        }
                    }
                    if (!n) {
                        n = Math.floor(Math.pow(16, 8) * Math.random()).toString(16);
                        for (var f = {},
                        u = 0,
                        l = a.length; u < l; u++) {
                            var c = a[u];
                            f[c] = c
                        }
                        r[n] = [Function(["require", "module", "exports"], "(" + e + ")(self)"), f]
                    }
                    var h = Math.floor(Math.pow(16, 8) * Math.random()).toString(16),
                    p = {};
                    p[n] = n,
                    r[h] = [Function(["require"], "var f = require(" + s(n) + ");(f.default ? f.default : f)(self);"), p];
                    var m = {}; !
                    function e(t) {
                        for (var n in m[t] = !0, r[t][1]) {
                            var i = r[t][1][n];
                            m[i] || e(i)
                        }
                    } (h);
                    var _ = "(" + i + ")({" + Object.keys(m).map(function(e) {
                        return s(e) + ":[" + r[e][0] + "," + s(r[e][1]) + "]"
                    }).join(",") + "},{},[" + s(h) + "])",
                    v = window.URL || window.webkitURL || window.mozURL || window.msURL,
                    g = new Blob([_], {
                        type: "text/javascript"
                    });
                    if (t && t.bare) return g;
                    var y = v.createObjectURL(g),
                    b = new Worker(y);
                    return b.objectURL = y,
                    b
                }
            },
            {}],
            5 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                }),
                n.createDefaultConfig = function() {
                    return Object.assign({},
                    i)
                };
                var i = n.defaultConfig = {
                    enableWorker: !1,
                    enableStashBuffer: !0,
                    stashInitialSize: void 0,
                    isLive: !1,
                    lazyLoad: !0,
                    lazyLoadMaxDuration: 180,
                    lazyLoadRecoverDuration: 30,
                    deferLoadAfterSourceOpen: !0,
                    autoCleanupMaxBackwardDuration: 180,
                    autoCleanupMinBackwardDuration: 120,
                    statisticsInfoReportInterval: 600,
                    fixAudioTimestampGap: !0,
                    accurateSeek: !1,
                    seekType: "range",
                    seekParamStart: "bstart",
                    seekParamEnd: "bend",
                    rangeLoadZeroStart: !1,
                    customSeekHandler: void 0,
                    reuseRedirectedURL: !1
                }
            },
            {}],
            6 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i, r = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                o = e("../io/io-controller.js"),
                s = (i = o) && i.__esModule ? i: {
                default:
                    i
                },
                a = e("../config.js"),
                u = function() {
                    function e() { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, e)
                    }
                    return r(e, null, [{
                        key: "supportMSEH264Playback",
                        value: function() {
                            return window.MediaSource && window.MediaSource.isTypeSupported('video/mp4; codecs="avc1.42E01E,mp4a.40.2"')
                        }
                    },
                    {
                        key: "supportNetworkStreamIO",
                        value: function() {
                            var e = new s.
                        default({},
                            (0, a.createDefaultConfig)()),
                            t = e.loaderType;
                            return e.destroy(),
                            "fetch-stream-loader" == t || "xhr-moz-chunked-loader" == t
                        }
                    },
                    {
                        key: "getNetworkLoaderTypeName",
                        value: function() {
                            var e = new s.
                        default({},
                            (0, a.createDefaultConfig)()),
                            t = e.loaderType;
                            return e.destroy(),
                            t
                        }
                    },
                    {
                        key: "supportNativeMediaPlayback",
                        value: function(t) {
                            void 0 == e.videoElement && (e.videoElement = window.document.createElement("video"));
                            var n = e.videoElement.canPlayType(t);
                            return "probably" === n || "maybe" == n
                        }
                    },
                    {
                        key: "getFeatureList",
                        value: function() {
                            var t = {
                                mseFlvPlayback: !1,
                                mseLiveFlvPlayback: !1,
                                networkStreamIO: !1,
                                networkLoaderName: "",
                                nativeMP4H264Playback: !1,
                                nativeWebmVP8Playback: !1,
                                nativeWebmVP9Playback: !1
                            };
                            return t.mseFlvPlayback = e.supportMSEH264Playback(),
                            t.networkStreamIO = e.supportNetworkStreamIO(),
                            t.networkLoaderName = e.getNetworkLoaderTypeName(),
                            t.mseLiveFlvPlayback = t.mseFlvPlayback && t.networkStreamIO,
                            t.nativeMP4H264Playback = e.supportNativeMediaPlayback('video/mp4; codecs="avc1.42001E, mp4a.40.2"'),
                            t.nativeWebmVP8Playback = e.supportNativeMediaPlayback('video/webm; codecs="vp8.0, vorbis"'),
                            t.nativeWebmVP9Playback = e.supportNativeMediaPlayback('video/webm; codecs="vp9"'),
                            t
                        }
                    }]),
                    e
                } ();
                n.
            default = u
            },
            {
                "../config.js": 5,
                "../io/io-controller.js": 23
            }],
            7 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                r = function() {
                    function e() { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, e),
                        this.mimeType = null,
                        this.duration = null,
                        this.hasAudio = null,
                        this.hasVideo = null,
                        this.audioCodec = null,
                        this.videoCodec = null,
                        this.audioDataRate = null,
                        this.videoDataRate = null,
                        this.audioSampleRate = null,
                        this.audioChannelCount = null,
                        this.width = null,
                        this.height = null,
                        this.fps = null,
                        this.profile = null,
                        this.level = null,
                        this.refFrames = null,
                        this.chromaFormat = null,
                        this.sarNum = null,
                        this.sarDen = null,
                        this.metadata = null,
                        this.segments = null,
                        this.segmentCount = null,
                        this.hasKeyframesIndex = null,
                        this.keyframesIndex = null
                    }
                    return i(e, [{
                        key: "isComplete",
                        value: function() {
                            var e = !1 === this.hasAudio || !0 === this.hasAudio && null != this.audioCodec && null != this.audioSampleRate && null != this.audioChannelCount,
                            t = !1 === this.hasVideo || !0 === this.hasVideo && null != this.videoCodec && null != this.width && null != this.height && null != this.fps && null != this.profile && null != this.level && null != this.refFrames && null != this.chromaFormat && null != this.sarNum && null != this.sarDen;
                            return null != this.mimeType && null != this.duration && null != this.metadata && null != this.hasKeyframesIndex && e && t
                        }
                    },
                    {
                        key: "isSeekable",
                        value: function() {
                            return ! 0 === this.hasKeyframesIndex
                        }
                    },
                    {
                        key: "getNearestKeyframe",
                        value: function(e) {
                            if (null == this.keyframesIndex) return null;
                            var t = this.keyframesIndex,
                            n = this._search(t.times, e);
                            return {
                                index: n,
                                milliseconds: t.times[n],
                                fileposition: t.filepositions[n]
                            }
                        }
                    },
                    {
                        key: "_search",
                        value: function(e, t) {
                            var n = 0,
                            i = e.length - 1,
                            r = 0,
                            o = 0,
                            s = i;
                            for (t < e[0] && (n = 0, o = s + 1); o <= s;) {
                                if ((r = o + Math.floor((s - o) / 2)) === i || t >= e[r] && t < e[r + 1]) {
                                    n = r;
                                    break
                                }
                                e[r] < t ? o = r + 1 : s = r - 1
                            }
                            return n
                        }
                    }]),
                    e
                } ();
                n.
            default = r
            },
            {}],
            8 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } ();

                function r(e, t) {
                    if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }
                n.SampleInfo = function e(t, n, i, o, s) {
                    r(this, e),
                    this.dts = t,
                    this.pts = n,
                    this.duration = i,
                    this.originalDts = o,
                    this.isSyncPoint = s,
                    this.fileposition = null
                },
                n.MediaSegmentInfo = function() {
                    function e() {
                        r(this, e),
                        this.beginDts = 0,
                        this.endDts = 0,
                        this.beginPts = 0,
                        this.endPts = 0,
                        this.originalBeginDts = 0,
                        this.originalEndDts = 0,
                        this.syncPoints = [],
                        this.firstSample = null,
                        this.lastSample = null
                    }
                    return i(e, [{
                        key: "appendSyncPoint",
                        value: function(e) {
                            e.isSyncPoint = !0,
                            this.syncPoints.push(e)
                        }
                    }]),
                    e
                } (),
                n.IDRSampleList = function() {
                    function e() {
                        r(this, e),
                        this._list = []
                    }
                    return i(e, [{
                        key: "clear",
                        value: function() {
                            this._list = []
                        }
                    },
                    {
                        key: "appendArray",
                        value: function(e) {
                            var t = this._list;
                            0 !== e.length && (t.length > 0 && e[0].originalDts < t[t.length - 1].originalDts && this.clear(), Array.prototype.push.apply(t, e))
                        }
                    },
                    {
                        key: "getLastSyncPointBeforeDts",
                        value: function(e) {
                            if (0 == this._list.length) return null;
                            var t = this._list,
                            n = 0,
                            i = t.length - 1,
                            r = 0,
                            o = 0,
                            s = i;
                            for (e < t[0].dts && (n = 0, o = s + 1); o <= s;) {
                                if ((r = o + Math.floor((s - o) / 2)) === i || e >= t[r].dts && e < t[r + 1].dts) {
                                    n = r;
                                    break
                                }
                                t[r].dts < e ? o = r + 1 : s = r - 1
                            }
                            return this._list[n]
                        }
                    }]),
                    e
                } (),
                n.MediaSegmentInfoList = function() {
                    function e(t) {
                        r(this, e),
                        this._type = t,
                        this._list = [],
                        this._lastAppendLocation = -1
                    }
                    return i(e, [{
                        key: "isEmpty",
                        value: function() {
                            return 0 === this._list.length
                        }
                    },
                    {
                        key: "clear",
                        value: function() {
                            this._list = [],
                            this._lastAppendLocation = -1
                        }
                    },
                    {
                        key: "_searchNearestSegmentBefore",
                        value: function(e) {
                            var t = this._list;
                            if (0 === t.length) return - 2;
                            var n = t.length - 1,
                            i = 0,
                            r = 0,
                            o = n,
                            s = 0;
                            if (e < t[0].originalBeginDts) return s = -1;
                            for (; r <= o;) {
                                if ((i = r + Math.floor((o - r) / 2)) === n || e > t[i].lastSample.originalDts && e < t[i + 1].originalBeginDts) {
                                    s = i;
                                    break
                                }
                                t[i].originalBeginDts < e ? r = i + 1 : o = i - 1
                            }
                            return s
                        }
                    },
                    {
                        key: "_searchNearestSegmentAfter",
                        value: function(e) {
                            return this._searchNearestSegmentBefore(e) + 1
                        }
                    },
                    {
                        key: "append",
                        value: function(e) {
                            var t = this._list,
                            n = e,
                            i = this._lastAppendLocation,
                            r = 0; - 1 !== i && i < t.length && n.originalBeginDts >= t[i].lastSample.originalDts && (i === t.length - 1 || i < t.length - 1 && n.originalBeginDts < t[i + 1].originalBeginDts) ? r = i + 1 : t.length > 0 && (r = this._searchNearestSegmentBefore(n.originalBeginDts) + 1),
                            this._lastAppendLocation = r,
                            this._list.splice(r, 0, n)
                        }
                    },
                    {
                        key: "getLastSegmentBefore",
                        value: function(e) {
                            var t = this._searchNearestSegmentBefore(e);
                            return t >= 0 ? this._list[t] : null
                        }
                    },
                    {
                        key: "getLastSampleBefore",
                        value: function(e) {
                            var t = this.getLastSegmentBefore(e);
                            return null != t ? t.lastSample: null
                        }
                    },
                    {
                        key: "getLastSyncPointBefore",
                        value: function(e) {
                            for (var t = this._searchNearestSegmentBefore(e), n = this._list[t].syncPoints; 0 === n.length && t > 0;) t--,
                            n = this._list[t].syncPoints;
                            return n.length > 0 ? n[n.length - 1] : null
                        }
                    },
                    {
                        key: "type",
                        get: function() {
                            return this._type
                        }
                    },
                    {
                        key: "length",
                        get: function() {
                            return this._list.length
                        }
                    }]),
                    e
                } ()
            },
            {}],
            9 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                r = e("events"),
                o = p(r),
                s = e("../utils/logger.js"),
                a = p(s),
                u = e("../utils/browser.js"),
                l = p(u),
                c = e("./mse-events.js"),
                d = p(c),
                f = e("./media-segment-info.js"),
                h = e("../utils/exception.js");

                function p(e) {
                    return e && e.__esModule ? e: {
                    default:
                        e
                    }
                }
                var m = function() {
                    function e(t) { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, e),
                        this.TAG = "MSEController",
                        this._config = t,
                        this._emitter = new o.
                    default,
                        this._config.isLive && void 0 == this._config.autoCleanupSourceBuffer && (this._config.autoCleanupSourceBuffer = !0),
                        this.e = {
                            onSourceOpen: this._onSourceOpen.bind(this),
                            onSourceEnded: this._onSourceEnded.bind(this),
                            onSourceClose: this._onSourceClose.bind(this),
                            onSourceBufferError: this._onSourceBufferError.bind(this),
                            onSourceBufferUpdateEnd: this._onSourceBufferUpdateEnd.bind(this)
                        },
                        this._mediaSource = null,
                        this._mediaSourceObjectURL = null,
                        this._mediaElement = null,
                        this._isBufferFull = !1,
                        this._hasPendingEos = !1,
                        this._requireSetMediaDuration = !1,
                        this._pendingMediaDuration = 0,
                        this._pendingSourceBufferInit = [],
                        this._mimeTypes = {
                            video: null,
                            audio: null
                        },
                        this._sourceBuffers = {
                            video: null,
                            audio: null
                        },
                        this._lastInitSegments = {
                            video: null,
                            audio: null
                        },
                        this._pendingSegments = {
                            video: [],
                            audio: []
                        },
                        this._pendingRemoveRanges = {
                            video: [],
                            audio: []
                        },
                        this._idrList = new f.IDRSampleList
                    }
                    return i(e, [{
                        key: "destroy",
                        value: function() { (this._mediaElement || this._mediaSource) && this.detachMediaElement(),
                            this.e = null,
                            this._emitter.removeAllListeners(),
                            this._emitter = null
                        }
                    },
                    {
                        key: "on",
                        value: function(e, t) {
                            this._emitter.addListener(e, t)
                        }
                    },
                    {
                        key: "off",
                        value: function(e, t) {
                            this._emitter.removeListener(e, t)
                        }
                    },
                    {
                        key: "attachMediaElement",
                        value: function(e) {
                            if (this._mediaSource) throw new h.IllegalStateException("MediaSource has been attached to an HTMLMediaElement!");
                            var t = this._mediaSource = new window.MediaSource;
                            t.addEventListener("sourceopen", this.e.onSourceOpen),
                            t.addEventListener("sourceended", this.e.onSourceEnded),
                            t.addEventListener("sourceclose", this.e.onSourceClose),
                            this._mediaElement = e,
                            this._mediaSourceObjectURL = window.URL.createObjectURL(this._mediaSource),
                            e.src = this._mediaSourceObjectURL
                        }
                    },
                    {
                        key: "detachMediaElement",
                        value: function() {
                            if (this._mediaSource) {
                                var e = this._mediaSource;
                                for (var t in this._sourceBuffers) {
                                    var n = this._pendingSegments[t];
                                    n.splice(0, n.length),
                                    this._pendingSegments[t] = null,
                                    this._pendingRemoveRanges[t] = null,
                                    this._lastInitSegments[t] = null;
                                    var i = this._sourceBuffers[t];
                                    i && ("closed" !== e.readyState && (e.removeSourceBuffer(i), i.removeEventListener("error", this.e.onSourceBufferError), i.removeEventListener("updateend", this.e.onSourceBufferUpdateEnd)), this._mimeTypes[t] = null, this._sourceBuffers[t] = null)
                                }
                                if ("open" === e.readyState) try {
                                    e.endOfStream()
                                } catch(e) {
                                    a.
                                default.e(this.TAG, e.message)
                                }
                                e.removeEventListener("sourceopen", this.e.onSourceOpen),
                                e.removeEventListener("sourceended", this.e.onSourceEnded),
                                e.removeEventListener("sourceclose", this.e.onSourceClose),
                                this._pendingSourceBufferInit = [],
                                this._isBufferFull = !1,
                                this._idrList.clear(),
                                this._mediaSource = null
                            }
                            this._mediaElement && (this._mediaElement.src = "", this._mediaElement.removeAttribute("src"), this._mediaElement = null),
                            this._mediaSourceObjectURL && (window.URL.revokeObjectURL(this._mediaSourceObjectURL), this._mediaSourceObjectURL = null)
                        }
                    },
                    {
                        key: "appendInitSegment",
                        value: function(e, t) {
                            if (!this._mediaSource || "open" !== this._mediaSource.readyState) return this._pendingSourceBufferInit.push(e),
                            void this._pendingSegments[e.type].push(e);
                            var n = e,
                            i = "" + n.container;
                            n.codec && n.codec.length > 0 && (i += ";codecs=" + n.codec);
                            var r = !1;
                            if (a.
                        default.v(this.TAG, "Received Initialization Segment, mimeType: " + i), this._lastInitSegments[n.type] = n, i !== this._mimeTypes[n.type]) {
                                if (this._mimeTypes[n.type]) a.
                            default.v(this.TAG, "Notice: " + n.type + " mimeType changed, origin: " + this._mimeTypes[n.type] + ", target: " + i);
                                else {
                                    r = !0;
                                    try {
                                        if (l.
                                    default.webkit && "video" === n.type) for (var o = 1 * new Date; 1 * new Date - o < 1e3;);
                                        var s = this._sourceBuffers[n.type] = this._mediaSource.addSourceBuffer(i);
                                        s.addEventListener("error", this.e.onSourceBufferError),
                                        s.addEventListener("updateend", this.e.onSourceBufferUpdateEnd)
                                    } catch(e) {
                                        return a.
                                    default.e(this.TAG, e.message),
                                        void this._emitter.emit(d.
                                    default.ERROR, {
                                            code: e.code,
                                            msg: e.message
                                        })
                                    }
                                }
                                this._mimeTypes[n.type] = i
                            }
                            t || this._pendingSegments[n.type].push(n),
                            r || this._sourceBuffers[n.type] && !this._sourceBuffers[n.type].updating && this._doAppendSegments(),
                            l.
                        default.safari && "audio/mpeg" === n.container && n.mediaDuration > 0 && (this._requireSetMediaDuration = !0, this._pendingMediaDuration = n.mediaDuration / 1e3, this._updateMediaSourceDuration())
                        }
                    },
                    {
                        key: "appendMediaSegment",
                        value: function(e) {
                            var t = e;
                            this._pendingSegments[t.type].push(t),
                            this._config.autoCleanupSourceBuffer && this._needCleanupSourceBuffer() && this._doCleanupSourceBuffer();
                            var n = this._sourceBuffers[t.type]; ! n || n.updating || this._hasPendingRemoveRanges() || this._doAppendSegments()
                        }
                    },
                    {
                        key: "seek",
                        value: function(e) {
                            for (var t in this._sourceBuffers) if (this._sourceBuffers[t]) {
                                var n = this._sourceBuffers[t];
                                if ("open" === this._mediaSource.readyState) try {
                                    n.abort()
                                } catch(e) {
                                    a.
                                default.e(this.TAG, e.message)
                                }
                                this._idrList.clear();
                                var i = this._pendingSegments[t];
                                if (i.splice(0, i.length), "closed" !== this._mediaSource.readyState) {
                                    for (var r = 0; r < n.buffered.length; r++) {
                                        var o = n.buffered.start(r),
                                        s = n.buffered.end(r);
                                        this._pendingRemoveRanges[t].push({
                                            start: o,
                                            end: s
                                        })
                                    }
                                    if (n.updating || this._doRemoveRanges(), l.
                                default.safari) {
                                        var u = this._lastInitSegments[t];
                                        u && (this._pendingSegments[t].push(u), n.updating || this._doAppendSegments())
                                    }
                                }
                            }
                        }
                    },
                    {
                        key: "endOfStream",
                        value: function() {
                            var e = this._mediaSource,
                            t = this._sourceBuffers;
                            e && "open" === e.readyState ? t.video && t.video.updating || t.audio && t.audio.updating ? this._hasPendingEos = !0 : (this._hasPendingEos = !1, e.endOfStream()) : e && "closed" === e.readyState && this._hasPendingSegments() && (this._hasPendingEos = !0)
                        }
                    },
                    {
                        key: "getNearestKeyframe",
                        value: function(e) {
                            return this._idrList.getLastSyncPointBeforeDts(e)
                        }
                    },
                    {
                        key: "_needCleanupSourceBuffer",
                        value: function() {
                            if (!this._config.autoCleanupSourceBuffer) return ! 1;
                            var e = this._mediaElement.currentTime;
                            for (var t in this._sourceBuffers) {
                                var n = this._sourceBuffers[t];
                                if (n) {
                                    var i = n.buffered;
                                    if (i.length >= 1 && e - i.start(0) >= this._config.autoCleanupMaxBackwardDuration) return ! 0
                                }
                            }
                            return ! 1
                        }
                    },
                    {
                        key: "_doCleanupSourceBuffer",
                        value: function() {
                            var e = this._mediaElement.currentTime;
                            for (var t in this._sourceBuffers) {
                                var n = this._sourceBuffers[t];
                                if (n) {
                                    for (var i = n.buffered,
                                    r = !1,
                                    o = 0; o < i.length; o++) {
                                        var s = i.start(o),
                                        a = i.end(o);
                                        if (s <= e && e < a + 3) {
                                            if (e - s >= this._config.autoCleanupMaxBackwardDuration) {
                                                r = !0;
                                                var u = e - this._config.autoCleanupMinBackwardDuration;
                                                this._pendingRemoveRanges[t].push({
                                                    start: s,
                                                    end: u
                                                })
                                            }
                                        } else a < e && (r = !0, this._pendingRemoveRanges[t].push({
                                            start: s,
                                            end: a
                                        }))
                                    }
                                    r && !n.updating && this._doRemoveRanges()
                                }
                            }
                        }
                    },
                    {
                        key: "_updateMediaSourceDuration",
                        value: function() {
                            var e = this._sourceBuffers;
                            if (0 !== this._mediaElement.readyState && "open" === this._mediaSource.readyState && !(e.video && e.video.updating || e.audio && e.audio.updating)) {
                                var t = this._mediaSource.duration,
                                n = this._pendingMediaDuration;
                                n > 0 && (isNaN(t) || n > t) && (a.
                            default.v(this.TAG, "Update MediaSource duration from " + t + " to " + n), this._mediaSource.duration = n),
                                this._requireSetMediaDuration = !1,
                                this._pendingMediaDuration = 0
                            }
                        }
                    },
                    {
                        key: "_doRemoveRanges",
                        value: function() {
                            for (var e in this._pendingRemoveRanges) if (this._sourceBuffers[e] && !this._sourceBuffers[e].updating) for (var t = this._sourceBuffers[e], n = this._pendingRemoveRanges[e]; n.length && !t.updating;) {
                                var i = n.shift();
                                t.remove(i.start, i.end)
                            }
                        }
                    },
                    {
                        key: "_doAppendSegments",
                        value: function() {
                            var e = this._pendingSegments;
                            for (var t in e) if (this._sourceBuffers[t] && !this._sourceBuffers[t].updating && e[t].length > 0) {
                                var n = e[t].shift();
                                if (n.timestampOffset) {
                                    var i = this._sourceBuffers[t].timestampOffset,
                                    r = n.timestampOffset / 1e3,
                                    o = Math.abs(i - r);
                                    o > .1 && (a.
                                default.v(this.TAG, "Update MPEG audio timestampOffset from " + i + " to " + r), this._sourceBuffers[t].timestampOffset = r),
                                    delete n.timestampOffset
                                }
                                if (!n.data || 0 === n.data.byteLength) continue;
                                try {
                                    this._sourceBuffers[t].appendBuffer(n.data),
                                    this._isBufferFull = !1,
                                    "video" === t && n.hasOwnProperty("info") && this._idrList.appendArray(n.info.syncPoints)
                                } catch(e) {
                                    this._pendingSegments[t].unshift(n),
                                    22 === e.code ? (this._isBufferFull || this._emitter.emit(d.
                                default.BUFFER_FULL), this._isBufferFull = !0) : (a.
                                default.e(this.TAG, e.message), this._emitter.emit(d.
                                default.ERROR, {
                                        code: e.code,
                                        msg: e.message
                                    }))
                                }
                            }
                        }
                    },
                    {
                        key: "_onSourceOpen",
                        value: function() {
                            if (a.
                        default.v(this.TAG, "MediaSource onSourceOpen"), this._mediaSource.removeEventListener("sourceopen", this.e.onSourceOpen), this._pendingSourceBufferInit.length > 0) for (var e = this._pendingSourceBufferInit; e.length;) {
                                var t = e.shift();
                                this.appendInitSegment(t, !0)
                            }
                            this._hasPendingSegments() && this._doAppendSegments(),
                            this._emitter.emit(d.
                        default.SOURCE_OPEN)
                        }
                    },
                    {
                        key: "_onSourceEnded",
                        value: function() {
                            a.
                        default.v(this.TAG, "MediaSource onSourceEnded")
                        }
                    },
                    {
                        key: "_onSourceClose",
                        value: function() {
                            a.
                        default.v(this.TAG, "MediaSource onSourceClose"),
                            this._mediaSource && null != this.e && (this._mediaSource.removeEventListener("sourceopen", this.e.onSourceOpen), this._mediaSource.removeEventListener("sourceended", this.e.onSourceEnded), this._mediaSource.removeEventListener("sourceclose", this.e.onSourceClose))
                        }
                    },
                    {
                        key: "_hasPendingSegments",
                        value: function() {
                            var e = this._pendingSegments;
                            return e.video.length > 0 || e.audio.length > 0
                        }
                    },
                    {
                        key: "_hasPendingRemoveRanges",
                        value: function() {
                            var e = this._pendingRemoveRanges;
                            return e.video.length > 0 || e.audio.length > 0
                        }
                    },
                    {
                        key: "_onSourceBufferUpdateEnd",
                        value: function() {
                            this._requireSetMediaDuration ? this._updateMediaSourceDuration() : this._hasPendingRemoveRanges() ? this._doRemoveRanges() : this._hasPendingSegments() ? this._doAppendSegments() : this._hasPendingEos && this.endOfStream(),
                            this._emitter.emit(d.
                        default.UPDATE_END)
                        }
                    },
                    {
                        key: "_onSourceBufferError",
                        value: function(e) {
                            a.
                        default.e(this.TAG, "SourceBuffer Error: " + e)
                        }
                    }]),
                    e
                } ();
                n.
            default = m
            },
            {
                "../utils/browser.js": 39,
                "../utils/exception.js": 40,
                "../utils/logger.js": 41,
                "./media-segment-info.js": 8,
                "./mse-events.js": 10,
                events: 2
            }],
            10 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                }),
                n.
            default = {
                    ERROR: "error",
                    SOURCE_OPEN: "source_open",
                    UPDATE_END: "update_end",
                    BUFFER_FULL: "buffer_full"
                }
            },
            {}],
            11 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                r = e("events"),
                o = g(r),
                s = e("../utils/logger.js"),
                a = g(s),
                u = e("../utils/logging-control.js"),
                l = g(u),
                c = e("./transmuxing-controller.js"),
                d = g(c),
                f = e("./transmuxing-events.js"),
                h = g(f),
                p = e("./transmuxing-worker.js"),
                m = g(p),
                _ = e("./media-info.js"),
                v = g(_);

                function g(e) {
                    return e && e.__esModule ? e: {
                    default:
                        e
                    }
                }
                var y = function() {
                    function t(n, i) {
                        if (function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, t), this.TAG = "Transmuxer", this._emitter = new o.
                    default, i.enableWorker && "undefined" != typeof Worker) try {
                            var r = e("webworkify");
                            this._worker = r(m.
                        default),
                            this._workerDestroying = !1,
                            this._worker.addEventListener("message", this._onWorkerMessage.bind(this)),
                            this._worker.postMessage({
                                cmd: "init",
                                param: [n, i]
                            }),
                            this.e = {
                                onLoggingConfigChanged: this._onLoggingConfigChanged.bind(this)
                            },
                            l.
                        default.registerListener(this.e.onLoggingConfigChanged),
                            this._worker.postMessage({
                                cmd: "logging_config",
                                param: l.
                            default.getConfig()
                            })
                        } catch(e) {
                            a.
                        default.e(this.TAG, "Error while initialize transmuxing worker, fallback to inline transmuxing"),
                            this._worker = null,
                            this._controller = new d.
                        default(n, i)
                        } else this._controller = new d.
                    default(n, i);
                        if (this._controller) {
                            var s = this._controller;
                            s.on(h.
                        default.IO_ERROR, this._onIOError.bind(this)),
                            s.on(h.
                        default.DEMUX_ERROR, this._onDemuxError.bind(this)),
                            s.on(h.
                        default.INIT_SEGMENT, this._onInitSegment.bind(this)),
                            s.on(h.
                        default.MEDIA_SEGMENT, this._onMediaSegment.bind(this)),
                            s.on(h.
                        default.LOADING_COMPLETE, this._onLoadingComplete.bind(this)),
                            s.on(h.
                        default.RECOVERED_EARLY_EOF, this._onRecoveredEarlyEof.bind(this)),
                            s.on(h.
                        default.MEDIA_INFO, this._onMediaInfo.bind(this)),
                            s.on(h.
                        default.STATISTICS_INFO, this._onStatisticsInfo.bind(this)),
                            s.on(h.
                        default.RECOMMEND_SEEKPOINT, this._onRecommendSeekpoint.bind(this))
                        }
                    }
                    return i(t, [{
                        key: "destroy",
                        value: function() {
                            this._worker ? this._workerDestroying || (this._workerDestroying = !0, this._worker.postMessage({
                                cmd: "destroy"
                            }), l.
                        default.removeListener(this.e.onLoggingConfigChanged), this.e = null) : (this._controller.destroy(), this._controller = null),
                            this._emitter.removeAllListeners(),
                            this._emitter = null
                        }
                    },
                    {
                        key: "on",
                        value: function(e, t) {
                            this._emitter.addListener(e, t)
                        }
                    },
                    {
                        key: "off",
                        value: function(e, t) {
                            this._emitter.removeListener(e, t)
                        }
                    },
                    {
                        key: "hasWorker",
                        value: function() {
                            return null != this._worker
                        }
                    },
                    {
                        key: "open",
                        value: function() {
                            this._worker ? this._worker.postMessage({
                                cmd: "start"
                            }) : this._controller.start()
                        }
                    },
                    {
                        key: "sendWSData",
                        value: function(e) {
                            this._worker ? this._worker.postMessage({
                                cmd: "sendWSData",
                                data: e
                            }) : this._controller.sendWSData(e)
                        }
                    },
                    {
                        key: "close",
                        value: function() {
                            this._worker ? this._worker.postMessage({
                                cmd: "stop"
                            }) : this._controller.stop()
                        }
                    },
                    {
                        key: "seek",
                        value: function(e) {
                            this._worker ? this._worker.postMessage({
                                cmd: "seek",
                                param: e
                            }) : this._controller.seek(e)
                        }
                    },
                    {
                        key: "pause",
                        value: function() {
                            this._worker ? this._worker.postMessage({
                                cmd: "pause"
                            }) : this._controller.pause()
                        }
                    },
                    {
                        key: "resume",
                        value: function() {
                            this._worker ? this._worker.postMessage({
                                cmd: "resume"
                            }) : this._controller.resume()
                        }
                    },
                    {
                        key: "_onInitSegment",
                        value: function(e, t) {
                            var n = this;
                            Promise.resolve().then(function() {
                                n._emitter.emit(h.
                            default.INIT_SEGMENT, e, t)
                            })
                        }
                    },
                    {
                        key: "_onMediaSegment",
                        value: function(e, t) {
                            var n = this;
                            Promise.resolve().then(function() {
                                n._emitter.emit(h.
                            default.MEDIA_SEGMENT, e, t)
                            })
                        }
                    },
                    {
                        key: "_onLoadingComplete",
                        value: function() {
                            var e = this;
                            Promise.resolve().then(function() {
                                e._emitter.emit(h.
                            default.LOADING_COMPLETE)
                            })
                        }
                    },
                    {
                        key: "_onRecoveredEarlyEof",
                        value: function() {
                            var e = this;
                            Promise.resolve().then(function() {
                                e._emitter.emit(h.
                            default.RECOVERED_EARLY_EOF)
                            })
                        }
                    },
                    {
                        key: "_onMediaInfo",
                        value: function(e) {
                            var t = this;
                            Promise.resolve().then(function() {
                                t._emitter.emit(h.
                            default.MEDIA_INFO, e)
                            })
                        }
                    },
                    {
                        key: "_onStatisticsInfo",
                        value: function(e) {
                            var t = this;
                            Promise.resolve().then(function() {
                                t._emitter.emit(h.
                            default.STATISTICS_INFO, e)
                            })
                        }
                    },
                    {
                        key: "_onIOError",
                        value: function(e, t) {
                            var n = this;
                            Promise.resolve().then(function() {
                                n._emitter.emit(h.
                            default.IO_ERROR, e, t)
                            })
                        }
                    },
                    {
                        key: "_onDemuxError",
                        value: function(e, t) {
                            var n = this;
                            Promise.resolve().then(function() {
                                n._emitter.emit(h.
                            default.DEMUX_ERROR, e, t)
                            })
                        }
                    },
                    {
                        key: "_onRecommendSeekpoint",
                        value: function(e) {
                            var t = this;
                            Promise.resolve().then(function() {
                                t._emitter.emit(h.
                            default.RECOMMEND_SEEKPOINT, e)
                            })
                        }
                    },
                    {
                        key: "_onLoggingConfigChanged",
                        value: function(e) {
                            this._worker && this._worker.postMessage({
                                cmd: "logging_config",
                                param: e
                            })
                        }
                    },
                    {
                        key: "_onWorkerMessage",
                        value: function(e) {
                            var t = e.data,
                            n = t.data;
                            if ("destroyed" === t.msg || this._workerDestroying) return this._workerDestroying = !1,
                            this._worker.terminate(),
                            void(this._worker = null);
                            switch (t.msg) {
                            case h.
                            default.INIT_SEGMENT:
                            case h.
                            default.MEDIA_SEGMENT:
                                this._emitter.emit(t.msg, n.type, n.data);
                                break;
                            case h.
                            default.LOADING_COMPLETE:
                            case h.
                            default.RECOVERED_EARLY_EOF:
                                this._emitter.emit(t.msg);
                                break;
                            case h.
                            default.MEDIA_INFO:
                                Object.setPrototypeOf(n, v.
                            default.prototype),
                                this._emitter.emit(t.msg, n);
                                break;
                            case h.
                            default.STATISTICS_INFO:
                                this._emitter.emit(t.msg, n);
                                break;
                            case h.
                            default.IO_ERROR:
                            case h.
                            default.DEMUX_ERROR:
                                this._emitter.emit(t.msg, n.type, n.info);
                                break;
                            case h.
                            default.RECOMMEND_SEEKPOINT:
                                this._emitter.emit(t.msg, n);
                                break;
                            case "logcat_callback":
                                a.
                            default.emitter.emit("log", n.type, n.logcat)
                            }
                        }
                    }]),
                    t
                } ();
                n.
            default = y
            },
            {
                "../utils/logger.js": 41,
                "../utils/logging-control.js": 42,
                "./media-info.js": 7,
                "./transmuxing-controller.js": 12,
                "./transmuxing-events.js": 13,
                "./transmuxing-worker.js": 14,
                events: 2,
                webworkify: 4
            }],
            12 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                r = e("events"),
                o = E(r),
                s = e("../utils/logger.js"),
                a = E(s),
                u = e("../utils/browser.js"),
                l = E(u),
                c = e("./media-info.js"),
                d = E(c),
                f = e("../demux/flv-demuxer.js"),
                h = E(f),
                p = e("../remux/mp4-remuxer.js"),
                m = E(p),
                _ = e("../demux/demux-errors.js"),
                v = E(_),
                g = e("../io/io-controller.js"),
                y = E(g),
                b = e("./transmuxing-events.js"),
                w = E(b);

                function E(e) {
                    return e && e.__esModule ? e: {
                    default:
                        e
                    }
                }
                e("../io/loader.js");
                var S = function() {
                    function e(t, n) { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, e),
                        this.TAG = "TransmuxingController",
                        this._emitter = new o.
                    default,
                        this._config = n,
                        t.segments || (t.segments = [{
                            duration: t.duration,
                            filesize: t.filesize,
                            url: t.url
                        }]),
                        "boolean" != typeof t.cors && (t.cors = !0),
                        "boolean" != typeof t.withCredentials && (t.withCredentials = !1),
                        this._mediaDataSource = t,
                        this._currentSegmentIndex = 0;
                        var i = 0;
                        this._mediaDataSource.segments.forEach(function(e) {
                            e.timestampBase = i,
                            i += e.duration,
                            e.cors = t.cors,
                            e.withCredentials = t.withCredentials,
                            n.referrerPolicy && (e.referrerPolicy = n.referrerPolicy)
                        }),
                        isNaN(i) || this._mediaDataSource.duration === i || (this._mediaDataSource.duration = i),
                        this._mediaInfo = null,
                        this._demuxer = null,
                        this._remuxer = null,
                        this._ioctl = null,
                        this._pendingSeekTime = null,
                        this._pendingResolveSeekPoint = null,
                        this._statisticsReporter = null
                    }
                    return i(e, [{
                        key: "destroy",
                        value: function() {
                            this._mediaInfo = null,
                            this._mediaDataSource = null,
                            this._statisticsReporter && this._disableStatisticsReporter(),
                            this._ioctl && (this._ioctl.destroy(), this._ioctl = null),
                            this._demuxer && (this._demuxer.destroy(), this._demuxer = null),
                            this._remuxer && (this._remuxer.destroy(), this._remuxer = null),
                            this._emitter.removeAllListeners(),
                            this._emitter = null
                        }
                    },
                    {
                        key: "on",
                        value: function(e, t) {
                            this._emitter.addListener(e, t)
                        }
                    },
                    {
                        key: "off",
                        value: function(e, t) {
                            this._emitter.removeListener(e, t)
                        }
                    },
                    {
                        key: "start",
                        value: function() {
                            this._loadSegment(0),
                            this._enableStatisticsReporter()
                        }
                    },
                    {
                        key: "_loadSegment",
                        value: function(e, t) {
                            this._currentSegmentIndex = e;
                            var n = this._mediaDataSource.segments[e],
                            i = this._ioctl = new y.
                        default(n, this._config, e);
                            i.onError = this._onIOException.bind(this),
                            i.onSeeked = this._onIOSeeked.bind(this),
                            i.onComplete = this._onIOComplete.bind(this),
                            i.onRedirect = this._onIORedirect.bind(this),
                            i.onRecoveredEarlyEof = this._onIORecoveredEarlyEof.bind(this),
                            t ? this._demuxer.bindDataSource(this._ioctl) : i.onDataArrival = this._onInitChunkArrival.bind(this),
                            i.open(t)
                        }
                    },
                    {
                        key: "stop",
                        value: function() {
                            this._internalAbort(),
                            this._disableStatisticsReporter()
                        }
                    },
                    {
                        key: "_internalAbort",
                        value: function() {
                            this._ioctl && (this._ioctl.destroy(), this._ioctl = null)
                        }
                    },
                    {
                        key: "pause",
                        value: function() {
                            this._ioctl && this._ioctl.isWorking() && (this._ioctl.pause(), this._disableStatisticsReporter())
                        }
                    },
                    {
                        key: "resume",
                        value: function() {
                            this._ioctl && this._ioctl.isPaused() && (this._ioctl.resume(), this._enableStatisticsReporter())
                        }
                    },
                    {
                        key: "sendWSData",
                        value: function(e) {
                            this._ioctl && this._ioctl.sendWSData(e)
                        }
                    },
                    {
                        key: "seek",
                        value: function(e) {
                            if (null != this._mediaInfo && this._mediaInfo.isSeekable()) {
                                var t = this._searchSegmentIndexContains(e);
                                if (t === this._currentSegmentIndex) {
                                    var n = this._mediaInfo.segments[t];
                                    if (void 0 == n) this._pendingSeekTime = e;
                                    else {
                                        var i = n.getNearestKeyframe(e);
                                        this._remuxer.seek(i.milliseconds),
                                        this._ioctl.seek(i.fileposition),
                                        this._pendingResolveSeekPoint = i.milliseconds
                                    }
                                } else {
                                    var r = this._mediaInfo.segments[t];
                                    if (void 0 == r) this._pendingSeekTime = e,
                                    this._internalAbort(),
                                    this._remuxer.seek(),
                                    this._remuxer.insertDiscontinuity(),
                                    this._loadSegment(t);
                                    else {
                                        var o = r.getNearestKeyframe(e);
                                        this._internalAbort(),
                                        this._remuxer.seek(e),
                                        this._remuxer.insertDiscontinuity(),
                                        this._demuxer.resetMediaInfo(),
                                        this._demuxer.timestampBase = this._mediaDataSource.segments[t].timestampBase,
                                        this._loadSegment(t, o.fileposition),
                                        this._pendingResolveSeekPoint = o.milliseconds,
                                        this._reportSegmentMediaInfo(t)
                                    }
                                }
                                this._enableStatisticsReporter()
                            }
                        }
                    },
                    {
                        key: "_searchSegmentIndexContains",
                        value: function(e) {
                            for (var t = this._mediaDataSource.segments,
                            n = t.length - 1,
                            i = 0; i < t.length; i++) if (e < t[i].timestampBase) {
                                n = i - 1;
                                break
                            }
                            return n
                        }
                    },
                    {
                        key: "_onInitChunkArrival",
                        value: function(e, t) {
                            var n = this,
                            i = null,
                            r = 0;
                            if (t > 0) this._demuxer.bindDataSource(this._ioctl),
                            this._demuxer.timestampBase = this._mediaDataSource.segments[this._currentSegmentIndex].timestampBase,
                            r = this._demuxer.parseChunks(e, t);
                            else if ((i = h.
                        default.probe(e)).match) {
                                this._demuxer = new h.
                            default(i, this._config),
                                this._remuxer || (this._remuxer = new m.
                            default(this._config));
                                var o = this._mediaDataSource;
                                void 0 == o.duration || isNaN(o.duration) || (this._demuxer.overridedDuration = o.duration),
                                "boolean" == typeof o.hasAudio && (this._demuxer.overridedHasAudio = o.hasAudio),
                                "boolean" == typeof o.hasVideo && (this._demuxer.overridedHasVideo = o.hasVideo),
                                this._demuxer.timestampBase = o.segments[this._currentSegmentIndex].timestampBase,
                                this._demuxer.onError = this._onDemuxException.bind(this),
                                this._demuxer.onMediaInfo = this._onMediaInfo.bind(this),
                                this._remuxer.bindDataSource(this._demuxer.bindDataSource(this._ioctl)),
                                this._remuxer.onInitSegment = this._onRemuxerInitSegmentArrival.bind(this),
                                this._remuxer.onMediaSegment = this._onRemuxerMediaSegmentArrival.bind(this),
                                r = this._demuxer.parseChunks(e, t)
                            } else i = null,
                            a.
                        default.e(this.TAG, "Non-FLV, Unsupported media type!"),
                            Promise.resolve().then(function() {
                                n._internalAbort()
                            }),
                            this._emitter.emit(w.
                        default.DEMUX_ERROR, v.
                        default.FORMAT_UNSUPPORTED, "Non-FLV, Unsupported media type"),
                            r = 0;
                            return r
                        }
                    },
                    {
                        key: "_onMediaInfo",
                        value: function(e) {
                            var t = this;
                            null == this._mediaInfo && (this._mediaInfo = Object.assign({},
                            e), this._mediaInfo.keyframesIndex = null, this._mediaInfo.segments = [], this._mediaInfo.segmentCount = this._mediaDataSource.segments.length, Object.setPrototypeOf(this._mediaInfo, d.
                        default.prototype));
                            var n = Object.assign({},
                            e);
                            Object.setPrototypeOf(n, d.
                        default.prototype),
                            this._mediaInfo.segments[this._currentSegmentIndex] = n,
                            this._reportSegmentMediaInfo(this._currentSegmentIndex),
                            null != this._pendingSeekTime && Promise.resolve().then(function() {
                                var e = t._pendingSeekTime;
                                t._pendingSeekTime = null,
                                t.seek(e)
                            })
                        }
                    },
                    {
                        key: "_onIOSeeked",
                        value: function() {
                            this._remuxer.insertDiscontinuity()
                        }
                    },
                    {
                        key: "_onIOComplete",
                        value: function(e) {
                            var t = e,
                            n = t + 1;
                            n < this._mediaDataSource.segments.length ? (this._internalAbort(), this._remuxer.flushStashedSamples(), this._loadSegment(n)) : (this._remuxer && this._remuxer.flushStashedSamples(), this._emitter.emit(w.
                        default.LOADING_COMPLETE), this._disableStatisticsReporter())
                        }
                    },
                    {
                        key: "_onIORedirect",
                        value: function(e) {
                            var t = this._ioctl.extraData;
                            this._mediaDataSource.segments[t].redirectedURL = e
                        }
                    },
                    {
                        key: "_onIORecoveredEarlyEof",
                        value: function() {
                            this._emitter.emit(w.
                        default.RECOVERED_EARLY_EOF)
                        }
                    },
                    {
                        key: "_onIOException",
                        value: function(e, t) {
                            a.
                        default.e(this.TAG, "IOException: type = " + e + ", code = " + t.code + ", msg = " + t.msg),
                            this._emitter.emit(w.
                        default.IO_ERROR, e, t),
                            this._disableStatisticsReporter()
                        }
                    },
                    {
                        key: "_onDemuxException",
                        value: function(e, t) {
                            a.
                        default.e(this.TAG, "DemuxException: type = " + e + ", info = " + t),
                            this._emitter.emit(w.
                        default.DEMUX_ERROR, e, t)
                        }
                    },
                    {
                        key: "_onRemuxerInitSegmentArrival",
                        value: function(e, t) {
                            this._emitter.emit(w.
                        default.INIT_SEGMENT, e, t)
                        }
                    },
                    {
                        key: "_onRemuxerMediaSegmentArrival",
                        value: function(e, t) {
                            if (null == this._pendingSeekTime && (this._emitter.emit(w.
                        default.MEDIA_SEGMENT, e, t), null != this._pendingResolveSeekPoint && "video" === e)) {
                                var n = t.info.syncPoints,
                                i = this._pendingResolveSeekPoint;
                                this._pendingResolveSeekPoint = null,
                                l.
                            default.safari && n.length > 0 && n[0].originalDts === i && (i = n[0].pts),
                                this._emitter.emit(w.
                            default.RECOMMEND_SEEKPOINT, i)
                            }
                        }
                    },
                    {
                        key: "_enableStatisticsReporter",
                        value: function() {
                            null == this._statisticsReporter && (this._statisticsReporter = self.setInterval(this._reportStatisticsInfo.bind(this), this._config.statisticsInfoReportInterval))
                        }
                    },
                    {
                        key: "_disableStatisticsReporter",
                        value: function() {
                            this._statisticsReporter && (self.clearInterval(this._statisticsReporter), this._statisticsReporter = null)
                        }
                    },
                    {
                        key: "_reportSegmentMediaInfo",
                        value: function(e) {
                            var t = this._mediaInfo.segments[e],
                            n = Object.assign({},
                            t);
                            n.duration = this._mediaInfo.duration,
                            n.segmentCount = this._mediaInfo.segmentCount,
                            delete n.segments,
                            delete n.keyframesIndex,
                            this._emitter.emit(w.
                        default.MEDIA_INFO, n)
                        }
                    },
                    {
                        key: "_reportStatisticsInfo",
                        value: function() {
                            var e = {};
                            e.url = this._ioctl.currentURL,
                            e.hasRedirect = this._ioctl.hasRedirect,
                            e.hasRedirect && (e.redirectedURL = this._ioctl.currentRedirectedURL),
                            this._config.localStore && (e.data = this._ioctl.getLocalStoreData()),
                            e.speed = this._ioctl.currentSpeed,
                            e.receivedLength = this._ioctl._loader._receivedLength,
                            e.loaderType = this._ioctl.loaderType,
                            e.currentSegmentIndex = this._currentSegmentIndex,
                            e.totalSegmentCount = this._mediaDataSource.segments.length,
                            this._emitter.emit(w.
                        default.STATISTICS_INFO, e)
                        }
                    }]),
                    e
                } ();
                n.
            default = S
            },
            {
                "../demux/demux-errors.js": 16,
                "../demux/flv-demuxer.js": 18,
                "../io/io-controller.js": 23,
                "../io/loader.js": 24,
                "../remux/mp4-remuxer.js": 38,
                "../utils/browser.js": 39,
                "../utils/logger.js": 41,
                "./media-info.js": 7,
                "./transmuxing-events.js": 13,
                events: 2
            }],
            13 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                }),
                n.
            default = {
                    IO_ERROR: "io_error",
                    DEMUX_ERROR: "demux_error",
                    INIT_SEGMENT: "init_segment",
                    MEDIA_SEGMENT: "media_segment",
                    LOADING_COMPLETE: "loading_complete",
                    RECOVERED_EARLY_EOF: "recovered_early_eof",
                    MEDIA_INFO: "media_info",
                    STATISTICS_INFO: "statistics_info",
                    RECOMMEND_SEEKPOINT: "recommend_seekpoint"
                }
            },
            {}],
            14 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = e("../utils/logger.js"),
                r = (f(i), e("../utils/logging-control.js")),
                o = f(r),
                s = e("../utils/polyfill.js"),
                a = f(s),
                u = e("./transmuxing-controller.js"),
                l = f(u),
                c = e("./transmuxing-events.js"),
                d = f(c);

                function f(e) {
                    return e && e.__esModule ? e: {
                    default:
                        e
                    }
                }
                n.
            default = function(e) {
                    var t = null,
                    n = function(t, n) {
                        e.postMessage({
                            msg: "logcat_callback",
                            data: {
                                type: t,
                                logcat: n
                            }
                        })
                    }.bind(this);
                    a.
                default.install(),
                    e.addEventListener("message",
                    function(i) {
                        switch (i.data.cmd) {
                        case "init":
                            (t = new l.
                        default(i.data.param[0], i.data.param[1])).on(d.
                        default.IO_ERROR,
                            function(t, n) {
                                e.postMessage({
                                    msg: d.
                                default.IO_ERROR,
                                    data: {
                                        type: t,
                                        info: n
                                    }
                                })
                            }.bind(this)),
                            t.on(d.
                        default.DEMUX_ERROR,
                            function(t, n) {
                                e.postMessage({
                                    msg: d.
                                default.DEMUX_ERROR,
                                    data: {
                                        type: t,
                                        info: n
                                    }
                                })
                            }.bind(this)),
                            t.on(d.
                        default.INIT_SEGMENT,
                            function(t, n) {
                                var i = {
                                    msg: d.
                                default.INIT_SEGMENT,
                                    data: {
                                        type: t,
                                        data: n
                                    }
                                };
                                e.postMessage(i, [n.data])
                            }.bind(this)),
                            t.on(d.
                        default.MEDIA_SEGMENT,
                            function(t, n) {
                                var i = {
                                    msg: d.
                                default.MEDIA_SEGMENT,
                                    data: {
                                        type: t,
                                        data: n
                                    }
                                };
                                e.postMessage(i, [n.data])
                            }.bind(this)),
                            t.on(d.
                        default.LOADING_COMPLETE,
                            function() {
                                var t = {
                                    msg: d.
                                default.LOADING_COMPLETE
                                };
                                e.postMessage(t)
                            }.bind(this)),
                            t.on(d.
                        default.RECOVERED_EARLY_EOF,
                            function() {
                                var t = {
                                    msg: d.
                                default.RECOVERED_EARLY_EOF
                                };
                                e.postMessage(t)
                            }.bind(this)),
                            t.on(d.
                        default.MEDIA_INFO,
                            function(t) {
                                var n = {
                                    msg: d.
                                default.MEDIA_INFO,
                                    data: t
                                };
                                e.postMessage(n)
                            }.bind(this)),
                            t.on(d.
                        default.STATISTICS_INFO,
                            function(t) {
                                var n = {
                                    msg: d.
                                default.STATISTICS_INFO,
                                    data: t
                                };
                                e.postMessage(n)
                            }.bind(this)),
                            t.on(d.
                        default.RECOMMEND_SEEKPOINT,
                            function(t) {
                                e.postMessage({
                                    msg: d.
                                default.RECOMMEND_SEEKPOINT,
                                    data: t
                                })
                            }.bind(this));
                            break;
                        case "destroy":
                            t && (t.destroy(), t = null),
                            e.postMessage({
                                msg: "destroyed"
                            });
                            break;
                        case "start":
                            t.start();
                            break;
                        case "stop":
                            t.stop();
                            break;
                        case "seek":
                            t.seek(i.data.param);
                            break;
                        case "pause":
                            t.pause();
                            break;
                        case "resume":
                            t.resume();
                            break;
                        case "sendWSData":
                            t.sendWSData(i.data.data);
                            break;
                        case "logging_config":
                            var r = i.data.param;
                            o.
                        default.applyConfig(r),
                            !0 === r.enableCallback ? o.
                        default.addLogListener(n):
                            o.
                        default.removeLogListener(n)
                        }
                    })
                }
            },
            {
                "../utils/logger.js": 41,
                "../utils/logging-control.js": 42,
                "../utils/polyfill.js": 43,
                "./transmuxing-controller.js": 12,
                "./transmuxing-events.js": 13
            }],
            15 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                r = e("../utils/logger.js"),
                o = l(r),
                s = e("../utils/utf8-conv.js"),
                a = l(s),
                u = e("../utils/exception.js");

                function l(e) {
                    return e && e.__esModule ? e: {
                    default:
                        e
                    }
                }
                var c, d = (c = new ArrayBuffer(2), new DataView(c).setInt16(0, 256, !0), 256 === new Int16Array(c)[0]),
                f = function() {
                    function e() { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, e)
                    }
                    return i(e, null, [{
                        key: "parseScriptData",
                        value: function(t, n, i) {
                            var r = {};
                            try {
                                var s = e.parseValue(t, n, i),
                                a = e.parseValue(t, n + s.size, i - s.size);
                                r[s.data] = a.data
                            } catch(e) {
                                o.
                            default.e("AMF", e.toString())
                            }
                            return r
                        }
                    },
                    {
                        key: "parseObject",
                        value: function(t, n, i) {
                            if (i < 3) throw new u.IllegalStateException("Data not enough when parse ScriptDataObject");
                            var r = e.parseString(t, n, i),
                            o = e.parseValue(t, n + r.size, i - r.size),
                            s = o.objectEnd;
                            return {
                                data: {
                                    name: r.data,
                                    value: o.data
                                },
                                size: r.size + o.size,
                                objectEnd: s
                            }
                        }
                    },
                    {
                        key: "parseVariable",
                        value: function(t, n, i) {
                            return e.parseObject(t, n, i)
                        }
                    },
                    {
                        key: "parseString",
                        value: function(e, t, n) {
                            if (n < 2) throw new u.IllegalStateException("Data not enough when parse String");
                            var i = new DataView(e, t, n),
                            r = i.getUint16(0, !d);
                            return {
                                data: r > 0 ? (0, a.
                            default)(new Uint8Array(e, t + 2, r)) : "",
                                size: 2 + r
                            }
                        }
                    },
                    {
                        key: "parseLongString",
                        value: function(e, t, n) {
                            if (n < 4) throw new u.IllegalStateException("Data not enough when parse LongString");
                            var i = new DataView(e, t, n),
                            r = i.getUint32(0, !d);
                            return {
                                data: r > 0 ? (0, a.
                            default)(new Uint8Array(e, t + 4, r)) : "",
                                size: 4 + r
                            }
                        }
                    },
                    {
                        key: "parseDate",
                        value: function(e, t, n) {
                            if (n < 10) throw new u.IllegalStateException("Data size invalid when parse Date");
                            var i = new DataView(e, t, n),
                            r = i.getFloat64(0, !d),
                            o = i.getInt16(8, !d);
                            return {
                                data: new Date(r += 60 * o * 1e3),
                                size: 10
                            }
                        }
                    },
                    {
                        key: "parseValue",
                        value: function(t, n, i) {
                            if (i < 1) throw new u.IllegalStateException("Data not enough when parse Value");
                            var r = new DataView(t, n, i),
                            s = 1,
                            a = r.getUint8(0),
                            l = void 0,
                            c = !1;
                            try {
                                switch (a) {
                                case 0:
                                    l = r.getFloat64(1, !d),
                                    s += 8;
                                    break;
                                case 1:
                                    var f = r.getUint8(1);
                                    l = !!f,
                                    s += 1;
                                    break;
                                case 2:
                                    var h = e.parseString(t, n + 1, i - 1);
                                    l = h.data,
                                    s += h.size;
                                    break;
                                case 3:
                                    l = {};
                                    var p = 0;
                                    for (9 == (16777215 & r.getUint32(i - 4, !d)) && (p = 3); s < i - 4;) {
                                        var m = e.parseObject(t, n + s, i - s - p);
                                        if (m.objectEnd) break;
                                        l[m.data.name] = m.data.value,
                                        s += m.size
                                    }
                                    if (s <= i - 3) {
                                        var _ = 16777215 & r.getUint32(s - 1, !d);
                                        9 === _ && (s += 3)
                                    }
                                    break;
                                case 8:
                                    l = {},
                                    s += 4;
                                    var v = 0;
                                    for (9 == (16777215 & r.getUint32(i - 4, !d)) && (v = 3); s < i - 8;) {
                                        var g = e.parseVariable(t, n + s, i - s - v);
                                        if (g.objectEnd) break;
                                        l[g.data.name] = g.data.value,
                                        s += g.size
                                    }
                                    if (s <= i - 3) {
                                        var y = 16777215 & r.getUint32(s - 1, !d);
                                        9 === y && (s += 3)
                                    }
                                    break;
                                case 9:
                                    l = void 0,
                                    s = 1,
                                    c = !0;
                                    break;
                                case 10:
                                    l = [];
                                    var b = r.getUint32(1, !d);
                                    s += 4;
                                    for (var w = 0; w < b; w++) {
                                        var E = e.parseValue(t, n + s, i - s);
                                        l.push(E.data),
                                        s += E.size
                                    }
                                    break;
                                case 11:
                                    var S = e.parseDate(t, n + 1, i - 1);
                                    l = S.data,
                                    s += S.size;
                                    break;
                                case 12:
                                    var k = e.parseString(t, n + 1, i - 1);
                                    l = k.data,
                                    s += k.size;
                                    break;
                                default:
                                    s = i,
                                    o.
                                default.w("AMF", "Unsupported AMF value type " + a)
                                }
                            } catch(e) {
                                o.
                            default.e("AMF", e.toString())
                            }
                            return {
                                data: l,
                                size: s,
                                objectEnd: c
                            }
                        }
                    }]),
                    e
                } ();
                n.
            default = f
            },
            {
                "../utils/exception.js": 40,
                "../utils/logger.js": 41,
                "../utils/utf8-conv.js": 44
            }],
            16 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                }),
                n.
            default = {
                    OK: "OK",
                    FORMAT_ERROR: "FormatError",
                    FORMAT_UNSUPPORTED: "FormatUnsupported",
                    CODEC_UNSUPPORTED: "CodecUnsupported"
                }
            },
            {}],
            17 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                r = e("../utils/exception.js"),
                o = function() {
                    function e(t) { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, e),
                        this.TAG = "ExpGolomb",
                        this._buffer = t,
                        this._buffer_index = 0,
                        this._total_bytes = t.byteLength,
                        this._total_bits = 8 * t.byteLength,
                        this._current_word = 0,
                        this._current_word_bits_left = 0
                    }
                    return i(e, [{
                        key: "destroy",
                        value: function() {
                            this._buffer = null
                        }
                    },
                    {
                        key: "_fillCurrentWord",
                        value: function() {
                            var e = this._total_bytes - this._buffer_index;
                            if (e <= 0) throw new r.IllegalStateException("ExpGolomb: _fillCurrentWord() but no bytes available");
                            var t = Math.min(4, e),
                            n = new Uint8Array(4);
                            n.set(this._buffer.subarray(this._buffer_index, this._buffer_index + t)),
                            this._current_word = new DataView(n.buffer).getUint32(0, !1),
                            this._buffer_index += t,
                            this._current_word_bits_left = 8 * t
                        }
                    },
                    {
                        key: "readBits",
                        value: function(e) {
                            if (e > 32) throw new r.InvalidArgumentException("ExpGolomb: readBits() bits exceeded max 32bits!");
                            if (e <= this._current_word_bits_left) {
                                var t = this._current_word >>> 32 - e;
                                return this._current_word <<= e,
                                this._current_word_bits_left -= e,
                                t
                            }
                            var n = this._current_word_bits_left ? this._current_word: 0;
                            n >>>= 32 - this._current_word_bits_left;
                            var i = e - this._current_word_bits_left;
                            this._fillCurrentWord();
                            var o = Math.min(i, this._current_word_bits_left),
                            s = this._current_word >>> 32 - o;
                            return this._current_word <<= o,
                            this._current_word_bits_left -= o,
                            n = n << o | s
                        }
                    },
                    {
                        key: "readBool",
                        value: function() {
                            return 1 === this.readBits(1)
                        }
                    },
                    {
                        key: "readByte",
                        value: function() {
                            return this.readBits(8)
                        }
                    },
                    {
                        key: "_skipLeadingZero",
                        value: function() {
                            var e = void 0;
                            for (e = 0; e < this._current_word_bits_left; e++) if (0 != (this._current_word & 2147483648 >>> e)) return this._current_word <<= e,
                            this._current_word_bits_left -= e,
                            e;
                            return this._fillCurrentWord(),
                            e + this._skipLeadingZero()
                        }
                    },
                    {
                        key: "readUEG",
                        value: function() {
                            var e = this._skipLeadingZero();
                            return this.readBits(e + 1) - 1
                        }
                    },
                    {
                        key: "readSEG",
                        value: function() {
                            var e = this.readUEG();
                            return 1 & e ? e + 1 >>> 1 : -1 * (e >>> 1)
                        }
                    }]),
                    e
                } ();
                n.
            default = o
            },
            {
                "../utils/exception.js": 40
            }],
            18 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
                function(e) {
                    return typeof e
                }: function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
                },
                r = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                o = e("../utils/logger.js"),
                s = _(o),
                a = e("./amf-parser.js"),
                u = _(a),
                l = e("./sps-parser.js"),
                c = _(l),
                d = e("./demux-errors.js"),
                f = _(d),
                h = e("../core/media-info.js"),
                p = _(h),
                m = e("../utils/exception.js");

                function _(e) {
                    return e && e.__esModule ? e: {
                    default:
                        e
                    }
                }
                var v = function() {
                    function e(t, n) {
                        var i; !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, e),
                        this.TAG = "FLVDemuxer",
                        this._config = n,
                        this._onError = null,
                        this._onMediaInfo = null,
                        this._onTrackMetadata = null,
                        this._onDataAvailable = null,
                        this._dataOffset = t.dataOffset,
                        this._firstParse = !0,
                        this._dispatch = !1,
                        this._hasAudio = t.hasAudioTrack,
                        this._hasVideo = t.hasVideoTrack,
                        this._hasAudioFlagOverrided = !1,
                        this._hasVideoFlagOverrided = !1,
                        this._audioInitialMetadataDispatched = !1,
                        this._videoInitialMetadataDispatched = !1,
                        this._mediaInfo = new p.
                    default,
                        this._mediaInfo.hasAudio = this._hasAudio,
                        this._mediaInfo.hasVideo = this._hasVideo,
                        this._metadata = null,
                        this._audioMetadata = null,
                        this._videoMetadata = null,
                        this._naluLengthSize = 4,
                        this._timestampBase = 0,
                        this._timescale = 1e3,
                        this._duration = 0,
                        this._durationOverrided = !1,
                        this._referenceFrameRate = {
                            fixed: !0,
                            fps: 23.976,
                            fps_num: 23976,
                            fps_den: 1e3
                        },
                        this._flvSoundRateTable = [5500, 11025, 22050, 44100, 48e3],
                        this._mpegSamplingRates = [96e3, 88200, 64e3, 48e3, 44100, 32e3, 24e3, 22050, 16e3, 12e3, 11025, 8e3, 7350],
                        this._mpegAudioV10SampleRateTable = [44100, 48e3, 32e3, 0],
                        this._mpegAudioV20SampleRateTable = [22050, 24e3, 16e3, 0],
                        this._mpegAudioV25SampleRateTable = [11025, 12e3, 8e3, 0],
                        this._mpegAudioL1BitRateTable = [0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448, -1],
                        this._mpegAudioL2BitRateTable = [0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384, -1],
                        this._mpegAudioL3BitRateTable = [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, -1],
                        this._videoTrack = {
                            type: "video",
                            id: 1,
                            sequenceNumber: 0,
                            samples: [],
                            length: 0
                        },
                        this._audioTrack = {
                            type: "audio",
                            id: 2,
                            sequenceNumber: 0,
                            samples: [],
                            length: 0
                        },
                        this._littleEndian = (i = new ArrayBuffer(2), new DataView(i).setInt16(0, 256, !0), 256 === new Int16Array(i)[0])
                    }
                    return r(e, [{
                        key: "destroy",
                        value: function() {
                            this._mediaInfo = null,
                            this._metadata = null,
                            this._audioMetadata = null,
                            this._videoMetadata = null,
                            this._videoTrack = null,
                            this._audioTrack = null,
                            this._onError = null,
                            this._onMediaInfo = null,
                            this._onTrackMetadata = null,
                            this._onDataAvailable = null
                        }
                    },
                    {
                        key: "bindDataSource",
                        value: function(e) {
                            return e.onDataArrival = this.parseChunks.bind(this),
                            this
                        }
                    },
                    {
                        key: "resetMediaInfo",
                        value: function() {
                            this._mediaInfo = new p.
                        default
                        }
                    },
                    {
                        key: "_isInitialMetadataDispatched",
                        value: function() {
                            return this._hasAudio && this._hasVideo ? this._audioInitialMetadataDispatched && this._videoInitialMetadataDispatched: this._hasAudio && !this._hasVideo ? this._audioInitialMetadataDispatched: !(this._hasAudio || !this._hasVideo) && this._videoInitialMetadataDispatched
                        }
                    },
                    {
                        key: "parseChunks",
                        value: function(t, n) {
                            if (! (this._onError && this._onMediaInfo && this._onTrackMetadata && this._onDataAvailable)) throw new m.IllegalStateException("Flv: onError & onMediaInfo & onTrackMetadata & onDataAvailable callback must be specified");
                            var i = 0,
                            r = this._littleEndian;
                            if (0 === n) {
                                if (! (t.byteLength > 13)) return 0;
                                var o = e.probe(t);
                                i = o.dataOffset
                            }
                            if (this._firstParse) {
                                this._firstParse = !1,
                                n + i !== this._dataOffset && s.
                            default.w(this.TAG, "First time parsing but chunk byteStart invalid!");
                                var a = new DataView(t, i),
                                u = a.getUint32(0, !r);
                                0 !== u && s.
                            default.w(this.TAG, "PrevTagSize0 !== 0 !!!"),
                                i += 4
                            }
                            for (; i < t.byteLength;) {
                                this._dispatch = !0;
                                var l = new DataView(t, i);
                                if (i + 11 + 4 > t.byteLength) break;
                                var c = l.getUint8(0),
                                d = 16777215 & l.getUint32(0, !r);
                                if (i + 11 + d + 4 > t.byteLength) break;
                                if (8 === c || 9 === c || 18 === c) {
                                    var f = l.getUint8(4),
                                    h = l.getUint8(5),
                                    p = l.getUint8(6),
                                    _ = l.getUint8(7),
                                    v = p | h << 8 | f << 16 | _ << 24,
                                    g = 16777215 & l.getUint32(7, !r);
                                    0 !== g && s.
                                default.w(this.TAG, "Meet tag which has StreamID != 0!");
                                    var y = i + 11;
                                    switch (c) {
                                    case 8:
                                        this._parseAudioData(t, y, d, v);
                                        break;
                                    case 9:
                                        this._parseVideoData(t, y, d, v, n + i);
                                        break;
                                    case 18:
                                        this._parseScriptData(t, y, d)
                                    }
                                    var b = l.getUint32(11 + d, !r);
                                    b !== 11 + d && s.
                                default.w(this.TAG, "Invalid PrevTagSize " + b),
                                    i += 11 + d + 4
                                } else s.
                            default.w(this.TAG, "Unsupported tag type " + c + ", skipped"),
                                i += 11 + d + 4
                            }
                            return this._isInitialMetadataDispatched() && this._dispatch && (this._audioTrack.length || this._videoTrack.length) && this._onDataAvailable(this._audioTrack, this._videoTrack),
                            i
                        }
                    },
                    {
                        key: "_parseScriptData",
                        value: function(e, t, n) {
                            var r = u.
                        default.parseScriptData(e, t, n);
                            if (r.hasOwnProperty("onMetaData")) {
                                if (null == r.onMetaData || "object" !== i(r.onMetaData)) return void s.
                            default.w(this.TAG, "Invalid onMetaData structure!");
                                this._metadata && s.
                            default.w(this.TAG, "Found another onMetaData tag!"),
                                this._metadata = r;
                                var o = this._metadata.onMetaData;
                                if ("boolean" == typeof o.hasAudio && !1 === this._hasAudioFlagOverrided && (this._hasAudio = o.hasAudio, this._mediaInfo.hasAudio = this._hasAudio), "boolean" == typeof o.hasVideo && !1 === this._hasVideoFlagOverrided && (this._hasVideo = o.hasVideo, this._mediaInfo.hasVideo = this._hasVideo), "number" == typeof o.audiodatarate && (this._mediaInfo.audioDataRate = o.audiodatarate), "number" == typeof o.videodatarate && (this._mediaInfo.videoDataRate = o.videodatarate), "number" == typeof o.width && (this._mediaInfo.width = o.width), "number" == typeof o.height && (this._mediaInfo.height = o.height), "number" == typeof o.duration) {
                                    if (!this._durationOverrided) {
                                        var a = Math.floor(o.duration * this._timescale);
                                        this._duration = a,
                                        this._mediaInfo.duration = a
                                    }
                                } else this._mediaInfo.duration = 0;
                                if ("number" == typeof o.framerate) {
                                    var l = Math.floor(1e3 * o.framerate);
                                    if (l > 0) {
                                        var c = l / 1e3;
                                        this._referenceFrameRate.fixed = !0,
                                        this._referenceFrameRate.fps = c,
                                        this._referenceFrameRate.fps_num = l,
                                        this._referenceFrameRate.fps_den = 1e3,
                                        this._mediaInfo.fps = c
                                    }
                                }
                                if ("object" === i(o.keyframes)) {
                                    this._mediaInfo.hasKeyframesIndex = !0;
                                    var d = o.keyframes;
                                    this._mediaInfo.keyframesIndex = this._parseKeyframesIndex(d),
                                    o.keyframes = null
                                } else this._mediaInfo.hasKeyframesIndex = !1;
                                this._dispatch = !1,
                                this._mediaInfo.metadata = o,
                                s.
                            default.v(this.TAG, "Parsed onMetaData"),
                                this._mediaInfo.isComplete() && this._onMediaInfo(this._mediaInfo)
                            }
                        }
                    },
                    {
                        key: "_parseKeyframesIndex",
                        value: function(e) {
                            for (var t = [], n = [], i = 1; i < e.times.length; i++) {
                                var r = this._timestampBase + Math.floor(1e3 * e.times[i]);
                                t.push(r),
                                n.push(e.filepositions[i])
                            }
                            return {
                                times: t,
                                filepositions: n
                            }
                        }
                    },
                    {
                        key: "_parseAudioData",
                        value: function(e, t, n, i) {
                            if (n <= 1) s.
                        default.w(this.TAG, "Flv: Invalid audio packet, missing SoundData payload!");
                            else if (!0 !== this._hasAudioFlagOverrided || !1 !== this._hasAudio) {
                                this._littleEndian;
                                var r = new DataView(e, t, n),
                                o = r.getUint8(0),
                                a = o >>> 4;
                                if (2 === a || 10 === a) {
                                    var u = 0,
                                    l = (12 & o) >>> 2;
                                    if (l >= 0 && l <= 4) {
                                        u = this._flvSoundRateTable[l];
                                        var c = 1 & o,
                                        d = this._audioMetadata,
                                        h = this._audioTrack;
                                        if (d || (!1 === this._hasAudio && !1 === this._hasAudioFlagOverrided && (this._hasAudio = !0, this._mediaInfo.hasAudio = !0), (d = this._audioMetadata = {}).type = "audio", d.id = h.id, d.timescale = this._timescale, d.duration = this._duration, d.audioSampleRate = u, d.channelCount = 0 === c ? 1 : 2), 10 === a) {
                                            var p = this._parseAACAudioData(e, t + 1, n - 1);
                                            if (void 0 == p) return;
                                            if (0 === p.packetType) {
                                                d.config && s.
                                            default.w(this.TAG, "Found another AudioSpecificConfig!");
                                                var m = p.data;
                                                d.audioSampleRate = m.samplingRate,
                                                d.channelCount = m.channelCount,
                                                d.codec = m.codec,
                                                d.originalCodec = m.originalCodec,
                                                d.config = m.config,
                                                d.refSampleDuration = 1024 / d.audioSampleRate * d.timescale,
                                                s.
                                            default.v(this.TAG, "Parsed AudioSpecificConfig"),
                                                this._isInitialMetadataDispatched() ? this._dispatch && (this._audioTrack.length || this._videoTrack.length) && this._onDataAvailable(this._audioTrack, this._videoTrack) : this._audioInitialMetadataDispatched = !0,
                                                this._dispatch = !1,
                                                this._onTrackMetadata("audio", d);
                                                var _ = this._mediaInfo;
                                                _.audioCodec = d.originalCodec,
                                                _.audioSampleRate = d.audioSampleRate,
                                                _.audioChannelCount = d.channelCount,
                                                _.hasVideo ? null != _.videoCodec && (_.mimeType = 'video/x-flv; codecs="' + _.videoCodec + "," + _.audioCodec + '"') : _.mimeType = 'video/x-flv; codecs="' + _.audioCodec + '"',
                                                _.isComplete() && this._onMediaInfo(_)
                                            } else if (1 === p.packetType) {
                                                var v = this._timestampBase + i,
                                                g = {
                                                    unit: p.data,
                                                    length: p.data.byteLength,
                                                    dts: v,
                                                    pts: v
                                                };
                                                h.samples.push(g),
                                                h.length += p.data.length
                                            } else s.
                                        default.e(this.TAG, "Flv: Unsupported AAC data type " + p.packetType)
                                        } else if (2 === a) {
                                            if (!d.codec) {
                                                var y = this._parseMP3AudioData(e, t + 1, n - 1, !0);
                                                if (void 0 == y) return;
                                                d.audioSampleRate = y.samplingRate,
                                                d.channelCount = y.channelCount,
                                                d.codec = y.codec,
                                                d.originalCodec = y.originalCodec,
                                                d.refSampleDuration = 1152 / d.audioSampleRate * d.timescale,
                                                s.
                                            default.v(this.TAG, "Parsed MPEG Audio Frame Header"),
                                                this._audioInitialMetadataDispatched = !0,
                                                this._onTrackMetadata("audio", d);
                                                var b = this._mediaInfo;
                                                b.audioCodec = d.codec,
                                                b.audioSampleRate = d.audioSampleRate,
                                                b.audioChannelCount = d.channelCount,
                                                b.audioDataRate = y.bitRate,
                                                b.hasVideo ? null != b.videoCodec && (b.mimeType = 'video/x-flv; codecs="' + b.videoCodec + "," + b.audioCodec + '"') : b.mimeType = 'video/x-flv; codecs="' + b.audioCodec + '"',
                                                b.isComplete() && this._onMediaInfo(b)
                                            }
                                            var w = this._parseMP3AudioData(e, t + 1, n - 1, !1);
                                            if (void 0 == w) return;
                                            var E = this._timestampBase + i,
                                            S = {
                                                unit: w,
                                                length: w.byteLength,
                                                dts: E,
                                                pts: E
                                            };
                                            h.samples.push(S),
                                            h.length += w.length
                                        }
                                    } else this._onError(f.
                                default.FORMAT_ERROR, "Flv: Invalid audio sample rate idx: " + l)
                                } else this._onError(f.
                            default.CODEC_UNSUPPORTED, "Flv: Unsupported audio codec idx: " + a)
                            }
                        }
                    },
                    {
                        key: "_parseAACAudioData",
                        value: function(e, t, n) {
                            if (! (n <= 1)) {
                                var i = {},
                                r = new Uint8Array(e, t, n);
                                return i.packetType = r[0],
                                0 === r[0] ? i.data = this._parseAACAudioSpecificConfig(e, t + 1, n - 1) : i.data = r.subarray(1),
                                i
                            }
                            s.
                        default.w(this.TAG, "Flv: Invalid AAC packet, missing AACPacketType or/and Data!")
                        }
                    },
                    {
                        key: "_parseAACAudioSpecificConfig",
                        value: function(e, t, n) {
                            var i = new Uint8Array(e, t, n),
                            r = null,
                            o = 0,
                            s = 0,
                            a = 0,
                            u = null;
                            if (o = s = i[0] >>> 3, (a = (7 & i[0]) << 1 | i[1] >>> 7) < 0 || a >= this._mpegSamplingRates.length) this._onError(f.
                        default.FORMAT_ERROR, "Flv: AAC invalid sampling frequency index!");
                            else {
                                var l = this._mpegSamplingRates[a],
                                c = (120 & i[1]) >>> 3;
                                if (! (c < 0 || c >= 8)) {
                                    5 === o && (u = (7 & i[1]) << 1 | i[2] >>> 7, i[2]);
                                    var d = self.navigator.userAgent.toLowerCase();
                                    return - 1 !== d.indexOf("firefox") ? a >= 6 ? (o = 5, r = new Array(4), u = a - 3) : (o = 2, r = new Array(2), u = a) : -1 !== d.indexOf("android") ? (o = 2, r = new Array(2), u = a) : (o = 5, u = a, r = new Array(4), a >= 6 ? u = a - 3 : 1 === c && (o = 2, r = new Array(2), u = a)),
                                    r[0] = o << 3,
                                    r[0] |= (15 & a) >>> 1,
                                    r[1] = (15 & a) << 7,
                                    r[1] |= (15 & c) << 3,
                                    5 === o && (r[1] |= (15 & u) >>> 1, r[2] = (1 & u) << 7, r[2] |= 8, r[3] = 0),
                                    {
                                        config: r,
                                        samplingRate: l,
                                        channelCount: c,
                                        codec: "mp4a.40." + o,
                                        originalCodec: "mp4a.40." + s
                                    }
                                }
                                this._onError(f.
                            default.FORMAT_ERROR, "Flv: AAC invalid channel configuration")
                            }
                        }
                    },
                    {
                        key: "_parseMP3AudioData",
                        value: function(e, t, n, i) {
                            if (! (n < 4)) {
                                this._littleEndian;
                                var r = new Uint8Array(e, t, n),
                                o = null;
                                if (i) {
                                    if (255 !== r[0]) return;
                                    var a = r[1] >>> 3 & 3,
                                    u = (6 & r[1]) >> 1,
                                    l = (240 & r[2]) >>> 4,
                                    c = (12 & r[2]) >>> 2,
                                    d = r[3] >>> 6 & 3,
                                    f = 3 !== d ? 2 : 1,
                                    h = 0,
                                    p = 0;
                                    switch (a) {
                                    case 0:
                                        h = this._mpegAudioV25SampleRateTable[c];
                                        break;
                                    case 2:
                                        h = this._mpegAudioV20SampleRateTable[c];
                                        break;
                                    case 3:
                                        h = this._mpegAudioV10SampleRateTable[c]
                                    }
                                    switch (u) {
                                    case 1:
                                        l < this._mpegAudioL3BitRateTable.length && (p = this._mpegAudioL3BitRateTable[l]);
                                        break;
                                    case 2:
                                        l < this._mpegAudioL2BitRateTable.length && (p = this._mpegAudioL2BitRateTable[l]);
                                        break;
                                    case 3:
                                        l < this._mpegAudioL1BitRateTable.length && (p = this._mpegAudioL1BitRateTable[l])
                                    }
                                    o = {
                                        bitRate: p,
                                        samplingRate: h,
                                        channelCount: f,
                                        codec: "mp3",
                                        originalCodec: "mp3"
                                    }
                                } else o = r;
                                return o
                            }
                            s.
                        default.w(this.TAG, "Flv: Invalid MP3 packet, header missing!")
                        }
                    },
                    {
                        key: "_parseVideoData",
                        value: function(e, t, n, i, r) {
                            if (n <= 1) s.
                        default.w(this.TAG, "Flv: Invalid video packet, missing VideoData payload!");
                            else if (!0 !== this._hasVideoFlagOverrided || !1 !== this._hasVideo) {
                                var o = new Uint8Array(e, t, n)[0],
                                a = (240 & o) >>> 4,
                                u = 15 & o;
                                7 === u ? this._parseAVCVideoPacket(e, t + 1, n - 1, i, r, a) : this._onError(f.
                            default.CODEC_UNSUPPORTED, "Flv: Unsupported codec in video frame: " + u)
                            }
                        }
                    },
                    {
                        key: "_parseAVCVideoPacket",
                        value: function(e, t, n, i, r, o) {
                            if (n < 4) s.
                        default.w(this.TAG, "Flv: Invalid AVC packet, missing AVCPacketType or/and CompositionTime");
                            else {
                                var a = this._littleEndian,
                                u = new DataView(e, t, n),
                                l = u.getUint8(0),
                                c = 16777215 & u.getUint32(0, !a),
                                d = c << 8 >> 8;
                                if (0 === l) this._parseAVCDecoderConfigurationRecord(e, t + 4, n - 4);
                                else if (1 === l) this._parseAVCVideoData(e, t + 4, n - 4, i, r, o, d);
                                else if (2 !== l) return void this._onError(f.
                            default.FORMAT_ERROR, "Flv: Invalid video packet type " + l)
                            }
                        }
                    },
                    {
                        key: "_parseAVCDecoderConfigurationRecord",
                        value: function(e, t, n) {
                            if (n < 7) s.
                        default.w(this.TAG, "Flv: Invalid AVCDecoderConfigurationRecord, lack of data!");
                            else {
                                var i = this._videoMetadata,
                                r = this._videoTrack,
                                o = this._littleEndian,
                                a = new DataView(e, t, n);
                                if (i) {
                                    if (void 0 !== i.avcc) return void s.
                                default.w(this.TAG, "Found another AVCDecoderConfigurationRecord!")
                                } else ! 1 === this._hasVideo && !1 === this._hasVideoFlagOverrided && (this._hasVideo = !0, this._mediaInfo.hasVideo = !0),
                                (i = this._videoMetadata = {}).type = "video",
                                i.id = r.id,
                                i.timescale = this._timescale,
                                i.duration = this._duration;
                                var u = a.getUint8(0),
                                l = a.getUint8(1);
                                if (a.getUint8(2), a.getUint8(3), 1 === u && 0 !== l) if (this._naluLengthSize = 1 + (3 & a.getUint8(4)), 3 === this._naluLengthSize || 4 === this._naluLengthSize) {
                                    var d = 31 & a.getUint8(5);
                                    if (0 !== d) {
                                        d > 1 && s.
                                    default.w(this.TAG, "Flv: Strange AVCDecoderConfigurationRecord: SPS Count = " + d);
                                        for (var h = 6,
                                        p = 0; p < d; p++) {
                                            var m = a.getUint16(h, !o);
                                            if (h += 2, 0 !== m) {
                                                var _ = new Uint8Array(e, t + h, m);
                                                h += m;
                                                var v = c.
                                            default.parseSPS(_);
                                                if (0 === p) {
                                                    i.codecWidth = v.codec_size.width,
                                                    i.codecHeight = v.codec_size.height,
                                                    i.presentWidth = v.present_size.width,
                                                    i.presentHeight = v.present_size.height,
                                                    i.profile = v.profile_string,
                                                    i.level = v.level_string,
                                                    i.bitDepth = v.bit_depth,
                                                    i.chromaFormat = v.chroma_format,
                                                    i.sarRatio = v.sar_ratio,
                                                    i.frameRate = v.frame_rate,
                                                    !1 !== v.frame_rate.fixed && 0 !== v.frame_rate.fps_num && 0 !== v.frame_rate.fps_den || (i.frameRate = this._referenceFrameRate);
                                                    var g = i.frameRate.fps_den,
                                                    y = i.frameRate.fps_num;
                                                    i.refSampleDuration = i.timescale * (g / y);
                                                    for (var b = _.subarray(1, 4), w = "avc1.", E = 0; E < 3; E++) {
                                                        var S = b[E].toString(16);
                                                        S.length < 2 && (S = "0" + S),
                                                        w += S
                                                    }
                                                    i.codec = w;
                                                    var k = this._mediaInfo;
                                                    k.width = i.codecWidth,
                                                    k.height = i.codecHeight,
                                                    k.fps = i.frameRate.fps,
                                                    k.profile = i.profile,
                                                    k.level = i.level,
                                                    k.refFrames = v.ref_frames,
                                                    k.chromaFormat = v.chroma_format_string,
                                                    k.sarNum = i.sarRatio.width,
                                                    k.sarDen = i.sarRatio.height,
                                                    k.videoCodec = w,
                                                    k.hasAudio ? null != k.audioCodec && (k.mimeType = 'video/x-flv; codecs="' + k.videoCodec + "," + k.audioCodec + '"') : k.mimeType = 'video/x-flv; codecs="' + k.videoCodec + '"',
                                                    k.isComplete() && this._onMediaInfo(k)
                                                }
                                            }
                                        }
                                        var x = a.getUint8(h);
                                        if (0 !== x) {
                                            x > 1 && s.
                                        default.w(this.TAG, "Flv: Strange AVCDecoderConfigurationRecord: PPS Count = " + x),
                                            h++;
                                            for (var L = 0; L < x; L++) {
                                                var T = a.getUint16(h, !o);
                                                h += 2,
                                                0 !== T && (h += T)
                                            }
                                            i.avcc = new Uint8Array(n),
                                            i.avcc.set(new Uint8Array(e, t, n), 0),
                                            s.
                                        default.v(this.TAG, "Parsed AVCDecoderConfigurationRecord"),
                                            this._isInitialMetadataDispatched() ? this._dispatch && (this._audioTrack.length || this._videoTrack.length) && this._onDataAvailable(this._audioTrack, this._videoTrack) : this._videoInitialMetadataDispatched = !0,
                                            this._dispatch = !1,
                                            this._onTrackMetadata("video", i)
                                        } else this._onError(f.
                                    default.FORMAT_ERROR, "Flv: Invalid AVCDecoderConfigurationRecord: No PPS")
                                    } else this._onError(f.
                                default.FORMAT_ERROR, "Flv: Invalid AVCDecoderConfigurationRecord: No SPS")
                                } else this._onError(f.
                            default.FORMAT_ERROR, "Flv: Strange NaluLengthSizeMinusOne: " + (this._naluLengthSize - 1));
                                else this._onError(f.
                            default.FORMAT_ERROR, "Flv: Invalid AVCDecoderConfigurationRecord")
                            }
                        }
                    },
                    {
                        key: "_parseAVCVideoData",
                        value: function(e, t, n, i, r, o, a) {
                            for (var u = this._littleEndian,
                            l = new DataView(e, t, n), c = [], d = 0, f = 0, h = this._naluLengthSize, p = this._timestampBase + i, m = 1 === o; f < n;) {
                                if (f + 4 >= n) {
                                    s.
                                default.w(this.TAG, "Malformed Nalu near timestamp " + p + ", offset = " + f + ", dataSize = " + n);
                                    break
                                }
                                var _ = l.getUint32(f, !u);
                                if (3 === h && (_ >>>= 8), _ > n - h) return void s.
                            default.w(this.TAG, "Malformed Nalus near timestamp " + p + ", NaluSize > DataSize!");
                                var v = 31 & l.getUint8(f + h);
                                5 === v && (m = !0);
                                var g = new Uint8Array(e, t + f, h + _),
                                y = {
                                    type: v,
                                    data: g
                                };
                                c.push(y),
                                d += g.byteLength,
                                f += h + _
                            }
                            if (c.length) {
                                var b = this._videoTrack,
                                w = {
                                    units: c,
                                    length: d,
                                    isKeyframe: m,
                                    dts: p,
                                    cts: a,
                                    pts: p + a
                                };
                                m && (w.fileposition = r),
                                b.samples.push(w),
                                b.length += d
                            }
                        }
                    },
                    {
                        key: "onTrackMetadata",
                        get: function() {
                            return this._onTrackMetadata
                        },
                        set: function(e) {
                            this._onTrackMetadata = e
                        }
                    },
                    {
                        key: "onMediaInfo",
                        get: function() {
                            return this._onMediaInfo
                        },
                        set: function(e) {
                            this._onMediaInfo = e
                        }
                    },
                    {
                        key: "onError",
                        get: function() {
                            return this._onError
                        },
                        set: function(e) {
                            this._onError = e
                        }
                    },
                    {
                        key: "onDataAvailable",
                        get: function() {
                            return this._onDataAvailable
                        },
                        set: function(e) {
                            this._onDataAvailable = e
                        }
                    },
                    {
                        key: "timestampBase",
                        get: function() {
                            return this._timestampBase
                        },
                        set: function(e) {
                            this._timestampBase = e
                        }
                    },
                    {
                        key: "overridedDuration",
                        get: function() {
                            return this._duration
                        },
                        set: function(e) {
                            this._durationOverrided = !0,
                            this._duration = e,
                            this._mediaInfo.duration = e
                        }
                    },
                    {
                        key: "overridedHasAudio",
                        set: function(e) {
                            this._hasAudioFlagOverrided = !0,
                            this._hasAudio = e,
                            this._mediaInfo.hasAudio = e
                        }
                    },
                    {
                        key: "overridedHasVideo",
                        set: function(e) {
                            this._hasVideoFlagOverrided = !0,
                            this._hasVideo = e,
                            this._mediaInfo.hasVideo = e
                        }
                    }], [{
                        key: "probe",
                        value: function(e) {
                            var t = new Uint8Array(e),
                            n = {
                                match: !1
                            };
                            if (70 !== t[0] || 76 !== t[1] || 86 !== t[2] || 1 !== t[3]) return n;
                            var i, r, o = (4 & t[4]) >>> 2 != 0,
                            s = 0 != (1 & t[4]),
                            a = (i = t)[r = 5] << 24 | i[r + 1] << 16 | i[r + 2] << 8 | i[r + 3];
                            return a < 9 ? n: {
                                match: !0,
                                consumed: a,
                                dataOffset: a,
                                hasAudioTrack: o,
                                hasVideoTrack: s
                            }
                        }
                    }]),
                    e
                } ();
                n.
            default = v
            },
            {
                "../core/media-info.js": 7,
                "../utils/exception.js": 40,
                "../utils/logger.js": 41,
                "./amf-parser.js": 15,
                "./demux-errors.js": 16,
                "./sps-parser.js": 19
            }],
            19 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i, r = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                o = e("./exp-golomb.js"),
                s = (i = o) && i.__esModule ? i: {
                default:
                    i
                },
                a = function() {
                    function e() { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, e)
                    }
                    return r(e, null, [{
                        key: "_ebsp2rbsp",
                        value: function(e) {
                            for (var t = e,
                            n = t.byteLength,
                            i = new Uint8Array(n), r = 0, o = 0; o < n; o++) o >= 2 && 3 === t[o] && 0 === t[o - 1] && 0 === t[o - 2] || (i[r] = t[o], r++);
                            return new Uint8Array(i.buffer, 0, r)
                        }
                    },
                    {
                        key: "parseSPS",
                        value: function(t) {
                            var n = e._ebsp2rbsp(t),
                            i = new s.
                        default(n);
                            i.readByte();
                            var r = i.readByte();
                            i.readByte();
                            var o = i.readByte();
                            i.readUEG();
                            var a = e.getProfileString(r),
                            u = e.getLevelString(o),
                            l = 1,
                            c = 420,
                            d = 8;
                            if ((100 === r || 110 === r || 122 === r || 244 === r || 44 === r || 83 === r || 86 === r || 118 === r || 128 === r || 138 === r || 144 === r) && (3 === (l = i.readUEG()) && i.readBits(1), l <= 3 && (c = [0, 420, 422, 444][l]), d = i.readUEG() + 8, i.readUEG(), i.readBits(1), i.readBool())) for (var f = 3 !== l ? 8 : 12, h = 0; h < f; h++) i.readBool() && (h < 6 ? e._skipScalingList(i, 16) : e._skipScalingList(i, 64));
                            i.readUEG();
                            var p = i.readUEG();
                            if (0 === p) i.readUEG();
                            else if (1 === p) {
                                i.readBits(1),
                                i.readSEG(),
                                i.readSEG();
                                for (var m = i.readUEG(), _ = 0; _ < m; _++) i.readSEG()
                            }
                            var v = i.readUEG();
                            i.readBits(1);
                            var g = i.readUEG(),
                            y = i.readUEG(),
                            b = i.readBits(1);
                            0 === b && i.readBits(1),
                            i.readBits(1);
                            var w = 0,
                            E = 0,
                            S = 0,
                            k = 0,
                            x = i.readBool();
                            x && (w = i.readUEG(), E = i.readUEG(), S = i.readUEG(), k = i.readUEG());
                            var L = 1,
                            T = 1,
                            A = 0,
                            R = !0,
                            C = 0,
                            O = 0,
                            D = i.readBool();
                            if (D) {
                                if (i.readBool()) {
                                    var I = i.readByte();
                                    I > 0 && I < 16 ? (L = [1, 12, 10, 16, 40, 24, 20, 32, 80, 18, 15, 64, 160, 4, 3, 2][I - 1], T = [1, 11, 11, 11, 33, 11, 11, 11, 33, 11, 11, 33, 99, 3, 2, 1][I - 1]) : 255 === I && (L = i.readByte() << 8 | i.readByte(), T = i.readByte() << 8 | i.readByte())
                                }
                                if (i.readBool() && i.readBool(), i.readBool() && (i.readBits(4), i.readBool() && i.readBits(24)), i.readBool() && (i.readUEG(), i.readUEG()), i.readBool()) {
                                    var M = i.readBits(32),
                                    j = i.readBits(32);
                                    R = i.readBool(),
                                    A = (C = j) / (O = 2 * M)
                                }
                            }
                            var B = 1;
                            1 === L && 1 === T || (B = L / T);
                            var N = 0,
                            P = 0;
                            if (0 === l) N = 1,
                            P = 2 - b;
                            else {
                                var U = 3 === l ? 1 : 2,
                                F = 1 === l ? 2 : 1;
                                N = U,
                                P = F * (2 - b)
                            }
                            var W = 16 * (g + 1),
                            G = 16 * (y + 1) * (2 - b);
                            W -= (w + E) * N,
                            G -= (S + k) * P;
                            var H = Math.ceil(W * B);
                            return i.destroy(),
                            i = null,
                            {
                                profile_string: a,
                                level_string: u,
                                bit_depth: d,
                                ref_frames: v,
                                chroma_format: c,
                                chroma_format_string: e.getChromaFormatString(c),
                                frame_rate: {
                                    fixed: R,
                                    fps: A,
                                    fps_den: O,
                                    fps_num: C
                                },
                                sar_ratio: {
                                    width: L,
                                    height: T
                                },
                                codec_size: {
                                    width: W,
                                    height: G
                                },
                                present_size: {
                                    width: H,
                                    height: G
                                }
                            }
                        }
                    },
                    {
                        key: "_skipScalingList",
                        value: function(e, t) {
                            for (var n = 8,
                            i = 8,
                            r = 0,
                            o = 0; o < t; o++) 0 !== i && (r = e.readSEG(), i = (n + r + 256) % 256),
                            n = 0 === i ? n: i
                        }
                    },
                    {
                        key: "getProfileString",
                        value: function(e) {
                            switch (e) {
                            case 66:
                                return "Baseline";
                            case 77:
                                return "Main";
                            case 88:
                                return "Extended";
                            case 100:
                                return "High";
                            case 110:
                                return "High10";
                            case 122:
                                return "High422";
                            case 244:
                                return "High444";
                            default:
                                return "Unknown"
                            }
                        }
                    },
                    {
                        key: "getLevelString",
                        value: function(e) {
                            return (e / 10).toFixed(1)
                        }
                    },
                    {
                        key: "getChromaFormatString",
                        value: function(e) {
                            switch (e) {
                            case 420:
                                return "4:2:0";
                            case 422:
                                return "4:2:2";
                            case 444:
                                return "4:4:4";
                            default:
                                return "Unknown"
                            }
                        }
                    }]),
                    e
                } ();
                n.
            default = a
            },
            {
                "./exp-golomb.js": 17
            }],
            20 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
                function(e) {
                    return typeof e
                }: function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
                },
                r = e("./utils/polyfill.js"),
                o = g(r),
                s = e("./core/features.js"),
                a = g(s),
                u = e("./player/flv-player.js"),
                l = g(u),
                c = e("./player/native-player.js"),
                d = g(c),
                f = e("./player/player-events.js"),
                h = g(f),
                p = e("./player/player-errors.js"),
                m = e("./utils/logging-control.js"),
                _ = g(m),
                v = e("./utils/exception.js");

                function g(e) {
                    return e && e.__esModule ? e: {
                    default:
                        e
                    }
                }
                o.
            default.install();
                var y = {
                    createPlayer: function(e, t) {
                        var n = e;
                        if (null == n || "object" !== (void 0 === n ? "undefined": i(n))) throw new v.InvalidArgumentException("MediaDataSource must be an javascript object!");
                        if (!n.hasOwnProperty("type")) throw new v.InvalidArgumentException("MediaDataSource must has type field to indicate video file type!");
                        switch (n.type) {
                        case "flv":
                            return new l.
                        default(n, t);
                        default:
                            return new d.
                        default(n, t)
                        }
                    },
                    isSupported: function() {
                        return a.
                    default.supportMSEH264Playback()
                    },
                    getFeatureList: function() {
                        return a.
                    default.getFeatureList()
                    }
                };
                y.Events = h.
            default,
                y.ErrorTypes = p.ErrorTypes,
                y.ErrorDetails = p.ErrorDetails,
                y.FlvPlayer = l.
            default,
                y.NativePlayer = d.
            default,
                y.LoggingControl = _.
            default,
                Object.defineProperty(y, "version", {
                    enumerable: !0,
                    get: function() {
                        return "1.4.2"
                    }
                }),
                n.
            default = y
            },
            {
                "./core/features.js": 6,
                "./player/flv-player.js": 32,
                "./player/native-player.js": 33,
                "./player/player-errors.js": 34,
                "./player/player-events.js": 35,
                "./utils/exception.js": 40,
                "./utils/logging-control.js": 42,
                "./utils/polyfill.js": 43
            }],
            21 : [function(e, t, n) {
                "use strict";
                t.exports = e("./flv.js").
            default
            },
            {
                "./flv.js": 20
            }],
            22 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
                function(e) {
                    return typeof e
                }: function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
                },
                r = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                o = e("../utils/logger.js"),
                s = (c(o), e("../utils/browser.js")),
                a = c(s),
                u = e("./loader.js"),
                l = e("../utils/exception.js");

                function c(e) {
                    return e && e.__esModule ? e: {
                    default:
                        e
                    }
                }
                var d = function(e) {
                    function t(e, n) { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, t);
                        var i = function(e, t) {
                            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return ! t || "object" != typeof t && "function" != typeof t ? e: t
                        } (this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, "fetch-stream-loader"));
                        return i.TAG = "FetchStreamLoader",
                        i._seekHandler = e,
                        i._config = n,
                        i._needStash = !0,
                        i._requestAbort = !1,
                        i._contentLength = null,
                        i._receivedLength = 0,
                        i
                    }
                    return function(e, t) {
                        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                        e.prototype = Object.create(t && t.prototype, {
                            constructor: {
                                value: e,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }),
                        t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
                    } (t, e),
                    r(t, null, [{
                        key: "isSupported",
                        value: function() {
                            try {
                                var e = a.
                            default.msedge && a.
                            default.version.minor >= 15048,
                                t = !a.
                            default.msedge || e;
                                return self.fetch && self.ReadableStream && t
                            } catch(e) {
                                return ! 1
                            }
                        }
                    }]),
                    r(t, [{
                        key: "destroy",
                        value: function() {
                            this.isWorking() && this.abort(),
                            function e(t, n, i) {
                                null === t && (t = Function.prototype);
                                var r = Object.getOwnPropertyDescriptor(t, n);
                                if (void 0 === r) {
                                    var o = Object.getPrototypeOf(t);
                                    return null === o ? void 0 : e(o, n, i)
                                }
                                if ("value" in r) return r.value;
                                var s = r.get;
                                return void 0 !== s ? s.call(i) : void 0
                            } (t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "destroy", this).call(this)
                        }
                    },
                    {
                        key: "open",
                        value: function(e, t) {
                            var n = this;
                            this._dataSource = e,
                            this._range = t;
                            var r = e.url;
                            this._config.reuseRedirectedURL && void 0 != e.redirectedURL && (r = e.redirectedURL);
                            var o = this._seekHandler.getConfig(r, t),
                            s = new self.Headers;
                            if ("object" === i(o.headers)) {
                                var a = o.headers;
                                for (var c in a) a.hasOwnProperty(c) && s.append(c, a[c])
                            }
                            var d = {
                                method: "GET",
                                headers: s,
                                mode: "cors",
                                cache: "default",
                                referrerPolicy: "no-referrer-when-downgrade"
                            }; ! 1 === e.cors && (d.mode = "same-origin"),
                            e.withCredentials && (d.credentials = "include"),
                            e.referrerPolicy && (d.referrerPolicy = e.referrerPolicy),
                            this._status = u.LoaderStatus.kConnecting,
                            self.fetch(o.url, d).then(function(e) {
                                if (n._requestAbort) return n._requestAbort = !1,
                                void(n._status = u.LoaderStatus.kIdle);
                                if (e.ok && e.status >= 200 && e.status <= 299) {
                                    if (e.url !== o.url && n._onURLRedirect) {
                                        var t = n._seekHandler.removeURLParameters(e.url);
                                        n._onURLRedirect(t)
                                    }
                                    var i = e.headers.get("Content-Length");
                                    return null != i && (n._contentLength = parseInt(i), 0 !== n._contentLength && n._onContentLengthKnown && n._onContentLengthKnown(n._contentLength)),
                                    n._pump.call(n, e.body.getReader())
                                }
                                if (n._status = u.LoaderStatus.kError, !n._onError) throw new l.RuntimeException("FetchStreamLoader: Http code invalid, " + e.status + " " + e.statusText);
                                n._onError(u.LoaderErrors.HTTP_STATUS_CODE_INVALID, {
                                    code: e.status,
                                    msg: e.statusText
                                })
                            }).
                            catch(function(e) {
                                if (n._status = u.LoaderStatus.kError, !n._onError) throw e;
                                n._onError(u.LoaderErrors.EXCEPTION, {
                                    code: -1,
                                    msg: e.message
                                })
                            })
                        }
                    },
                    {
                        key: "abort",
                        value: function() {
                            this._requestAbort = !0
                        }
                    },
                    {
                        key: "_pump",
                        value: function(e) {
                            var t = this;
                            return e.read().then(function(n) {
                                if (n.done) if (null !== t._contentLength && t._receivedLength < t._contentLength) {
                                    t._status = u.LoaderStatus.kError;
                                    var i = u.LoaderErrors.EARLY_EOF,
                                    r = {
                                        code: -1,
                                        msg: "Fetch stream meet Early-EOF"
                                    };
                                    if (!t._onError) throw new l.RuntimeException(r.msg);
                                    t._onError(i, r)
                                } else t._status = u.LoaderStatus.kComplete,
                                t._onComplete && t._onComplete(t._range.from, t._range.from + t._receivedLength - 1);
                                else {
                                    if (!0 === t._requestAbort) return t._requestAbort = !1,
                                    t._status = u.LoaderStatus.kComplete,
                                    e.cancel();
                                    t._status = u.LoaderStatus.kBuffering;
                                    var o = n.value.buffer,
                                    s = t._range.from + t._receivedLength;
                                    t._receivedLength += o.byteLength,
                                    t._onDataArrival && t._onDataArrival(o, s, t._receivedLength),
                                    t._pump(e)
                                }
                            }).
                            catch(function(e) {
                                if (11 !== e.code || !a.
                            default.msedge) {
                                    t._status = u.LoaderStatus.kError;
                                    var n = 0,
                                    i = null;
                                    if (19 !== e.code && "network error" !== e.message || !(null === t._contentLength || null !== t._contentLength && t._receivedLength < t._contentLength) ? (n = u.LoaderErrors.EXCEPTION, i = {
                                        code: e.code,
                                        msg: e.message
                                    }) : (n = u.LoaderErrors.EARLY_EOF, i = {
                                        code: e.code,
                                        msg: "Fetch stream meet Early-EOF"
                                    }), !t._onError) throw new l.RuntimeException(i.msg);
                                    t._onError(n, i)
                                }
                            })
                        }
                    }]),
                    t
                } (u.BaseLoader);
                n.
            default = d
            },
            {
                "../utils/browser.js": 39,
                "../utils/exception.js": 40,
                "../utils/logger.js": 41,
                "./loader.js": 24
            }],
            23 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                r = e("../utils/logger.js"),
                o = S(r),
                s = e("./speed-sampler.js"),
                a = S(s),
                u = e("./loader.js"),
                l = e("./fetch-stream-loader.js"),
                c = S(l),
                d = e("./xhr-moz-chunked-loader.js"),
                f = S(d),
                h = e("./xhr-msstream-loader.js"),
                p = (S(h), e("./xhr-range-loader.js")),
                m = S(p),
                _ = e("./websocket-loader.js"),
                v = S(_),
                g = e("./range-seek-handler.js"),
                y = S(g),
                b = e("./param-seek-handler.js"),
                w = S(b),
                E = e("../utils/exception.js");

                function S(e) {
                    return e && e.__esModule ? e: {
                    default:
                        e
                    }
                }
                var k = function() {
                    function e(t, n, i) { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, e),
                        this.TAG = "IOController",
                        this._config = n,
                        this._extraData = i,
                        this._stashInitialSize = 393216,
                        void 0 != n.stashInitialSize && n.stashInitialSize > 0 && (this._stashInitialSize = n.stashInitialSize),
                        this._localStoreBuffer = [],
                        this._stashUsed = 0,
                        this._stashSize = this._stashInitialSize,
                        this._bufferSize = 3145728,
                        this._stashBuffer = new ArrayBuffer(this._bufferSize),
                        this._stashByteStart = 0,
                        this._enableStash = !0,
                        !1 === n.enableStashBuffer && (this._enableStash = !1),
                        this._loader = null,
                        this._loaderClass = null,
                        this._seekHandler = null,
                        this._dataSource = t,
                        this._isWebSocketURL = /wss?:\/\/(.+?)/.test(t.url),
                        this._refTotalLength = t.filesize ? t.filesize: null,
                        this._totalLength = this._refTotalLength,
                        this._fullRequestFlag = !1,
                        this._currentRange = null,
                        this._redirectedURL = null,
                        this._speedNormalized = 0,
                        this._speedSampler = new a.
                    default,
                        this._speedNormalizeList = [64, 128, 256, 384, 512, 768, 1024, 1536, 2048, 3072, 4096],
                        this._isEarlyEofReconnecting = !1,
                        this._paused = !1,
                        this._resumeFrom = 0,
                        this._onDataArrival = null,
                        this._onSeeked = null,
                        this._onError = null,
                        this._onComplete = null,
                        this._onRedirect = null,
                        this._onRecoveredEarlyEof = null,
                        this._selectSeekHandler(),
                        this._selectLoader(),
                        this._createLoader()
                    }
                    return i(e, [{
                        key: "destroy",
                        value: function() {
                            this._loader.isWorking() && this._loader.abort(),
                            this._loader.destroy(),
                            this._loader = null,
                            this._loaderClass = null,
                            this._dataSource = null,
                            this._stashBuffer = null,
                            this._stashUsed = this._stashSize = this._bufferSize = this._stashByteStart = 0,
                            this._currentRange = null,
                            this._speedSampler = null,
                            this._isEarlyEofReconnecting = !1,
                            this._onDataArrival = null,
                            this._onSeeked = null,
                            this._onError = null,
                            this._onComplete = null,
                            this._onRedirect = null,
                            this._onRecoveredEarlyEof = null,
                            this._extraData = null
                        }
                    },
                    {
                        key: "isWorking",
                        value: function() {
                            return this._loader && this._loader.isWorking() && !this._paused
                        }
                    },
                    {
                        key: "isPaused",
                        value: function() {
                            return this._paused
                        }
                    },
                    {
                        key: "_selectSeekHandler",
                        value: function() {
                            var e = this._config;
                            if ("range" === e.seekType) this._seekHandler = new y.
                        default(this._config.rangeLoadZeroStart);
                            else if ("param" === e.seekType) {
                                var t = e.seekParamStart || "bstart",
                                n = e.seekParamEnd || "bend";
                                this._seekHandler = new w.
                            default(t, n)
                            } else {
                                if ("custom" !== e.seekType) throw new E.InvalidArgumentException("Invalid seekType in config: " + e.seekType);
                                if ("function" != typeof e.customSeekHandler) throw new E.InvalidArgumentException("Custom seekType specified in config but invalid customSeekHandler!");
                                this._seekHandler = new e.customSeekHandler
                            }
                        }
                    },
                    {
                        key: "_selectLoader",
                        value: function() {
                            if (this._isWebSocketURL) this._loaderClass = v.
                        default;
                            else if (c.
                        default.isSupported()) this._loaderClass = c.
                        default;
                            else if (f.
                        default.isSupported()) this._loaderClass = f.
                        default;
                            else {
                                if (!m.
                            default.isSupported()) throw new E.RuntimeException("Your browser doesn't support xhr with arraybuffer responseType!");
                                this._loaderClass = m.
                            default
                            }
                        }
                    },
                    {
                        key: "_createLoader",
                        value: function() {
                            this._loader = new this._loaderClass(this._seekHandler, this._config),
                            !1 === this._loader.needStashBuffer && (this._enableStash = !1),
                            this._loader.onContentLengthKnown = this._onContentLengthKnown.bind(this),
                            this._loader.onURLRedirect = this._onURLRedirect.bind(this),
                            this._loader.onDataArrival = this._onLoaderChunkArrival.bind(this),
                            this._loader.onComplete = this._onLoaderComplete.bind(this),
                            this._loader.onError = this._onLoaderError.bind(this)
                        }
                    },
                    {
                        key: "open",
                        value: function(e) {
                            this._currentRange = {
                                from: 0,
                                to: -1
                            },
                            e && (this._currentRange.from = e),
                            this._speedSampler.reset(),
                            e || (this._fullRequestFlag = !0),
                            this._loader.open(this._dataSource, Object.assign({},
                            this._currentRange))
                        }
                    },
                    {
                        key: "abort",
                        value: function() {
                            this._loader.abort(),
                            this._paused && (this._paused = !1, this._resumeFrom = 0)
                        }
                    },
                    {
                        key: "pause",
                        value: function() {
                            this.isWorking() && (this._loader.abort(), 0 !== this._stashUsed ? (this._resumeFrom = this._stashByteStart, this._currentRange.to = this._stashByteStart - 1) : this._resumeFrom = this._currentRange.to + 1, this._stashUsed = 0, this._stashByteStart = 0, this._paused = !0)
                        }
                    },
                    {
                        key: "resume",
                        value: function() {
                            if (this._paused) {
                                this._paused = !1;
                                var e = this._resumeFrom;
                                this._resumeFrom = 0,
                                this._internalSeek(e, !0)
                            }
                        }
                    },
                    {
                        key: "seek",
                        value: function(e) {
                            this._paused = !1,
                            this._stashUsed = 0,
                            this._stashByteStart = 0,
                            this._internalSeek(e, !0)
                        }
                    },
                    {
                        key: "getLocalStoreData",
                        value: function() {
                            return new Blob([new Uint8Array(this._localStoreBuffer).buffer])
                        }
                    },
                    {
                        key: "sendWSData",
                        value: function(e) {
                            this._isWebSocketURL && this._loader._ws.send(e)
                        }
                    },
                    {
                        key: "_internalSeek",
                        value: function(e, t) {
                            this._loader.isWorking() && this._loader.abort(),
                            this._flushStashBuffer(t),
                            this._loader.destroy(),
                            this._loader = null;
                            var n = {
                                from: e,
                                to: -1
                            };
                            this._currentRange = {
                                from: n.from,
                                to: -1
                            },
                            this._speedSampler.reset(),
                            this._stashSize = this._stashInitialSize,
                            this._createLoader(),
                            this._loader.open(this._dataSource, n),
                            this._onSeeked && this._onSeeked()
                        }
                    },
                    {
                        key: "updateUrl",
                        value: function(e) {
                            if (!e || "string" != typeof e || 0 === e.length) throw new E.InvalidArgumentException("Url must be a non-empty string!");
                            this._dataSource.url = e
                        }
                    },
                    {
                        key: "_expandBuffer",
                        value: function(e) {
                            for (var t = this._stashSize; t + 1048576 < e;) t *= 2;
                            if ((t += 1048576) !== this._bufferSize) {
                                var n = new ArrayBuffer(t);
                                if (this._stashUsed > 0) {
                                    var i = new Uint8Array(this._stashBuffer, 0, this._stashUsed),
                                    r = new Uint8Array(n, 0, t);
                                    r.set(i, 0)
                                }
                                this._stashBuffer = n,
                                this._bufferSize = t
                            }
                        }
                    },
                    {
                        key: "_normalizeSpeed",
                        value: function(e) {
                            var t = this._speedNormalizeList,
                            n = t.length - 1,
                            i = 0,
                            r = 0,
                            o = n;
                            if (e < t[0]) return t[0];
                            for (; r <= o;) {
                                if ((i = r + Math.floor((o - r) / 2)) === n || e >= t[i] && e < t[i + 1]) return t[i];
                                t[i] < e ? r = i + 1 : o = i - 1
                            }
                        }
                    },
                    {
                        key: "_adjustStashSize",
                        value: function(e) {
                            var t = 0; (t = this._config.isLive ? e: e < 512 ? e: e >= 512 && e <= 1024 ? Math.floor(1.5 * e) : 2 * e) > 8192 && (t = 8192);
                            var n = 1024 * t + 1048576;
                            this._bufferSize < n && this._expandBuffer(n),
                            this._stashSize = 1024 * t
                        }
                    },
                    {
                        key: "_dispatchChunks",
                        value: function(e, t) {
                            return this._currentRange.to = t + e.byteLength - 1,
                            this._onDataArrival(e, t)
                        }
                    },
                    {
                        key: "_onURLRedirect",
                        value: function(e) {
                            this._redirectedURL = e,
                            this._onRedirect && this._onRedirect(e)
                        }
                    },
                    {
                        key: "_onContentLengthKnown",
                        value: function(e) {
                            e && this._fullRequestFlag && (this._totalLength = e, this._fullRequestFlag = !1)
                        }
                    },
                    {
                        key: "_onLoaderChunkArrival",
                        value: function(e, t, n) {
                            if (!this._onDataArrival) throw new E.IllegalStateException("IOController: No existing consumer (onDataArrival) callback!");
                            if (this._config.localStore && (this._localStoreBuffer = this._localStoreBuffer.concat(Array.from(new Uint8Array(e)))), !this._paused) {
                                this._isEarlyEofReconnecting && (this._isEarlyEofReconnecting = !1, this._onRecoveredEarlyEof && this._onRecoveredEarlyEof()),
                                this._speedSampler.addBytes(e.byteLength);
                                var i = this._speedSampler.lastSecondKBps;
                                if (0 !== i) {
                                    var r = this._normalizeSpeed(i);
                                    this._speedNormalized !== r && (this._speedNormalized = r, this._adjustStashSize(r))
                                }
                                if (this._enableStash) if (0 === this._stashUsed && 0 === this._stashByteStart && (this._stashByteStart = t), this._stashUsed + e.byteLength <= this._stashSize) {
                                    var o = new Uint8Array(this._stashBuffer, 0, this._stashSize);
                                    o.set(new Uint8Array(e), this._stashUsed),
                                    this._stashUsed += e.byteLength
                                } else {
                                    var s = new Uint8Array(this._stashBuffer, 0, this._bufferSize);
                                    if (this._stashUsed > 0) {
                                        var a = this._stashBuffer.slice(0, this._stashUsed),
                                        u = this._dispatchChunks(a, this._stashByteStart);
                                        if (u < a.byteLength) {
                                            if (u > 0) {
                                                var l = new Uint8Array(a, u);
                                                s.set(l, 0),
                                                this._stashUsed = l.byteLength,
                                                this._stashByteStart += u
                                            }
                                        } else this._stashUsed = 0,
                                        this._stashByteStart += u;
                                        this._stashUsed + e.byteLength > this._bufferSize && (this._expandBuffer(this._stashUsed + e.byteLength), s = new Uint8Array(this._stashBuffer, 0, this._bufferSize)),
                                        s.set(new Uint8Array(e), this._stashUsed),
                                        this._stashUsed += e.byteLength
                                    } else {
                                        var c = this._dispatchChunks(e, t);
                                        if (c < e.byteLength) {
                                            var d = e.byteLength - c;
                                            d > this._bufferSize && (this._expandBuffer(d), s = new Uint8Array(this._stashBuffer, 0, this._bufferSize)),
                                            s.set(new Uint8Array(e, c), 0),
                                            this._stashUsed += d,
                                            this._stashByteStart = t + c
                                        }
                                    }
                                } else if (0 === this._stashUsed) {
                                    var f = this._dispatchChunks(e, t);
                                    if (f < e.byteLength) {
                                        var h = e.byteLength - f;
                                        h > this._bufferSize && this._expandBuffer(h);
                                        var p = new Uint8Array(this._stashBuffer, 0, this._bufferSize);
                                        p.set(new Uint8Array(e, f), 0),
                                        this._stashUsed += h,
                                        this._stashByteStart = t + f
                                    }
                                } else {
                                    this._stashUsed + e.byteLength > this._bufferSize && this._expandBuffer(this._stashUsed + e.byteLength);
                                    var m = new Uint8Array(this._stashBuffer, 0, this._bufferSize);
                                    m.set(new Uint8Array(e), this._stashUsed),
                                    this._stashUsed += e.byteLength;
                                    var _ = this._dispatchChunks(this._stashBuffer.slice(0, this._stashUsed), this._stashByteStart);
                                    if (_ < this._stashUsed && _ > 0) {
                                        var v = new Uint8Array(this._stashBuffer, _);
                                        m.set(v, 0)
                                    }
                                    this._stashUsed -= _,
                                    this._stashByteStart += _
                                }
                            }
                        }
                    },
                    {
                        key: "_flushStashBuffer",
                        value: function(e) {
                            if (this._stashUsed > 0) {
                                var t = this._stashBuffer.slice(0, this._stashUsed),
                                n = this._dispatchChunks(t, this._stashByteStart),
                                i = t.byteLength - n;
                                if (n < t.byteLength) {
                                    if (!e) {
                                        if (n > 0) {
                                            var r = new Uint8Array(this._stashBuffer, 0, this._bufferSize),
                                            s = new Uint8Array(t, n);
                                            r.set(s, 0),
                                            this._stashUsed = s.byteLength,
                                            this._stashByteStart += n
                                        }
                                        return 0
                                    }
                                    o.
                                default.w(this.TAG, i + " bytes unconsumed data remain when flush buffer, dropped")
                                }
                                return this._stashUsed = 0,
                                this._stashByteStart = 0,
                                i
                            }
                            return 0
                        }
                    },
                    {
                        key: "_onLoaderComplete",
                        value: function(e, t) {
                            this._flushStashBuffer(!0),
                            this._onComplete && this._onComplete(this._extraData)
                        }
                    },
                    {
                        key: "_onLoaderError",
                        value: function(e, t) {
                            switch (o.
                        default.e(this.TAG, "Loader error, code = " + t.code + ", msg = " + t.msg), this._flushStashBuffer(!1), this._isEarlyEofReconnecting && (this._isEarlyEofReconnecting = !1, e = u.LoaderErrors.UNRECOVERABLE_EARLY_EOF), e) {
                            case u.LoaderErrors.EARLY_EOF:
                                if (!this._config.isLive && this._totalLength) {
                                    var n = this._currentRange.to + 1;
                                    return void(n < this._totalLength && (o.
                                default.w(this.TAG, "Connection lost, trying reconnect..."), this._isEarlyEofReconnecting = !0, this._internalSeek(n, !1)))
                                }
                                e = u.LoaderErrors.UNRECOVERABLE_EARLY_EOF;
                                break;
                            case u.LoaderErrors.UNRECOVERABLE_EARLY_EOF:
                            case u.LoaderErrors.CONNECTING_TIMEOUT:
                            case u.LoaderErrors.HTTP_STATUS_CODE_INVALID:
                            case u.LoaderErrors.EXCEPTION:
                            }
                            if (!this._onError) throw new E.RuntimeException("IOException: " + t.msg);
                            this._onError(e, t)
                        }
                    },
                    {
                        key: "status",
                        get: function() {
                            return this._loader.status
                        }
                    },
                    {
                        key: "extraData",
                        get: function() {
                            return this._extraData
                        },
                        set: function(e) {
                            this._extraData = e
                        }
                    },
                    {
                        key: "onDataArrival",
                        get: function() {
                            return this._onDataArrival
                        },
                        set: function(e) {
                            this._onDataArrival = e
                        }
                    },
                    {
                        key: "onSeeked",
                        get: function() {
                            return this._onSeeked
                        },
                        set: function(e) {
                            this._onSeeked = e
                        }
                    },
                    {
                        key: "onError",
                        get: function() {
                            return this._onError
                        },
                        set: function(e) {
                            this._onError = e
                        }
                    },
                    {
                        key: "onComplete",
                        get: function() {
                            return this._onComplete
                        },
                        set: function(e) {
                            this._onComplete = e
                        }
                    },
                    {
                        key: "onRedirect",
                        get: function() {
                            return this._onRedirect
                        },
                        set: function(e) {
                            this._onRedirect = e
                        }
                    },
                    {
                        key: "onRecoveredEarlyEof",
                        get: function() {
                            return this._onRecoveredEarlyEof
                        },
                        set: function(e) {
                            this._onRecoveredEarlyEof = e
                        }
                    },
                    {
                        key: "currentURL",
                        get: function() {
                            return this._dataSource.url
                        }
                    },
                    {
                        key: "hasRedirect",
                        get: function() {
                            return null != this._redirectedURL || void 0 != this._dataSource.redirectedURL
                        }
                    },
                    {
                        key: "currentRedirectedURL",
                        get: function() {
                            return this._redirectedURL || this._dataSource.redirectedURL
                        }
                    },
                    {
                        key: "currentSpeed",
                        get: function() {
                            return this._loaderClass === m.
                        default ? this._loader.currentSpeed: this._speedSampler.lastSecondKBps
                        }
                    },
                    {
                        key: "loaderType",
                        get: function() {
                            return this._loader.type
                        }
                    }]),
                    e
                } ();
                n.
            default = k
            },
            {
                "../utils/exception.js": 40,
                "../utils/logger.js": 41,
                "./fetch-stream-loader.js": 22,
                "./loader.js": 24,
                "./param-seek-handler.js": 25,
                "./range-seek-handler.js": 26,
                "./speed-sampler.js": 27,
                "./websocket-loader.js": 28,
                "./xhr-moz-chunked-loader.js": 29,
                "./xhr-msstream-loader.js": 30,
                "./xhr-range-loader.js": 31
            }],
            24 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                }),
                n.BaseLoader = n.LoaderErrors = n.LoaderStatus = void 0;
                var i = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                r = e("../utils/exception.js"),
                o = n.LoaderStatus = {
                    kIdle: 0,
                    kConnecting: 1,
                    kBuffering: 2,
                    kError: 3,
                    kComplete: 4
                };
                n.LoaderErrors = {
                    OK: "OK",
                    EXCEPTION: "Exception",
                    HTTP_STATUS_CODE_INVALID: "HttpStatusCodeInvalid",
                    CONNECTING_TIMEOUT: "ConnectingTimeout",
                    EARLY_EOF: "EarlyEof",
                    UNRECOVERABLE_EARLY_EOF: "UnrecoverableEarlyEof"
                },
                n.BaseLoader = function() {
                    function e(t) { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, e),
                        this._type = t || "undefined",
                        this._status = o.kIdle,
                        this._needStash = !1,
                        this._onContentLengthKnown = null,
                        this._onURLRedirect = null,
                        this._onDataArrival = null,
                        this._onError = null,
                        this._onComplete = null
                    }
                    return i(e, [{
                        key: "destroy",
                        value: function() {
                            this._status = o.kIdle,
                            this._onContentLengthKnown = null,
                            this._onURLRedirect = null,
                            this._onDataArrival = null,
                            this._onError = null,
                            this._onComplete = null
                        }
                    },
                    {
                        key: "isWorking",
                        value: function() {
                            return this._status === o.kConnecting || this._status === o.kBuffering
                        }
                    },
                    {
                        key: "open",
                        value: function(e, t) {
                            throw new r.NotImplementedException("Unimplemented abstract function!")
                        }
                    },
                    {
                        key: "abort",
                        value: function() {
                            throw new r.NotImplementedException("Unimplemented abstract function!")
                        }
                    },
                    {
                        key: "type",
                        get: function() {
                            return this._type
                        }
                    },
                    {
                        key: "status",
                        get: function() {
                            return this._status
                        }
                    },
                    {
                        key: "needStashBuffer",
                        get: function() {
                            return this._needStash
                        }
                    },
                    {
                        key: "onContentLengthKnown",
                        get: function() {
                            return this._onContentLengthKnown
                        },
                        set: function(e) {
                            this._onContentLengthKnown = e
                        }
                    },
                    {
                        key: "onURLRedirect",
                        get: function() {
                            return this._onURLRedirect
                        },
                        set: function(e) {
                            this._onURLRedirect = e
                        }
                    },
                    {
                        key: "onDataArrival",
                        get: function() {
                            return this._onDataArrival
                        },
                        set: function(e) {
                            this._onDataArrival = e
                        }
                    },
                    {
                        key: "onError",
                        get: function() {
                            return this._onError
                        },
                        set: function(e) {
                            this._onError = e
                        }
                    },
                    {
                        key: "onComplete",
                        get: function() {
                            return this._onComplete
                        },
                        set: function(e) {
                            this._onComplete = e
                        }
                    }]),
                    e
                } ()
            },
            {
                "../utils/exception.js": 40
            }],
            25 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                r = function() {
                    function e(t, n) { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, e),
                        this._startName = t,
                        this._endName = n
                    }
                    return i(e, [{
                        key: "getConfig",
                        value: function(e, t) {
                            var n = e;
                            if (0 !== t.from || -1 !== t.to) {
                                var i = !0; - 1 === n.indexOf("?") && (n += "?", i = !1),
                                i && (n += "&"),
                                n += this._startName + "=" + t.from.toString(),
                                -1 !== t.to && (n += "&" + this._endName + "=" + t.to.toString())
                            }
                            return {
                                url: n,
                                headers: {}
                            }
                        }
                    },
                    {
                        key: "removeURLParameters",
                        value: function(e) {
                            var t = e.split("?")[0],
                            n = void 0,
                            i = e.indexOf("?"); - 1 !== i && (n = e.substring(i + 1));
                            var r = "";
                            if (void 0 != n && n.length > 0) for (var o = n.split("&"), s = 0; s < o.length; s++) {
                                var a = o[s].split("="),
                                u = s > 0;
                                a[0] !== this._startName && a[0] !== this._endName && (u && (r += "&"), r += o[s])
                            }
                            return 0 === r.length ? t: t + "?" + r
                        }
                    }]),
                    e
                } ();
                n.
            default = r
            },
            {}],
            26 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                r = function() {
                    function e(t) { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, e),
                        this._zeroStart = t || !1
                    }
                    return i(e, [{
                        key: "getConfig",
                        value: function(e, t) {
                            var n = {};
                            if (0 !== t.from || -1 !== t.to) {
                                var i = void 0;
                                i = -1 !== t.to ? "bytes=" + t.from.toString() + "-" + t.to.toString() : "bytes=" + t.from.toString() + "-",
                                n.Range = i
                            } else this._zeroStart && (n.Range = "bytes=0-");
                            return {
                                url: e,
                                headers: n
                            }
                        }
                    },
                    {
                        key: "removeURLParameters",
                        value: function(e) {
                            return e
                        }
                    }]),
                    e
                } ();
                n.
            default = r
            },
            {}],
            27 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                r = function() {
                    function e() { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, e),
                        this._firstCheckpoint = 0,
                        this._lastCheckpoint = 0,
                        this._intervalBytes = 0,
                        this._totalBytes = 0,
                        this._lastSecondBytes = 0,
                        self.performance && self.performance.now ? this._now = self.performance.now.bind(self.performance) : this._now = Date.now
                    }
                    return i(e, [{
                        key: "reset",
                        value: function() {
                            this._firstCheckpoint = this._lastCheckpoint = 0,
                            this._totalBytes = this._intervalBytes = 0,
                            this._lastSecondBytes = 0
                        }
                    },
                    {
                        key: "addBytes",
                        value: function(e) {
                            0 === this._firstCheckpoint ? (this._firstCheckpoint = this._now(), this._lastCheckpoint = this._firstCheckpoint, this._intervalBytes += e, this._totalBytes += e) : this._now() - this._lastCheckpoint < 1e3 ? (this._intervalBytes += e, this._totalBytes += e) : (this._lastSecondBytes = this._intervalBytes, this._intervalBytes = e, this._totalBytes += e, this._lastCheckpoint = this._now())
                        }
                    },
                    {
                        key: "currentKBps",
                        get: function() {
                            this.addBytes(0);
                            var e = (this._now() - this._lastCheckpoint) / 1e3;
                            return 0 == e && (e = 1),
                            this._intervalBytes / e / 1024
                        }
                    },
                    {
                        key: "lastSecondKBps",
                        get: function() {
                            return this.addBytes(0),
                            0 !== this._lastSecondBytes ? this._lastSecondBytes / 1024 : this._now() - this._lastCheckpoint >= 500 ? this.currentKBps: 0
                        }
                    },
                    {
                        key: "averageKBps",
                        get: function() {
                            var e = (this._now() - this._firstCheckpoint) / 1e3;
                            return this._totalBytes / e / 1024
                        }
                    }]),
                    e
                } ();
                n.
            default = r
            },
            {}],
            28 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i, r = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                o = e("../utils/logger.js"),
                s = ((i = o) && i.__esModule, e("./loader.js")),
                a = e("../utils/exception.js"),
                u = function(e) {
                    function t() { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, t);
                        var e = function(e, t) {
                            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return ! t || "object" != typeof t && "function" != typeof t ? e: t
                        } (this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, "websocket-loader"));
                        return e.TAG = "WebSocketLoader",
                        e._needStash = !0,
                        e._ws = null,
                        e._requestAbort = !1,
                        e._receivedLength = 0,
                        e
                    }
                    return function(e, t) {
                        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                        e.prototype = Object.create(t && t.prototype, {
                            constructor: {
                                value: e,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }),
                        t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
                    } (t, e),
                    r(t, null, [{
                        key: "isSupported",
                        value: function() {
                            try {
                                return void 0 !== self.WebSocket
                            } catch(e) {
                                return ! 1
                            }
                        }
                    }]),
                    r(t, [{
                        key: "destroy",
                        value: function() {
                            this._ws && this.abort(),
                            function e(t, n, i) {
                                null === t && (t = Function.prototype);
                                var r = Object.getOwnPropertyDescriptor(t, n);
                                if (void 0 === r) {
                                    var o = Object.getPrototypeOf(t);
                                    return null === o ? void 0 : e(o, n, i)
                                }
                                if ("value" in r) return r.value;
                                var s = r.get;
                                return void 0 !== s ? s.call(i) : void 0
                            } (t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "destroy", this).call(this)
                        }
                    },
                    {
                        key: "open",
                        value: function(e) {
                            try {
                                var t = this._ws = new self.WebSocket(e.url);
                                t.binaryType = "arraybuffer",
                                t.onopen = this._onWebSocketOpen.bind(this),
                                t.onclose = this._onWebSocketClose.bind(this),
                                t.onmessage = this._onWebSocketMessage.bind(this),
                                t.onerror = this._onWebSocketError.bind(this),
                                this._status = s.LoaderStatus.kConnecting
                            } catch(e) {
                                this._status = s.LoaderStatus.kError;
                                var n = {
                                    code: e.code,
                                    msg: e.message
                                };
                                if (!this._onError) throw new a.RuntimeException(n.msg);
                                this._onError(s.LoaderErrors.EXCEPTION, n)
                            }
                        }
                    },
                    {
                        key: "abort",
                        value: function() {
                            var e = this._ws; ! e || 0 !== e.readyState && 1 !== e.readyState || (this._requestAbort = !0, e.close()),
                            this._ws = null,
                            this._status = s.LoaderStatus.kComplete
                        }
                    },
                    {
                        key: "_onWebSocketOpen",
                        value: function(e) {
                            this._status = s.LoaderStatus.kBuffering
                        }
                    },
                    {
                        key: "_onWebSocketClose",
                        value: function(e) { ! 0 !== this._requestAbort ? (this._status = s.LoaderStatus.kComplete, this._onComplete && this._onComplete(0, this._receivedLength - 1)) : this._requestAbort = !1
                        }
                    },
                    {
                        key: "_onWebSocketMessage",
                        value: function(e) {
                            var t = this;
                            if (e.data instanceof ArrayBuffer) this._dispatchArrayBuffer(e.data);
                            else if (e.data instanceof Blob) {
                                var n = new FileReader;
                                n.onload = function() {
                                    t._dispatchArrayBuffer(n.result)
                                },
                                n.readAsArrayBuffer(e.data)
                            } else {
                                this._status = s.LoaderStatus.kError;
                                var i = {
                                    code: -1,
                                    msg: "Unsupported WebSocket message type: " + e.data.constructor.name
                                };
                                if (!this._onError) throw new a.RuntimeException(i.msg);
                                this._onError(s.LoaderErrors.EXCEPTION, i)
                            }
                        }
                    },
                    {
                        key: "_dispatchArrayBuffer",
                        value: function(e) {
                            var t = e,
                            n = this._receivedLength;
                            this._receivedLength += t.byteLength,
                            this._onDataArrival && this._onDataArrival(t, n, this._receivedLength)
                        }
                    },
                    {
                        key: "_onWebSocketError",
                        value: function(e) {
                            this._status = s.LoaderStatus.kError;
                            var t = {
                                code: e.code,
                                msg: e.message
                            };
                            if (!this._onError) throw new a.RuntimeException(t.msg);
                            this._onError(s.LoaderErrors.EXCEPTION, t)
                        }
                    }]),
                    t
                } (s.BaseLoader);
                n.
            default = u
            },
            {
                "../utils/exception.js": 40,
                "../utils/logger.js": 41,
                "./loader.js": 24
            }],
            29 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i, r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
                function(e) {
                    return typeof e
                }: function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
                },
                o = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                s = e("../utils/logger.js"),
                a = (i = s) && i.__esModule ? i: {
                default:
                    i
                },
                u = e("./loader.js"),
                l = e("../utils/exception.js"),
                c = function(e) {
                    function t(e, n) { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, t);
                        var i = function(e, t) {
                            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return ! t || "object" != typeof t && "function" != typeof t ? e: t
                        } (this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, "xhr-moz-chunked-loader"));
                        return i.TAG = "MozChunkedLoader",
                        i._seekHandler = e,
                        i._config = n,
                        i._needStash = !0,
                        i._xhr = null,
                        i._requestAbort = !1,
                        i._contentLength = null,
                        i._receivedLength = 0,
                        i
                    }
                    return function(e, t) {
                        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                        e.prototype = Object.create(t && t.prototype, {
                            constructor: {
                                value: e,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }),
                        t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
                    } (t, e),
                    o(t, null, [{
                        key: "isSupported",
                        value: function() {
                            try {
                                var e = new XMLHttpRequest;
                                return e.open("GET", "https://example.com", !0),
                                e.responseType = "moz-chunked-arraybuffer",
                                "moz-chunked-arraybuffer" === e.responseType
                            } catch(e) {
                                return a.
                            default.w("MozChunkedLoader", e.message),
                                !1
                            }
                        }
                    }]),
                    o(t, [{
                        key: "destroy",
                        value: function() {
                            this.isWorking() && this.abort(),
                            this._xhr && (this._xhr.onreadystatechange = null, this._xhr.onprogress = null, this._xhr.onloadend = null, this._xhr.onerror = null, this._xhr = null),
                            function e(t, n, i) {
                                null === t && (t = Function.prototype);
                                var r = Object.getOwnPropertyDescriptor(t, n);
                                if (void 0 === r) {
                                    var o = Object.getPrototypeOf(t);
                                    return null === o ? void 0 : e(o, n, i)
                                }
                                if ("value" in r) return r.value;
                                var s = r.get;
                                return void 0 !== s ? s.call(i) : void 0
                            } (t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "destroy", this).call(this)
                        }
                    },
                    {
                        key: "open",
                        value: function(e, t) {
                            this._dataSource = e,
                            this._range = t;
                            var n = e.url;
                            this._config.reuseRedirectedURL && void 0 != e.redirectedURL && (n = e.redirectedURL);
                            var i = this._seekHandler.getConfig(n, t);
                            this._requestURL = i.url;
                            var o = this._xhr = new XMLHttpRequest;
                            if (o.open("GET", i.url, !0), o.responseType = "moz-chunked-arraybuffer", o.onreadystatechange = this._onReadyStateChange.bind(this), o.onprogress = this._onProgress.bind(this), o.onloadend = this._onLoadEnd.bind(this), o.onerror = this._onXhrError.bind(this), e.withCredentials && (o.withCredentials = !0), "object" === r(i.headers)) {
                                var s = i.headers;
                                for (var a in s) s.hasOwnProperty(a) && o.setRequestHeader(a, s[a])
                            }
                            this._status = u.LoaderStatus.kConnecting,
                            o.send()
                        }
                    },
                    {
                        key: "abort",
                        value: function() {
                            this._requestAbort = !0,
                            this._xhr && this._xhr.abort(),
                            this._status = u.LoaderStatus.kComplete
                        }
                    },
                    {
                        key: "_onReadyStateChange",
                        value: function(e) {
                            var t = e.target;
                            if (2 === t.readyState) {
                                if (void 0 != t.responseURL && t.responseURL !== this._requestURL && this._onURLRedirect) {
                                    var n = this._seekHandler.removeURLParameters(t.responseURL);
                                    this._onURLRedirect(n)
                                }
                                if (0 !== t.status && (t.status < 200 || t.status > 299)) {
                                    if (this._status = u.LoaderStatus.kError, !this._onError) throw new l.RuntimeException("MozChunkedLoader: Http code invalid, " + t.status + " " + t.statusText);
                                    this._onError(u.LoaderErrors.HTTP_STATUS_CODE_INVALID, {
                                        code: t.status,
                                        msg: t.statusText
                                    })
                                } else this._status = u.LoaderStatus.kBuffering
                            }
                        }
                    },
                    {
                        key: "_onProgress",
                        value: function(e) {
                            if (this._status !== u.LoaderStatus.kError) {
                                null === this._contentLength && null !== e.total && 0 !== e.total && (this._contentLength = e.total, this._onContentLengthKnown && this._onContentLengthKnown(this._contentLength));
                                var t = e.target.response,
                                n = this._range.from + this._receivedLength;
                                this._receivedLength += t.byteLength,
                                this._onDataArrival && this._onDataArrival(t, n, this._receivedLength)
                            }
                        }
                    },
                    {
                        key: "_onLoadEnd",
                        value: function(e) { ! 0 !== this._requestAbort ? this._status !== u.LoaderStatus.kError && (this._status = u.LoaderStatus.kComplete, this._onComplete && this._onComplete(this._range.from, this._range.from + this._receivedLength - 1)) : this._requestAbort = !1
                        }
                    },
                    {
                        key: "_onXhrError",
                        value: function(e) {
                            this._status = u.LoaderStatus.kError;
                            var t = 0,
                            n = null;
                            if (this._contentLength && e.loaded < this._contentLength ? (t = u.LoaderErrors.EARLY_EOF, n = {
                                code: -1,
                                msg: "Moz-Chunked stream meet Early-Eof"
                            }) : (t = u.LoaderErrors.EXCEPTION, n = {
                                code: -1,
                                msg: e.constructor.name + " " + e.type
                            }), !this._onError) throw new l.RuntimeException(n.msg);
                            this._onError(t, n)
                        }
                    }]),
                    t
                } (u.BaseLoader);
                n.
            default = c
            },
            {
                "../utils/exception.js": 40,
                "../utils/logger.js": 41,
                "./loader.js": 24
            }],
            30 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i, r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
                function(e) {
                    return typeof e
                }: function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
                },
                o = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                s = e("../utils/logger.js"),
                a = (i = s) && i.__esModule ? i: {
                default:
                    i
                },
                u = e("./loader.js"),
                l = e("../utils/exception.js"),
                c = function(e) {
                    function t(e, n) { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, t);
                        var i = function(e, t) {
                            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return ! t || "object" != typeof t && "function" != typeof t ? e: t
                        } (this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, "xhr-msstream-loader"));
                        return i.TAG = "MSStreamLoader",
                        i._seekHandler = e,
                        i._config = n,
                        i._needStash = !0,
                        i._xhr = null,
                        i._reader = null,
                        i._totalRange = null,
                        i._currentRange = null,
                        i._currentRequestURL = null,
                        i._currentRedirectedURL = null,
                        i._contentLength = null,
                        i._receivedLength = 0,
                        i._bufferLimit = 16777216,
                        i._lastTimeBufferSize = 0,
                        i._isReconnecting = !1,
                        i
                    }
                    return function(e, t) {
                        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                        e.prototype = Object.create(t && t.prototype, {
                            constructor: {
                                value: e,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }),
                        t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
                    } (t, e),
                    o(t, null, [{
                        key: "isSupported",
                        value: function() {
                            try {
                                if (void 0 === self.MSStream || void 0 === self.MSStreamReader) return ! 1;
                                var e = new XMLHttpRequest;
                                return e.open("GET", "https://example.com", !0),
                                e.responseType = "ms-stream",
                                "ms-stream" === e.responseType
                            } catch(e) {
                                return a.
                            default.w("MSStreamLoader", e.message),
                                !1
                            }
                        }
                    }]),
                    o(t, [{
                        key: "destroy",
                        value: function() {
                            this.isWorking() && this.abort(),
                            this._reader && (this._reader.onprogress = null, this._reader.onload = null, this._reader.onerror = null, this._reader = null),
                            this._xhr && (this._xhr.onreadystatechange = null, this._xhr = null),
                            function e(t, n, i) {
                                null === t && (t = Function.prototype);
                                var r = Object.getOwnPropertyDescriptor(t, n);
                                if (void 0 === r) {
                                    var o = Object.getPrototypeOf(t);
                                    return null === o ? void 0 : e(o, n, i)
                                }
                                if ("value" in r) return r.value;
                                var s = r.get;
                                return void 0 !== s ? s.call(i) : void 0
                            } (t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "destroy", this).call(this)
                        }
                    },
                    {
                        key: "open",
                        value: function(e, t) {
                            this._internalOpen(e, t, !1)
                        }
                    },
                    {
                        key: "_internalOpen",
                        value: function(e, t, n) {
                            this._dataSource = e,
                            n ? this._currentRange = t: this._totalRange = t;
                            var i = e.url;
                            this._config.reuseRedirectedURL && (void 0 != this._currentRedirectedURL ? i = this._currentRedirectedURL: void 0 != e.redirectedURL && (i = e.redirectedURL));
                            var o = this._seekHandler.getConfig(i, t);
                            this._currentRequestURL = o.url;
                            var s = this._reader = new self.MSStreamReader;
                            s.onprogress = this._msrOnProgress.bind(this),
                            s.onload = this._msrOnLoad.bind(this),
                            s.onerror = this._msrOnError.bind(this);
                            var a = this._xhr = new XMLHttpRequest;
                            if (a.open("GET", o.url, !0), a.responseType = "ms-stream", a.onreadystatechange = this._xhrOnReadyStateChange.bind(this), a.onerror = this._xhrOnError.bind(this), e.withCredentials && (a.withCredentials = !0), "object" === r(o.headers)) {
                                var l = o.headers;
                                for (var c in l) l.hasOwnProperty(c) && a.setRequestHeader(c, l[c])
                            }
                            this._isReconnecting ? this._isReconnecting = !1 : this._status = u.LoaderStatus.kConnecting,
                            a.send()
                        }
                    },
                    {
                        key: "abort",
                        value: function() {
                            this._internalAbort(),
                            this._status = u.LoaderStatus.kComplete
                        }
                    },
                    {
                        key: "_internalAbort",
                        value: function() {
                            this._reader && (1 === this._reader.readyState && this._reader.abort(), this._reader.onprogress = null, this._reader.onload = null, this._reader.onerror = null, this._reader = null),
                            this._xhr && (this._xhr.abort(), this._xhr.onreadystatechange = null, this._xhr = null)
                        }
                    },
                    {
                        key: "_xhrOnReadyStateChange",
                        value: function(e) {
                            var t = e.target;
                            if (2 === t.readyState) if (t.status >= 200 && t.status <= 299) {
                                if (this._status = u.LoaderStatus.kBuffering, void 0 != t.responseURL) {
                                    var n = this._seekHandler.removeURLParameters(t.responseURL);
                                    t.responseURL !== this._currentRequestURL && n !== this._currentRedirectedURL && (this._currentRedirectedURL = n, this._onURLRedirect && this._onURLRedirect(n))
                                }
                                var i = t.getResponseHeader("Content-Length");
                                if (null != i && null == this._contentLength) {
                                    var r = parseInt(i);
                                    r > 0 && (this._contentLength = r, this._onContentLengthKnown && this._onContentLengthKnown(this._contentLength))
                                }
                            } else {
                                if (this._status = u.LoaderStatus.kError, !this._onError) throw new l.RuntimeException("MSStreamLoader: Http code invalid, " + t.status + " " + t.statusText);
                                this._onError(u.LoaderErrors.HTTP_STATUS_CODE_INVALID, {
                                    code: t.status,
                                    msg: t.statusText
                                })
                            } else if (3 === t.readyState && t.status >= 200 && t.status <= 299) {
                                this._status = u.LoaderStatus.kBuffering;
                                var o = t.response;
                                this._reader.readAsArrayBuffer(o)
                            }
                        }
                    },
                    {
                        key: "_xhrOnError",
                        value: function(e) {
                            this._status = u.LoaderStatus.kError;
                            var t = u.LoaderErrors.EXCEPTION,
                            n = {
                                code: -1,
                                msg: e.constructor.name + " " + e.type
                            };
                            if (!this._onError) throw new l.RuntimeException(n.msg);
                            this._onError(t, n)
                        }
                    },
                    {
                        key: "_msrOnProgress",
                        value: function(e) {
                            var t = e.target,
                            n = t.result;
                            if (null != n) {
                                var i = n.slice(this._lastTimeBufferSize);
                                this._lastTimeBufferSize = n.byteLength;
                                var r = this._totalRange.from + this._receivedLength;
                                this._receivedLength += i.byteLength,
                                this._onDataArrival && this._onDataArrival(i, r, this._receivedLength),
                                n.byteLength >= this._bufferLimit && (a.
                            default.v(this.TAG, "MSStream buffer exceeded max size near " + (r + i.byteLength) + ", reconnecting..."), this._doReconnectIfNeeded())
                            } else this._doReconnectIfNeeded()
                        }
                    },
                    {
                        key: "_doReconnectIfNeeded",
                        value: function() {
                            if (null == this._contentLength || this._receivedLength < this._contentLength) {
                                this._isReconnecting = !0,
                                this._lastTimeBufferSize = 0,
                                this._internalAbort();
                                var e = {
                                    from: this._totalRange.from + this._receivedLength,
                                    to: -1
                                };
                                this._internalOpen(this._dataSource, e, !0)
                            }
                        }
                    },
                    {
                        key: "_msrOnLoad",
                        value: function(e) {
                            this._status = u.LoaderStatus.kComplete,
                            this._onComplete && this._onComplete(this._totalRange.from, this._totalRange.from + this._receivedLength - 1)
                        }
                    },
                    {
                        key: "_msrOnError",
                        value: function(e) {
                            this._status = u.LoaderStatus.kError;
                            var t = 0,
                            n = null;
                            if (this._contentLength && this._receivedLength < this._contentLength ? (t = u.LoaderErrors.EARLY_EOF, n = {
                                code: -1,
                                msg: "MSStream meet Early-Eof"
                            }) : (t = u.LoaderErrors.EARLY_EOF, n = {
                                code: -1,
                                msg: e.constructor.name + " " + e.type
                            }), !this._onError) throw new l.RuntimeException(n.msg);
                            this._onError(t, n)
                        }
                    }]),
                    t
                } (u.BaseLoader);
                n.
            default = c
            },
            {
                "../utils/exception.js": 40,
                "../utils/logger.js": 41,
                "./loader.js": 24
            }],
            31 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
                function(e) {
                    return typeof e
                }: function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
                },
                r = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                o = e("../utils/logger.js"),
                s = d(o),
                a = e("./speed-sampler.js"),
                u = d(a),
                l = e("./loader.js"),
                c = e("../utils/exception.js");

                function d(e) {
                    return e && e.__esModule ? e: {
                    default:
                        e
                    }
                }
                var f = function(e) {
                    function t(e, n) { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, t);
                        var i = function(e, t) {
                            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return ! t || "object" != typeof t && "function" != typeof t ? e: t
                        } (this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, "xhr-range-loader"));
                        return i.TAG = "RangeLoader",
                        i._seekHandler = e,
                        i._config = n,
                        i._needStash = !1,
                        i._chunkSizeKBList = [128, 256, 384, 512, 768, 1024, 1536, 2048, 3072, 4096, 5120, 6144, 7168, 8192],
                        i._currentChunkSizeKB = 384,
                        i._currentSpeedNormalized = 0,
                        i._zeroSpeedChunkCount = 0,
                        i._xhr = null,
                        i._speedSampler = new u.
                    default,
                        i._requestAbort = !1,
                        i._waitForTotalLength = !1,
                        i._totalLengthReceived = !1,
                        i._currentRequestURL = null,
                        i._currentRedirectedURL = null,
                        i._currentRequestRange = null,
                        i._totalLength = null,
                        i._contentLength = null,
                        i._receivedLength = 0,
                        i._lastTimeLoaded = 0,
                        i
                    }
                    return function(e, t) {
                        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                        e.prototype = Object.create(t && t.prototype, {
                            constructor: {
                                value: e,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }),
                        t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
                    } (t, e),
                    r(t, null, [{
                        key: "isSupported",
                        value: function() {
                            try {
                                var e = new XMLHttpRequest;
                                return e.open("GET", "https://example.com", !0),
                                e.responseType = "arraybuffer",
                                "arraybuffer" === e.responseType
                            } catch(e) {
                                return s.
                            default.w("RangeLoader", e.message),
                                !1
                            }
                        }
                    }]),
                    r(t, [{
                        key: "destroy",
                        value: function() {
                            this.isWorking() && this.abort(),
                            this._xhr && (this._xhr.onreadystatechange = null, this._xhr.onprogress = null, this._xhr.onload = null, this._xhr.onerror = null, this._xhr = null),
                            function e(t, n, i) {
                                null === t && (t = Function.prototype);
                                var r = Object.getOwnPropertyDescriptor(t, n);
                                if (void 0 === r) {
                                    var o = Object.getPrototypeOf(t);
                                    return null === o ? void 0 : e(o, n, i)
                                }
                                if ("value" in r) return r.value;
                                var s = r.get;
                                return void 0 !== s ? s.call(i) : void 0
                            } (t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "destroy", this).call(this)
                        }
                    },
                    {
                        key: "open",
                        value: function(e, t) {
                            this._dataSource = e,
                            this._range = t,
                            this._status = l.LoaderStatus.kConnecting;
                            var n = !1;
                            void 0 != this._dataSource.filesize && 0 !== this._dataSource.filesize && (n = !0, this._totalLength = this._dataSource.filesize),
                            this._totalLengthReceived || n ? this._openSubRange() : (this._waitForTotalLength = !0, this._internalOpen(this._dataSource, {
                                from: 0,
                                to: -1
                            }))
                        }
                    },
                    {
                        key: "_openSubRange",
                        value: function() {
                            var e = 1024 * this._currentChunkSizeKB,
                            t = this._range.from + this._receivedLength,
                            n = t + e;
                            null != this._contentLength && n - this._range.from >= this._contentLength && (n = this._range.from + this._contentLength - 1),
                            this._currentRequestRange = {
                                from: t,
                                to: n
                            },
                            this._internalOpen(this._dataSource, this._currentRequestRange)
                        }
                    },
                    {
                        key: "_internalOpen",
                        value: function(e, t) {
                            this._lastTimeLoaded = 0;
                            var n = e.url;
                            this._config.reuseRedirectedURL && (void 0 != this._currentRedirectedURL ? n = this._currentRedirectedURL: void 0 != e.redirectedURL && (n = e.redirectedURL));
                            var r = this._seekHandler.getConfig(n, t);
                            this._currentRequestURL = r.url;
                            var o = this._xhr = new XMLHttpRequest;
                            if (o.open("GET", r.url, !0), o.responseType = "arraybuffer", o.onreadystatechange = this._onReadyStateChange.bind(this), o.onprogress = this._onProgress.bind(this), o.onload = this._onLoad.bind(this), o.onerror = this._onXhrError.bind(this), e.withCredentials && (o.withCredentials = !0), "object" === i(r.headers)) {
                                var s = r.headers;
                                for (var a in s) s.hasOwnProperty(a) && o.setRequestHeader(a, s[a])
                            }
                            o.send()
                        }
                    },
                    {
                        key: "abort",
                        value: function() {
                            this._requestAbort = !0,
                            this._internalAbort(),
                            this._status = l.LoaderStatus.kComplete
                        }
                    },
                    {
                        key: "_internalAbort",
                        value: function() {
                            this._xhr && (this._xhr.onreadystatechange = null, this._xhr.onprogress = null, this._xhr.onload = null, this._xhr.onerror = null, this._xhr.abort(), this._xhr = null)
                        }
                    },
                    {
                        key: "_onReadyStateChange",
                        value: function(e) {
                            var t = e.target;
                            if (2 === t.readyState) {
                                if (void 0 != t.responseURL) {
                                    var n = this._seekHandler.removeURLParameters(t.responseURL);
                                    t.responseURL !== this._currentRequestURL && n !== this._currentRedirectedURL && (this._currentRedirectedURL = n, this._onURLRedirect && this._onURLRedirect(n))
                                }
                                if (t.status >= 200 && t.status <= 299) {
                                    if (this._waitForTotalLength) return;
                                    this._status = l.LoaderStatus.kBuffering
                                } else {
                                    if (this._status = l.LoaderStatus.kError, !this._onError) throw new c.RuntimeException("RangeLoader: Http code invalid, " + t.status + " " + t.statusText);
                                    this._onError(l.LoaderErrors.HTTP_STATUS_CODE_INVALID, {
                                        code: t.status,
                                        msg: t.statusText
                                    })
                                }
                            }
                        }
                    },
                    {
                        key: "_onProgress",
                        value: function(e) {
                            if (this._status !== l.LoaderStatus.kError) {
                                if (null === this._contentLength) {
                                    var t = !1;
                                    if (this._waitForTotalLength) {
                                        this._waitForTotalLength = !1,
                                        this._totalLengthReceived = !0,
                                        t = !0;
                                        var n = e.total;
                                        this._internalAbort(),
                                        null != n & 0 !== n && (this._totalLength = n)
                                    }
                                    if ( - 1 === this._range.to ? this._contentLength = this._totalLength - this._range.from: this._contentLength = this._range.to - this._range.from + 1, t) return void this._openSubRange();
                                    this._onContentLengthKnown && this._onContentLengthKnown(this._contentLength)
                                }
                                var i = e.loaded - this._lastTimeLoaded;
                                this._lastTimeLoaded = e.loaded,
                                this._speedSampler.addBytes(i)
                            }
                        }
                    },
                    {
                        key: "_normalizeSpeed",
                        value: function(e) {
                            var t = this._chunkSizeKBList,
                            n = t.length - 1,
                            i = 0,
                            r = 0,
                            o = n;
                            if (e < t[0]) return t[0];
                            for (; r <= o;) {
                                if ((i = r + Math.floor((o - r) / 2)) === n || e >= t[i] && e < t[i + 1]) return t[i];
                                t[i] < e ? r = i + 1 : o = i - 1
                            }
                        }
                    },
                    {
                        key: "_onLoad",
                        value: function(e) {
                            if (this._status !== l.LoaderStatus.kError) if (this._waitForTotalLength) this._waitForTotalLength = !1;
                            else {
                                this._lastTimeLoaded = 0;
                                var t = this._speedSampler.lastSecondKBps;
                                if (0 === t && (this._zeroSpeedChunkCount++, this._zeroSpeedChunkCount >= 3 && (t = this._speedSampler.currentKBps)), 0 !== t) {
                                    var n = this._normalizeSpeed(t);
                                    this._currentSpeedNormalized !== n && (this._currentSpeedNormalized = n, this._currentChunkSizeKB = n)
                                }
                                var i = e.target.response,
                                r = this._range.from + this._receivedLength;
                                this._receivedLength += i.byteLength;
                                var o = !1;
                                null != this._contentLength && this._receivedLength < this._contentLength ? this._openSubRange() : o = !0,
                                this._onDataArrival && this._onDataArrival(i, r, this._receivedLength),
                                o && (this._status = l.LoaderStatus.kComplete, this._onComplete && this._onComplete(this._range.from, this._range.from + this._receivedLength - 1))
                            }
                        }
                    },
                    {
                        key: "_onXhrError",
                        value: function(e) {
                            this._status = l.LoaderStatus.kError;
                            var t = 0,
                            n = null;
                            if (this._contentLength && this._receivedLength > 0 && this._receivedLength < this._contentLength ? (t = l.LoaderErrors.EARLY_EOF, n = {
                                code: -1,
                                msg: "RangeLoader meet Early-Eof"
                            }) : (t = l.LoaderErrors.EXCEPTION, n = {
                                code: -1,
                                msg: e.constructor.name + " " + e.type
                            }), !this._onError) throw new c.RuntimeException(n.msg);
                            this._onError(t, n)
                        }
                    },
                    {
                        key: "currentSpeed",
                        get: function() {
                            return this._speedSampler.lastSecondKBps
                        }
                    }]),
                    t
                } (l.BaseLoader);
                n.
            default = f
            },
            {
                "../utils/exception.js": 40,
                "../utils/logger.js": 41,
                "./loader.js": 24,
                "./speed-sampler.js": 27
            }],
            32 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
                function(e) {
                    return typeof e
                }: function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
                },
                r = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                o = e("events"),
                s = k(o),
                a = e("../utils/logger.js"),
                u = k(a),
                l = e("../utils/browser.js"),
                c = k(l),
                d = e("./player-events.js"),
                f = k(d),
                h = e("../core/transmuxer.js"),
                p = k(h),
                m = e("../core/transmuxing-events.js"),
                _ = k(m),
                v = e("../core/mse-controller.js"),
                g = k(v),
                y = e("../core/mse-events.js"),
                b = k(y),
                w = e("./player-errors.js"),
                E = e("../config.js"),
                S = e("../utils/exception.js");

                function k(e) {
                    return e && e.__esModule ? e: {
                    default:
                        e
                    }
                }
                var x = function() {
                    function e(t, n) {
                        if (function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, e), this.TAG = "FlvPlayer", this._type = "FlvPlayer", this._emitter = new s.
                    default, this._config = (0, E.createDefaultConfig)(), "object" === (void 0 === n ? "undefined": i(n)) && Object.assign(this._config, n), "flv" !== t.type.toLowerCase()) throw new S.InvalidArgumentException("FlvPlayer requires an flv MediaDataSource input!"); ! 0 === t.isLive && (this._config.isLive = !0),
                        this.e = {
                            onvLoadedMetadata: this._onvLoadedMetadata.bind(this),
                            onvSeeking: this._onvSeeking.bind(this),
                            onvCanPlay: this._onvCanPlay.bind(this),
                            onvStalled: this._onvStalled.bind(this),
                            onvProgress: this._onvProgress.bind(this)
                        },
                        self.performance && self.performance.now ? this._now = self.performance.now.bind(self.performance) : this._now = Date.now,
                        this._pendingSeekTime = null,
                        this._requestSetTime = !1,
                        this._seekpointRecord = null,
                        this._progressChecker = null,
                        this._mediaDataSource = t,
                        this._mediaElement = null,
                        this._msectl = null,
                        this._transmuxer = null,
                        this._mseSourceOpened = !1,
                        this._hasPendingLoad = !1,
                        this._receivedCanPlay = !1,
                        this._mediaInfo = null,
                        this._statisticsInfo = null;
                        var r = c.
                    default.chrome && (c.
                    default.version.major < 50 || 50 === c.
                    default.version.major && c.
                    default.version.build < 2661);
                        this._alwaysSeekKeyframe = !!(r || c.
                    default.msedge || c.
                    default.msie),
                        this._alwaysSeekKeyframe && (this._config.accurateSeek = !1)
                    }
                    return r(e, [{
                        key: "destroy",
                        value: function() {
                            null != this._progressChecker && (window.clearInterval(this._progressChecker), this._progressChecker = null),
                            this._transmuxer && this.unload(),
                            this._mediaElement && this.detachMediaElement(),
                            this.e = null,
                            this._mediaDataSource = null,
                            this._emitter.removeAllListeners(),
                            this._emitter = null
                        }
                    },
                    {
                        key: "on",
                        value: function(e, t) {
                            var n = this;
                            e === f.
                        default.MEDIA_INFO ? null != this._mediaInfo && Promise.resolve().then(function() {
                                n._emitter.emit(f.
                            default.MEDIA_INFO, n.mediaInfo)
                            }) : e === f.
                        default.STATISTICS_INFO && null != this._statisticsInfo && Promise.resolve().then(function() {
                                n._emitter.emit(f.
                            default.STATISTICS_INFO, n.statisticsInfo)
                            }),
                            this._emitter.addListener(e, t)
                        }
                    },
                    {
                        key: "off",
                        value: function(e, t) {
                            this._emitter.removeListener(e, t)
                        }
                    },
                    {
                        key: "attachMediaElement",
                        value: function(e) {
                            var t = this;
                            if (this._mediaElement = e, e.addEventListener("loadedmetadata", this.e.onvLoadedMetadata), e.addEventListener("seeking", this.e.onvSeeking), e.addEventListener("canplay", this.e.onvCanPlay), e.addEventListener("stalled", this.e.onvStalled), e.addEventListener("progress", this.e.onvProgress), this._msectl = new g.
                        default(this._config), this._msectl.on(b.
                        default.UPDATE_END, this._onmseUpdateEnd.bind(this)), this._msectl.on(b.
                        default.BUFFER_FULL, this._onmseBufferFull.bind(this)), this._msectl.on(b.
                        default.SOURCE_OPEN,
                            function() {
                                t._mseSourceOpened = !0,
                                t._hasPendingLoad && (t._hasPendingLoad = !1, t.load())
                            }), this._msectl.on(b.
                        default.ERROR,
                            function(e) {
                                t._emitter.emit(f.
                            default.ERROR, w.ErrorTypes.MEDIA_ERROR, w.ErrorDetails.MEDIA_MSE_ERROR, e)
                            }), this._msectl.attachMediaElement(e), null != this._pendingSeekTime) try {
                                e.currentTime = this._pendingSeekTime,
                                this._pendingSeekTime = null
                            } catch(e) {}
                        }
                    },
                    {
                        key: "detachMediaElement",
                        value: function() {
                            this._mediaElement && (this._msectl.detachMediaElement(), this._mediaElement.removeEventListener("loadedmetadata", this.e.onvLoadedMetadata), this._mediaElement.removeEventListener("seeking", this.e.onvSeeking), this._mediaElement.removeEventListener("canplay", this.e.onvCanPlay), this._mediaElement.removeEventListener("stalled", this.e.onvStalled), this._mediaElement.removeEventListener("progress", this.e.onvProgress), this._mediaElement = null),
                            this._msectl && (this._msectl.destroy(), this._msectl = null)
                        }
                    },
                    {
                        key: "load",
                        value: function() {
                            var e = this;
                            if (!this._mediaElement) throw new S.IllegalStateException("HTMLMediaElement must be attached before load()!");
                            if (this._transmuxer) throw new S.IllegalStateException("FlvPlayer.load() has been called, please call unload() first!");
                            this._hasPendingLoad || (this._config.deferLoadAfterSourceOpen && !1 === this._mseSourceOpened ? this._hasPendingLoad = !0 : (this._mediaElement.readyState > 0 && (this._requestSetTime = !0, this._mediaElement.currentTime = 0), this._transmuxer = new p.
                        default(this._mediaDataSource, this._config), this._transmuxer.on(_.
                        default.INIT_SEGMENT,
                            function(t, n) {
                                e._msectl.appendInitSegment(n)
                            }), this._transmuxer.on(_.
                        default.MEDIA_SEGMENT,
                            function(t, n) {
                                if (e._msectl.appendMediaSegment(n), e._config.lazyLoad && !e._config.isLive) {
                                    var i = e._mediaElement.currentTime;
                                    n.info.endDts >= 1e3 * (i + e._config.lazyLoadMaxDuration) && null == e._progressChecker && (u.
                                default.v(e.TAG, "Maximum buffering duration exceeded, suspend transmuxing task"), e._suspendTransmuxer())
                                }
                            }), this._transmuxer.on(_.
                        default.LOADING_COMPLETE,
                            function() {
                                e._msectl.endOfStream(),
                                e._emitter.emit(f.
                            default.LOADING_COMPLETE)
                            }), this._transmuxer.on(_.
                        default.RECOVERED_EARLY_EOF,
                            function() {
                                e._emitter.emit(f.
                            default.RECOVERED_EARLY_EOF)
                            }), this._transmuxer.on(_.
                        default.IO_ERROR,
                            function(t, n) {
                                e._emitter.emit(f.
                            default.ERROR, w.ErrorTypes.NETWORK_ERROR, t, n)
                            }), this._transmuxer.on(_.
                        default.DEMUX_ERROR,
                            function(t, n) {
                                e._emitter.emit(f.
                            default.ERROR, w.ErrorTypes.MEDIA_ERROR, t, {
                                    code: -1,
                                    msg: n
                                })
                            }), this._transmuxer.on(_.
                        default.MEDIA_INFO,
                            function(t) {
                                e._mediaInfo = t,
                                e._emitter.emit(f.
                            default.MEDIA_INFO, Object.assign({},
                                t))
                            }), this._transmuxer.on(_.
                        default.STATISTICS_INFO,
                            function(t) {
                                e._statisticsInfo = e._fillStatisticsInfo(t),
                                e._emitter.emit(f.
                            default.STATISTICS_INFO, Object.assign({},
                                e._statisticsInfo))
                            }), this._transmuxer.on(_.
                        default.RECOMMEND_SEEKPOINT,
                            function(t) {
                                e._mediaElement && !e._config.accurateSeek && (e._requestSetTime = !0, e._mediaElement.currentTime = t / 1e3)
                            }), this._transmuxer.open()))
                        }
                    },
                    {
                        key: "unload",
                        value: function() {
                            this._mediaElement && this._mediaElement.pause(),
                            this._msectl && this._msectl.seek(0),
                            this._transmuxer && (this._transmuxer.close(), this._transmuxer.destroy(), this._transmuxer = null)
                        }
                    },
                    {
                        key: "play",
                        value: function() {
                            return this._mediaElement.play()
                        }
                    },
                    {
                        key: "pause",
                        value: function() {
                            this._mediaElement.pause()
                        }
                    },
                    {
                        key: "sendWSData",
                        value: function(e) {
                            this._transmuxer.sendWSData(e)
                        }
                    },
                    {
                        key: "_fillStatisticsInfo",
                        value: function(e) {
                            if (e.playerType = this._type, !(this._mediaElement instanceof HTMLVideoElement)) return e;
                            var t = !0,
                            n = 0,
                            i = 0;
                            if (this._mediaElement.getVideoPlaybackQuality) {
                                var r = this._mediaElement.getVideoPlaybackQuality();
                                n = r.totalVideoFrames,
                                i = r.droppedVideoFrames
                            } else void 0 != this._mediaElement.webkitDecodedFrameCount ? (n = this._mediaElement.webkitDecodedFrameCount, i = this._mediaElement.webkitDroppedFrameCount) : t = !1;
                            return t && (e.decodedFrames = n, e.droppedFrames = i),
                            e
                        }
                    },
                    {
                        key: "_onmseUpdateEnd",
                        value: function() {
                            if (this._config.lazyLoad && !this._config.isLive) {
                                for (var e = this._mediaElement.buffered,
                                t = this._mediaElement.currentTime,
                                n = 0,
                                i = 0; i < e.length; i++) {
                                    var r = e.start(i),
                                    o = e.end(i);
                                    if (r <= t && t < o) {
                                        n = o;
                                        break
                                    }
                                }
                                n >= t + this._config.lazyLoadMaxDuration && null == this._progressChecker && (u.
                            default.v(this.TAG, "Maximum buffering duration exceeded, suspend transmuxing task"), this._suspendTransmuxer())
                            }
                        }
                    },
                    {
                        key: "_onmseBufferFull",
                        value: function() {
                            u.
                        default.v(this.TAG, "MSE SourceBuffer is full, suspend transmuxing task"),
                            null == this._progressChecker && this._suspendTransmuxer()
                        }
                    },
                    {
                        key: "_suspendTransmuxer",
                        value: function() {
                            this._transmuxer && (this._transmuxer.pause(), null == this._progressChecker && (this._progressChecker = window.setInterval(this._checkProgressAndResume.bind(this), 1e3)))
                        }
                    },
                    {
                        key: "_checkProgressAndResume",
                        value: function() {
                            for (var e = this._mediaElement.currentTime,
                            t = this._mediaElement.buffered,
                            n = !1,
                            i = 0; i < t.length; i++) {
                                var r = t.start(i),
                                o = t.end(i);
                                if (e >= r && e < o) {
                                    e >= o - this._config.lazyLoadRecoverDuration && (n = !0);
                                    break
                                }
                            }
                            n && (window.clearInterval(this._progressChecker), this._progressChecker = null, n && (u.
                        default.v(this.TAG, "Continue loading from paused position"), this._transmuxer.resume()))
                        }
                    },
                    {
                        key: "_isTimepointBuffered",
                        value: function(e) {
                            for (var t = this._mediaElement.buffered,
                            n = 0; n < t.length; n++) {
                                var i = t.start(n),
                                r = t.end(n);
                                if (e >= i && e < r) return ! 0
                            }
                            return ! 1
                        }
                    },
                    {
                        key: "_internalSeek",
                        value: function(e) {
                            var t = this._isTimepointBuffered(e),
                            n = !1,
                            i = 0;
                            if (e < 1 && this._mediaElement.buffered.length > 0) {
                                var r = this._mediaElement.buffered.start(0); (r < 1 && e < r || c.
                            default.safari) && (n = !0, i = c.
                            default.safari ? .1 : r)
                            }
                            if (n) this._requestSetTime = !0,
                            this._mediaElement.currentTime = i;
                            else if (t) {
                                if (this._alwaysSeekKeyframe) {
                                    var o = this._msectl.getNearestKeyframe(Math.floor(1e3 * e));
                                    this._requestSetTime = !0,
                                    this._mediaElement.currentTime = null != o ? o.dts / 1e3: e
                                } else this._requestSetTime = !0,
                                this._mediaElement.currentTime = e;
                                null != this._progressChecker && this._checkProgressAndResume()
                            } else null != this._progressChecker && (window.clearInterval(this._progressChecker), this._progressChecker = null),
                            this._msectl.seek(e),
                            this._transmuxer.seek(Math.floor(1e3 * e)),
                            this._config.accurateSeek && (this._requestSetTime = !0, this._mediaElement.currentTime = e)
                        }
                    },
                    {
                        key: "_checkAndApplyUnbufferedSeekpoint",
                        value: function() {
                            if (this._seekpointRecord) if (this._seekpointRecord.recordTime <= this._now() - 100) {
                                var e = this._mediaElement.currentTime;
                                this._seekpointRecord = null,
                                this._isTimepointBuffered(e) || (null != this._progressChecker && (window.clearTimeout(this._progressChecker), this._progressChecker = null), this._msectl.seek(e), this._transmuxer.seek(Math.floor(1e3 * e)), this._config.accurateSeek && (this._requestSetTime = !0, this._mediaElement.currentTime = e))
                            } else window.setTimeout(this._checkAndApplyUnbufferedSeekpoint.bind(this), 50)
                        }
                    },
                    {
                        key: "_checkAndResumeStuckPlayback",
                        value: function(e) {
                            var t = this._mediaElement;
                            if (e || !this._receivedCanPlay || t.readyState < 2) {
                                var n = t.buffered;
                                n.length > 0 && t.currentTime < n.start(0) && (u.
                            default.w(this.TAG, "Playback seems stuck at " + t.currentTime + ", seek to " + n.start(0)), this._requestSetTime = !0, this._mediaElement.currentTime = n.start(0), this._mediaElement.removeEventListener("progress", this.e.onvProgress))
                            } else this._mediaElement.removeEventListener("progress", this.e.onvProgress)
                        }
                    },
                    {
                        key: "_onvLoadedMetadata",
                        value: function(e) {
                            null != this._pendingSeekTime && (this._mediaElement.currentTime = this._pendingSeekTime, this._pendingSeekTime = null)
                        }
                    },
                    {
                        key: "_onvSeeking",
                        value: function(e) {
                            var t = this._mediaElement.currentTime,
                            n = this._mediaElement.buffered;
                            if (this._requestSetTime) this._requestSetTime = !1;
                            else {
                                if (t < 1 && n.length > 0) {
                                    var i = n.start(0);
                                    if (i < 1 && t < i || c.
                                default.safari) return this._requestSetTime = !0,
                                    void(this._mediaElement.currentTime = c.
                                default.safari ? .1 : i)
                                }
                                if (this._isTimepointBuffered(t)) {
                                    if (this._alwaysSeekKeyframe) {
                                        var r = this._msectl.getNearestKeyframe(Math.floor(1e3 * t));
                                        null != r && (this._requestSetTime = !0, this._mediaElement.currentTime = r.dts / 1e3)
                                    }
                                    null != this._progressChecker && this._checkProgressAndResume()
                                } else this._seekpointRecord = {
                                    seekPoint: t,
                                    recordTime: this._now()
                                },
                                window.setTimeout(this._checkAndApplyUnbufferedSeekpoint.bind(this), 50)
                            }
                        }
                    },
                    {
                        key: "_onvCanPlay",
                        value: function(e) {
                            this._receivedCanPlay = !0,
                            this._mediaElement.removeEventListener("canplay", this.e.onvCanPlay)
                        }
                    },
                    {
                        key: "_onvStalled",
                        value: function(e) {
                            this._checkAndResumeStuckPlayback(!0)
                        }
                    },
                    {
                        key: "_onvProgress",
                        value: function(e) {
                            this._checkAndResumeStuckPlayback()
                        }
                    },
                    {
                        key: "type",
                        get: function() {
                            return this._type
                        }
                    },
                    {
                        key: "buffered",
                        get: function() {
                            return this._mediaElement.buffered
                        }
                    },
                    {
                        key: "duration",
                        get: function() {
                            return this._mediaElement.duration
                        }
                    },
                    {
                        key: "volume",
                        get: function() {
                            return this._mediaElement.volume
                        },
                        set: function(e) {
                            this._mediaElement.volume = e
                        }
                    },
                    {
                        key: "muted",
                        get: function() {
                            return this._mediaElement.muted
                        },
                        set: function(e) {
                            this._mediaElement.muted = e
                        }
                    },
                    {
                        key: "currentTime",
                        get: function() {
                            return this._mediaElement ? this._mediaElement.currentTime: 0
                        },
                        set: function(e) {
                            this._mediaElement ? this._internalSeek(e) : this._pendingSeekTime = e
                        }
                    },
                    {
                        key: "mediaInfo",
                        get: function() {
                            return Object.assign({},
                            this._mediaInfo)
                        }
                    },
                    {
                        key: "statisticsInfo",
                        get: function() {
                            return null == this._statisticsInfo && (this._statisticsInfo = {}),
                            this._statisticsInfo = this._fillStatisticsInfo(this._statisticsInfo),
                            Object.assign({},
                            this._statisticsInfo)
                        }
                    }]),
                    e
                } ();
                n.
            default = x
            },
            {
                "../config.js": 5,
                "../core/mse-controller.js": 9,
                "../core/mse-events.js": 10,
                "../core/transmuxer.js": 11,
                "../core/transmuxing-events.js": 13,
                "../utils/browser.js": 39,
                "../utils/exception.js": 40,
                "../utils/logger.js": 41,
                "./player-errors.js": 34,
                "./player-events.js": 35,
                events: 2
            }],
            33 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
                function(e) {
                    return typeof e
                }: function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
                },
                r = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                o = e("events"),
                s = d(o),
                a = e("./player-events.js"),
                u = d(a),
                l = e("../config.js"),
                c = e("../utils/exception.js");

                function d(e) {
                    return e && e.__esModule ? e: {
                    default:
                        e
                    }
                }
                var f = function() {
                    function e(t, n) {
                        if (function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, e), this.TAG = "NativePlayer", this._type = "NativePlayer", this._emitter = new s.
                    default, this._config = (0, l.createDefaultConfig)(), "object" === (void 0 === n ? "undefined": i(n)) && Object.assign(this._config, n), "flv" === t.type.toLowerCase()) throw new c.InvalidArgumentException("NativePlayer does't support flv MediaDataSource input!");
                        if (t.hasOwnProperty("segments")) throw new c.InvalidArgumentException("NativePlayer(" + t.type + ") doesn't support multipart playback!");
                        this.e = {
                            onvLoadedMetadata: this._onvLoadedMetadata.bind(this)
                        },
                        this._pendingSeekTime = null,
                        this._statisticsReporter = null,
                        this._mediaDataSource = t,
                        this._mediaElement = null
                    }
                    return r(e, [{
                        key: "destroy",
                        value: function() {
                            this._mediaElement && (this.unload(), this.detachMediaElement()),
                            this.e = null,
                            this._mediaDataSource = null,
                            this._emitter.removeAllListeners(),
                            this._emitter = null
                        }
                    },
                    {
                        key: "on",
                        value: function(e, t) {
                            var n = this;
                            e === u.
                        default.MEDIA_INFO ? null != this._mediaElement && 0 !== this._mediaElement.readyState && Promise.resolve().then(function() {
                                n._emitter.emit(u.
                            default.MEDIA_INFO, n.mediaInfo)
                            }) : e === u.
                        default.STATISTICS_INFO && null != this._mediaElement && 0 !== this._mediaElement.readyState && Promise.resolve().then(function() {
                                n._emitter.emit(u.
                            default.STATISTICS_INFO, n.statisticsInfo)
                            }),
                            this._emitter.addListener(e, t)
                        }
                    },
                    {
                        key: "off",
                        value: function(e, t) {
                            this._emitter.removeListener(e, t)
                        }
                    },
                    {
                        key: "attachMediaElement",
                        value: function(e) {
                            if (this._mediaElement = e, e.addEventListener("loadedmetadata", this.e.onvLoadedMetadata), null != this._pendingSeekTime) try {
                                e.currentTime = this._pendingSeekTime,
                                this._pendingSeekTime = null
                            } catch(e) {}
                        }
                    },
                    {
                        key: "detachMediaElement",
                        value: function() {
                            this._mediaElement && (this._mediaElement.src = "", this._mediaElement.removeAttribute("src"), this._mediaElement.removeEventListener("loadedmetadata", this.e.onvLoadedMetadata), this._mediaElement = null),
                            null != this._statisticsReporter && (window.clearInterval(this._statisticsReporter), this._statisticsReporter = null)
                        }
                    },
                    {
                        key: "load",
                        value: function() {
                            if (!this._mediaElement) throw new c.IllegalStateException("HTMLMediaElement must be attached before load()!");
                            this._mediaElement.src = this._mediaDataSource.url,
                            this._mediaElement.readyState > 0 && (this._mediaElement.currentTime = 0),
                            this._mediaElement.preload = "auto",
                            this._mediaElement.load(),
                            this._statisticsReporter = window.setInterval(this._reportStatisticsInfo.bind(this), this._config.statisticsInfoReportInterval)
                        }
                    },
                    {
                        key: "unload",
                        value: function() {
                            this._mediaElement && (this._mediaElement.src = "", this._mediaElement.removeAttribute("src")),
                            null != this._statisticsReporter && (window.clearInterval(this._statisticsReporter), this._statisticsReporter = null)
                        }
                    },
                    {
                        key: "play",
                        value: function() {
                            return this._mediaElement.play()
                        }
                    },
                    {
                        key: "pause",
                        value: function() {
                            this._mediaElement.pause()
                        }
                    },
                    {
                        key: "_onvLoadedMetadata",
                        value: function(e) {
                            null != this._pendingSeekTime && (this._mediaElement.currentTime = this._pendingSeekTime, this._pendingSeekTime = null),
                            this._emitter.emit(u.
                        default.MEDIA_INFO, this.mediaInfo)
                        }
                    },
                    {
                        key: "_reportStatisticsInfo",
                        value: function() {
                            this._emitter.emit(u.
                        default.STATISTICS_INFO, this.statisticsInfo)
                        }
                    },
                    {
                        key: "type",
                        get: function() {
                            return this._type
                        }
                    },
                    {
                        key: "buffered",
                        get: function() {
                            return this._mediaElement.buffered
                        }
                    },
                    {
                        key: "duration",
                        get: function() {
                            return this._mediaElement.duration
                        }
                    },
                    {
                        key: "volume",
                        get: function() {
                            return this._mediaElement.volume
                        },
                        set: function(e) {
                            this._mediaElement.volume = e
                        }
                    },
                    {
                        key: "muted",
                        get: function() {
                            return this._mediaElement.muted
                        },
                        set: function(e) {
                            this._mediaElement.muted = e
                        }
                    },
                    {
                        key: "currentTime",
                        get: function() {
                            return this._mediaElement ? this._mediaElement.currentTime: 0
                        },
                        set: function(e) {
                            this._mediaElement ? this._mediaElement.currentTime = e: this._pendingSeekTime = e
                        }
                    },
                    {
                        key: "mediaInfo",
                        get: function() {
                            var e = this._mediaElement instanceof HTMLAudioElement ? "audio/": "video/",
                            t = {
                                mimeType: e + this._mediaDataSource.type
                            };
                            return this._mediaElement && (t.duration = Math.floor(1e3 * this._mediaElement.duration), this._mediaElement instanceof HTMLVideoElement && (t.width = this._mediaElement.videoWidth, t.height = this._mediaElement.videoHeight)),
                            t
                        }
                    },
                    {
                        key: "statisticsInfo",
                        get: function() {
                            var e = {
                                playerType: this._type,
                                url: this._mediaDataSource.url
                            };
                            if (! (this._mediaElement instanceof HTMLVideoElement)) return e;
                            var t = !0,
                            n = 0,
                            i = 0;
                            if (this._mediaElement.getVideoPlaybackQuality) {
                                var r = this._mediaElement.getVideoPlaybackQuality();
                                n = r.totalVideoFrames,
                                i = r.droppedVideoFrames
                            } else void 0 != this._mediaElement.webkitDecodedFrameCount ? (n = this._mediaElement.webkitDecodedFrameCount, i = this._mediaElement.webkitDroppedFrameCount) : t = !1;
                            return t && (e.decodedFrames = n, e.droppedFrames = i),
                            e
                        }
                    }]),
                    e
                } ();
                n.
            default = f
            },
            {
                "../config.js": 5,
                "../utils/exception.js": 40,
                "./player-events.js": 35,
                events: 2
            }],
            34 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                }),
                n.ErrorDetails = n.ErrorTypes = void 0;
                var i, r = e("../io/loader.js"),
                o = e("../demux/demux-errors.js"),
                s = (i = o) && i.__esModule ? i: {
                default:
                    i
                };
                n.ErrorTypes = {
                    NETWORK_ERROR: "NetworkError",
                    MEDIA_ERROR: "MediaError",
                    OTHER_ERROR: "OtherError"
                },
                n.ErrorDetails = {
                    NETWORK_EXCEPTION: r.LoaderErrors.EXCEPTION,
                    NETWORK_STATUS_CODE_INVALID: r.LoaderErrors.HTTP_STATUS_CODE_INVALID,
                    NETWORK_TIMEOUT: r.LoaderErrors.CONNECTING_TIMEOUT,
                    NETWORK_UNRECOVERABLE_EARLY_EOF: r.LoaderErrors.UNRECOVERABLE_EARLY_EOF,
                    MEDIA_MSE_ERROR: "MediaMSEError",
                    MEDIA_FORMAT_ERROR: s.
                default.FORMAT_ERROR,
                    MEDIA_FORMAT_UNSUPPORTED: s.
                default.FORMAT_UNSUPPORTED,
                    MEDIA_CODEC_UNSUPPORTED: s.
                default.CODEC_UNSUPPORTED
                }
            },
            {
                "../demux/demux-errors.js": 16,
                "../io/loader.js": 24
            }],
            35 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                }),
                n.
            default = {
                    ERROR: "error",
                    LOADING_COMPLETE: "loading_complete",
                    RECOVERED_EARLY_EOF: "recovered_early_eof",
                    MEDIA_INFO: "media_info",
                    STATISTICS_INFO: "statistics_info"
                }
            },
            {}],
            36 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                r = function() {
                    function e() { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, e)
                    }
                    return i(e, null, [{
                        key: "getSilentFrame",
                        value: function(e, t) {
                            if ("mp4a.40.2" === e) {
                                if (1 === t) return new Uint8Array([0, 200, 0, 128, 35, 128]);
                                if (2 === t) return new Uint8Array([33, 0, 73, 144, 2, 25, 0, 35, 128]);
                                if (3 === t) return new Uint8Array([0, 200, 0, 128, 32, 132, 1, 38, 64, 8, 100, 0, 142]);
                                if (4 === t) return new Uint8Array([0, 200, 0, 128, 32, 132, 1, 38, 64, 8, 100, 0, 128, 44, 128, 8, 2, 56]);
                                if (5 === t) return new Uint8Array([0, 200, 0, 128, 32, 132, 1, 38, 64, 8, 100, 0, 130, 48, 4, 153, 0, 33, 144, 2, 56]);
                                if (6 === t) return new Uint8Array([0, 200, 0, 128, 32, 132, 1, 38, 64, 8, 100, 0, 130, 48, 4, 153, 0, 33, 144, 2, 0, 178, 0, 32, 8, 224])
                            } else {
                                if (1 === t) return new Uint8Array([1, 64, 34, 128, 163, 78, 230, 128, 186, 8, 0, 0, 0, 28, 6, 241, 193, 10, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 94]);
                                if (2 === t) return new Uint8Array([1, 64, 34, 128, 163, 94, 230, 128, 186, 8, 0, 0, 0, 0, 149, 0, 6, 241, 161, 10, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 94]);
                                if (3 === t) return new Uint8Array([1, 64, 34, 128, 163, 94, 230, 128, 186, 8, 0, 0, 0, 0, 149, 0, 6, 241, 161, 10, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 94])
                            }
                            return null
                        }
                    }]),
                    e
                } ();
                n.
            default = r
            },
            {}],
            37 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                r = function() {
                    function e() { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, e)
                    }
                    return i(e, null, [{
                        key: "init",
                        value: function() {
                            for (var t in e.types = {
                                avc1: [],
                                avcC: [],
                                btrt: [],
                                dinf: [],
                                dref: [],
                                esds: [],
                                ftyp: [],
                                hdlr: [],
                                mdat: [],
                                mdhd: [],
                                mdia: [],
                                mfhd: [],
                                minf: [],
                                moof: [],
                                moov: [],
                                mp4a: [],
                                mvex: [],
                                mvhd: [],
                                sdtp: [],
                                stbl: [],
                                stco: [],
                                stsc: [],
                                stsd: [],
                                stsz: [],
                                stts: [],
                                tfdt: [],
                                tfhd: [],
                                traf: [],
                                trak: [],
                                trun: [],
                                trex: [],
                                tkhd: [],
                                vmhd: [],
                                smhd: [],
                                ".mp3": []
                            },
                            e.types) e.types.hasOwnProperty(t) && (e.types[t] = [t.charCodeAt(0), t.charCodeAt(1), t.charCodeAt(2), t.charCodeAt(3)]);
                            var n = e.constants = {};
                            n.FTYP = new Uint8Array([105, 115, 111, 109, 0, 0, 0, 1, 105, 115, 111, 109, 97, 118, 99, 49]),
                            n.STSD_PREFIX = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 1]),
                            n.STTS = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0]),
                            n.STSC = n.STCO = n.STTS,
                            n.STSZ = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
                            n.HDLR_VIDEO = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 118, 105, 100, 101, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 86, 105, 100, 101, 111, 72, 97, 110, 100, 108, 101, 114, 0]),
                            n.HDLR_AUDIO = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 115, 111, 117, 110, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 83, 111, 117, 110, 100, 72, 97, 110, 100, 108, 101, 114, 0]),
                            n.DREF = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 12, 117, 114, 108, 32, 0, 0, 0, 1]),
                            n.SMHD = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0]),
                            n.VMHD = new Uint8Array([0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0])
                        }
                    },
                    {
                        key: "box",
                        value: function(e) {
                            for (var t = 8,
                            n = null,
                            i = Array.prototype.slice.call(arguments, 1), r = i.length, o = 0; o < r; o++) t += i[o].byteLength; (n = new Uint8Array(t))[0] = t >>> 24 & 255,
                            n[1] = t >>> 16 & 255,
                            n[2] = t >>> 8 & 255,
                            n[3] = 255 & t,
                            n.set(e, 4);
                            for (var s = 8,
                            a = 0; a < r; a++) n.set(i[a], s),
                            s += i[a].byteLength;
                            return n
                        }
                    },
                    {
                        key: "generateInitSegment",
                        value: function(t) {
                            var n = e.box(e.types.ftyp, e.constants.FTYP),
                            i = e.moov(t),
                            r = new Uint8Array(n.byteLength + i.byteLength);
                            return r.set(n, 0),
                            r.set(i, n.byteLength),
                            r
                        }
                    },
                    {
                        key: "moov",
                        value: function(t) {
                            var n = e.mvhd(t.timescale, t.duration),
                            i = e.trak(t),
                            r = e.mvex(t);
                            return e.box(e.types.moov, n, i, r)
                        }
                    },
                    {
                        key: "mvhd",
                        value: function(t, n) {
                            return e.box(e.types.mvhd, new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, t >>> 24 & 255, t >>> 16 & 255, t >>> 8 & 255, 255 & t, n >>> 24 & 255, n >>> 16 & 255, n >>> 8 & 255, 255 & n, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 64, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255]))
                        }
                    },
                    {
                        key: "trak",
                        value: function(t) {
                            return e.box(e.types.trak, e.tkhd(t), e.mdia(t))
                        }
                    },
                    {
                        key: "tkhd",
                        value: function(t) {
                            var n = t.id,
                            i = t.duration,
                            r = t.presentWidth,
                            o = t.presentHeight;
                            return e.box(e.types.tkhd, new Uint8Array([0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, n >>> 24 & 255, n >>> 16 & 255, n >>> 8 & 255, 255 & n, 0, 0, 0, 0, i >>> 24 & 255, i >>> 16 & 255, i >>> 8 & 255, 255 & i, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 64, 0, 0, 0, r >>> 8 & 255, 255 & r, 0, 0, o >>> 8 & 255, 255 & o, 0, 0]))
                        }
                    },
                    {
                        key: "mdia",
                        value: function(t) {
                            return e.box(e.types.mdia, e.mdhd(t), e.hdlr(t), e.minf(t))
                        }
                    },
                    {
                        key: "mdhd",
                        value: function(t) {
                            var n = t.timescale,
                            i = t.duration;
                            return e.box(e.types.mdhd, new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, n >>> 24 & 255, n >>> 16 & 255, n >>> 8 & 255, 255 & n, i >>> 24 & 255, i >>> 16 & 255, i >>> 8 & 255, 255 & i, 85, 196, 0, 0]))
                        }
                    },
                    {
                        key: "hdlr",
                        value: function(t) {
                            var n = null;
                            return n = "audio" === t.type ? e.constants.HDLR_AUDIO: e.constants.HDLR_VIDEO,
                            e.box(e.types.hdlr, n)
                        }
                    },
                    {
                        key: "minf",
                        value: function(t) {
                            var n = null;
                            return n = "audio" === t.type ? e.box(e.types.smhd, e.constants.SMHD) : e.box(e.types.vmhd, e.constants.VMHD),
                            e.box(e.types.minf, n, e.dinf(), e.stbl(t))
                        }
                    },
                    {
                        key: "dinf",
                        value: function() {
                            var t = e.box(e.types.dinf, e.box(e.types.dref, e.constants.DREF));
                            return t
                        }
                    },
                    {
                        key: "stbl",
                        value: function(t) {
                            var n = e.box(e.types.stbl, e.stsd(t), e.box(e.types.stts, e.constants.STTS), e.box(e.types.stsc, e.constants.STSC), e.box(e.types.stsz, e.constants.STSZ), e.box(e.types.stco, e.constants.STCO));
                            return n
                        }
                    },
                    {
                        key: "stsd",
                        value: function(t) {
                            return "audio" === t.type ? "mp3" === t.codec ? e.box(e.types.stsd, e.constants.STSD_PREFIX, e.mp3(t)) : e.box(e.types.stsd, e.constants.STSD_PREFIX, e.mp4a(t)) : e.box(e.types.stsd, e.constants.STSD_PREFIX, e.avc1(t))
                        }
                    },
                    {
                        key: "mp3",
                        value: function(t) {
                            var n = t.channelCount,
                            i = t.audioSampleRate,
                            r = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, n, 0, 16, 0, 0, 0, 0, i >>> 8 & 255, 255 & i, 0, 0]);
                            return e.box(e.types[".mp3"], r)
                        }
                    },
                    {
                        key: "mp4a",
                        value: function(t) {
                            var n = t.channelCount,
                            i = t.audioSampleRate,
                            r = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, n, 0, 16, 0, 0, 0, 0, i >>> 8 & 255, 255 & i, 0, 0]);
                            return e.box(e.types.mp4a, r, e.esds(t))
                        }
                    },
                    {
                        key: "esds",
                        value: function(t) {
                            var n = t.config || [],
                            i = n.length,
                            r = new Uint8Array([0, 0, 0, 0, 3, 23 + i, 0, 1, 0, 4, 15 + i, 64, 21, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5].concat([i]).concat(n).concat([6, 1, 2]));
                            return e.box(e.types.esds, r)
                        }
                    },
                    {
                        key: "avc1",
                        value: function(t) {
                            var n = t.avcc,
                            i = t.codecWidth,
                            r = t.codecHeight,
                            o = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, i >>> 8 & 255, 255 & i, r >>> 8 & 255, 255 & r, 0, 72, 0, 0, 0, 72, 0, 0, 0, 0, 0, 0, 0, 1, 10, 120, 113, 113, 47, 102, 108, 118, 46, 106, 115, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 255, 255]);
                            return e.box(e.types.avc1, o, e.box(e.types.avcC, n))
                        }
                    },
                    {
                        key: "mvex",
                        value: function(t) {
                            return e.box(e.types.mvex, e.trex(t))
                        }
                    },
                    {
                        key: "trex",
                        value: function(t) {
                            var n = t.id,
                            i = new Uint8Array([0, 0, 0, 0, n >>> 24 & 255, n >>> 16 & 255, n >>> 8 & 255, 255 & n, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1]);
                            return e.box(e.types.trex, i)
                        }
                    },
                    {
                        key: "moof",
                        value: function(t, n) {
                            return e.box(e.types.moof, e.mfhd(t.sequenceNumber), e.traf(t, n))
                        }
                    },
                    {
                        key: "mfhd",
                        value: function(t) {
                            var n = new Uint8Array([0, 0, 0, 0, t >>> 24 & 255, t >>> 16 & 255, t >>> 8 & 255, 255 & t]);
                            return e.box(e.types.mfhd, n)
                        }
                    },
                    {
                        key: "traf",
                        value: function(t, n) {
                            var i = t.id,
                            r = e.box(e.types.tfhd, new Uint8Array([0, 0, 0, 0, i >>> 24 & 255, i >>> 16 & 255, i >>> 8 & 255, 255 & i])),
                            o = e.box(e.types.tfdt, new Uint8Array([0, 0, 0, 0, n >>> 24 & 255, n >>> 16 & 255, n >>> 8 & 255, 255 & n])),
                            s = e.sdtp(t),
                            a = e.trun(t, s.byteLength + 16 + 16 + 8 + 16 + 8 + 8);
                            return e.box(e.types.traf, r, o, a, s)
                        }
                    },
                    {
                        key: "sdtp",
                        value: function(t) {
                            for (var n = t.samples || [], i = n.length, r = new Uint8Array(4 + i), o = 0; o < i; o++) {
                                var s = n[o].flags;
                                r[o + 4] = s.isLeading << 6 | s.dependsOn << 4 | s.isDependedOn << 2 | s.hasRedundancy
                            }
                            return e.box(e.types.sdtp, r)
                        }
                    },
                    {
                        key: "trun",
                        value: function(t, n) {
                            var i = t.samples || [],
                            r = i.length,
                            o = 12 + 16 * r,
                            s = new Uint8Array(o);
                            n += 8 + o,
                            s.set([0, 0, 15, 1, r >>> 24 & 255, r >>> 16 & 255, r >>> 8 & 255, 255 & r, n >>> 24 & 255, n >>> 16 & 255, n >>> 8 & 255, 255 & n], 0);
                            for (var a = 0; a < r; a++) {
                                var u = i[a].duration,
                                l = i[a].size,
                                c = i[a].flags,
                                d = i[a].cts;
                                s.set([u >>> 24 & 255, u >>> 16 & 255, u >>> 8 & 255, 255 & u, l >>> 24 & 255, l >>> 16 & 255, l >>> 8 & 255, 255 & l, c.isLeading << 2 | c.dependsOn, c.isDependedOn << 6 | c.hasRedundancy << 4 | c.isNonSync, 0, 0, d >>> 24 & 255, d >>> 16 & 255, d >>> 8 & 255, 255 & d], 12 + 16 * a)
                            }
                            return e.box(e.types.trun, s)
                        }
                    },
                    {
                        key: "mdat",
                        value: function(t) {
                            return e.box(e.types.mdat, t)
                        }
                    }]),
                    e
                } ();
                r.init(),
                n.
            default = r
            },
            {}],
            38 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                r = e("../utils/logger.js"),
                o = p(r),
                s = e("./mp4-generator.js"),
                a = p(s),
                u = e("./aac-silent.js"),
                l = p(u),
                c = e("../utils/browser.js"),
                d = p(c),
                f = e("../core/media-segment-info.js"),
                h = e("../utils/exception.js");

                function p(e) {
                    return e && e.__esModule ? e: {
                    default:
                        e
                    }
                }
                var m = function() {
                    function e(t) { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, e),
                        this.TAG = "MP4Remuxer",
                        this._config = t,
                        this._isLive = !0 === t.isLive,
                        this._dtsBase = -1,
                        this._dtsBaseInited = !1,
                        this._audioDtsBase = 1 / 0,
                        this._videoDtsBase = 1 / 0,
                        this._audioNextDts = void 0,
                        this._videoNextDts = void 0,
                        this._audioStashedLastSample = null,
                        this._videoStashedLastSample = null,
                        this._audioMeta = null,
                        this._videoMeta = null,
                        this._audioSegmentInfoList = new f.MediaSegmentInfoList("audio"),
                        this._videoSegmentInfoList = new f.MediaSegmentInfoList("video"),
                        this._onInitSegment = null,
                        this._onMediaSegment = null,
                        this._forceFirstIDR = !(!d.
                    default.chrome || !(d.
                    default.version.major < 50 || 50 === d.
                    default.version.major && d.
                    default.version.build < 2661)),
                        this._fillSilentAfterSeek = d.
                    default.msedge || d.
                    default.msie,
                        this._mp3UseMpegAudio = !d.
                    default.firefox,
                        this._fillAudioTimestampGap = this._config.fixAudioTimestampGap
                    }
                    return i(e, [{
                        key: "destroy",
                        value: function() {
                            this._dtsBase = -1,
                            this._dtsBaseInited = !1,
                            this._audioMeta = null,
                            this._videoMeta = null,
                            this._audioSegmentInfoList.clear(),
                            this._audioSegmentInfoList = null,
                            this._videoSegmentInfoList.clear(),
                            this._videoSegmentInfoList = null,
                            this._onInitSegment = null,
                            this._onMediaSegment = null
                        }
                    },
                    {
                        key: "bindDataSource",
                        value: function(e) {
                            return e.onDataAvailable = this.remux.bind(this),
                            e.onTrackMetadata = this._onTrackMetadataReceived.bind(this),
                            this
                        }
                    },
                    {
                        key: "insertDiscontinuity",
                        value: function() {
                            this._audioNextDts = this._videoNextDts = void 0
                        }
                    },
                    {
                        key: "seek",
                        value: function(e) {
                            this._audioStashedLastSample = null,
                            this._videoStashedLastSample = null,
                            this._videoSegmentInfoList.clear(),
                            this._audioSegmentInfoList.clear()
                        }
                    },
                    {
                        key: "remux",
                        value: function(e, t) {
                            if (!this._onMediaSegment) throw new h.IllegalStateException("MP4Remuxer: onMediaSegment callback must be specificed!");
                            this._dtsBaseInited || this._calculateDtsBase(e, t),
                            this._remuxVideo(t),
                            this._remuxAudio(e)
                        }
                    },
                    {
                        key: "_onTrackMetadataReceived",
                        value: function(e, t) {
                            var n = null,
                            i = "mp4",
                            r = t.codec;
                            if ("audio" === e) this._audioMeta = t,
                            "mp3" === t.codec && this._mp3UseMpegAudio ? (i = "mpeg", r = "", n = new Uint8Array) : n = a.
                        default.generateInitSegment(t);
                            else {
                                if ("video" !== e) return;
                                this._videoMeta = t,
                                n = a.
                            default.generateInitSegment(t)
                            }
                            if (!this._onInitSegment) throw new h.IllegalStateException("MP4Remuxer: onInitSegment callback must be specified!");
                            this._onInitSegment(e, {
                                type: e,
                                data: n.buffer,
                                codec: r,
                                container: e + "/" + i,
                                mediaDuration: t.duration
                            })
                        }
                    },
                    {
                        key: "_calculateDtsBase",
                        value: function(e, t) {
                            this._dtsBaseInited || (e.samples && e.samples.length && (this._audioDtsBase = e.samples[0].dts), t.samples && t.samples.length && (this._videoDtsBase = t.samples[0].dts), this._dtsBase = Math.min(this._audioDtsBase, this._videoDtsBase), this._dtsBaseInited = !0)
                        }
                    },
                    {
                        key: "flushStashedSamples",
                        value: function() {
                            var e = this._videoStashedLastSample,
                            t = this._audioStashedLastSample,
                            n = {
                                type: "video",
                                id: 1,
                                sequenceNumber: 0,
                                samples: [],
                                length: 0
                            };
                            null != e && (n.samples.push(e), n.length = e.length);
                            var i = {
                                type: "audio",
                                id: 2,
                                sequenceNumber: 0,
                                samples: [],
                                length: 0
                            };
                            null != t && (i.samples.push(t), i.length = t.length),
                            this._videoStashedLastSample = null,
                            this._audioStashedLastSample = null,
                            this._remuxVideo(n, !0),
                            this._remuxAudio(i, !0)
                        }
                    },
                    {
                        key: "_remuxAudio",
                        value: function(e, t) {
                            if (null != this._audioMeta) {
                                var n = e,
                                i = n.samples,
                                r = void 0,
                                s = -1,
                                u = -1,
                                c = this._audioMeta.refSampleDuration,
                                h = "mp3" === this._audioMeta.codec && this._mp3UseMpegAudio,
                                p = this._dtsBaseInited && void 0 === this._audioNextDts,
                                m = !1;
                                if (i && 0 !== i.length && (1 !== i.length || t)) {
                                    var _ = 0,
                                    v = null,
                                    g = 0;
                                    h ? (_ = 0, g = n.length) : (_ = 8, g = 8 + n.length);
                                    var y = null;
                                    if (i.length > 1 && (y = i.pop(), g -= y.length), null != this._audioStashedLastSample) {
                                        var b = this._audioStashedLastSample;
                                        this._audioStashedLastSample = null,
                                        i.unshift(b),
                                        g += b.length
                                    }
                                    null != y && (this._audioStashedLastSample = y);
                                    var w = i[0].dts - this._dtsBase;
                                    if (this._audioNextDts) r = w - this._audioNextDts;
                                    else if (this._audioSegmentInfoList.isEmpty()) r = 0,
                                    this._fillSilentAfterSeek && !this._videoSegmentInfoList.isEmpty() && "mp3" !== this._audioMeta.originalCodec && (m = !0);
                                    else {
                                        var E = this._audioSegmentInfoList.getLastSampleBefore(w);
                                        if (null != E) {
                                            var S = w - (E.originalDts + E.duration);
                                            S <= 3 && (S = 0);
                                            var k = E.dts + E.duration + S;
                                            r = w - k
                                        } else r = 0
                                    }
                                    if (m) {
                                        var x = w - r,
                                        L = this._videoSegmentInfoList.getLastSegmentBefore(w);
                                        if (null != L && L.beginDts < x) {
                                            var T = l.
                                        default.getSilentFrame(this._audioMeta.originalCodec, this._audioMeta.channelCount);
                                            if (T) {
                                                var A = L.beginDts,
                                                R = x - L.beginDts;
                                                o.
                                            default.v(this.TAG, "InsertPrefixSilentAudio: dts: " + A + ", duration: " + R),
                                                i.unshift({
                                                    unit: T,
                                                    dts: A,
                                                    pts: A
                                                }),
                                                g += T.byteLength
                                            }
                                        } else m = !1
                                    }
                                    for (var C = [], O = 0; O < i.length; O++) {
                                        var D = i[O],
                                        I = D.unit,
                                        M = D.dts - this._dtsBase,
                                        j = M - r; - 1 === s && (s = j);
                                        var B = 0;
                                        if (O !== i.length - 1) {
                                            var N = i[O + 1].dts - this._dtsBase - r;
                                            B = N - j
                                        } else if (null != y) {
                                            var P = y.dts - this._dtsBase - r;
                                            B = P - j
                                        } else B = C.length >= 1 ? C[C.length - 1].duration: Math.floor(c);
                                        var U = !1,
                                        F = null;
                                        if (B > 1.5 * c && "mp3" !== this._audioMeta.codec && this._fillAudioTimestampGap && !d.
                                    default.safari) {
                                            U = !0;
                                            var W = Math.abs(B - c),
                                            G = Math.ceil(W / c),
                                            H = j + c;
                                            o.
                                        default.w(this.TAG, "Large audio timestamp gap detected, may cause AV sync to drift. Silent frames will be generated to avoid unsync.\ndts: " + (j + B) + " ms, expected: " + (j + Math.round(c)) + " ms, delta: " + Math.round(W) + " ms, generate: " + G + " frames");
                                            var q = l.
                                        default.getSilentFrame(this._audioMeta.originalCodec, this._audioMeta.channelCount);
                                            null == q && (o.
                                        default.w(this.TAG, "Unable to generate silent frame for " + this._audioMeta.originalCodec + " with " + this._audioMeta.channelCount + " channels, repeat last frame"), q = I),
                                            F = [];
                                            for (var z = 0; z < G; z++) {
                                                var V = Math.round(H);
                                                if (F.length > 0) {
                                                    var K = F[F.length - 1];
                                                    K.duration = V - K.dts
                                                }
                                                var X = {
                                                    dts: V,
                                                    pts: V,
                                                    cts: 0,
                                                    unit: q,
                                                    size: q.byteLength,
                                                    duration: 0,
                                                    originalDts: M,
                                                    flags: {
                                                        isLeading: 0,
                                                        dependsOn: 1,
                                                        isDependedOn: 0,
                                                        hasRedundancy: 0
                                                    }
                                                };
                                                F.push(X),
                                                g += I.byteLength,
                                                H += c
                                            }
                                            var $ = F[F.length - 1];
                                            $.duration = j + B - $.dts,
                                            B = Math.round(c)
                                        }
                                        C.push({
                                            dts: j,
                                            pts: j,
                                            cts: 0,
                                            unit: D.unit,
                                            size: D.unit.byteLength,
                                            duration: B,
                                            originalDts: M,
                                            flags: {
                                                isLeading: 0,
                                                dependsOn: 1,
                                                isDependedOn: 0,
                                                hasRedundancy: 0
                                            }
                                        }),
                                        U && C.push.apply(C, F)
                                    }
                                    h ? v = new Uint8Array(g) : ((v = new Uint8Array(g))[0] = g >>> 24 & 255, v[1] = g >>> 16 & 255, v[2] = g >>> 8 & 255, v[3] = 255 & g, v.set(a.
                                default.types.mdat, 4));
                                    for (var Y = 0; Y < C.length; Y++) {
                                        var Q = C[Y].unit;
                                        if (Q.byteLength + _ > v.byteLength) {
                                            console.log("mdatbox total=" + v.byteLength + ",offset=" + _ + ",uint length=" + Q.byteLength);
                                            var J = new Uint8Array(Q.byteLength + _);
                                            J.set(v, 0),
                                            v = J
                                        }
                                        try {
                                            v.set(Q, _),
                                            _ += Q.byteLength
                                        } catch(e) {}
                                    }
                                    v.byteLength > g && (v[0] = v.byteLength >>> 24 & 255, v[1] = v.byteLength >>> 16 & 255, v[2] = v.byteLength >>> 8 & 255, v[3] = 255 & v.byteLength);
                                    var Z = C[C.length - 1];
                                    u = Z.dts + Z.duration,
                                    this._audioNextDts = u;
                                    var ee = new f.MediaSegmentInfo;
                                    ee.beginDts = s,
                                    ee.endDts = u,
                                    ee.beginPts = s,
                                    ee.endPts = u,
                                    ee.originalBeginDts = C[0].originalDts,
                                    ee.originalEndDts = Z.originalDts + Z.duration,
                                    ee.firstSample = new f.SampleInfo(C[0].dts, C[0].pts, C[0].duration, C[0].originalDts, !1),
                                    ee.lastSample = new f.SampleInfo(Z.dts, Z.pts, Z.duration, Z.originalDts, !1),
                                    this._isLive || this._audioSegmentInfoList.append(ee),
                                    n.samples = C,
                                    n.sequenceNumber++;
                                    var te = null;
                                    te = h ? new Uint8Array: a.
                                default.moof(n, s),
                                    n.samples = [],
                                    n.length = 0;
                                    var ne = {
                                        type: "audio",
                                        data: this._mergeBoxes(te, v).buffer,
                                        sampleCount: C.length,
                                        info: ee
                                    };
                                    h && p && (ne.timestampOffset = s),
                                    this._onMediaSegment("audio", ne)
                                }
                            }
                        }
                    },
                    {
                        key: "_remuxVideo",
                        value: function(e, t) {
                            if (null != this._videoMeta) {
                                var n = e,
                                i = n.samples,
                                r = void 0,
                                o = -1,
                                s = -1,
                                u = -1,
                                l = -1;
                                if (i && 0 !== i.length && (1 !== i.length || t)) {
                                    var c = 8,
                                    d = null,
                                    h = 8 + e.length,
                                    p = null;
                                    if (i.length > 1 && (p = i.pop(), h -= p.length), null != this._videoStashedLastSample) {
                                        var m = this._videoStashedLastSample;
                                        this._videoStashedLastSample = null,
                                        i.unshift(m),
                                        h += m.length
                                    }
                                    null != p && (this._videoStashedLastSample = p);
                                    var _ = i[0].dts - this._dtsBase;
                                    if (this._videoNextDts) r = _ - this._videoNextDts;
                                    else if (this._videoSegmentInfoList.isEmpty()) r = 0;
                                    else {
                                        var v = this._videoSegmentInfoList.getLastSampleBefore(_);
                                        if (null != v) {
                                            var g = _ - (v.originalDts + v.duration);
                                            g <= 3 && (g = 0);
                                            var y = v.dts + v.duration + g;
                                            r = _ - y
                                        } else r = 0
                                    }
                                    for (var b = new f.MediaSegmentInfo,
                                    w = [], E = 0; E < i.length; E++) {
                                        var S = i[E],
                                        k = S.dts - this._dtsBase,
                                        x = S.isKeyframe,
                                        L = k - r,
                                        T = S.cts,
                                        A = L + T; - 1 === o && (o = L, u = A);
                                        var R = 0;
                                        if (E !== i.length - 1) {
                                            var C = i[E + 1].dts - this._dtsBase - r;
                                            R = C - L
                                        } else if (null != p) {
                                            var O = p.dts - this._dtsBase - r;
                                            R = O - L
                                        } else R = w.length >= 1 ? w[w.length - 1].duration: Math.floor(this._videoMeta.refSampleDuration);
                                        if (x) {
                                            var D = new f.SampleInfo(L, A, R, S.dts, !0);
                                            D.fileposition = S.fileposition,
                                            b.appendSyncPoint(D)
                                        }
                                        w.push({
                                            dts: L,
                                            pts: A,
                                            cts: T,
                                            units: S.units,
                                            size: S.length,
                                            isKeyframe: x,
                                            duration: R,
                                            originalDts: k,
                                            flags: {
                                                isLeading: 0,
                                                dependsOn: x ? 2 : 1,
                                                isDependedOn: x ? 1 : 0,
                                                hasRedundancy: 0,
                                                isNonSync: x ? 0 : 1
                                            }
                                        })
                                    } (d = new Uint8Array(h))[0] = h >>> 24 & 255,
                                    d[1] = h >>> 16 & 255,
                                    d[2] = h >>> 8 & 255,
                                    d[3] = 255 & h,
                                    d.set(a.
                                default.types.mdat, 4);
                                    for (var I = 0; I < w.length; I++) for (var M = w[I].units; M.length;) {
                                        var j = M.shift(),
                                        B = j.data;
                                        d.set(B, c),
                                        c += B.byteLength
                                    }
                                    var N = w[w.length - 1];
                                    if (s = N.dts + N.duration, l = N.pts + N.duration, this._videoNextDts = s, b.beginDts = o, b.endDts = s, b.beginPts = u, b.endPts = l, b.originalBeginDts = w[0].originalDts, b.originalEndDts = N.originalDts + N.duration, b.firstSample = new f.SampleInfo(w[0].dts, w[0].pts, w[0].duration, w[0].originalDts, w[0].isKeyframe), b.lastSample = new f.SampleInfo(N.dts, N.pts, N.duration, N.originalDts, N.isKeyframe), this._isLive || this._videoSegmentInfoList.append(b), n.samples = w, n.sequenceNumber++, this._forceFirstIDR) {
                                        var P = w[0].flags;
                                        P.dependsOn = 2,
                                        P.isNonSync = 0
                                    }
                                    var U = a.
                                default.moof(n, o);
                                    n.samples = [],
                                    n.length = 0,
                                    this._onMediaSegment("video", {
                                        type: "video",
                                        data: this._mergeBoxes(U, d).buffer,
                                        sampleCount: w.length,
                                        info: b
                                    })
                                }
                            }
                        }
                    },
                    {
                        key: "_mergeBoxes",
                        value: function(e, t) {
                            var n = new Uint8Array(e.byteLength + t.byteLength);
                            return n.set(e, 0),
                            n.set(t, e.byteLength),
                            n
                        }
                    },
                    {
                        key: "onInitSegment",
                        get: function() {
                            return this._onInitSegment
                        },
                        set: function(e) {
                            this._onInitSegment = e
                        }
                    },
                    {
                        key: "onMediaSegment",
                        get: function() {
                            return this._onMediaSegment
                        },
                        set: function(e) {
                            this._onMediaSegment = e
                        }
                    }]),
                    e
                } ();
                n.
            default = m
            },
            {
                "../core/media-segment-info.js": 8,
                "../utils/browser.js": 39,
                "../utils/exception.js": 40,
                "../utils/logger.js": 41,
                "./aac-silent.js": 36,
                "./mp4-generator.js": 37
            }],
            39 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = {}; !
                function() {
                    var e = self.navigator.userAgent.toLowerCase(),
                    t = /(edge)\/([\w.]+)/.exec(e) || /(opr)[\/]([\w.]+)/.exec(e) || /(chrome)[ \/]([\w.]+)/.exec(e) || /(iemobile)[\/]([\w.]+)/.exec(e) || /(version)(applewebkit)[ \/]([\w.]+).*(safari)[ \/]([\w.]+)/.exec(e) || /(webkit)[ \/]([\w.]+).*(version)[ \/]([\w.]+).*(safari)[ \/]([\w.]+)/.exec(e) || /(webkit)[ \/]([\w.]+)/.exec(e) || /(opera)(?:.*version|)[ \/]([\w.]+)/.exec(e) || /(msie) ([\w.]+)/.exec(e) || e.indexOf("trident") >= 0 && /(rv)(?::| )([\w.]+)/.exec(e) || e.indexOf("compatible") < 0 && /(firefox)[ \/]([\w.]+)/.exec(e) || [],
                    n = /(ipad)/.exec(e) || /(ipod)/.exec(e) || /(windows phone)/.exec(e) || /(iphone)/.exec(e) || /(kindle)/.exec(e) || /(android)/.exec(e) || /(windows)/.exec(e) || /(mac)/.exec(e) || /(linux)/.exec(e) || /(cros)/.exec(e) || [],
                    r = {
                        browser: t[5] || t[3] || t[1] || "",
                        version: t[2] || t[4] || "0",
                        majorVersion: t[4] || t[2] || "0",
                        platform: n[0] || ""
                    },
                    o = {};
                    if (r.browser) {
                        o[r.browser] = !0;
                        var s = r.majorVersion.split(".");
                        o.version = {
                            major: parseInt(r.majorVersion, 10),
                            string: r.version
                        },
                        s.length > 1 && (o.version.minor = parseInt(s[1], 10)),
                        s.length > 2 && (o.version.build = parseInt(s[2], 10))
                    }
                    for (var a in r.platform && (o[r.platform] = !0), (o.chrome || o.opr || o.safari) && (o.webkit = !0), (o.rv || o.iemobile) && (o.rv && delete o.rv, r.browser = "msie", o.msie = !0), o.edge && (delete o.edge, r.browser = "msedge", o.msedge = !0), o.opr && (r.browser = "opera", o.opera = !0), o.safari && o.android && (r.browser = "android", o.android = !0), o.name = r.browser, o.platform = r.platform, i) i.hasOwnProperty(a) && delete i[a];
                    Object.assign(i, o)
                } (),
                n.
            default = i
            },
            {}],
            40 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } ();

                function r(e, t) {
                    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                    return ! t || "object" != typeof t && "function" != typeof t ? e: t
                }
                function o(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                    e.prototype = Object.create(t && t.prototype, {
                        constructor: {
                            value: e,
                            enumerable: !1,
                            writable: !0,
                            configurable: !0
                        }
                    }),
                    t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
                }
                function s(e, t) {
                    if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }
                var a = n.RuntimeException = function() {
                    function e(t) {
                        s(this, e),
                        this._message = t
                    }
                    return i(e, [{
                        key: "toString",
                        value: function() {
                            return this.name + ": " + this.message
                        }
                    },
                    {
                        key: "name",
                        get: function() {
                            return "RuntimeException"
                        }
                    },
                    {
                        key: "message",
                        get: function() {
                            return this._message
                        }
                    }]),
                    e
                } ();
                n.IllegalStateException = function(e) {
                    function t(e) {
                        return s(this, t),
                        r(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, e))
                    }
                    return o(t, e),
                    i(t, [{
                        key: "name",
                        get: function() {
                            return "IllegalStateException"
                        }
                    }]),
                    t
                } (a),
                n.InvalidArgumentException = function(e) {
                    function t(e) {
                        return s(this, t),
                        r(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, e))
                    }
                    return o(t, e),
                    i(t, [{
                        key: "name",
                        get: function() {
                            return "InvalidArgumentException"
                        }
                    }]),
                    t
                } (a),
                n.NotImplementedException = function(e) {
                    function t(e) {
                        return s(this, t),
                        r(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, e))
                    }
                    return o(t, e),
                    i(t, [{
                        key: "name",
                        get: function() {
                            return "NotImplementedException"
                        }
                    }]),
                    t
                } (a)
            },
            {}],
            41 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i, r = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                o = e("events"),
                s = (i = o) && i.__esModule ? i: {
                default:
                    i
                },
                a = function() {
                    function e() { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, e)
                    }
                    return r(e, null, [{
                        key: "e",
                        value: function(t, n) {
                            t && !e.FORCE_GLOBAL_TAG || (t = e.GLOBAL_TAG);
                            var i = "[" + t + "] > " + n;
                            e.ENABLE_CALLBACK && e.emitter.emit("log", "error", i),
                            e.ENABLE_ERROR && (console.error ? console.error(i) : console.warn ? console.warn(i) : console.log(i))
                        }
                    },
                    {
                        key: "i",
                        value: function(t, n) {
                            t && !e.FORCE_GLOBAL_TAG || (t = e.GLOBAL_TAG);
                            var i = "[" + t + "] > " + n;
                            e.ENABLE_CALLBACK && e.emitter.emit("log", "info", i),
                            e.ENABLE_INFO && (console.info ? console.info(i) : console.log(i))
                        }
                    },
                    {
                        key: "w",
                        value: function(t, n) {
                            t && !e.FORCE_GLOBAL_TAG || (t = e.GLOBAL_TAG);
                            var i = "[" + t + "] > " + n;
                            e.ENABLE_CALLBACK && e.emitter.emit("log", "warn", i),
                            e.ENABLE_WARN && (console.warn ? console.warn(i) : console.log(i))
                        }
                    },
                    {
                        key: "d",
                        value: function(t, n) {
                            t && !e.FORCE_GLOBAL_TAG || (t = e.GLOBAL_TAG);
                            var i = "[" + t + "] > " + n;
                            e.ENABLE_CALLBACK && e.emitter.emit("log", "debug", i),
                            e.ENABLE_DEBUG && (console.debug ? console.debug(i) : console.log(i))
                        }
                    },
                    {
                        key: "v",
                        value: function(t, n) {
                            t && !e.FORCE_GLOBAL_TAG || (t = e.GLOBAL_TAG);
                            var i = "[" + t + "] > " + n;
                            e.ENABLE_CALLBACK && e.emitter.emit("log", "verbose", i),
                            e.ENABLE_VERBOSE && console.log(i)
                        }
                    }]),
                    e
                } ();
                a.GLOBAL_TAG = "flv.js",
                a.FORCE_GLOBAL_TAG = !1,
                a.ENABLE_ERROR = !0,
                a.ENABLE_INFO = !0,
                a.ENABLE_WARN = !0,
                a.ENABLE_DEBUG = !0,
                a.ENABLE_VERBOSE = !0,
                a.ENABLE_CALLBACK = !1,
                a.emitter = new s.
            default,
                n.
            default = a
            },
            {
                events: 2
            }],
            42 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                r = e("events"),
                o = u(r),
                s = e("./logger.js"),
                a = u(s);

                function u(e) {
                    return e && e.__esModule ? e: {
                    default:
                        e
                    }
                }
                var l = function() {
                    function e() { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, e)
                    }
                    return i(e, null, [{
                        key: "getConfig",
                        value: function() {
                            return {
                                globalTag: a.
                            default.GLOBAL_TAG,
                                forceGlobalTag: a.
                            default.FORCE_GLOBAL_TAG,
                                enableVerbose: a.
                            default.ENABLE_VERBOSE,
                                enableDebug: a.
                            default.ENABLE_DEBUG,
                                enableInfo: a.
                            default.ENABLE_INFO,
                                enableWarn: a.
                            default.ENABLE_WARN,
                                enableError: a.
                            default.ENABLE_ERROR,
                                enableCallback: a.
                            default.ENABLE_CALLBACK
                            }
                        }
                    },
                    {
                        key: "applyConfig",
                        value: function(e) {
                            a.
                        default.GLOBAL_TAG = e.globalTag,
                            a.
                        default.FORCE_GLOBAL_TAG = e.forceGlobalTag,
                            a.
                        default.ENABLE_VERBOSE = e.enableVerbose,
                            a.
                        default.ENABLE_DEBUG = e.enableDebug,
                            a.
                        default.ENABLE_INFO = e.enableInfo,
                            a.
                        default.ENABLE_WARN = e.enableWarn,
                            a.
                        default.ENABLE_ERROR = e.enableError,
                            a.
                        default.ENABLE_CALLBACK = e.enableCallback
                        }
                    },
                    {
                        key: "_notifyChange",
                        value: function() {
                            var t = e.emitter;
                            if (t.listenerCount("change") > 0) {
                                var n = e.getConfig();
                                t.emit("change", n)
                            }
                        }
                    },
                    {
                        key: "registerListener",
                        value: function(t) {
                            e.emitter.addListener("change", t)
                        }
                    },
                    {
                        key: "removeListener",
                        value: function(t) {
                            e.emitter.removeListener("change", t)
                        }
                    },
                    {
                        key: "addLogListener",
                        value: function(t) {
                            a.
                        default.emitter.addListener("log", t),
                            a.
                        default.emitter.listenerCount("log") > 0 && (a.
                        default.ENABLE_CALLBACK = !0, e._notifyChange())
                        }
                    },
                    {
                        key: "removeLogListener",
                        value: function(t) {
                            a.
                        default.emitter.removeListener("log", t),
                            0 === a.
                        default.emitter.listenerCount("log") && (a.
                        default.ENABLE_CALLBACK = !1, e._notifyChange())
                        }
                    },
                    {
                        key: "forceGlobalTag",
                        get: function() {
                            return a.
                        default.FORCE_GLOBAL_TAG
                        },
                        set: function(t) {
                            a.
                        default.FORCE_GLOBAL_TAG = t,
                            e._notifyChange()
                        }
                    },
                    {
                        key: "globalTag",
                        get: function() {
                            return a.
                        default.GLOBAL_TAG
                        },
                        set: function(t) {
                            a.
                        default.GLOBAL_TAG = t,
                            e._notifyChange()
                        }
                    },
                    {
                        key: "enableAll",
                        get: function() {
                            return a.
                        default.ENABLE_VERBOSE && a.
                        default.ENABLE_DEBUG && a.
                        default.ENABLE_INFO && a.
                        default.ENABLE_WARN && a.
                        default.ENABLE_ERROR
                        },
                        set: function(t) {
                            a.
                        default.ENABLE_VERBOSE = t,
                            a.
                        default.ENABLE_DEBUG = t,
                            a.
                        default.ENABLE_INFO = t,
                            a.
                        default.ENABLE_WARN = t,
                            a.
                        default.ENABLE_ERROR = t,
                            e._notifyChange()
                        }
                    },
                    {
                        key: "enableDebug",
                        get: function() {
                            return a.
                        default.ENABLE_DEBUG
                        },
                        set: function(t) {
                            a.
                        default.ENABLE_DEBUG = t,
                            e._notifyChange()
                        }
                    },
                    {
                        key: "enableVerbose",
                        get: function() {
                            return a.
                        default.ENABLE_VERBOSE
                        },
                        set: function(t) {
                            a.
                        default.ENABLE_VERBOSE = t,
                            e._notifyChange()
                        }
                    },
                    {
                        key: "enableInfo",
                        get: function() {
                            return a.
                        default.ENABLE_INFO
                        },
                        set: function(t) {
                            a.
                        default.ENABLE_INFO = t,
                            e._notifyChange()
                        }
                    },
                    {
                        key: "enableWarn",
                        get: function() {
                            return a.
                        default.ENABLE_WARN
                        },
                        set: function(t) {
                            a.
                        default.ENABLE_WARN = t,
                            e._notifyChange()
                        }
                    },
                    {
                        key: "enableError",
                        get: function() {
                            return a.
                        default.ENABLE_ERROR
                        },
                        set: function(t) {
                            a.
                        default.ENABLE_ERROR = t,
                            e._notifyChange()
                        }
                    }]),
                    e
                } ();
                l.emitter = new o.
            default,
                n.
            default = l
            },
            {
                "./logger.js": 41,
                events: 2
            }],
            43 : [function(e, t, n) {
                "use strict";
                Object.defineProperty(n, "__esModule", {
                    value: !0
                });
                var i = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var i = t[n];
                            i.enumerable = i.enumerable || !1,
                            i.configurable = !0,
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i)
                        }
                    }
                    return function(t, n, i) {
                        return n && e(t.prototype, n),
                        i && e(t, i),
                        t
                    }
                } (),
                r = function() {
                    function t() { !
                        function(e, t) {
                            if (! (e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        } (this, t)
                    }
                    return i(t, null, [{
                        key: "install",
                        value: function() {
                            Object.setPrototypeOf = Object.setPrototypeOf ||
                            function(e, t) {
                                return e.__proto__ = t,
                                e
                            },
                            Object.assign = Object.assign ||
                            function(e) {
                                if (void 0 === e || null === e) throw new TypeError("Cannot convert undefined or null to object");
                                for (var t = Object(e), n = 1; n < arguments.length; n++) {
                                    var i = arguments[n];
                                    if (void 0 !== i && null !== i) for (var r in i) i.hasOwnProperty(r) && (t[r] = i[r])
                                }
                                return t
                            },
                            "function" != typeof self.Promise && e("es6-promise").polyfill()
                        }
                    }]),
                    t
                } ();
                r.install(),
                n.
            default = r
            },
            {
                "es6-promise": 1
            }],
            44 : [function(e, t, n) {
                "use strict";

                function i(e, t, n) {
                    var i = e;
                    if (t + n < i.length) {
                        for (; n--;) if (128 != (192 & i[++t])) return ! 1;
                        return ! 0
                    }
                    return ! 1
                }
                Object.defineProperty(n, "__esModule", {
                    value: !0
                }),
                n.
            default = function(e) {
                    for (var t = [], n = e, r = 0, o = e.length; r < o;) if (n[r] < 128) t.push(String.fromCharCode(n[r])),
                    ++r;
                    else {
                        if (n[r] < 192);
                        else if (n[r] < 224) {
                            if (i(n, r, 1)) {
                                var s = (31 & n[r]) << 6 | 63 & n[r + 1];
                                if (s >= 128) {
                                    t.push(String.fromCharCode(65535 & s)),
                                    r += 2;
                                    continue
                                }
                            }
                        } else if (n[r] < 240) {
                            if (i(n, r, 2)) {
                                var a = (15 & n[r]) << 12 | (63 & n[r + 1]) << 6 | 63 & n[r + 2];
                                if (a >= 2048 && 55296 != (63488 & a)) {
                                    t.push(String.fromCharCode(65535 & a)),
                                    r += 3;
                                    continue
                                }
                            }
                        } else if (n[r] < 248 && i(n, r, 3)) {
                            var u = (7 & n[r]) << 18 | (63 & n[r + 1]) << 12 | (63 & n[r + 2]) << 6 | 63 & n[r + 3];
                            if (u > 65536 && u < 1114112) {
                                u -= 65536,
                                t.push(String.fromCharCode(u >>> 10 | 55296)),
                                t.push(String.fromCharCode(1023 & u | 56320)),
                                r += 4;
                                continue
                            }
                        }
                        t.push(String.fromCharCode(65533)),
                        ++r
                    }
                    return t.join("")
                }
            },
            {}]
        },
        {},
        [21])(21)
    }).call(this, n(5))
},
function(e, t, n) {
    "use strict";
    var i, r, o, s = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
    function(e) {
        return typeof e
    }: function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol": typeof e
    };

    function a(e) {
        e.webkitRequestFullScreen ? e.webkitRequestFullScreen() : e.mozRequestFullScreen ? e.mozRequestFullScreen() : e.requestFullScreen ? e.requestFullscreen() : console.log("浏览器不支持全屏API或已被禁用", null, null, null, !0, !0)
    }
    function u() {
        document.webkitCancelFullScreen ? document.webkitCancelFullScreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.cancelFullScreen ? document.cancelFullScreen() : document.exitFullscreen ? document.exitFullscreen() : console.log("浏览器不支持全屏API或已被禁用", null, null, null, !0, !0)
    }
    function l(e) {
        e = parseInt(e);
        return parseInt(e / 3600) + ":" + parseInt(e % 3600 / 60) + ":" + e % 3600 % 60
    }
    function c(e) {
        return new Date(1 * e).format("HH:mm:ss")
    }
    function d(e) {
        return new Date(1 * e).format("yyyy-MM-dd HH:mm:ss")
    }
    r = [n(6), n(4), n(3), n(0)],
    void 0 === (o = "function" == typeof(i = function(e, t, n, i) {
        function r(e) {
            this._dom = null,
            this.windows = [],
            this.listenWindow = {},
            this.broadcastWindow = {},
            e = "object" == (void 0 === e ? "undefined": s(e)) ? e: {};
            var n = this._config = function e(t, n) {
                for (var i in t) null == n[i] ? n[i] = t[i] : "object" == s(n[i]) && e(t[i], n[i]);
                return n
            } ({
                winNums: 4,
                play: "",
                stop: "",
                volume: {
                    text: "",
                    value: 80,
                    handler: function() {}
                },
                winContextMenu: [],
                videoLimit: 0,
                videoLimitHandler: function(e) {},
                audioLimit: 0,
                audioLimitHandler: function(e) {},
                onAudioPlay: function() {},
                download: {
                    enable: !1,
                    text: "",
                    handler: function() {}
                },
                capture: {
                    enable: !0,
                    text: "",
                    handler: function(e, t) {}
                },
                fullscreenText: null,
                playback: {
                    enable: !1,
                    formatter: "time",
                    forward: {
                        enable: !0,
                        text: "",
                        handler: function(e) {}
                    },
                    multiple: [1],
                    backward: {
                        enable: !1,
                        text: "",
                        handler: function(e) {}
                    },
                    kFrame: {
                        enable: !1,
                        text: "",
                        handler: function() {}
                    },
                    seek: function(e) {}
                },
                videoEvent: function(e, t, n) {},
                onDisconnect: function(e, t) {}
            },
            e);
            if (n.domid && (this._dom = document.getElementById(n.domid)), !this._dom) throw "unknown element";
            this.setWindowNum(this._config.winNums),
            document.body.addEventListener("click",
            function() {
                t(".win-menu").remove()
            })
        }
        return window.MediaSource = window.MediaSource || window.WebKitMediaSource,
        e.LoggingControl.enableDebug = !0,
        r.prototype = {
            _players: {},
            setWindowNum: function(e) {
                if (this.windows.length > e) for (var n = e; n < this.windows.length; n++) t(this.windows[n]._dom).hide();
                var i, r, o, h, p, m = void 0;
                for (6 == e ? (i = r = 100 / (m = 3) * 2 + "%", o = h = 100 / m + "%") : 8 == e ? (i = r = 100 / (m = 4) * 3 + "%", o = h = 100 / m + "%") : o = i = h = r = 100 / (m = Math.sqrt(e)) + "%", n = 0; n < e; n++) {
                    var _, v;
                    0 == n ? (_ = i, v = r) : (_ = o, v = h);
                    var g = null == this.windows[n] ? {}: this.windows[n];
                    if (g._rawWidth = _, g._rawHeight = v, g._dom) g._dom.style.width = _,
                    g._dom.style.height = v,
                    t(g._dom).show();
                    else {
                        var y = document.createElement("div");
                        y.style.width = _,
                        y.style.height = v,
                        y.className = "flv-player-win",
                        0 == n && (y.className = "flv-player-win win-focus", this.focusWin = g),
                        null != this._config.winContextMenu && this._config.winContextMenu.length > 0 && (g._menu = this._config.winContextMenu,
                        function(e) {
                            y.oncontextmenu = function(n) {
                                var i = n || event;
                                t(".win-menu").remove();
                                var r = document.createElement("div");
                                r.className = "win-menu";
                                for (var o = document.createElement("ul"), s = 0; s < e._menu.length; s++) if (null != e._menu[s].text && 0 != e._menu[s].text.length) {
                                    var a = document.createElement("li");
                                    if (a.innerText = e._menu[s].text, "function" == typeof e._menu[s].handler) {
                                        var u = e._menu[s].handler; !
                                        function(e, n, i) {
                                            a.onclick = function() {
                                                t(".win-menu").remove(),
                                                i(n)
                                            }
                                        } (0, e, u)
                                    }
                                    o.appendChild(a)
                                }
                                return r.appendChild(o),
                                console.log(i),
                                console.log(i.target),
                                r.style.left = i.clientX + "px",
                                r.style.top = i.clientY + "px",
                                this.appendChild(r),
                                !1
                            }
                        } (g));
                        var b = document.createElement("video");
                        b.volume = .5;
                        var w = document.createElement("div");
                        w.className = "flv-container",
                        w.style.height = "100%",
                        w.style.width = "100%",
                        w.appendChild(b),
                        y.appendChild(w);
                        var E = document.createElement("input");
                        E.type = "range",
                        E.value = 0,
                        E.className = "playback-track",
                        E.style.cssText += "display:none;";
                        var S = document.createElement("div");
                        S.className = "flv-ctrl";
                        var k = document.createElement("span");
                        k.className = "flv-ctrl-text";
                        var x = document.createElement("span");
                        x.className = "flv-ctrl-speed";
                        var L = document.createElement("div");
                        L.className = "flv-ctrl-operator";
                        var T = document.createElement("span");
                        
            
                       T.className = "flv-btn ",
                        T.innerHTML = "<i class='fa fa-pause '></i></div>",
                        "string" == typeof this._config.stop ? this._config.stopText = this._config.stop: "object" == s(this._config.stop) && (this._config.stopText = this._config.stop.text),
                        this._config.stopText && T.setAttribute("title", this._config.stopText);
                       T.style.cssText += "display:none;";
                          
                        var A = document.createElement("span");
                        A.className = "flv-btn ",
                        A.innerHTML = "<i class='fa fa-play'></i></div>",
                        "string" == typeof this._config.play ? this._config.playText = this._config.play: "object" == s(this._config.play) && (this._config.playText = this._config.play.text),
                        null != this._config.playText && this._config.playText.length > 0 && t(A).attr("title", this._config.playText.split("/")[0]);
                      
                       var R = document.createElement("span");
                        R.className = "flv-btn flv-volume disable",
                        R.innerHTML = "<i name='volume' class='fa fa-volume-up'></i><i name='quiet' style='display: none;' class=\"fa fa-ban fa-stack-2x text-danger\"></i><div class='flv-volume-slider'><input type='range' min='0' max='100'></div>",
                        "string" == typeof this._config.volume ? this._config.volumeText = this._config.volume: "object" == s(this._config.volume) ? this._config.volumeText = this._config.volume.text: this._config.volumeText = "",
                        t(R).attr("title", this._config.volumeText),
                        t(R).find("input").val(this._config.volume.value);
                        R.style.cssText += "display:none;";
                        var C = document.createElement("span");
                        C.className = "flv-btn disable",
                        C.innerHTML = "<i class='fa fa-camera'></i></div>",
                        this._config.capture && C.setAttribute("title", this._config.capture.text);
                        C.style.cssText += "display:none;";
                        var O = document.createElement("span");
                        O.className = "flv-btn disable",
                        O.innerHTML = "<i class='fa fa-download'></i></div>",
                        this._config.downloadText && O.setAttribute("title", this._config.downloadText);
                        O.style.cssText += "display:none;";
                        var D = document.createElement("span");
                        D.className = "flv-btn flv-fullscreen-btn",
                        D.innerHTML = "<i class='fa fa-arrows-alt'></i></div>",
                        this._config.fullscreenText && D.setAttribute("title", this._config.fullscreenText);
                        D.style.cssText += "display:none;";
                        var I = document.createElement("span");
                        I.className = "flv-btn disable",
                        I.style.cssText += "display:none;";
                        var M = document.createElement("span");
                        M.className = "flv-btn disable",
                        M.style.cssText += "display:none;",
                        M.innerHTML = "<i class='fa fa-fast-backward'></i></div>";
                        var j = document.createElement("span");
                        j.className = "flv-btn disable",
                        j.style.cssText += "display:none;",
                        j.innerHTML = "<i class='fa fa-fast-forward'></i></div>";
                        var B = document.createElement("span");
                        B.className = "flv-btn disable",
                        B.style.cssText += "display:none;",
                        B.innerHTML = "<i class='fa fa-film'></i></div>",
                        L.appendChild(M),
                        L.appendChild(I),
                        I.style.cssText = "width:auto";
                        var N = document.createElement("select");
                        N.className = "multiple";
                        for (var P = 0; P < this._config.playback.multiple.length; P++) t(N).append("<option value='" + this._config.playback.multiple[P] + "'>X" + this._config.playback.multiple[P] + "</option>");
                        N.value = 1,
                        I.appendChild(N),
                        I.style.display = "none",
                        L.appendChild(j),
                        L.appendChild(B),
                        L.appendChild(T),
                        L.appendChild(A),
                        L.appendChild(E),
                        L.appendChild(R),
                        f.versions.webKit && t(R).find("input").css("background", "linear-gradient(to right, transparent 0%, #059CFA 0%, #059CFA " + this._config.volume.value + "%, transparent 0%),linear-gradient(to right, transparent 0%, #666 " + (100 - this._config.volume.value) + "%, #666 100%, transparent 100%)"),
                        this._config.capture.enable && L.appendChild(C),
                        this._config.download.enable && L.appendChild(O),
                        L.appendChild(D),
                        S.appendChild(E),
                        S.appendChild(k),
                        S.appendChild(x),
                        S.appendChild(L),
                        y.appendChild(S),
                        t(this._dom).append(y),
                        b.oncontextmenu = function() {
                            return ! 1
                        },
                        this._config.playback.enable && (t(E).show(), this._config.playback.forward.enable && (t(j).show(), t(j).attr("title", this._config.playback.forward.text), t(I).show()), this._config.playback.backward.enable && (t(M).show(), t(M).attr("title", this._config.playback.backward.text), t(I).show()), this._config.playback.kFrame.enable && (t(B).show(), t(B).attr("title", this._config.playback.kFrame.text))),
                        g.isFullscreen = !1,
                        g.index = n,
                        g._video = b,
                        g._dom = y,
                        g._track = E,
                        g._stop_btn = T,
                        g._play_btn = A,
                        g._volume_btn = R,
                        g._fs_btn = D,
                        g._capture_btn = C,
                        g._forward_btn = j,
                        g._backward_btn = M,
                        g._multi_btn = N,
                        g._kframe_btn = B,
                        this._config.download.enable && (g._download_btn = O),
                        g._speedText = x,
                        g._text = k,
                        g.status = "idle",
                        this.windows.push(g),
                        function(e, n) {
                            t(e._dom).click(function() {
                                e.index != n.focusWin.index && (t(".win-focus").removeClass("win-focus"), t(this).addClass("win-focus"), n.focusWin = e, "function" == typeof n._config.select && n._config.select(e.index))
                            }),
                          
                            t(e._fs_btn).click(function() {
                                null != n.isFullscreen && n.isFullscreen ? (u(n._dom), t(n._dom).resize(), n.isFullscreen = !1, t(n._dom).find(".flv-fullscreen-btn").find("i").addClass("fa-arrows-alt").removeClass("fa-compress")) : (a(n._dom), t(n._dom).resize(), n.isFullscreen = !0, t(n._dom).find(".flv-fullscreen-btn").find("i").removeClass("fa-arrows-alt").addClass("fa-compress"))
                            }),
                            t(e._stop_btn).click(function() {
                                t(this).hide();
                                  t(this).next().show();
                                 n._config.stop.handler(e.index, "stop"); 
                              
                            // t(this).hasClass("disable")  (n.stop(e.index), "function" == typeof n._config.stop.handler && n._config.play.handler(e.index))
                            }),
                            t(e._play_btn).click(function() {
                               
                                 t(this).hide();
                                  t(this).prev().show();
                            
                              n._config.play.handler(e.index, "play");

                            
                               /* if (!t(this).hasClass("disable")) {
                                    console.log()
                                    if ("playing" == e.status) {
                                        t(this).find("i").removeClass("fa-pause").addClass("fa-play");
                                        try {
                                            n._config.playText.split("/").length > 1 && t(this).attr("title", n._config.playText.split("/")[1])
                                        } catch(e) {}
                                        "function" == typeof n._config.play.handler && n._config.play.handler(e.index, "pause")
                                    } else "pause" == e.status && (t(this).find("i").removeClass("fa-play").addClass("fa-pause"), null != n._config.playText && n._config.playText.length > 0 && t(this).attr("title", n._config.playText.split("/")[0]), "function" == typeof n._config.play.handler && n._config.play.handler(e.index, "play"));
                                    n.togglePause(e.index)
                                }*/
                            }),
                            t(e._capture_btn).click(function() {
                                t(this).hasClass("disable") || n.capture(e.index)
                            }),
                            t(e._download_btn).click(function() {
                                t(this).hasClass("disable") || "function" == typeof n._config.download.handler && n._config.download.handler(e.index)
                            }),
                            t("[name='volume']").click(function() {
                                t(this).parent().hasClass("disable") || (e._video.muted = !0, t(this).siblings(".fa-ban").show())
                            }),
                            t("[name='quiet']").click(function() {
                                t(this).parent().hasClass("disable") || (e._video.muted = !1, t(this).hide())
                            }),
                            t(e._volume_btn).find("input").change(function(i) {
                                var r = t(this).val();
                                e._video.volume = r / 100,
                                0 == r ? (e._video.muted = !0, t(this).parent().siblings(".fa-ban").show()) : (e._video.muted = !1, t(this).parent().siblings(".fa-ban").hide()),
                                f.versions.webKit && t(this).css("background", "linear-gradient(to right, transparent 0%, #059CFA 0%, #059CFA " + r + "%, transparent 0%),linear-gradient(to right, transparent 0%, #666 " + (100 - r) + "%, #666 100%, transparent 100%)"),
                                "function" == typeof n._config.volume.handler && n._config.volume.handler(e.index, r),
                                i.stopPropagation()
                            }),
                            t(e._track).change(function() {
                                if ("idle" != e.status) {
                                    var i = t(this).attr("max"),
                                    r = t(this).val();
                                    e._video.currentTime = r,
                                    f.versions.webKit && t(this).css("background", "linear-gradient(to right, transparent 0%, #95FA1D 0%, #95FA1D " + r / i * 100 + "%, transparent 0%),linear-gradient(to right, transparent 0%, #D0FFD9 100%, #D0FFD9 100%, transparent 100%)"),
                                    n.showLoading(e.index),
                                    "function" == typeof n._config.playback.seek && n._config.playback.seek(e.index, r)
                                } else t(this).val(0)
                            }),
                            t(e._track).on("mouseover",
                            function(e) {
                                t(this).addClass("track-focus");
                                var i = e.target.max * (e.offsetX / t(e.target).width()),
                                r = null;
                                "time" == n._config.playback.formatter ? r = l(i) + "/" + l(e.target.max) : "daytime" == n._config.playback.formatter ? r = c(1 * e.target.min + i) + "/" + c(e.target.max) : "datetime" == n._config.playback.formatter && (r = d(1 * e.target.min + 1 * i) + "/" + d(e.target.max)),
                                e.target.title = r
                            }),
                            t(e._track).mouseout(function() {
                                t(this).removeClass("track-focus")
                            }),
                            t(e._video).on("timeupdate",
                            function() {
                                var i = this.currentTime,
                                r = t(e._track).attr("max");
                                isNaN(r) && (r = this.duration, t(e._track).attr("max", r)),
                                !n._config.playback.enable && this.duration - this.currentTime > 1.5 ? this.currentTime = this.duration - 1 : n._config.playback.enable && (this.currentTime == this.duration ? t(e._play_btn).find("i").removeClass("fa-pause").addClass("fa-play") : t(e._play_btn).find("i").removeClass("fa-play").addClass("fa-pause")),
                                f.versions.webKit,
                                t(e._track).css("background", "linear-gradient(to right, transparent 0%, #95FA1D 0%, #95FA1D " + i / r * 100 + "%, transparent 0%),linear-gradient(to right, transparent 0%, #D0FFD9 100%, #D0FFD9 100%, transparent 100%)"),
                                t(e._track).val(this.currentTime),
                                "function" == typeof n._config.videoEvent && n._config.videoEvent(e.index, "timeupdate", this.currentTime)
                            }),
                            t(e._video).on("canplay",
                            function() {
                                e.status = "playing",
                                t(e._dom).find(".flv-btn").removeClass("disable"),
                                t(e._play_btn).find("i").removeClass("fa-play").addClass("fa-pause"),
                                e.status,
                                n.hideLoading(e.index),
                                "function" == typeof n._config.videoEvent && n._config.videoEvent(e.index, "canplay")
                            }),
                            t(e._video).on("pause",
                            function() {
                                "function" == typeof n._config.videoEvent && n._config.videoEvent(e.index, "pause")
                            }),
                            t(e._video).on("waiting",
                            function() {
                                "function" == typeof n._config.videoEvent && n._config.videoEvent(e.index, "waiting")
                            }),
                            t(e._video).on("ended",
                            function() {
                                "function" == typeof n._config.videoEvent && n._config.videoEvent(e.index, "ended")
                            }),
                            t(e._forward_btn).click(function() {
                                "function" == typeof n._config.playback.forward.handler && n._config.playback.forward.handler(e.index, t(e._multi_btn).val())
                            }),
                            t(e._backward_btn).click(function() {
                                "function" == typeof n._config.playback.backward.handler && n._config.playback.backward.handler(e.index, t(e._multi_btn).val())
                            }),
                            t(e._kframe_btn).click(function() {
                                "function" == typeof n._config.playback.kFrame.handler && n._config.playback.kFrame.handler(e.index)
                            }),
                            t(e._video).on("error",
                            function(n) {
                                t(e._dom).find(".loading").remove(),
                                console.log("video play fail,error code=" + n.currentTarget.error.code + ":" + n.currentTarget.error.message)
                            })
                        } (g, this)
                    }
                }
                if (null == this.listenWindow._audio) {
                    var U = document.createElement("audio");
                    this.listenWindow._audio = U,
                    this._dom.appendChild(U)
                }
                t((p = this).listenWindow._audio).on("error",
                function(e) {
                    console.log("audio play fail,error code=" + e.currentTarget.error.code + ":" + e.currentTarget.error.message)
                }),
                t(p.listenWindow._audio).on("timeupdate",
                function() {
                    this.duration - this.currentTime > 5 && (console.log("duration:" + this.duration + ",currentTime:" + this.currentTime), this.currentTime = this.duration - 2)
                }),
                t(p.listenWindow._audio).on("canplay",
                function() {
                    p.listenWindow.status = "playing",
                    "function" == typeof p._config.onAudioPlay && p._config.onAudioPlay()
                })
            },
            showLoading: function(e) {
                t(this.windows[e]._dom).find(".loading").length > 0 || t(this.windows[e]._dom).find(".flv-container").prepend("<div class='loading'></div>")
            },
            hideLoading: function(e) {
                t(this.windows[e]._dom).find(".loading").remove()
            },
            setMenuText: function(e, t, n) {
                this.windows[e]._menu[t].text = n
            },
            play: function(n, i, r, o, s) {
                                           
                 vant.Toast('3333333');

                if (n < 0) if ("idle" == this.getFocusWindow().status) n = this.getFocusWindow().index;
                else {
                    for (n = 0; n < this.windows.length && "idle" != this.windows[n].status;) n++;
                    if (n == this.windows.length) return void console.log("all of the windows are playing")
                }
                null != i && (this.windows[n]._sourceUrl = i),
                this.showLoading(n),
                null != r && (this.windows[n]._hasAudio = r);
                var a = 1;
                if (null != o && (t(this.windows[n]._track).attr("min", 0), null != s && (a = (s - o) / 1e3, t(this.windows[n]._track).attr("max", a))), null == this.windows[n].player) {
                    this.windows[n].status = "waiting";
                    var u = e.createPlayer({
                        type: "flv",
                        duration: 1e3 * a,
                        isLive: !0,
                        url: this.windows[n]._sourceUrl
                    },
                    {
                        enableWorker: !0,
                        stashInitialSize: 393216,
                        enableStashBuffer: !1,
                        autoCleanupSourceBuffer: !0,
                        fixAudioTimestampGap: !0,
                        lazyLoad: !1,
                        localStore: !1
                    });
                    u.attachMediaElement(this.windows[n]._video),
                    u.on(e.Events.LOADING_COMPLETE,
                    function(e) {
                        "function" == typeof this._config.onDisconnect && "playing" == this.windows[n].status && this._config.onDisconnect(0, n),
                        this.stop(n)
                    }.bind(this)),
                    u.on(e.Events.ERROR,
                    function(e, t) {
                        console.log("flvjs error:" + e + ";detail:" + t),
                        this.stop(n)
                    }.bind(this));
                    var l = this;
                    u.on(e.Events.STATISTICS_INFO,
                    function(e) {
                        this._playtime || (this._playtime = 1 * new Date),
                        l._config.videoLimit && (!l._config.playback || !l._config.playback.enable) && 1 * new Date - this._playtime >= l._config.videoLimit && l._config.videoLimit > 0 ? l._config.videoLimitHandler(this.index) : (t(this._speedText).text(e.speed.toFixed(2) + "KB/" + (e.receivedLength / 1024).toFixed(2) + "KB"), t(this._speedText).attr("title", e.speed.toFixed(2) + "KB/" + (e.receivedLength / 1024).toFixed(2) + "KB"))
                    }.bind(this.windows[n])),
                    this.windows[n].player = u,
                    this.windows[n].player.load()
                } else this.windows[n].status = "playing";
                return this.windows[n].player.play(),
                n
            },
            playFile: function(n, i, r, o, s) {
                if (n < 0) if ("idle" == this.getFocusWindow().status) n = this.getFocusWindow().index;
                else {
                    for (n = 0; n < this.windows.length && "idle" != this.windows[n].status;) n++;
                    if (n == this.windows.length) return void console.log("all of the windows are playing")
                }
                null != i && (this.windows[n]._sourceUrl = i),
                this.showLoading(n);
                var a = 1;
                if (null != o && (t(this.windows[n]._track).attr("min", 0), null != s && (a = (s - o) / 1e3, t(this.windows[n]._track).attr("max", a))), null == this.windows[n].player) {
                    this.windows[n].status = "waiting";
                    var u = e.createPlayer({
                        type: r,
                        duration: 1e3 * a,
                        isLive: !1,
                        url: this.windows[n]._sourceUrl
                    },
                    {
                        enableWorker: !0,
                        stashInitialSize: 393216,
                        enableStashBuffer: !0,
                        autoCleanupSourceBuffer: !0,
                        fixAudioTimestampGap: !0,
                        lazyLoad: !1
                    });
                    u.attachMediaElement(this.windows[n]._video),
                    u.on(e.Events.LOADING_COMPLETE,
                    function(e) {}.bind(this)),
                    u.on(e.Events.STATISTICS_INFO,
                    function(e) {}.bind(this.windows[n])),
                    u.on(e.Events.ERROR,
                    function(e, t) {
                        console.log("flvjs error:" + e + ";detail:" + t),
                        this.stop(n)
                    }.bind(this)),
                    this.windows[n].player = u,
                    this.windows[n].player.load()
                } else this.windows[n].status = "playing";
                return this.windows[n].player.play(),
                n
            },
            _reconnect: function(e) {
                e < 0 && (this.listenWindow.currentType === this.REQUEST_TYPE.LISTEN ? (this.stopListen(), this.listen()) : this.listenWindow.currentType === this.REQUEST_TYPE.TALK && (this.stopTalk(), this.talk())),
                this.stop(e),
                this.play(e)
            },
            getFocusWindow: function() {
                return this.focusWin
            },
            setVideoLimit: function(e) {
                this._config.videoLimit = e
            },
            setAudioLimit: function(e) {
                this._config.audioLimit = e
            },
            refreshPlayTime: function(e) {
                e < 0 ? this.listenWindow._playtime = 0 : this.windows[e]._playtime = 0
            },
            togglePause: function(e, t) {
                this.windows[e].player && (null == t ? "pause" == this.windows[e].status ? (this.windows[e].player.play(), this.windows[e].status = "playing") : (this.windows[e].player.pause(), this.windows[e].status = "pause") : t ? (this.windows[e].player.pause(), this.windows[e].status = "pause") : (this.windows[e].player.play(), this.windows[e].status = "playing"))
            },
            playAll: function() {
                for (var e = 0; e < this.windows.length; e++)"pause" != this.windows[e].status && (this.windows[e].player.play(), this.windows[index].status = "playing")
            },
            capture: function(e) {
                var t = document.createElement("canvas");
                t.width = 400,
                t.height = 300,
                t.getContext("2d").drawImage(this.windows[e]._video, 0, 0, 400, 300);
                var i = t.toDataURL("image/jpeg");
                this._config.capture && "function" == typeof this._config.capture.handler && this._config.capture.handler(e, i),
                n.saveAs(function(e) {
                    for (var t = e.split(","), n = t[0].match(/:(.*?);/)[1], i = atob(t[1]), r = i.length, o = new Uint8Array(r); r--;) o[r] = i.charCodeAt(r);
                    return new Blob([o], {
                        type: n
                    })
                } (i), 1 * new Date + ".jpg")
            },
            stop: function(e) {
     
                this.hideLoading(e),
                this.windows[e].status = "idle",
                this._config.download.enable && t(this.windows[e]._download_btn).addClass("disable"),
                t(this.windows[e]._dom).find(".flv-btn").addClass("disable"),
                t(this.windows[e]._fs_btn).removeClass("disable"),
                t(this.windows[e]._play_btn).find("i").removeClass("fa-pause").addClass("fa-play"),
                t(this.windows[e]._speedText).text(""),
                t(this.windows[e]._text).text(""),
                t(this.windows[e]._track).val(0),
                t(this.windows[e]._track).css("background-image", "linear-gradient(to right, transparent 0%, #95FA1D 0%, #95FA1D 0%, transparent 0%),linear-gradient(to right, transparent 0%, #666 100%, #666 100%, transparent 100%)"),
                this.windows[e].player && this.windows[e].player.destroy(),
                delete this.windows[e].player,
                delete this.windows[e]._playtime
            },
            stopAll: function() {

                for (var e = 0; e < this.windows.length; e++)"idle" != this.windows[e].status && this.stop(e)
            },
            save: function(e, t) {
                t || (t = 1 * new Date);
                try { - 1 == e ? n.saveAs(this.listenWindow.player._statisticsInfo.data, t + ".mp4") : n.saveAs(this.windows[e].player._statisticsInfo.data, t + ".mp4")
                } catch(e) {}
            },
            setText: function(e, n) {
                this.windows[e] && (t(this.windows[e]._text).text(n), t(this.windows[e]._text).attr("title", n))
            },
            listen: function(t) {
                if ("idle" != this.listenWindow.status && this.stopListen(), null != t && (this.listenWindow._sourceUrl = t), null == this.listenWindow.player) {
                    this.listenWindow.currentType = SBHPlayer.REQUEST_TYPE.LISTEN;
                    var n = e.createPlayer({
                        type: "flv",
                        isLive: !1,
                        duration: 1e3,
                        hasAudio: !0,
                        hasVideo: !1,
                        url: this.listenWindow._sourceUrl
                    },
                    {
                        enableWorker: !0,
                        stashInitialSize: 384,
                        enableStashBuffer: !1,
                        autoCleanupSourceBuffer: !0,
                        lazyLoad: !1,
                        localStore: !1
                    });
                    n.attachMediaElement(this.listenWindow._audio),
                    n.on(e.Events.LOADING_COMPLETE,
                    function(e) {
                        "function" == typeof this._config.onDisconnect && "playing" == this.listenWindow.status && this._config.onDisconnect(3),
                        this.stopListen()
                    }.bind(this));
                    var i = this;
                    n.on(e.Events.STATISTICS_INFO,
                    function(e) {
                        this._playtime || (this._playtime = 1 * new Date),
                        i._config.audioLimit && 1 * new Date - this._playtime >= i._config.audioLimit && i._config.audioLimit > 0 && i._config.audioLimitHandler(0)
                    }.bind(this.listenWindow)),
                    this.listenWindow.status = "waiting",
                    this.listenWindow.player = n,
                    this.listenWindow.player.load(),
                    this.listenWindow.player.play()
                }
            },
            stopListen: function() {
                try {
                    this.listenWindow.status = "idle"
                } catch(e) {}
                try {
                    this.listenWindow.player.destroy()
                } catch(e) {}
                delete this.listenWindow.player,
                delete this.listenWindow._playtime
            },
            pauseListen: function(e) {
                e ? (this.listenWindow.status = "pause", this.listenWindow.player.pause()) : (this.listenWindow.status = "playing", this.listenWindow.player.play())
            },
            talk: function(t) {
                if ("idle" != this.listenWindow.status && this.stopListen(), null != t && (this.listenWindow._sourceUrl = t), null == this.listenWindow.player) {
                    this.listenWindow.currentType = SBHPlayer.REQUEST_TYPE.TALK;
                    var n = e.createPlayer({
                        type: "flv",
                        isLive: !1,
                        hasAudio: !0,
                        hasVideo: !1,
                        duration: 1e3,
                        url: this.listenWindow._sourceUrl
                    },
                    {
                        enableWorker: !1,
                        stashInitialSize: 1024,
                        enableStashBuffer: !1,
                        autoCleanupSourceBuffer: !0,
                        lazyLoad: !1
                    });
                    n.on(e.Events.LOADING_COMPLETE,
                    function(e) {
                        "function" == typeof this._config.onDisconnect && "playing" == this.listenWindow.status && this._config.onDisconnect(2),
                        this.stopTalk()
                    }.bind(this));
                    var r = this;
                    n.on(e.Events.STATISTICS_INFO,
                    function(e) {
                        this._playtime || (this._playtime = 1 * new Date),
                        r._config.audioLimit && 1 * new Date - this._playtime >= r._config.audioLimit && r._config.audioLimit > 0 && r._config.audioLimitHandler(1)
                    }.bind(this.listenWindow)),
                    this.listenWindow.status = "waiting",
                    n.attachMediaElement(this.listenWindow._audio),
                    this.listenWindow.player = n,
                    this.listenWindow.player.load(),
                    this.listenWindow.player.play()
                }
                null == this.listenWindow.recorder ? i.get(function(e) {
                    this.listenWindow.recorder = e,
                    this.listenWindow.recorder.start()
                }.bind(this), {
                    sampleBits: 16,
                    sampleRate: 8e3,
                    localRec: !0,
                    onRecData: function(e) {
                        null == this.listenWindow.player ? this.stopTalk() : "playing" == this.listenWindow.status && this.listenWindow.player.sendWSData(e)
                    }.bind(this)
                }) : this.listenWindow.recorder.start()
            },
            stopTalk: function() {
                this.listenWindow.recorder && (this.listenWindow.recorder.stop(), delete this.listenWindow.recorder),
                this.stopListen()
            },
            pauseTalk: function(e) {
                this.pauseListen(e)
            },
            broadcast: function(e) {
                var t = new WebSocket(e);
                this.broadcastWindow.ws = t,
                t.onclose = function() {
                    this.stopBroadcast(),
                    "function" == typeof this._config.onDisconnect && this._config.onDisconnect(4)
                },
                i.get(function(e) {
                    this.broadcastWindow.recorder = e,
                    this.broadcastWindow.recorder.start()
                }.bind(this), {
                    sampleBits: 16,
                    sampleRate: 8e3,
                    localRec: !0,
                    onRecData: function(e) {
                        3 == this.broadcastWindow.ws.readyState ? this.broadcastWindow.recorder.stop() : this.broadcastWindow.ws.send(e)
                    }.bind(this)
                })
            },
            stopBroadcast: function() {
                this.broadcastWindow.recorder.stop(),
                this.broadcastWindow.ws.close()
            }
        },
        window.SBHPlayer = r,
        SBHPlayer.REQUEST_TYPE = {
            VIDEOAUDIO: 0,
            VIDEO: 1,
            TALK: 2,
            LISTEN: 3,
            BROADCAST: 4
        },
        SBHPlayer.isSupported = function() {
            return e.isSupported()
        },
        r
    }) ? i.apply(t, r) : i) || (e.exports = o),
    Date.prototype.format = function(e) {
        var t = {
            "M+": this.getMonth() + 1,
            "d+": this.getDate(),
            "h+": this.getHours() % 12 == 0 ? 12 : this.getHours() % 12,
            "H+": this.getHours(),
            "m+": this.getMinutes(),
            "s+": this.getSeconds(),
            "q+": Math.floor((this.getMonth() + 3) / 3),
            S: this.getMilliseconds()
        };
        for (var n in /(y+)/.test(e) && (e = e.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length))), /(E+)/.test(e) && (e = e.replace(RegExp.$1, (RegExp.$1.length > 1 ? RegExp.$1.length > 2 ? "/u661f/u671f": "/u5468": "") + {
            0 : "/u65e5",
            1 : "/u4e00",
            2 : "/u4e8c",
            3 : "/u4e09",
            4 : "/u56db",
            5 : "/u4e94",
            6 : "/u516d"
        } [this.getDay() + ""])), t) new RegExp("(" + n + ")").test(e) && (e = e.replace(RegExp.$1, 1 == RegExp.$1.length ? t[n] : ("00" + t[n]).substr(("" + t[n]).length)));
        return e
    };
    var f = {
        versions: function() {
            var e = navigator.userAgent;
            navigator.appVersion;
            return {
                trident: e.indexOf("Trident") > -1,
                presto: e.indexOf("Presto") > -1,
                webKit: e.indexOf("AppleWebKit") > -1,
                gecko: e.indexOf("Gecko") > -1 && -1 == e.indexOf("KHTML"),
                mobile: !!e.match(/AppleWebKit.*Mobile.*/),
                ios: !!e.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/),
                android: e.indexOf("Android") > -1 || e.indexOf("Adr") > -1,
                iPhone: e.indexOf("iPhone") > -1,
                iPad: e.indexOf("iPad") > -1,
                webApp: -1 == e.indexOf("Safari"),
                weixin: e.indexOf("MicroMessenger") > -1,
                qq: " qq" == e.match(/\sQQ/i)
            }
        } (),
        language: (navigator.browserLanguage || navigator.language).toLowerCase()
    }
}]);