//
//  Constants.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/4.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import Foundation
import UIKit

func isIPhoneXseries() -> Bool {
    var iphoneXseries:Bool = false
    if UIDevice.current.userInterfaceIdiom != UIUserInterfaceIdiom.phone {
        return iphoneXseries
    }
    if #available(iOS 11.0, *) {
        let window = UIApplication.shared.delegate?.window as! UIWindow
        if window.safeAreaInsets.bottom >  CGFloat(0) {
            iphoneXseries = true
        }
    }
    return iphoneXseries
}

let KW = UIScreen.main.bounds.size.width
let KH = UIScreen.main.bounds.size.height
let navigationBarHeight : CGFloat = isIPhoneXseries() ? 88 : 64
let tabBarHeight : CGFloat = isIPhoneXseries() ? 49 + 34 : 49
let statusHeight : CGFloat = isIPhoneXseries() ? 44: 20
let bottomHeight : CGFloat = isIPhoneXseries() ?  34 : 0
let kNavBarBottom :CGFloat = CGFloat(WRNavigationBar.navBarBottom())

 let keyVersion  = "version"
 let keyisForce = "isForce"




func setToken(token:String?){
    UserDefaults.standard.set(token, forKey: "token")
}
func getToken()->String?{
    return UserDefaults.standard.string(forKey: "token")
}

func setIsLogin(isLogin:Bool){
    UserDefaults.standard.set(isLogin, forKey: "isLogin")
}
func isLogin()->Bool{
    return UserDefaults.standard.bool(forKey: "isLogin")
}

func setPhone(phone:String?){
    UserDefaults.standard.set(phone, forKey: "keyPhone")
}
func getPhone()->String?{
    return UserDefaults.standard.string(forKey: "keyPhone")
}

func computeAzimuth(lat1:Double,lon1:Double,lat2:Double,lon2:Double)->Double{
    var result:Double=0.0
    let factor:Double=360000.0
    let ilat1=0.5+lat1*factor
    let ilat2=0.5+lat2*factor
    let ilon1=0.5+lon1*factor
    let ilon2=0.5+lon2*factor
    func toRadians(angdeg:Double)->Double{
        return angdeg/180.0*Double.pi;
    }
    func toDegrees(angrad:Double)->Double{
        return angrad*180/Double.pi
    }
    let lat11=toRadians(angdeg: ilat1)
    let lon11=toRadians(angdeg: ilon1)
    let lat22=toRadians(angdeg: ilat2)
    let lon22=toRadians(angdeg: ilon2)
    if ilat1==ilat2 && ilon2==ilon1{
        return result;
    }else if ilon1==ilon2{
        if ilat1>ilat2{
            result=180.0
        }
    }else{
        let c=acos(sin(lat22)*sin(lat11)+cos(lat22)*cos(lat11)*cos(lon22-lon11))
        let A=asin(cos(lat22)*sin(lon22-lon11)/sin(c))
        result=toDegrees(angrad: A)
        if ilat2>ilat1 && ilon2>ilon1 {
            
        }else if ilat2<ilat1 && ilon2<ilon1 {
            result=180-result
        }else if ilat2<ilat1 && ilon2>ilon1{
            result=180-result
        }else if ilat2>ilat1 && ilon2<ilon1{
            result += 360
        }
    }
    return result
}

