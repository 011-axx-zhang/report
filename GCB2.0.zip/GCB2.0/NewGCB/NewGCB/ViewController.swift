//
//  ViewController.swift
//  NewGCB
//
//  Created by YTKJ on 2019/12/4.
//  Copyright © 2019 YTKJ. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
    }


}

